const float DT = 1.0 / 60;
// Full-double twin of DT for sites that need 1/60 at full precision (frame
// integrators in step() loops accumulate over thousands of frames; the
// float→double promotion of DT diverges from the inline literal at the
// 8th decimal, ~0.04u drift/min). Use DT_D where you'd otherwise type
// `0.0166666666666667` inline.
const double DT_D = 1.0 / 60.0;
// Inverse of the 60u physics-grid cell side (Plane_Physics.cpp).
// Numerically equal to DT_D but conceptually independent: would change if
// the grid resizes; would NOT change if the framerate target moves.
const double INV_PHYSICS_CELL_60 = 1.0 / 60.0;
const float PI = 3.1415926535897932384626433832795;
const int MAX_FACES = 12000;
// INVARIANT: MAX_FACES must stay <= 0x7FFF (32767). Bit 15 of the low 16-bit
// slot of rq_sort_packed[i] carries the is_quad flag; bits 0..14 carry the
// face index. Bumping MAX_FACES above 32767 will collide with the is_quad bit
// and must revisit the packing scheme in submit_* emitters and draw() reader.

// Fixed-point scale used to convert double sort_dist values into the int32
// portion of the packed int64 sort key. 256 (8.8 fixed point) gives ~4mm
// precision and ~8 million metres of range — more than enough for any
// reasonable view distance, while leaving plenty of headroom before int32
// overflow (2.1B / 256 ≈ 8.4M m). See radix_sort_faces for details.
//
// CRITICAL — rq_sort_packed layout assumption (do not silently change):
//   rq_sort_packed[i] = (int64(int(sort_dist * SORT_KEY_SCALE)) << 16)
//                     | int64(local_af | maybe_0x8000)
// The 24-bit sort key sits in bits 16..39, the face index + is_quad flag
// in bits 0..15. This layout is SAFE only because rq_sort_packed is sorted
// by `radix_sort_faces` (this file), which extracts the 24-bit key with
// explicit bit-shift+mask operations and never touches AS's built-in
// array<int64>.sortAsc().
//
// AS's array<int64>.sortAsc() compares only the LOW 32 BITS of each element
// as a signed int32 — the high bits are invisible to the comparator. If
// anyone ever swaps `radix_sort_faces` for `rq_sort_packed.sortAsc()`, the
// sort will silently misorder elements whenever the low-32 sign disagrees
// with the full-64 ordering. This was the runway-shadow bug fixed
// 2026-04-25 in the chunk sort (Plane_Shadow.cpp ~6779). See memory file
// `feedback_as_int64_sort_quirk.md` for the rule and `project_shadow_phase
// _b_investigation.md` for the case study.
//
// If you EVER need to relayer rq_sort_packed (e.g. widening the key range
// past 24 bits), you must either (a) update radix_sort_faces in lockstep
// or (b) move the key into the low 32 bits and use sortAsc().
const double SORT_KEY_SCALE = 256.0;

double math_fraction(double val) { return val - floor(val); }

class Vec3 {
  double x, y, z;

  Vec3() {
    x = 0;
    y = 0;
    z = 0;
  }
  Vec3(double x, double y, double z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }
  Vec3(const Vec3 &in other) {
    x = other.x;
    y = other.y;
    z = other.z;
  }

  void set(double x, double y, double z) {
    this.x = x;
    this.y = y;
    this.z = z;
  }

  double magnitude() const { return sqrt(x * x + y * y + z * z); }
  double sqr_magnitude() const { return x * x + y * y + z * z; }

  Vec3 normalize() const {
    double mag = magnitude();
    if (mag > 1e-9) {
      double inv = 1.0 / mag;
      return Vec3(x * inv, y * inv, z * inv);
    }
    return Vec3(0, 0, 0);
  }

  Vec3 opAdd(const Vec3 &in other) const {
    return Vec3(x + other.x, y + other.y, z + other.z);
  }
  Vec3 opSub(const Vec3 &in other) const {
    return Vec3(x - other.x, y - other.y, z - other.z);
  }
  Vec3 opMul(double scalar) const {
    return Vec3(x * scalar, y * scalar, z * scalar);
  }
  Vec3 &opAssign(const Vec3 &in other) {
    x = other.x;
    y = other.y;
    z = other.z;
    return this;
  }

  void add_in_place(const Vec3 &in other) {
    x += other.x;
    y += other.y;
    z += other.z;
  }
  void scale_in_place(double scalar) {
    x *= scalar;
    y *= scalar;
    z *= scalar;
  }
  void normalize_in_place() {
    double mag = magnitude();
    if (mag > 1e-9) {
      double inv = 1.0 / mag;
      x *= inv;
      y *= inv;
      z *= inv;
    } else {
      x = 0;
      y = 0;
      z = 0;
    }
  }
};


// Fast bitwise pseudo-random hash using purely integer inputs
double fast_hash(uint i) {
  i = i * 3266489917;
  i = (i ^ 61) ^ (i >> 16);
  i = i + (i << 3);
  i = i ^ (i >> 4);
  i = i * 0x27d4eb2d;
  i = i ^ (i >> 15);
  // Mul instead of div.
  return double(i & 0x0FFFFFFF) * 3.725290298461914e-9;
}

// Keep a wrapper for the legacy float-based hashes (used in get_vertex_pos)
double hash(double n) { return fast_hash(uint(int(n * 1024.0))); }

double noise3d(double x, double y, double z) {
  int ix = int(floor(x)), iy = int(floor(y)), iz = int(floor(z));
  double fx = x - ix, fy = y - iy, fz = z - iz;

  // Smoothstep
  double u = fx * fx * (3.0 - 2.0 * fx);
  double v = fy * fy * (3.0 - 2.0 * fy);
  double w = fz * fz * (3.0 - 2.0 * fz);

  uint n0 = (uint(ix) + uint(iy) * 157 + uint(iz) * 113) * 1024;
  uint n1 = n0 + 1024, n2 = n0 + 160768, n3 = n0 + 161792;
  uint n4 = n0 + 115712, n5 = n0 + 116736, n6 = n0 + 276480, n7 = n0 + 277504;

  // Inline the hash math for all 8 points; AS straight-line math is much
  // faster than function calls.
  n0 = n0 * 3266489917;
  n0 = (n0 ^ 61) ^ (n0 >> 16);
  n0 = n0 + (n0 << 3);
  n0 = n0 ^ (n0 >> 4);
  n0 = n0 * 0x27d4eb2d;
  n0 = n0 ^ (n0 >> 15);
  n1 = n1 * 3266489917;
  n1 = (n1 ^ 61) ^ (n1 >> 16);
  n1 = n1 + (n1 << 3);
  n1 = n1 ^ (n1 >> 4);
  n1 = n1 * 0x27d4eb2d;
  n1 = n1 ^ (n1 >> 15);
  n2 = n2 * 3266489917;
  n2 = (n2 ^ 61) ^ (n2 >> 16);
  n2 = n2 + (n2 << 3);
  n2 = n2 ^ (n2 >> 4);
  n2 = n2 * 0x27d4eb2d;
  n2 = n2 ^ (n2 >> 15);
  n3 = n3 * 3266489917;
  n3 = (n3 ^ 61) ^ (n3 >> 16);
  n3 = n3 + (n3 << 3);
  n3 = n3 ^ (n3 >> 4);
  n3 = n3 * 0x27d4eb2d;
  n3 = n3 ^ (n3 >> 15);
  n4 = n4 * 3266489917;
  n4 = (n4 ^ 61) ^ (n4 >> 16);
  n4 = n4 + (n4 << 3);
  n4 = n4 ^ (n4 >> 4);
  n4 = n4 * 0x27d4eb2d;
  n4 = n4 ^ (n4 >> 15);
  n5 = n5 * 3266489917;
  n5 = (n5 ^ 61) ^ (n5 >> 16);
  n5 = n5 + (n5 << 3);
  n5 = n5 ^ (n5 >> 4);
  n5 = n5 * 0x27d4eb2d;
  n5 = n5 ^ (n5 >> 15);
  n6 = n6 * 3266489917;
  n6 = (n6 ^ 61) ^ (n6 >> 16);
  n6 = n6 + (n6 << 3);
  n6 = n6 ^ (n6 >> 4);
  n6 = n6 * 0x27d4eb2d;
  n6 = n6 ^ (n6 >> 15);
  n7 = n7 * 3266489917;
  n7 = (n7 ^ 61) ^ (n7 >> 16);
  n7 = n7 + (n7 << 3);
  n7 = n7 ^ (n7 >> 4);
  n7 = n7 * 0x27d4eb2d;
  n7 = n7 ^ (n7 >> 15);

  double mult = 3.725290298461914e-9; // 1.0 / 0x0FFFFFFF
  double h000 = double(n0 & 0x0FFFFFFF) * mult;
  double h100 = double(n1 & 0x0FFFFFFF) * mult;
  double h010 = double(n2 & 0x0FFFFFFF) * mult;
  double h110 = double(n3 & 0x0FFFFFFF) * mult;
  double h001 = double(n4 & 0x0FFFFFFF) * mult;
  double h101 = double(n5 & 0x0FFFFFFF) * mult;
  double h011 = double(n6 & 0x0FFFFFFF) * mult;
  double h111 = double(n7 & 0x0FFFFFFF) * mult;

  double x00 = h000 + (h100 - h000) * u;
  double x10 = h010 + (h110 - h010) * u;
  double x01 = h001 + (h101 - h001) * u;
  double x11 = h011 + (h111 - h011) * u;

  double y0 = x00 + (x10 - x00) * v;
  double y1 = x01 + (x11 - x01) * v;

  return (y0 + (y1 - y0) * w) * 2.0 - 1.0;
}


Vec3 lerp(const Vec3 &in v1, const Vec3 &in v2, double t) {
  return v1.opMul(1.0 - t).opAdd(v2.opMul(t));
}

class Quaternion {
  double w, x, y, z;

  // Extracts Forward, Right, and Up vectors with minimal math.
  void get_basis(double &out fx, double &out fy, double &out fz, double &out rx,
                 double &out ry, double &out rz, double &out ux, double &out uy,
                 double &out uz) const {
    double x2 = x + x, y2 = y + y, z2 = z + z;
    double xx = x * x2, xy = x * y2, xz = x * z2;
    double yy = y * y2, yz = y * z2, zz = z * z2;
    double wx = w * x2, wy = w * y2, wz = w * z2;

    fx = 1.0 - (yy + zz);
    fy = xy + wz;
    fz = xz - wy;

    rx = xy - wz;
    ry = 1.0 - (xx + zz);
    rz = yz + wx;

    ux = xz + wy;
    uy = yz - wx;
    uz = 1.0 - (xx + yy);
  }

  // Forward vector only — fast path.
  void get_forward(double &out fx, double &out fy, double &out fz) const {
    double y2 = y + y, z2 = z + z;
    fx = 1.0 - (y * y2 + z * z2);
    fy = x * y2 + w * z2;
    fz = x * z2 - w * y2;
  }

  Quaternion(double w = 1, double x = 0, double y = 0, double z = 0) {
    this.w = w;
    this.x = x;
    this.y = y;
    this.z = z;
  }

  Quaternion &opAssign(const Quaternion &in other) {
    w = other.w;
    x = other.x;
    y = other.y;
    z = other.z;
    return this;
  }

  Quaternion opMul(const Quaternion &in r) const {
    return Quaternion(w * r.w - x * r.x - y * r.y - z * r.z,
                      w * r.x + x * r.w + y * r.z - z * r.y,
                      w * r.y - x * r.z + y * r.w + z * r.x,
                      w * r.z + x * r.y - y * r.x + z * r.w);
  }

  Quaternion opAdd(const Quaternion &in r) const {
    return Quaternion(w + r.w, x + r.x, y + r.y, z + r.z);
  }
  Quaternion opMul(double s) const {
    return Quaternion(w * s, x * s, y * s, z * s);
  }
  Quaternion opNeg() const { return Quaternion(-w, -x, -y, -z); }
  Quaternion inverse() const { return Quaternion(w, -x, -y, -z); }
  void normalize() {
    double mag = sqrt(w * w + x * x + y * y + z * z);
    if (mag > 1e-9) {
      double inv = 1.0 / mag;
      w *= inv;
      x *= inv;
      y *= inv;
      z *= inv;
    }
  }

  Vec3 rotate(const Vec3 &in v) const {
    Quaternion p(0, v.x, v.y, v.z);
    Quaternion result = this.opMul(p).opMul(this.inverse());
    return Vec3(result.x, result.y, result.z);
  }

  void rotate_scalar(double vx, double vy, double vz, double &out rx,
                     double &out ry, double &out rz) const {
    double qwx = w * vx, qwy = w * vy, qwz = w * vz;
    double qxx = x * vx, qxy = x * vy, qxz = x * vz;
    double qyx = y * vx, qyy = y * vy, qyz = y * vz;
    double qzx = z * vx, qzy = z * vy, qzz = z * vz;
    double ix = qwx + qyz - qzy;
    double iy = qwy + qzx - qxz;
    double iz = qwz + qxy - qyx;
    double iw = -qxx - qyy - qzz;
    rx = ix * w + iw * -x + iy * -z - iz * -y;
    ry = iy * w + iw * -y + iz * -x - ix * -z;
    rz = iz * w + iw * -z + ix * -y - iy * -x;
  }

  // Avoids the `inverse()` temp Quaternion allocation. Derived from
  // rotate_scalar by substituting (x,y,z) → (-x,-y,-z).
  void inverse_rotate_scalar(double vx, double vy, double vz, double &out rx,
                             double &out ry, double &out rz) const {
    double qwx = w * vx, qwy = w * vy, qwz = w * vz;
    double qxx = x * vx, qxy = x * vy, qxz = x * vz;
    double qyx = y * vx, qyy = y * vy, qyz = y * vz;
    double qzx = z * vx, qzy = z * vy, qzz = z * vz;
    double ix = qwx - qyz + qzy;
    double iy = qwy - qzx + qxz;
    double iz = qwz - qxy + qyx;
    double iw = qxx + qyy + qzz;
    rx = ix * w + iw * x + iy * z - iz * y;
    ry = iy * w + iw * y + iz * x - ix * z;
    rz = iz * w + iw * z + ix * y - iy * x;
  }
};

double dot(const Vec3 &in v1, const Vec3 &in v2) {
  return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}
Vec3 cross(const Vec3 &in a, const Vec3 &in b) {
  return Vec3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z,
              a.x * b.y - a.y * b.x);
}
double dot(const Quaternion &in q1, const Quaternion &in q2) {
  return q1.x * q2.x + q1.y * q2.y + q1.z * q2.z + q1.w * q2.w;
}

Quaternion slerp(Quaternion q1, Quaternion q2, double t) {
  double cos_omega = dot(q1, q2);
  if (cos_omega < 0.0) {
    q2 = q2.opNeg();
    cos_omega = -cos_omega;
  }
  if (cos_omega > 0.9995) {
    Quaternion result = q1.opMul(1.0 - t).opAdd(q2.opMul(t));
    result.normalize();
    return result;
  }
  double omega = acos(cos_omega), sin_omega = sin(omega);
  double inv_sin_omega = 1.0 / sin_omega;
  double scale1 = sin((1.0 - t) * omega) * inv_sin_omega,
         scale2 = sin(t * omega) * inv_sin_omega;
  return q1.opMul(scale1).opAdd(q2.opMul(scale2));
}

void closest_point_on_segment(double px, double py, double pz, double ax, double ay, double az, double bx, double by, double bz, double &out cx, double &out cy, double &out cz) {
  double ab_x = bx - ax, ab_y = by - ay, ab_z = bz - az;
  double len_sq = ab_x * ab_x + ab_y * ab_y + ab_z * ab_z;
  if (len_sq < 1e-9) {
    cx = ax;
    cy = ay;
    cz = az;
    return;
  }
  double t = ((px - ax) * ab_x + (py - ay) * ab_y + (pz - az) * ab_z) / len_sq;
  if (t < 0.0) {
    cx = ax;
    cy = ay;
    cz = az;
    return;
  }
  if (t > 1.0) {
    cx = bx;
    cy = by;
    cz = bz;
    return;
  }
  cx = ax + ab_x * t;
  cy = ay + ab_y * t;
  cz = az + ab_z * t;
}

void closest_point_on_triangle_degenerate(double pt_x, double pt_y, double pt_z,
                                          const Triangle &in tri,
                                          double &out cx, double &out cy,
                                          double &out cz) {
  double c1_x, c1_y, c1_z;
  closest_point_on_segment(pt_x, pt_y, pt_z, tri.p1x, tri.p1y, tri.p1z, tri.p2x,
                           tri.p2y, tri.p2z, c1_x, c1_y, c1_z);
  double c2_x, c2_y, c2_z;
  closest_point_on_segment(pt_x, pt_y, pt_z, tri.p2x, tri.p2y, tri.p2z, tri.p3x,
                           tri.p3y, tri.p3z, c2_x, c2_y, c2_z);
  double c3_x, c3_y, c3_z;
  closest_point_on_segment(pt_x, pt_y, pt_z, tri.p3x, tri.p3y, tri.p3z, tri.p1x,
                           tri.p1y, tri.p1z, c3_x, c3_y, c3_z);
  double d1 = (pt_x - c1_x) * (pt_x - c1_x) + (pt_y - c1_y) * (pt_y - c1_y) +
              (pt_z - c1_z) * (pt_z - c1_z);
  double d2 = (pt_x - c2_x) * (pt_x - c2_x) + (pt_y - c2_y) * (pt_y - c2_y) +
              (pt_z - c2_z) * (pt_z - c2_z);
  double d3 = (pt_x - c3_x) * (pt_x - c3_x) + (pt_y - c3_y) * (pt_y - c3_y) +
              (pt_z - c3_z) * (pt_z - c3_z);
  if (d1 <= d2 && d1 <= d3) {
    cx = c1_x;
    cy = c1_y;
    cz = c1_z;
    return;
  }
  if (d2 <= d1 && d2 <= d3) {
    cx = c2_x;
    cy = c2_y;
    cz = c2_z;
    return;
  }
  cx = c3_x;
  cy = c3_y;
  cz = c3_z;
}

void closest_point_on_triangle_edges(double pt_x, double pt_y, double pt_z,
                                     const Triangle &in tri, double u, double v,
                                     double w, double &out cx, double &out cy,
                                     double &out cz) {
  double best_d = 1e30;
  if (w < 0.0) {
    double t = ((pt_x - tri.p1x) * tri.e12x + (pt_y - tri.p1y) * tri.e12y +
                (pt_z - tri.p1z) * tri.e12z) *
               tri.inv_len_sq12;
    double tx, ty, tz;
    if (t <= 0.0) {
      tx = tri.p1x;
      ty = tri.p1y;
      tz = tri.p1z;
    } else if (t >= 1.0) {
      tx = tri.p2x;
      ty = tri.p2y;
      tz = tri.p2z;
    } else {
      tx = tri.p1x + tri.e12x * t;
      ty = tri.p1y + tri.e12y * t;
      tz = tri.p1z + tri.e12z * t;
    }
    best_d = (pt_x - tx) * (pt_x - tx) + (pt_y - ty) * (pt_y - ty) +
             (pt_z - tz) * (pt_z - tz);
    cx = tx;
    cy = ty;
    cz = tz;
  }
  if (u < 0.0) {
    double t = ((pt_x - tri.p2x) * tri.e23x + (pt_y - tri.p2y) * tri.e23y +
                (pt_z - tri.p2z) * tri.e23z) *
               tri.inv_len_sq23;
    double tx, ty, tz;
    if (t <= 0.0) {
      tx = tri.p2x;
      ty = tri.p2y;
      tz = tri.p2z;
    } else if (t >= 1.0) {
      tx = tri.p3x;
      ty = tri.p3y;
      tz = tri.p3z;
    } else {
      tx = tri.p2x + tri.e23x * t;
      ty = tri.p2y + tri.e23y * t;
      tz = tri.p2z + tri.e23z * t;
    }
    double d = (pt_x - tx) * (pt_x - tx) + (pt_y - ty) * (pt_y - ty) +
               (pt_z - tz) * (pt_z - tz);
    if (d < best_d) {
      best_d = d;
      cx = tx;
      cy = ty;
      cz = tz;
    }
  }
  if (v < 0.0) {
    double t = ((pt_x - tri.p3x) * tri.e31x + (pt_y - tri.p3y) * tri.e31y +
                (pt_z - tri.p3z) * tri.e31z) *
               tri.inv_len_sq31;
    double tx, ty, tz;
    if (t <= 0.0) {
      tx = tri.p3x;
      ty = tri.p3y;
      tz = tri.p3z;
    } else if (t >= 1.0) {
      tx = tri.p1x;
      ty = tri.p1y;
      tz = tri.p1z;
    } else {
      tx = tri.p3x + tri.e31x * t;
      ty = tri.p3y + tri.e31y * t;
      tz = tri.p3z + tri.e31z * t;
    }
    double d = (pt_x - tx) * (pt_x - tx) + (pt_y - ty) * (pt_y - ty) +
               (pt_z - tz) * (pt_z - tz);
    if (d < best_d) {
      cx = tx;
      cy = ty;
      cz = tz;
    }
  }
}

void closest_point_on_triangle_dist(double pt_x, double pt_y, double pt_z,
                                    double dist_to_plane,
                                    const Triangle &in tri, double &out cx,
                                    double &out cy, double &out cz) {
  double proj_x = pt_x - tri.nx * dist_to_plane;
  double proj_y = pt_y - tri.ny * dist_to_plane;
  double proj_z = pt_z - tri.nz * dist_to_plane;

  double v2_x = proj_x - tri.p1x, v2_y = proj_y - tri.p1y,
         v2_z = proj_z - tri.p1z;
  double d20 = v2_x * tri.v0x + v2_y * tri.v0y + v2_z * tri.v0z;
  double d21 = v2_x * tri.v1x + v2_y * tri.v1y + v2_z * tri.v1z;

  if (tri.invDenom != 0.0) {
    double v = (tri.d11 * d20 - tri.d01 * d21) * tri.invDenom;
    double w = (tri.d00 * d21 - tri.d01 * d20) * tri.invDenom;
    double u = 1.0 - v - w;

    if (u >= -1e-4 && v >= -1e-4 && w >= -1e-4) {
      cx = proj_x;
      cy = proj_y;
      cz = proj_z;
      return;
    }
    closest_point_on_triangle_edges(pt_x, pt_y, pt_z, tri, u, v, w, cx, cy, cz);
  } else {
    closest_point_on_triangle_degenerate(pt_x, pt_y, pt_z, tri, cx, cy, cz);
  }
}

void closest_point_on_triangle(double pt_x, double pt_y, double pt_z,
                               const Triangle &in tri, double &out cx,
                               double &out cy, double &out cz) {
  double dist_to_plane =
      pt_x * tri.nx + pt_y * tri.ny + pt_z * tri.nz + tri.plane_d;
  closest_point_on_triangle_dist(pt_x, pt_y, pt_z, dist_to_plane, tri, cx, cy,
                                 cz);
}
// OPTIMIZATION: 8-bit LSD radix sort on the upper 32 bits of the packed
// sort keys. Replaces the previous median-of-three quicksort. Keys are
// `(int32(sort_dist * SORT_KEY_SCALE) << 16) | (face_idx & 0xFFFF)`; the
// high 48 bits carry the (signed) sort key and the low 16 bits carry the
// face index along for the ride (MAX_FACES < 65536, so the index fits and
// is recovered after sort via `int(keys[i] & 0xFFFF)`).
//
// At active_faces near the cap (several thousand) this is ~2-3x faster
// than the quicksort it replaces: O(n) sequential reads, no compares, no
// recursion stack, no per-element branchy partition. The AngelScript VM
// pipelines the tight count/place loops far better than the partition body.
//
// Algorithm: bias the signed sort field by +2^20 into [0, 2^24) (small
// enough to stay in 24 bits, large enough to absorb the mildly-negative
// keys produced by the z_bias-offset submission paths), then invert
// (0xFFFFFF - x) so ascending unsigned LSD radix produces the DESCENDING
// painter's order. THREE 8-bit passes over bytes 2..4 of the int64
// (bits 16..39). Source/dest alternate between scratch_a and scratch_b;
// final sorted output lands in scratch_b. The upper bits are never read
// post-sort (downstream uses only `keys[i] & 0x7FFF` + bit 15 for
// is_quad), so we skip the per-element unbias writeback entirely and
// stamp out just the low 16 bits.
//
// Caller passes pre-allocated scratch buffers (sized MAX_FACES for the int64
// scratches, 256 for the byte counts) — same hoist-allocation-out-of-the-
// hot-path pattern the old quicksort used for its work stack.
void radix_sort_faces(array<int64> &inout keys,
                      array<int64> &inout scratch_a,
                      array<int64> &inout scratch_b,
                      array<int> &inout counts, int n) {
  // OPTIMIZATION: 3-pass 8-bit LSD radix over a 24-bit biased key (was 4
  // passes over a 32-bit key) + skip the unbias writeback pass.
  //
  // Keys are packed:  (sort_dist_int << 16) | (face_idx | maybe_0x8000).
  // sort_dist_int = int(sort_dist * SORT_KEY_SCALE). sort_dist is mostly
  // positive (up to ~fog_end * 256 ≈ 1.15M) but CAN be mildly negative
  // for the z_bias-offset submissions (smokes/trails/biased quads subtract
  // a z_bias up to 500, reaching ~-128K). A large 2^31 bias (as used
  // previously) would force a 32-bit key → 4 passes. A small 2^20 bias
  // keeps every biased key in [~0.9M, ~2.2M], which fits comfortably in
  // 24 bits → 3 passes is enough.
  //
  // Downstream only reads keys[i] & 0x7FFF (face idx) and keys[i] & 0x8000
  // (is_quad flag); the sort-key field is never read post-sort. So after
  // the last pass we write back only the low 16 bits of each sorted entry
  // — skipping the full per-element unbias/decode writeback entirely.
  const int64 IDX_MASK = int64(0xFFFF);
  const int64 BIAS     = int64(0x100000);      // 2^20 = 1,048,576
  const int64 MASK_24  = int64(0xFFFFFF);

  // OPTIMIZATION: Fuse the bias-preprocess with the first counting pass.
  // The standalone preprocess loop read keys[] and wrote scratch_a[] once,
  // then the pass-0 counting loop re-read scratch_a[] to populate counts[].
  // By counting bucket-0 (bits 16..23) inside the bias write, we drop one
  // full n-element pass over scratch_a. For n=MAX_FACES=8000 that's 8000
  // array reads eliminated per frame from the painter's sort.
  //
  // Bias: signed sort field into [0, 2^24); invert within that 24-bit field
  // so an ascending LSD radix produces descending (back-to-front / painter's)
  // order. Source → scratch_a.
  //
  // Parity: pass 0 a→b, pass 1 b→a, pass 2 a→b → final in scratch_b.
  for (int i = 0; i < 256; i++)
    counts[i] = 0;
  for (int i = 0; i < n; i++) {
    int64 k = keys[i];
    int64 biased = ((k >> 16) + BIAS) & MASK_24;   // arithmetic shift preserves sign
    int64 inv    = MASK_24 - biased;                // invert for descending
    int64 v      = (inv << 16) | (k & IDX_MASK);
    scratch_a[i] = v;
    counts[int((v >> 16) & 0xFF)]++;
  }

  // Pass-0 exclusive prefix sum + distribution (scratch_a → scratch_b).
  {
    int sum = 0;
    for (int i = 0; i < 256; i++) {
      int c = counts[i];
      counts[i] = sum;
      sum += c;
    }
    for (int i = 0; i < n; i++) {
      int64 v = scratch_a[i];
      int b = int((v >> 16) & 0xFF);
      scratch_b[counts[b]] = v;
      counts[b]++;
    }
  }

  // Passes 1 and 2 — same split-by-source pattern as before. Pass 1 reads
  // scratch_b and writes scratch_a; pass 2 reads scratch_a and writes
  // scratch_b. Shift starts at byte 3 (bits 24..31) since pass 0 already
  // handled byte 2 (bits 16..23).
  int shift = 24;
  for (int pass = 1; pass < 3; pass++) {
    for (int i = 0; i < 256; i++)
      counts[i] = 0;

    bool from_a = (pass & 1) == 0;

    // Counting pass — split by source so the inner loop stays tight.
    if (from_a) {
      for (int i = 0; i < n; i++)
        counts[int((scratch_a[i] >> shift) & 0xFF)]++;
    } else {
      for (int i = 0; i < n; i++)
        counts[int((scratch_b[i] >> shift) & 0xFF)]++;
    }

    // Exclusive prefix sum.
    int sum = 0;
    for (int i = 0; i < 256; i++) {
      int c = counts[i];
      counts[i] = sum;
      sum += c;
    }

    // Distribution pass — same split.
    if (from_a) {
      for (int i = 0; i < n; i++) {
        int64 v = scratch_a[i];
        int b = int((v >> shift) & 0xFF);
        scratch_b[counts[b]] = v;
        counts[b]++;
      }
    } else {
      for (int i = 0; i < n; i++) {
        int64 v = scratch_b[i];
        int b = int((v >> shift) & 0xFF);
        scratch_a[counts[b]] = v;
        counts[b]++;
      }
    }
    shift += 8;
  }

  // Final sorted buffer is scratch_b. Downstream only reads the low 16
  // bits, so stamp out just those — no unbias arithmetic per element.
  for (int i = 0; i < n; i++)
    keys[i] = scratch_b[i] & IDX_MASK;
}

void get_airfoil_profile(double x, double y, double c, double t,
                         array<Vec3> @p) {
  double z_base = 5.0;
  p[0].set(x + c * 0.4, y, z_base);
  p[1].set(x + c * 0.1, y, z_base + t * 0.5);
  p[2].set(x + c * 0.025, y, z_base + t * 0.425);
  p[3].set(x - c * 0.005, y, z_base + t * 0.35);
  p[4].set(x - c * 0.5, y, z_base + t * 0.14);
  p[5].set(x - c * 0.5, y, z_base - t * 0.14);
  p[6].set(x - c * 0.005, y, z_base - t * 0.3);
  p[7].set(x + c * 0.175, y, z_base - t * 0.15);
}

void project_fast(double px, double py, double pz, const Vec3 &in cam_pos,
                  const Vec3 &in cam_fwd, const Vec3 &in cam_left,
                  const Vec3 &in cam_up, double fov, float &out screen_x,
                  float &out screen_y, float &out screen_scale) {
  double dx = px - cam_pos.x;
  double dy = py - cam_pos.y;
  double dz = pz - cam_pos.z;

  double rx = dx * cam_fwd.x + dy * cam_fwd.y + dz * cam_fwd.z;
  if (rx < 0.1) {
    screen_scale = -1;
    return;
  }

  double scale = fov / rx;
  screen_scale = float(scale);
  screen_x =
      float(-(dx * cam_left.x + dy * cam_left.y + dz * cam_left.z) * scale);
  screen_y = float((dx * cam_up.x + dy * cam_up.y + dz * cam_up.z) * scale);
}

void project(double px, double py, double pz,
             const Quaternion &in view_orientation, const Vec3 &in camera_pos,
             double fov, float &out screen_x, float &out screen_y,
             float &out screen_scale) {
  double dx = px - camera_pos.x;
  double dy = py - camera_pos.y;
  double dz = pz - camera_pos.z;
  double inv_w = view_orientation.w, inv_x = -view_orientation.x,
         inv_y = -view_orientation.y, inv_z = -view_orientation.z;
  double qwx = inv_w * dx, qwy = inv_w * dy, qwz = inv_w * dz;
  double qxx = inv_x * dx, qxy = inv_x * dy, qxz = inv_x * dz;
  double qyx = inv_y * dx, qyy = inv_y * dy, qyz = inv_y * dz;
  double qzx = inv_z * dx, qzy = inv_z * dy, qzz = inv_z * dz;
  double ix = qwx + qyz - qzy;
  double iy = qwy + qzx - qxz;
  double iz = qwz + qxy - qyx;
  double iw = -qxx - qyy - qzz;
  double rx = ix * inv_w + iw * -inv_x + iy * -inv_z - iz * -inv_y;
  double ry = iy * inv_w + iw * -inv_y + iz * -inv_x - ix * -inv_z;
  double rz = iz * inv_w + iw * -inv_z + ix * -inv_y - iy * -inv_x;
  if (rx < 0.1) {
    screen_scale = -1;
    return;
  }
  screen_scale = float(fov / rx);
  screen_x = float(-ry * screen_scale);
  screen_y = float(rz * screen_scale);
}

uint multiply_color(uint col, double factor) {
  uint a = (col >> 24) & 0xFF;
  uint r = uint(double((col >> 16) & 0xFF) * factor);
  uint g = uint(double((col >> 8) & 0xFF) * factor);
  uint b = uint(double(col & 0xFF) * factor);
  return (a << 24) | (r << 16) | (g << 8) | b;
}

uint lerp_color(uint c1, uint c2, double t) {
  if (t <= 0)
    return c1;
  if (t >= 1)
    return c2;
  int a1 = (c1 >> 24) & 0xFF, r1 = (c1 >> 16) & 0xFF, g1 = (c1 >> 8) & 0xFF,
      b1 = c1 & 0xFF;
  int a2 = (c2 >> 24) & 0xFF, r2 = (c2 >> 16) & 0xFF, g2 = (c2 >> 8) & 0xFF,
      b2 = c2 & 0xFF;
  uint a = uint(a1 + (a2 - a1) * t);
  uint r = uint(r1 + (r2 - r1) * t);
  uint g = uint(g1 + (g2 - g1) * t);
  uint b = uint(b1 + (b2 - b1) * t);
  return (a << 24) | (r << 16) | (g << 8) | b;
}


void rotate_point_around_hinge(const Vec3 &in pt, const Vec3 &in h,
                               const Quaternion &in q, Vec3 &inout out_v) {
  double px = pt.x - h.x, py = pt.y - h.y, pz = pt.z - h.z;
  double qwx = q.w * px, qwy = q.w * py, qwz = q.w * pz;
  double qxx = q.x * px, qxy = q.x * py, qxz = q.x * pz;
  double qyx = q.y * px, qyy = q.y * py, qyz = q.y * pz;
  double qzx = q.z * px, qzy = q.z * py, qzz = q.z * pz;
  double ix = qwx + qyz - qzy;
  double iy = qwy + qzx - qxz;
  double iz = qwz + qxy - qyx;
  double iw = -qxx - qyy - qzz;
  double rx = ix * q.w + iw * -q.x + iy * -q.z - iz * -q.y;
  double ry = iy * q.w + iw * -q.y + iz * -q.x - ix * -q.z;
  double rz = iz * q.w + iw * -q.z + ix * -q.y - iy * -q.x;
  out_v.x = h.x + rx;
  out_v.y = h.y + ry;
  out_v.z = h.z + rz;
}

void lerp_in_place(const Vec3 &in v1, const Vec3 &in v2, double t,
                   Vec3 &inout out_v) {
  out_v.x = v1.x * (1.0 - t) + v2.x * t;
  out_v.y = v1.y * (1.0 - t) + v2.y * t;
  out_v.z = v1.z * (1.0 - t) + v2.z * t;
}

void slerp_in_place(const Quaternion &in q1, Quaternion q2, double t,
                    Quaternion &inout out_q) {
  double cos_omega = dot(q1, q2);
  if (cos_omega < 0.0) {
    q2.w = -q2.w;
    q2.x = -q2.x;
    q2.y = -q2.y;
    q2.z = -q2.z;
    cos_omega = -cos_omega;
  }
  if (cos_omega > 0.9995) {
    out_q.w = q1.w * (1.0 - t) + q2.w * t;
    out_q.x = q1.x * (1.0 - t) + q2.x * t;
    out_q.y = q1.y * (1.0 - t) + q2.y * t;
    out_q.z = q1.z * (1.0 - t) + q2.z * t;
    out_q.normalize();
    return;
  }
  double omega = acos(cos_omega), sin_omega = sin(omega);
  double inv_sin_omega = 1.0 / sin_omega;
  double scale1 = sin((1.0 - t) * omega) * inv_sin_omega,
         scale2 = sin(t * omega) * inv_sin_omega;
  out_q.w = q1.w * scale1 + q2.w * scale2;
  out_q.x = q1.x * scale1 + q2.x * scale2;
  out_q.y = q1.y * scale1 + q2.y * scale2;
  out_q.z = q1.z * scale1 + q2.z * scale2;
}