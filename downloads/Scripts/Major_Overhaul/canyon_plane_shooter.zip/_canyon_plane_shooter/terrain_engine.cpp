const double CELL_SIZE = 400.0;
const int CHUNK_CELLS = 3; // 3x3x3 cells per chunk -> 1200x1200x1200 size

// Pre-warm capacity for Chunk.triangles. See
// project_add_tri_prewarm_measurement_2026_04_26.
const int CHUNK_TRIANGLES_PREWARM = 128;

// Void-island layer: extra procedural-island pass in get_density() that
// fires only in deep voids (independent noise offsets — existing islands
// unaffected). VI_THRESH=1.5 disables the layer (combined-noise max≈1.5).
const double VI_THRESH   = 0.7;  // lower = more/bigger islands; useful 0.4-1.0
const double VI_SIZE     = 8.0;  // density boost when island fires
const double VI_MAX_DENS = -1.8; // only fire where density < this

// Prism evaluation tunables. AS rejects class-scope const
// (feedback_as_no_const_class_props) so these live at file scope.
// RADIUS^2 must equal RADIUS_SQ — grep on rename. UI defaults thread
// through resolve_pending_prisms parameters.

// Settle scan radius. Every chunk within this radius of spawn_pos must
// be absent or is_generated before Gate 3 evaluates. Bump to 500u if
// pr_tri_clear ever exceeds ~350u.
const double PRISM_SETTLE_RADIUS = 400.0;

// Gate 2 predictive density-probe radius (14 samples around spawn_pos).
const double PRISM_DENSITY_PROBE_RADIUS = 300.0;
// Gate 3 broadphase: chunk-center radius for triangle narrowphase.
// Fixed upper bound enclosing pr_tri_clear sphere at loosest UI tuning.
const double PRISM_CHUNK_COLLISION_RADIUS    = 3500.0;
const double PRISM_CHUNK_COLLISION_RADIUS_SQ = 12250000.0; // 3500^2

// Stratified super-cell axis size. Every 3x3x3 chunk group elects top K
// (=prism_per_super_cell) chunks as candidates. Replaced prior
// independent-Bernoulli hash gate (produced void-and-cluster patterns).
const int PRISM_SUPER_CELL_N = 3;

// Hardcoded guide prism near fog_end along runway forward axis. Inserted
// before the chunk loop so Gate 4 rejects close stratified candidates.
const double PRISM_GUIDE_X = 4200.0;
const double PRISM_GUIDE_Y =  200.0;
const double PRISM_GUIDE_Z = 1000.0;

// Forward-view exclusion corridor (AABB) at takeoff. Stratified
// candidates inside this box drop so only the guide prism is visible.
const double PRISM_CORRIDOR_X_MIN = 2400.0;
const double PRISM_CORRIDOR_X_MAX = 4200.0;
const double PRISM_CORRIDOR_Y_MIN = -400.0;
const double PRISM_CORRIDOR_Y_MAX =  800.0;
const double PRISM_CORRIDOR_Z_MIN = -200.0;
const double PRISM_CORRIDOR_Z_MAX = 1500.0;

double get_density(double wx, double wy, double wz) {
  double density = 0.2;

  double dwx = (wx - 800.0) * 0.6666666666666666;
  double dist_sq = dwx * dwx + wy * wy + wz * wz;
  double dist_from_center;

  if (dist_sq < 25000000.0) {
    dist_from_center = sqrt(dist_sq);
  } else {
    dist_from_center = 5000.0;
  }

  double central_cave = 4000.0 - dist_from_center;
  if (central_cave > 0)
    density -= (central_cave * 0.0006666666666666666);

  if (wz < -15000.0)
    density += (-15000.0 - wz) * 0.002;
  if (wz > 15000.0)
    density += (wz - 15000.0) * 0.002;

  double island_threshold = 0.8;
  if (dist_from_center < 5000.0) {
    island_threshold = 0.2 + (0.6 * (dist_from_center * 0.0002));
  }

  // Combine repeated threshold components once.
  double max_island_add = (1.5 - island_threshold) * 8.0;
  // Void-island upper bound; (1.5 - 1.5)=0 disables the layer.
  double vi_max_add = (1.5 - VI_THRESH) * VI_SIZE;
  if (vi_max_add < 0.0) vi_max_add = 0.0;
  double early_exit_add = max_island_add + vi_max_add + 0.2;

  if (density + 1.5 + early_exit_add < 0.0)
    return -2.0;
  if (density > 5.2)
    return 2.0;

  density += noise3d(wx * 0.0004, wy * 0.0004, wz * 0.0004) * 1.5;

  if (density + early_exit_add < 0.0)
    return -2.0;
  if (density > 3.7)
    return 2.0;

  if (density > -4.0 && density < 4.0) {
    // Ternary instead of abs() avoids AS function call.
    double cn = noise3d(wx * 0.0008 + 120.0, wy * 0.0008 - 450.0, wz * 0.0008 + 800.0);
    double cave_noise = (cn < 0) ? -cn : cn;
    double cave_carve = 0.25 - cave_noise;
    if (cave_carve > 0)
      density -= cave_carve * 8.0;

    if (density + early_exit_add < 0.0)
      return -2.0;
    if (density > 1.7)
      return 2.0;

    if (density > -2.0) {
      double tn = noise3d(wx * 0.0015 - 500.0, wy * 0.0015 + 200.0, wz * 0.0015);
      double tunnel_noise = (tn < 0) ? -tn : tn;
      double tunnel_carve = 0.15 - tunnel_noise;
      if (tunnel_carve > 0)
        density -= tunnel_carve * 10.0;
    }
  }

  if (density + early_exit_add < 0.0)
    return -2.0;
  if (density > 0.2)
    return 2.0;

  if (density + max_island_add > -0.2) {
    double island_noise =
        noise3d(wx * 0.0012 + 50.0, wy * 0.0012 - 30.0, wz * 0.0012 + 100.0);
    if (island_noise > island_threshold - 0.5) {
      double island_freq2 =
          noise3d(wx * 0.003 - 20.0, wy * 0.003 + 80.0, wz * 0.003 - 40.0) *
          0.5;
      double combined_island = island_noise + island_freq2;
      if (combined_island > island_threshold) {
        density += (combined_island - island_threshold) * 8.0;
      }
    }
  }

  // Void-island layer: mirrors the islands block above with independent
  // noise offsets, gated to already-empty space. VI_THRESH<1.5 makes
  // this a single compare when disabled.
  if (VI_THRESH < 1.5 && density < VI_MAX_DENS) {
    double vi_n =
        noise3d(wx * 0.0012 + 700.0, wy * 0.0012 - 400.0, wz * 0.0012 + 200.0);
    if (vi_n > VI_THRESH - 0.5) {
      double vi_n2 =
          noise3d(wx * 0.003 - 80.0, wy * 0.003 + 60.0, wz * 0.003 - 130.0) *
          0.5;
      double vi_combined = vi_n + vi_n2;
      if (vi_combined > VI_THRESH) {
        density += (vi_combined - VI_THRESH) * VI_SIZE;
      }
    }
  }

  if (density < -0.2)
    return density;
  if (density > 0.2)
    return density;

  density += noise3d(wx * 0.003, wy * 0.003, wz * 0.003) * 0.2;
  return density;
}
// Defines the procedural terrain volume.
bool is_solid(int gx, int gy, int gz) {
  // Spawn runway safe zone (flat ground, empty sky).
  if (gx >= -4 && gx <= 5 && gy >= -1 && gy <= 1) {
    if (gz < 0)
      return true;
    if (gz >= 0 && gz <= 5)
      return false;
  }

  return get_density(gx * CELL_SIZE, gy * CELL_SIZE, gz * CELL_SIZE) > 0.0;
}


void get_vertex_pos_flat(int gx, int gy, int gz, double wx, double wy,
                         double wz, double &out out_vx, double &out out_vy,
                         double &out out_vz) {
  double dx = 0.0;
  if (gx < -5)
    dx = -5 - gx;
  else if (gx > 6)
    dx = gx - 6;
  double dy = 0.0;
  if (gy < -2)
    dy = -2 - gy;
  else if (gy > 2)
    dy = gy - 2;
  double dz = 0.0;
  if (gz < -1)
    dz = -1 - gz;
  else if (gz > 6)
    dz = gz - 6;

  double box_dist_sq = dx * dx + dy * dy + dz * dz;
  double warp_mult = 1.0;
  if (box_dist_sq < 16.0) {
    double box_dist = sqrt(box_dist_sq);
    warp_mult = (box_dist * 0.25);
    warp_mult = warp_mult * warp_mult * (3.0 - 2.0 * warp_mult);
  }
  if (warp_mult < 0.001) {
    out_vx = wx;
    out_vy = wy;
    out_vz = wz;
    return;
  }
  double s1 = 0.0004;
  double macro_amp = 800.0 * warp_mult;
  double warp_x = noise3d(wx * s1, wy * s1, wz * s1) * macro_amp;
  double warp_y =
      noise3d(wx * s1 + 43.2, wy * s1 + 12.1, wz * s1 + 98.4) * macro_amp;
  double warp_z =
      noise3d(wx * s1 + 11.5, wy * s1 + 77.7, wz * s1 + 33.3) * macro_amp;

  double s2 = 0.0015;
  double mid_amp = 150.0 * warp_mult;
  warp_x += noise3d(wx * s2 + 22.2, wy * s2 + 33.3, wz * s2 + 44.4) * mid_amp;
  warp_y += noise3d(wx * s2 + 55.5, wy * s2 + 66.6, wz * s2 + 77.7) * mid_amp;
  warp_z += noise3d(wx * s2 + 88.8, wy * s2 + 99.9, wz * s2 + 11.1) * mid_amp;

  double cell_mult = CELL_SIZE * 0.05 * warp_mult;
  uint hash_x = uint(gx * 151 + gy * 233 + gz * 317);
  uint hash_y = uint(gx * 411 + gy * 193 + gz * 555);
  uint hash_z = uint(gx * 272 + gy * 543 + gz * 189);

  // Manually inline fast_hash to bypass VM call overhead.
  uint hx = hash_x * 3266489917;
  hx = (hx ^ 61) ^ (hx >> 16);
  hx = hx + (hx << 3);
  hx = hx ^ (hx >> 4);
  hx = hx * 0x27d4eb2d;
  hx = hx ^ (hx >> 15);
  double jx =
      (double(hx & 0x0FFFFFFF) * 3.725290298461914e-9 * 2.0 - 1.0) * cell_mult;

  uint hy = hash_y * 3266489917;
  hy = (hy ^ 61) ^ (hy >> 16);
  hy = hy + (hy << 3);
  hy = hy ^ (hy >> 4);
  hy = hy * 0x27d4eb2d;
  hy = hy ^ (hy >> 15);
  double jy =
      (double(hy & 0x0FFFFFFF) * 3.725290298461914e-9 * 2.0 - 1.0) * cell_mult;

  uint hz = hash_z * 3266489917;
  hz = (hz ^ 61) ^ (hz >> 16);
  hz = hz + (hz << 3);
  hz = hz ^ (hz >> 4);
  hz = hz * 0x27d4eb2d;
  hz = hz ^ (hz >> 15);
  double jz =
      (double(hz & 0x0FFFFFFF) * 3.725290298461914e-9 * 2.0 - 1.0) * cell_mult;

  out_vx = wx + warp_x + jx;
  out_vy = wy + warp_y + jy;
  out_vz = wz + warp_z + jz;
}


class Triangle {
  double p1x, p1y, p1z;
  double p2x, p2y, p2z;
  double p3x, p3y, p3z;
  double nx, ny, nz;
  // |n| components for branch-free AABB-vs-plane radius projection.
  double abs_nx, abs_ny, abs_nz;
  uint color;
  uint col_r, col_g, col_b;
  double min_x, max_x, min_y, max_y, min_z, max_z;
  double c_x, c_y, c_z;
  double bound_radius;
  double plane_d;
  double v0x, v0y, v0z;
  double v1x, v1y, v1z;
  double d00, d01, d11, invDenom;
  uint last_query_id = 0;

  // Pair grouping (populated by emit_face): every face emits 2 tris
  // back-to-back; leader+follower share 4 unique vertex cam-transforms.
  bool pair_leader = false;
  int pair_split_kind = 0;           // 0 = short diag (v1,v3 shared),
                                     // 1 = long  diag (v2,v4 shared).
  double pair_p4x = 0.0;             // 4th unique vertex (in follower,
  double pair_p4y = 0.0;             // not leader). Only meaningful on
  double pair_p4z = 0.0;             // the leader.

  double e12x, e12y, e12z;
  double e23x, e23y, e23z;
  double e31x, e31y, e31z;
  double inv_len_sq12, inv_len_sq23, inv_len_sq31;

  Triangle() {}

  void set(double ax, double ay, double az, double bx, double by, double bz,
           double cx, double cy, double cz, uint col = 0xFF55aa55) {
    p1x = ax;
    p1y = ay;
    p1z = az;
    p2x = bx;
    p2y = by;
    p2z = bz;
    p3x = cx;
    p3y = cy;
    p3z = cz;
    color = col;

    v1x = p2x - p1x;
    v1y = p2y - p1y;
    v1z = p2z - p1z;
    v0x = p3x - p1x;
    v0y = p3y - p1y;
    v0z = p3z - p1z;

    double c_x_norm = v1y * v0z - v1z * v0y;
    double c_y_norm = v1z * v0x - v1x * v0z;
    double c_z_norm = v1x * v0y - v1y * v0x;
    double nlen =
        sqrt(c_x_norm * c_x_norm + c_y_norm * c_y_norm + c_z_norm * c_z_norm);
    if (nlen > 1e-9) {
      double inv_nlen = 1.0 / nlen;
      nx = c_x_norm * inv_nlen;
      ny = c_y_norm * inv_nlen;
      nz = c_z_norm * inv_nlen;
    } else {
      nx = 0;
      ny = 0;
      nz = 0;
    }

    // |n| components for branch-free bbox tests.
    abs_nx = nx < 0 ? -nx : nx;
    abs_ny = ny < 0 ? -ny : ny;
    abs_nz = nz < 0 ? -nz : nz;

    plane_d = -(nx * p1x + ny * p1y + nz * p1z);
    d00 = v0x * v0x + v0y * v0y + v0z * v0z;
    d01 = v0x * v1x + v0y * v1y + v0z * v1z;
    d11 = v1x * v1x + v1y * v1y + v1z * v1z;
    double denom = d00 * d11 - d01 * d01;
    invDenom = (denom != 0.0) ? 1.0 / denom : 0.0;

    e12x = p2x - p1x;
    e12y = p2y - p1y;
    e12z = p2z - p1z;
    double lsq12 = e12x * e12x + e12y * e12y + e12z * e12z;
    inv_len_sq12 = lsq12 > 1e-9 ? 1.0 / lsq12 : 0.0;

    e23x = p3x - p2x;
    e23y = p3y - p2y;
    e23z = p3z - p2z;
    double lsq23 = e23x * e23x + e23y * e23y + e23z * e23z;
    inv_len_sq23 = lsq23 > 1e-9 ? 1.0 / lsq23 : 0.0;

    e31x = p1x - p3x;
    e31y = p1y - p3y;
    e31z = p1z - p3z;
    double lsq31 = e31x * e31x + e31y * e31y + e31z * e31z;
    inv_len_sq31 = lsq31 > 1e-9 ? 1.0 / lsq31 : 0.0;

    min_x = ax;
    if (bx < min_x)
      min_x = bx;
    if (cx < min_x)
      min_x = cx;
    max_x = ax;
    if (bx > max_x)
      max_x = bx;
    if (cx > max_x)
      max_x = cx;
    min_y = ay;
    if (by < min_y)
      min_y = by;
    if (cy < min_y)
      min_y = cy;
    max_y = ay;
    if (by > max_y)
      max_y = by;
    if (cy > max_y)
      max_y = cy;
    min_z = az;
    if (bz < min_z)
      min_z = bz;
    if (cz < min_z)
      min_z = cz;
    max_z = az;
    if (bz > max_z)
      max_z = bz;
    if (cz > max_z)
      max_z = cz;

    c_x = (ax + bx + cx) * 0.333333333333;
    c_y = (ay + by + cy) * 0.333333333333;
    c_z = (az + bz + cz) * 0.333333333333;

    double d1 = (ax - c_x) * (ax - c_x) + (ay - c_y) * (ay - c_y) +
                (az - c_z) * (az - c_z);
    double d2 = (bx - c_x) * (bx - c_x) + (by - c_y) * (by - c_y) +
                (bz - c_z) * (bz - c_z);
    double d3 = (cx - c_x) * (cx - c_x) + (cy - c_y) * (cy - c_y) +
                (cz - c_z) * (cz - c_z);
    bound_radius = sqrt(d1 > d2 ? (d1 > d3 ? d1 : d3) : (d2 > d3 ? d2 : d3));
  }
}

class ChunkMapNode {
  int64 key;
  Chunk @chunk;
  ChunkMapNode @next;
}

class ChunkMap {
  array<ChunkMapNode @> buckets;
  array<ChunkMapNode @> node_pool;
  uint mask;

  ChunkMap(uint size_power_of_two = 4096) {
    buckets.resize(size_power_of_two);
    mask = size_power_of_two - 1;
    // Pre-warm to prevent GC during chunk streaming.
    for (int i = 0; i < 1024; i++)
      node_pool.insertLast(ChunkMapNode());
  }

  ChunkMapNode @get_node() {
    uint pn = node_pool.length();
    if (pn > 0) {
      ChunkMapNode @n = node_pool[pn - 1];
      node_pool.removeLast();
      return n;
    }
    return ChunkMapNode();
  }

  void set(int64 key, Chunk @chunk) {
    // SplitMix64 finalizer — even bucket distribution for negative-coord keys.
    uint64 h = uint64(key);
    h = (h ^ (h >> 30)) * 0xbf58476d1ce4e5b9;
    h = (h ^ (h >> 27)) * 0x94d049bb133111eb;
    h = h ^ (h >> 31);
    uint idx = uint(h) & mask;
    ChunkMapNode @node = buckets[idx];
    while (node !is null) {
      if (node.key == key) {
        @node.chunk = @chunk;
        return;
      }
      @node = @node.next;
    }
    ChunkMapNode @new_node = get_node();
    new_node.key = key;
    @new_node.chunk = @chunk;
    @new_node.next = buckets[idx];
    @buckets[idx] = @new_node;
  }

  Chunk @get(int64 key) {
    // SplitMix64 — MUST match set/remove bucketing.
    uint64 h = uint64(key);
    h = (h ^ (h >> 30)) * 0xbf58476d1ce4e5b9;
    h = (h ^ (h >> 27)) * 0x94d049bb133111eb;
    h = h ^ (h >> 31);
    uint idx = uint(h) & mask;
    ChunkMapNode @node = buckets[idx];
    while (node !is null) {
      if (node.key == key)
        return node.chunk;
      @node = @node.next;
    }
    return null;
  }

  void remove(int64 key) {
    // SplitMix64 — MUST match set/get bucketing.
    uint64 h = uint64(key);
    h = (h ^ (h >> 30)) * 0xbf58476d1ce4e5b9;
    h = (h ^ (h >> 27)) * 0x94d049bb133111eb;
    h = h ^ (h >> 31);
    uint idx = uint(h) & mask;
    ChunkMapNode @node = buckets[idx];
    ChunkMapNode @prev = null;
    while (node !is null) {
      if (node.key == key) {
        if (prev is null) {
          @buckets[idx] = node.next;
        } else {
          @prev.next = node.next;
        }
        node_pool.insertLast(node);
        return;
      }
      @prev = node;
      @node = node.next;
    }
  }
}

// Coarse "is this chunk uniform?" check for preload_world. Samples
// density at a 3x3x3=27-point grid (600u spacing). Returns true iff
// every sample agrees (all solid or all empty) — chunk almost certainly
// has no marching-cube surface and can be skipped (no chunk alloc, no
// 125-cell scan, no mesh emit). Approximate: sub-600u tunnel features
// can fool this; they fill in via process_queue at approach.
bool chunk_likely_uniform(int cx, int cy, int cz) {
  int gx_start = cx * CHUNK_CELLS;
  int gy_start = cy * CHUNK_CELLS;
  int gz_start = cz * CHUNK_CELLS;
  bool any_solid = false, any_empty = false;
  // 3 samples/axis at offsets 0, 600u, 1200u from chunk start.
  for (int sx = 0; sx <= 2; sx++) {
    double wx = (gx_start + sx * 1.5) * CELL_SIZE;
    for (int sy = 0; sy <= 2; sy++) {
      double wy = (gy_start + sy * 1.5) * CELL_SIZE;
      for (int sz = 0; sz <= 2; sz++) {
        double wz = (gz_start + sz * 1.5) * CELL_SIZE;
        if (get_density(wx, wy, wz) > 0.0)
          any_solid = true;
        else
          any_empty = true;
        if (any_solid && any_empty)
          return false; // mixed → can't skip
      }
    }
  }
  return true; // every sample on the same side of zero
}

// Stratified super-cell election. Returns true iff (cx,cy,cz)'s
// deterministic hash is among the per_super_cell smallest within its
// 3x3x3 super-cell. Replaces prior independent-Bernoulli gate (Poisson
// clumping); guarantees spatial coverage. Tied hashes both admitted.
bool prism_chunk_is_supercell_topk(int cx, int cy, int cz, uint seed,
                                    int per_super_cell) {
  int N = PRISM_SUPER_CELL_N;
  // Floor-divide: AS `cx / N` truncates toward zero, so negatives need
  // an explicit branch to land adjacent chunks in the same super-cell.
  int scx = (cx >= 0) ? (cx / N) : -((-cx + N - 1) / N);
  int scy = (cy >= 0) ? (cy / N) : -((-cy + N - 1) / N);
  int scz = (cz >= 0) ? (cz / N) : -((-cz + N - 1) / N);

  int sx = cx + int(seed);
  int sy = cy + int(seed);
  int sz = cz + int(seed);
  double my_hash =
      fast_hash(uint(sx * 911 + sy * 523 + sz * 1021));

  // Count other chunks in the super-cell with smaller hash; bail when
  // rank reaches per_super_cell.
  int my_rank = 0;
  int x0 = scx * N, x1 = x0 + N;
  int y0 = scy * N, y1 = y0 + N;
  int z0 = scz * N, z1 = z0 + N;
  for (int qz = z0; qz < z1; qz++) {
    int qsz = qz + int(seed);
    for (int qy = y0; qy < y1; qy++) {
      int qsy = qy + int(seed);
      for (int qx = x0; qx < x1; qx++) {
        if (qx == cx && qy == cy && qz == cz) continue;
        int qsx = qx + int(seed);
        double other_hash =
            fast_hash(uint(qsx * 911 + qsy * 523 + qsz * 1021));
        if (other_hash < my_hash) {
          my_rank++;
          if (my_rank >= per_super_cell) return false;
        }
      }
    }
  }
  return true;
}

class Chunk {
  Vec3 center;
  array<Triangle @> triangles;
  int active_triangles = 0;
  bool is_generated = false;
  bool in_queue = false;
  double min_x, max_x, min_y, max_y, min_z, max_z;

  // Cached AABB extents.
  double aabb_cx, aabb_cy, aabb_cz;
  double aabb_hx, aabb_hy, aabb_hz;

  // Index into ChunkManager.ready_chunks (-1 if not present). For O(1)
  // swap-and-pop at unload.
  int ready_idx = -1;

  // TRAP: SoA mirror of per-tri fields was tried and reverted — rebuild
  // regressed ~25% and chunk-gen rbp spiked ~3× (each add_triangle ran
  // 11 insertLast calls). AS handle field access ≈ indexed array access;
  // don't assume otherwise without profiling.

  Chunk() {
    // Pre-warm so add_triangle's insertLast branch fires only on outliers.
    triangles.reserve(CHUNK_TRIANGLES_PREWARM);
    for (int i = 0; i < CHUNK_TRIANGLES_PREWARM; i++)
      triangles.insertLast(Triangle());
  }
}

class ChunkManager {
  ChunkMap chunks(4096);
  array<Chunk @> populated_chunks;
  // Tightly-packed view of populated_chunks (only generated + non-empty)
  // for shadow probes. populated_chunks is the authoritative unload set;
  // ready_chunks is appended in process_queue and O(1) swap-popped in
  // unload_far_chunks via Chunk.ready_idx.
  array<Chunk @> ready_chunks;
  array<Chunk @> chunk_pool;
  array<int64> generation_queue;
  // Deferred prism evaluation queue. Sorted-key FIFO; Gate 2/3/4 evaluate
  // only when neighborhood is settled. Deterministic across frame timing.
  array<int64> pending_prism_keys;
  // Gate-3 broadphase scratch (class-scoped, never freed).
  array<Chunk @> gate3_collision_chunks;

  double chunk_size;
  double inv_chunk_size;
  int min_cx = 2000000, max_cx = -2000000, min_cy = 2000000, max_cy = -2000000,
      min_cz = 2000000, max_cz = -2000000;
  array<bool> solid_cache(125);
  array<double> vert_cache_x(64);
  array<double> vert_cache_y(64);
  array<double> vert_cache_z(64);
  array<uint> vert_needed_gen(64);
  uint vert_needed_current_gen = 0;
  Vec3 sun_dir;

  ChunkManager(double size = CELL_SIZE * CHUNK_CELLS) {
    chunk_size = size;
    inv_chunk_size = 1.0 / size;
    sun_dir.set(0.5, 0.4, 1.0);
    sun_dir.normalize_in_place();
  }

  int64 get_key(int cx, int cy, int cz) {
    int64 kx = int64(cx) & 0x1FFFFF;
    int64 ky = int64(cy) & 0x1FFFFF;
    int64 kz = int64(cz) & 0x1FFFFF;
    return (kx << 42) | (ky << 21) | kz;
  }

  void get_chunk_coords(double px, double py, double pz, int &out cx,
                        int &out cy, int &out cz) {
    cx = int(floor(px * inv_chunk_size)); // mul instead of div
    cy = int(floor(py * inv_chunk_size));
    cz = int(floor(pz * inv_chunk_size));
  }

  void unload_far_chunks(const Vec3 &in plane_pos) {
    double max_dist_sq = (chunk_size * 5.0) * (chunk_size * 5.0);
    for (int i = int(populated_chunks.length()) - 1; i >= 0; i--) {
      Chunk @c = populated_chunks[i];
      double dx = c.center.x - plane_pos.x, dy = c.center.y - plane_pos.y,
             dz = c.center.z - plane_pos.z;
      if (dx * dx + dy * dy + dz * dz > max_dist_sq) {
        int cx, cy, cz;
        get_chunk_coords(c.center.x, c.center.y, c.center.z, cx, cy, cz);
        int64 key = get_key(cx, cy, cz);
        chunks.remove(key);
        c.is_generated = false;
        c.in_queue = false;
        // Swap-pop from ready_chunks. Empty chunks skipped registration
        // in process_queue (ready_idx stays -1), so the branch is free.
        int rdx = c.ready_idx;
        if (rdx >= 0) {
          int rlast = int(ready_chunks.length()) - 1;
          if (rdx != rlast) {
            @ready_chunks[rdx] = @ready_chunks[rlast];
            ready_chunks[rdx].ready_idx = rdx;
          }
          ready_chunks.removeLast();
          c.ready_idx = -1;
        }
        chunk_pool.insertLast(c);
        @populated_chunks[i] = @populated_chunks[populated_chunks.length() - 1];
        populated_chunks.removeLast();
      }
    }
  }

  void request_chunk(int cx, int cy, int cz) {
    int64 key = get_key(cx, cy, cz);
    Chunk @c = chunks.get(key);
    if (c is null) {
      Chunk @dummy;
      uint cp_n = chunk_pool.length();
      if (cp_n > 0) {
        @dummy = chunk_pool[cp_n - 1];
        chunk_pool.removeLast();
        dummy.active_triangles = 0;
        dummy.is_generated = false;
        // Defensive: pooled chunks must never carry stale ready_idx.
        dummy.ready_idx = -1;
      } else {
        @dummy = Chunk();
      }
      dummy.in_queue = true;
      chunks.set(key, dummy);
      generation_queue.insertLast(key);
    } else if (!c.is_generated && !c.in_queue) {
      // Ghost chunk that was dropped — put it back.
      c.in_queue = true;
      generation_queue.insertLast(key);
    }
  }

  // process_queue only enqueues candidates; resolution moved to
  // resolve_pending_prisms (called after) so Gate 3 sees settled neighbors.
  void process_queue(const Vec3 &in plane_pos, double fwd_x, double fwd_y,
                     double fwd_z,
                     uint prism_per_super_cell = 4,
                     uint prism_spawn_seed = 70) {
    double max_dist_sq = (chunk_size * 4.5) * (chunk_size * 4.5);
    double target_pos_x = plane_pos.x + fwd_x * (chunk_size * 0.5);
    double target_pos_y = plane_pos.y + fwd_y * (chunk_size * 0.5);
    double target_pos_z = plane_pos.z + fwd_z * (chunk_size * 0.5);

    for (int i = 0; i < 2 && generation_queue.length() > 0; i++) {
      int best_idx = -1;
      double best_score = 1e20;

      for (int j = int(generation_queue.length()) - 1; j >= 0; j--) {
        int64 key = generation_queue[j];

        int cx = int((key >> 42) & 0x1FFFFF);
        if ((cx & 0x100000) != 0)
          cx |= ~0x1FFFFF;
        int cy = int((key >> 21) & 0x1FFFFF);
        if ((cy & 0x100000) != 0)
          cy |= ~0x1FFFFF;
        int cz = int(key & 0x1FFFFF);
        if ((cz & 0x100000) != 0)
          cz |= ~0x1FFFFF;

        double center_x = (cx + 0.5) * chunk_size;
        double center_y = (cy + 0.5) * chunk_size;
        double center_z = (cz + 0.5) * chunk_size;
        double pdx = center_x - plane_pos.x;
        double pdy = center_y - plane_pos.y;
        double pdz = center_z - plane_pos.z;

        if (pdx * pdx + pdy * pdy + pdz * pdz > max_dist_sq) {
          Chunk @c = chunks.get(key);
          if (c !is null) {
            chunks.remove(key);
            c.is_generated = false;
            c.in_queue = false;
            // Defensive: pooled chunks must never carry stale ready_idx.
            // Mirrors the clear in unload_far_chunks; reuse paths also
            // clear on pool-exit (belt-and-suspenders).
            c.ready_idx = -1;
            chunk_pool.insertLast(c);
          }
          int last_idx = int(generation_queue.length()) - 1;
          generation_queue[j] = generation_queue[last_idx];
          generation_queue.removeLast();
          if (best_idx == last_idx)
            best_idx = j;
          continue;
        }

        double tdx = center_x - target_pos_x;
        double tdy = center_y - target_pos_y;
        double tdz = center_z - target_pos_z;

        double score = tdx * tdx + tdy * tdy + tdz * tdz;

        if (score < best_score) {
          best_score = score;
          best_idx = j;
        }
      }

      if (best_idx != -1) {
        int64 key = generation_queue[best_idx];
        generation_queue[best_idx] =
            generation_queue[generation_queue.length() - 1];
        generation_queue.removeLast();

        Chunk @c = chunks.get(key);
        if (c !is null)
          c.in_queue = false;

        int cx = int((key >> 42) & 0x1FFFFF);
        if ((cx & 0x100000) != 0)
          cx |= ~0x1FFFFF;
        int cy = int((key >> 21) & 0x1FFFFF);
        if ((cy & 0x100000) != 0)
          cy |= ~0x1FFFFF;
        int cz = int(key & 0x1FFFFF);
        if ((cz & 0x100000) != 0)
          cz |= ~0x1FFFFF;

        c.center.set((cx + 0.5) * chunk_size, (cy + 0.5) * chunk_size,
                     (cz + 0.5) * chunk_size);

        generate_chunk_geometry(c, cx, cy, cz);

        c.is_generated = true;
        populated_chunks.insertLast(c);
        // Register only non-empty chunks (empty bails stay out of probes).
        if (c.active_triangles > 0) {
          c.ready_idx = int(ready_chunks.length());
          ready_chunks.insertLast(c);
        }

        // Runway-zone gate: must mirror preload_runway exclusion so
        // fly-away/back doesn't materialize prisms in the safe zone.
        bool is_runway_chunk_for_prisms =
            (cx >= -2 && cx <= 1) && (cy >= -1 && cy <= 0) &&
            (cz >= -1 && cz <= 0);

        // Prism candidate enqueue (deferred). Stratified super-cell
        // election; Gate 2/3/4 deferred to resolve_pending_prisms.
        if (c.active_triangles > 0 && prism_per_super_cell > 0 &&
            !is_runway_chunk_for_prisms &&
            prism_chunk_is_supercell_topk(cx, cy, cz, prism_spawn_seed,
                                          int(prism_per_super_cell))) {
          // Sorted insert: pending_prism_keys stays ascending so
          // resolve_pending_prisms can skip per-frame sort.
          int64 ins_key = get_key(cx, cy, cz);
          uint plo = 0, phi = pending_prism_keys.length();
          while (plo < phi) {
            uint pmid = (plo + phi) >> 1;
            if (pending_prism_keys[pmid] < ins_key)
              plo = pmid + 1;
            else
              phi = pmid;
          }
          pending_prism_keys.insertAt(plo, ins_key);
        }

        if (cx < min_cx)
          min_cx = cx;
        if (cx > max_cx)
          max_cx = cx;
        if (cy < min_cy)
          min_cy = cy;
        if (cy > max_cy)
          max_cy = cy;
        if (cz < min_cz)
          min_cz = cz;
        if (cz > max_cz)
          max_cz = cz;
      }
    }
  }

  // Walk pending_prism_keys in sorted-key FIFO order; evaluate Gate
  // 2/3/4 on entries whose neighborhood is settled. Stop on first
  // unsettled entry — Gate 4 depends on FIFO ordering. Drops entries
  // whose source chunk has unloaded.
  void resolve_pending_prisms(array<FloatingPrism @> @floating_prisms,
                              array<FloatingPrism @> @prism_pool,
                              uint prism_spawn_seed,
                              double pr_dist_min  = 2000.0,
                              double pr_terr_min  = 1000.0,
                              double pr_terr_max  = 2400.0,
                              double pr_tri_clear =  280.0,
                              uint   pr_dens_tol  = 1) {
    if (pending_prism_keys.length() == 0)
      return;

    // Hoist squared variants + offset variance once per call.
    double pr_dist_min_sq  = pr_dist_min  * pr_dist_min;
    double pr_tri_clear_sq = pr_tri_clear * pr_tri_clear;
    double pr_terr_var     = pr_terr_max  - pr_terr_min;
    int    pr_dens_tol_i   = int(pr_dens_tol);

    // Compact survivors in-place at w++; dead + resolved entries drop
    // after final resize. AS sortAsc rejected — feedback_as_int64_sort_quirk.
    // ri (not r) avoids shadowing Gate 2's density radius.
    uint w = 0;
    bool blocked = false;
    // Length hoist safe: only in-place mutation during walk; resize(w) after.
    uint ppk_n = pending_prism_keys.length();
    for (uint ri = 0; ri < ppk_n; ri++) {
      int64 key = pending_prism_keys[ri];

      if (blocked) {
        // FIFO: once unsettled, every higher-keyed entry waits too.
        pending_prism_keys[w++] = key;
        continue;
      }

      Chunk @c = chunks.get(key);
      if (c is null) {
        // Source chunk unloaded — drop entry.
        continue;
      }

      // Decode coords from key (mirrors process_queue).
      int cx = int((key >> 42) & 0x1FFFFF);
      if ((cx & 0x100000) != 0)
        cx |= ~0x1FFFFF;
      int cy = int((key >> 21) & 0x1FFFFF);
      if ((cy & 0x100000) != 0)
        cy |= ~0x1FFFFF;
      int cz = int(key & 0x1FFFFF);
      if ((cz & 0x100000) != 0)
        cz |= ~0x1FFFFF;

      // Spawn_pos from triangle hash; idempotent (triangles never shift).
      int sx = cx + int(prism_spawn_seed);
      int sy = cy + int(prism_spawn_seed);
      int sz = cz + int(prism_spawn_seed);
      int rand_tri_idx =
          int(fast_hash(uint(sx * 111 + sy * 222 + sz * 333)) *
              c.active_triangles);
      Triangle @tri = c.triangles[rand_tri_idx];
      double dist_rand = fast_hash(uint(sx * 555 + sy * 777 + sz * 999));
      double offset_dist = pr_terr_min + dist_rand * pr_terr_var;
      Vec3 spawn_pos;
      spawn_pos.x = tri.c_x + tri.nx * offset_dist;
      spawn_pos.y = tri.c_y + tri.ny * offset_dist;
      spawn_pos.z = tri.c_z + tri.nz * offset_dist;
      // Hoist spawn_pos — read 30+ times across Gate 2/3/4.
      double sp_x = spawn_pos.x;
      double sp_y = spawn_pos.y;
      double sp_z = spawn_pos.z;

      // Forward-view exclusion corridor (cheap AABB before settle/Gates).
      // Dropped permanently — corridor is fixed.
      if (sp_x >= PRISM_CORRIDOR_X_MIN && sp_x <= PRISM_CORRIDOR_X_MAX &&
          sp_y >= PRISM_CORRIDOR_Y_MIN && sp_y <= PRISM_CORRIDOR_Y_MAX &&
          sp_z >= PRISM_CORRIDOR_Z_MIN && sp_z <= PRISM_CORRIDOR_Z_MAX) {
        continue;
      }

      // Settle check: every chunk within PRISM_SETTLE_RADIUS must be
      // absent or is_generated. Else retry next frame.
      bool all_settled = true;
      {
        int gcx0, gcy0, gcz0, gcx1, gcy1, gcz1;
        get_chunk_coords(sp_x - PRISM_SETTLE_RADIUS,
                         sp_y - PRISM_SETTLE_RADIUS,
                         sp_z - PRISM_SETTLE_RADIUS,
                         gcx0, gcy0, gcz0);
        get_chunk_coords(sp_x + PRISM_SETTLE_RADIUS,
                         sp_y + PRISM_SETTLE_RADIUS,
                         sp_z + PRISM_SETTLE_RADIUS,
                         gcx1, gcy1, gcz1);
        for (int qz = gcz0; qz <= gcz1 && all_settled; qz++) {
          for (int qy = gcy0; qy <= gcy1 && all_settled; qy++) {
            for (int qx = gcx0; qx <= gcx1 && all_settled; qx++) {
              int64 qkey = get_key(qx, qy, qz);
              Chunk @qc = chunks.get(qkey);
              if (qc !is null && !qc.is_generated)
                all_settled = false;
            }
          }
        }
      }

      if (!all_settled) {
        pending_prism_keys[w++] = key;
        blocked = true;
        continue;
      }

      // Gate 2: predictive density check. Center mandatory; 14 perimeter
      // samples (6 face + 8 corner) are k-of-N — up to pr_dens_tol fails
      // tolerated. Chain preserves early-bailout once fails > tol.
      bool is_safe = true;
      {
        double r = PRISM_DENSITY_PROBE_RADIUS;
        double rd = r * 0.5773502692;
        int tol = pr_dens_tol_i;
        if (get_density(sp_x, sp_y, sp_z) > -0.1) {
          is_safe = false;
        } else {
          int fails = 0;
          if (get_density(sp_x + r, sp_y, sp_z) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x - r, sp_y, sp_z) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x, sp_y + r, sp_z) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x, sp_y - r, sp_z) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x, sp_y, sp_z + r) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x, sp_y, sp_z - r) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x + rd, sp_y + rd, sp_z + rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x + rd, sp_y + rd, sp_z - rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x + rd, sp_y - rd, sp_z + rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x + rd, sp_y - rd, sp_z - rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x - rd, sp_y + rd, sp_z + rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x - rd, sp_y + rd, sp_z - rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x - rd, sp_y - rd, sp_z + rd) > -0.05) fails++;
          if (fails <= tol &&
              get_density(sp_x - rd, sp_y - rd, sp_z - rd) > -0.05) fails++;
          if (fails > tol) is_safe = false;
        }
      }

      // Gate 3: mesh collision. Spatial-hash broadphase over a 6x6x6
      // chunk-AABB into gate3_collision_chunks; triangle narrowphase
      // then iterates the pre-filtered list. is_generated still required
      // for the [1200u,3500u] annulus outside the settle radius.
      if (is_safe) {
        gate3_collision_chunks.resize(0);
        int bcx0, bcy0, bcz0, bcx1, bcy1, bcz1;
        get_chunk_coords(sp_x - PRISM_CHUNK_COLLISION_RADIUS,
                         sp_y - PRISM_CHUNK_COLLISION_RADIUS,
                         sp_z - PRISM_CHUNK_COLLISION_RADIUS,
                         bcx0, bcy0, bcz0);
        get_chunk_coords(sp_x + PRISM_CHUNK_COLLISION_RADIUS,
                         sp_y + PRISM_CHUNK_COLLISION_RADIUS,
                         sp_z + PRISM_CHUNK_COLLISION_RADIUS,
                         bcx1, bcy1, bcz1);
        // Pre-distance reject from cell coords skips ~50% of chunks.get
        // (sphere inscribed in ~6³ box).
        double cs = chunk_size;
        for (int qz = bcz0; qz <= bcz1; qz++) {
          double dcz = (qz + 0.5) * cs - sp_z;
          double dcz_sq = dcz * dcz;
          for (int qy = bcy0; qy <= bcy1; qy++) {
            double dcy = (qy + 0.5) * cs - sp_y;
            double dyz_sq = dcz_sq + dcy * dcy;
            // Outer-axis early reject.
            if (dyz_sq > PRISM_CHUNK_COLLISION_RADIUS_SQ)
              continue;
            for (int qx = bcx0; qx <= bcx1; qx++) {
              double dcx = (qx + 0.5) * cs - sp_x;
              if (dcx * dcx + dyz_sq > PRISM_CHUNK_COLLISION_RADIUS_SQ)
                continue;
              Chunk @qc = chunks.get(get_key(qx, qy, qz));
              if (qc is null || !qc.is_generated || qc.active_triangles == 0)
                continue;
              gate3_collision_chunks.insertLast(qc);
            }
          }
        }

        // Per-tri AABB bounds hoisted out of chunk*tri loop.
        double tri_aabb_lo_x = sp_x - pr_tri_clear;
        double tri_aabb_hi_x = sp_x + pr_tri_clear;
        double tri_aabb_lo_y = sp_y - pr_tri_clear;
        double tri_aabb_hi_y = sp_y + pr_tri_clear;
        double tri_aabb_lo_z = sp_z - pr_tri_clear;
        double tri_aabb_hi_z = sp_z + pr_tri_clear;

        uint gccc = gate3_collision_chunks.length();
        for (uint ci = 0; ci < gccc; ci++) {
          Chunk @pc = gate3_collision_chunks[ci];
          int pc_at = pc.active_triangles;
          for (int ti = 0; ti < pc_at; ti++) {
            Triangle @ct = pc.triangles[ti];
            // AABB pre-reject vs sphere AABB skips closest_point for
            // most in-chunk tris (~10% pass at default).
            if (tri_aabb_hi_x < ct.min_x || tri_aabb_lo_x > ct.max_x ||
                tri_aabb_hi_y < ct.min_y || tri_aabb_lo_y > ct.max_y ||
                tri_aabb_hi_z < ct.min_z || tri_aabb_lo_z > ct.max_z)
              continue;

            double cl_x, cl_y, cl_z;
            closest_point_on_triangle(sp_x, sp_y, sp_z,
                                      ct, cl_x, cl_y, cl_z);
            double d_x = sp_x - cl_x, d_y = sp_y - cl_y,
                   d_z = sp_z - cl_z;
            if (d_x * d_x + d_y * d_y + d_z * d_z < pr_tri_clear_sq) {
              is_safe = false;
              break;
            }
          }
          if (!is_safe)
            break;
        }
      }

      // Gate 4: existing-prism distance. FIFO on sorted keys means
      // floating_prisms is identical on every seed replay.
      if (is_safe) {
        bool exists = false;
        uint fpn = floating_prisms.length();
        for (uint k = 0; k < fpn; k++) {
          FloatingPrism @fpk = floating_prisms[k];
          double dx = fpk.pos.x - sp_x;
          double dy = fpk.pos.y - sp_y;
          double dz = fpk.pos.z - sp_z;
          if (dx * dx + dy * dy + dz * dz < pr_dist_min_sq) {
            exists = true;
            break;
          }
        }
        if (!exists) {
          FloatingPrism @fp;
          uint pp_n = (prism_pool !is null) ? prism_pool.length() : 0;
          if (pp_n > 0) {
            @fp = prism_pool[pp_n - 1];
            prism_pool.removeLast();
          } else {
            @fp = FloatingPrism();
          }
          fp.pos.set(sp_x, sp_y, sp_z);
          fp.size = 80.0;
          fp.color = 0xAAED711D;
          fp.life = 0;
          floating_prisms.insertLast(fp);
        }
      }

      // Resolved — entry drops (no write to w).
    }

    pending_prism_keys.resize(w);
  }

  // Pre-generate every chunk in a (2r+1)^3 box around origin and resolve
  // prisms synchronously at init(). Spherical cull + chunk_likely_uniform
  // skip ~75% of the cube at fog distance. Per-chunk finalize duplicates
  // preload_runway/process_queue (shared helper would cost more inlined).
  void preload_world(int radius_chunks,
                     uint prism_per_super_cell, uint prism_spawn_seed,
                     array<FloatingPrism @> @floating_prisms,
                     array<FloatingPrism @> @prism_pool,
                     double pr_dist_min  = 2000.0,
                     double pr_terr_min  = 1000.0,
                     double pr_terr_max  = 2400.0,
                     double pr_tri_clear =  280.0,
                     uint   pr_dens_tol  = 1) {
    // Hardcoded guide prism. MUST insert before the chunk loop so
    // Gate 4 of subsequent stratified candidates rejects within 2000u.
    {
      FloatingPrism @gp;
      uint pn = (prism_pool !is null) ? prism_pool.length() : 0;
      if (pn > 0) {
        @gp = prism_pool[pn - 1];
        prism_pool.removeLast();
      } else {
        @gp = FloatingPrism();
      }
      gp.pos.set(PRISM_GUIDE_X, PRISM_GUIDE_Y, PRISM_GUIDE_Z);
      gp.size = 80.0;
      gp.color = 0xAAED711D;
      gp.life = 0;
      floating_prisms.insertLast(gp);
    }

    // Spherical cull — drops corner chunks outside the inscribed sphere
    // (~50% of cube) with no radial-coverage loss.
    double max_center_dist = double(radius_chunks) * chunk_size;
    double max_center_dist_sq = max_center_dist * max_center_dist;

    for (int cz = -radius_chunks; cz <= radius_chunks; cz++) {
      double ccz = (cz + 0.5) * chunk_size;
      double ccz_sq = ccz * ccz;
      for (int cy = -radius_chunks; cy <= radius_chunks; cy++) {
        double ccy = (cy + 0.5) * chunk_size;
        double ccyz_sq = ccz_sq + ccy * ccy;
        // Outer-axis early reject.
        if (ccyz_sq > max_center_dist_sq)
          continue;
        for (int cx = -radius_chunks; cx <= radius_chunks; cx++) {
          double ccx = (cx + 0.5) * chunk_size;
          if (ccx * ccx + ccyz_sq > max_center_dist_sq)
            continue;
          int64 key = get_key(cx, cy, cz);

          Chunk @existing = chunks.get(key);
          if (existing !is null && existing.is_generated)
            continue; // covers runway chunks pre-meshed by preload_runway

          // Coarse pre-cull at 27 sample points; sub-600u features
          // missed here load via process_queue at approach.
          if (chunk_likely_uniform(cx, cy, cz))
            continue;

          Chunk @c;
          if (existing !is null) {
            // Already enqueued — won't happen on cold init; defensive.
            @c = existing;
            for (uint q = 0; q < generation_queue.length(); q++) {
              if (generation_queue[q] == key) {
                generation_queue[q] =
                    generation_queue[generation_queue.length() - 1];
                generation_queue.removeLast();
                break;
              }
            }
          } else {
            uint cp_n = chunk_pool.length();
            if (cp_n > 0) {
              @c = chunk_pool[cp_n - 1];
              chunk_pool.removeLast();
              c.active_triangles = 0;
              c.is_generated = false;
              c.ready_idx = -1;
              chunks.set(key, c);
            } else {
              @c = Chunk();
              chunks.set(key, c);
            }
          }
          c.in_queue = false;

          c.center.set((cx + 0.5) * chunk_size, (cy + 0.5) * chunk_size,
                       (cz + 0.5) * chunk_size);

          generate_chunk_geometry(c, cx, cy, cz);

          c.is_generated = true;
          populated_chunks.insertLast(c);
          if (c.active_triangles > 0) {
            c.ready_idx = int(ready_chunks.length());
            ready_chunks.insertLast(c);
          }

          // Prism enqueue (same as process_queue). Runway gate redundant
          // here but kept defensively.
          bool is_runway_chunk_for_prisms =
              (cx >= -2 && cx <= 1) && (cy >= -1 && cy <= 0) &&
              (cz >= -1 && cz <= 0);
          if (c.active_triangles > 0 && prism_per_super_cell > 0 &&
              !is_runway_chunk_for_prisms &&
              prism_chunk_is_supercell_topk(cx, cy, cz, prism_spawn_seed,
                                            int(prism_per_super_cell))) {
            int64 ins_key = get_key(cx, cy, cz);
            uint plo = 0, phi = pending_prism_keys.length();
            while (plo < phi) {
              uint pmid = (plo + phi) >> 1;
              if (pending_prism_keys[pmid] < ins_key)
                plo = pmid + 1;
              else
                phi = pmid;
            }
            pending_prism_keys.insertAt(plo, ins_key);
          }

          if (cx < min_cx) min_cx = cx;
          if (cx > max_cx) max_cx = cx;
          if (cy < min_cy) min_cy = cy;
          if (cy > max_cy) max_cy = cy;
          if (cz < min_cz) min_cz = cz;
          if (cz > max_cz) max_cz = cz;
        }
      }
    }

    // Drain prism queue synchronously — settle is trivially satisfied
    // (box meshed, outside-box chunks absent = settled).
    resolve_pending_prisms(floating_prisms, prism_pool, prism_spawn_seed,
                           pr_dist_min, pr_terr_min, pr_terr_max,
                           pr_tri_clear, pr_dens_tol);
  }

  // Pre-generate the 16 runway chunks (cx[-2,1] x cy[-1,0] x cz[-1,0])
  // before first step(). Skips prism spawning — runway is the safe zone.
  void preload_runway() {
    for (int cz = -1; cz <= 0; cz++) {
      for (int cy = -1; cy <= 0; cy++) {
        for (int cx = -2; cx <= 1; cx++) {
          int64 key = get_key(cx, cy, cz);

          // Defensive: skip if key already touched (re-init / unusual
          // call order). preload_runway is a one-shot from init().
          Chunk @existing = chunks.get(key);
          if (existing !is null && existing.is_generated)
            continue;

          Chunk @c;
          if (existing !is null) {
            // Already enqueued — defensive (shouldn't fire on cold init).
            @c = existing;
            for (uint q = 0; q < generation_queue.length(); q++) {
              if (generation_queue[q] == key) {
                generation_queue[q] =
                    generation_queue[generation_queue.length() - 1];
                generation_queue.removeLast();
                break;
              }
            }
          } else {
            uint cp_n = chunk_pool.length();
            if (cp_n > 0) {
              @c = chunk_pool[cp_n - 1];
              chunk_pool.removeLast();
              c.active_triangles = 0;
              c.is_generated = false;
              c.ready_idx = -1;
              chunks.set(key, c);
            } else {
              @c = Chunk();
              chunks.set(key, c);
            }
          }
          c.in_queue = false;

          c.center.set((cx + 0.5) * chunk_size, (cy + 0.5) * chunk_size,
                       (cz + 0.5) * chunk_size);

          generate_chunk_geometry(c, cx, cy, cz);

          c.is_generated = true;
          populated_chunks.insertLast(c);
          // Register only if non-empty (same invariant as process_queue).
          if (c.active_triangles > 0) {
            c.ready_idx = int(ready_chunks.length());
            ready_chunks.insertLast(c);
          }

          if (cx < min_cx)
            min_cx = cx;
          if (cx > max_cx)
            max_cx = cx;
          if (cy < min_cy)
            min_cy = cy;
          if (cy > max_cy)
            max_cy = cy;
          if (cz < min_cz)
            min_cz = cz;
          if (cz > max_cz)
            max_cz = cz;
        }
      }
    }
  }

  void generate_chunk_geometry(Chunk @c, int cx, int cy, int cz) {
    int gx_start = cx * CHUNK_CELLS;
    int gy_start = cy * CHUNK_CELLS;
    int gz_start = cz * CHUNK_CELLS;

    double cx_w = (gx_start + 1.5) * CELL_SIZE;
    double cy_w = (gy_start + 1.5) * CELL_SIZE;
    double cz_w = (gz_start + 1.5) * CELL_SIZE;
    double base_density = 0.2;
    double dwx = (cx_w - 800.0) * 0.6666666666666666;
    double dist_from_center = sqrt(dwx * dwx + cy_w * cy_w + cz_w * cz_w);
    double central_cave = 4000.0 - dist_from_center;
    if (central_cave > 0)
      base_density -= (central_cave * 0.0006666666666666666);
    if (cz_w < -15000.0)
      base_density += (-15000.0 - cz_w) * 0.002;
    if (cz_w > 15000.0)
      base_density += (cz_w - 15000.0) * 0.002;

    double island_threshold = 0.8;
    double max_dist_chunk = dist_from_center - 1040.0;
    if (max_dist_chunk < 5000.0) {
      double ratio = max_dist_chunk * 0.0002;
      if (ratio < 0.0)
        ratio = 0.0;
      island_threshold = 0.2 + (0.6 * ratio);
    }
    double max_island_add = (1.5 - island_threshold) * 8.0;
    // Match get_density's vi_max_add so all-empty cull doesn't skip
    // chunks that void-island would populate.
    double cull_vi_max_add = (1.5 - VI_THRESH) * VI_SIZE;
    if (cull_vi_max_add < 0.0) cull_vi_max_add = 0.0;

    bool near_spawn = (gx_start >= -8 && gx_start <= 12 && gy_start >= -4 &&
                       gy_start <= 4 && gz_start >= -4 && gz_start <= 8);
    if (!near_spawn) {
      if (base_density + 4.63 + 1.5 + max_island_add + cull_vi_max_add +
              0.2 < 0.0)
        return;
      if (base_density - 4.63 - 1.5 - 3.5 - 0.2 > 0.0)
        return;
    }

    bool all_solid = true, all_empty = true;

    // Iterative FP coords eliminate cast/mul in the 125-iteration loop.
    double base_wx = (gx_start - 1) * CELL_SIZE;
    double wx = base_wx;
    for (int x = -1; x <= 3; x++, wx += CELL_SIZE) {
      double base_wy = (gy_start - 1) * CELL_SIZE;
      double wy = base_wy;
      for (int y = -1; y <= 3; y++, wy += CELL_SIZE) {
        double base_wz = (gz_start - 1) * CELL_SIZE;
        double wz = base_wz;
        for (int z = -1; z <= 3; z++, wz += CELL_SIZE) {
          int idx = (x + 1) * 25 + (y + 1) * 5 + (z + 1);

          int gx = gx_start + x;
          int gy = gy_start + y;
          int gz = gz_start + z;

          // Inline the runway check with the pre-calculated world floats.
          bool solid;
          if (gx >= -4 && gx <= 5 && gy >= -1 && gy <= 1) {
            if (gz < 0)
              solid = true;
            else if (gz >= 0 && gz <= 5)
              solid = false;
            else
              solid = get_density(wx, wy, wz) > 0.0;
          } else {
            solid = get_density(wx, wy, wz) > 0.0;
          }

          solid_cache[idx] = solid;
          if (solid)
            all_empty = false;
          else
            all_solid = false;
        }
      }
    }

    if (all_solid || all_empty)
      return;

    vert_needed_current_gen++;
    if (vert_needed_current_gen == 0) {
      for (int i = 0; i < 64; i++)
        vert_needed_gen[i] = 0;
      vert_needed_current_gen = 1;
    }

    // Hoist member to local — 24 reads/cell when all 6 faces fire.
    uint vncg = vert_needed_current_gen;
    // v_base iterative; cube-vert offsets {0,1,4,5,16,17,20,21} are
    // constant adds.
    int s_idx_base_x = 25;
    int v_base_x = 0;
    for (int x = 0; x < CHUNK_CELLS; x++, s_idx_base_x += 25, v_base_x += 16) {
      int s_idx_base_y = s_idx_base_x + 5;
      int v_base_y = v_base_x;
      for (int y = 0; y < CHUNK_CELLS; y++, s_idx_base_y += 5, v_base_y += 4) {
        int s_idx = s_idx_base_y + 1;
        int v_base = v_base_y;
        for (int z = 0; z < CHUNK_CELLS; z++, s_idx++, v_base++) {
          if (solid_cache[s_idx]) {
            if (!solid_cache[s_idx - 25]) {              // -X face
              vert_needed_gen[v_base]      = vncg;
              vert_needed_gen[v_base + 4]  = vncg;
              vert_needed_gen[v_base + 1]  = vncg;
              vert_needed_gen[v_base + 5]  = vncg;
            }
            if (!solid_cache[s_idx + 25]) {              // +X face
              vert_needed_gen[v_base + 16] = vncg;
              vert_needed_gen[v_base + 20] = vncg;
              vert_needed_gen[v_base + 17] = vncg;
              vert_needed_gen[v_base + 21] = vncg;
            }
            if (!solid_cache[s_idx - 5]) {               // -Y face
              vert_needed_gen[v_base]      = vncg;
              vert_needed_gen[v_base + 16] = vncg;
              vert_needed_gen[v_base + 1]  = vncg;
              vert_needed_gen[v_base + 17] = vncg;
            }
            if (!solid_cache[s_idx + 5]) {               // +Y face
              vert_needed_gen[v_base + 4]  = vncg;
              vert_needed_gen[v_base + 20] = vncg;
              vert_needed_gen[v_base + 5]  = vncg;
              vert_needed_gen[v_base + 21] = vncg;
            }
            if (!solid_cache[s_idx - 1]) {               // -Z face
              vert_needed_gen[v_base]      = vncg;
              vert_needed_gen[v_base + 16] = vncg;
              vert_needed_gen[v_base + 4]  = vncg;
              vert_needed_gen[v_base + 20] = vncg;
            }
            if (!solid_cache[s_idx + 1]) {               // +Z face
              vert_needed_gen[v_base + 1]  = vncg;
              vert_needed_gen[v_base + 17] = vncg;
              vert_needed_gen[v_base + 5]  = vncg;
              vert_needed_gen[v_base + 21] = vncg;
            }
          }
        }
      }
    }

    // Iterative idx (matches s_idx_base/v_base_x above).
    double vert_base_wx = gx_start * CELL_SIZE;
    double v_wx = vert_base_wx;
    int idx_base_x = 0;
    for (int x = 0; x <= 3; x++, v_wx += CELL_SIZE, idx_base_x += 16) {
      double vert_base_wy = gy_start * CELL_SIZE;
      double v_wy = vert_base_wy;
      int idx_base_y = idx_base_x;
      for (int y = 0; y <= 3; y++, v_wy += CELL_SIZE, idx_base_y += 4) {
        double vert_base_wz = gz_start * CELL_SIZE;
        double v_wz = vert_base_wz;
        int idx = idx_base_y;
        for (int z = 0; z <= 3; z++, v_wz += CELL_SIZE, idx++) {
          if (vert_needed_gen[idx] == vncg) {
            get_vertex_pos_flat(gx_start + x, gy_start + y, gz_start + z, v_wx,
                                v_wy, v_wz, vert_cache_x[idx],
                                vert_cache_y[idx], vert_cache_z[idx]);
          }
        }
      }
    }

    // Same base-index approach for face emission.
    int e_idx_base_x = 25;
    for (int x = 0; x < CHUNK_CELLS; x++, e_idx_base_x += 25) {
      int e_idx_base_y = e_idx_base_x + 5;
      for (int y = 0; y < CHUNK_CELLS; y++, e_idx_base_y += 5) {
        int e_idx = e_idx_base_y + 1;
        for (int z = 0; z < CHUNK_CELLS; z++, e_idx++) {
          if (solid_cache[e_idx]) {
            int gx = gx_start + x;
            int gy = gy_start + y;
            int gz = gz_start + z;

            if (!solid_cache[e_idx - 25])
              emit_face(c, gx, gy, gz, x, y, z, 0); // -X
            if (!solid_cache[e_idx + 25])
              emit_face(c, gx, gy, gz, x, y, z, 1); // +X
            if (!solid_cache[e_idx - 5])
              emit_face(c, gx, gy, gz, x, y, z, 2); // -Y
            if (!solid_cache[e_idx + 5])
              emit_face(c, gx, gy, gz, x, y, z, 3); // +Y
            if (!solid_cache[e_idx - 1])
              emit_face(c, gx, gy, gz, x, y, z, 4); // -Z
            if (!solid_cache[e_idx + 1])
              emit_face(c, gx, gy, gz, x, y, z, 5); // +Z
          }
        }
      }
    }

    if (c.active_triangles > 0) {
      c.aabb_cx = (c.min_x + c.max_x) * 0.5;
      c.aabb_cy = (c.min_y + c.max_y) * 0.5;
      c.aabb_cz = (c.min_z + c.max_z) * 0.5;
      c.aabb_hx = c.max_x - c.aabb_cx;
      c.aabb_hy = c.max_y - c.aabb_cy;
      c.aabb_hz = c.max_z - c.aabb_cz;
    }
  }
  void add_triangle(Chunk @c, double ax, double ay, double az, double bx,
                    double by, double bz, double cx, double cy, double cz,
                    uint col) {
    if (c.active_triangles >= int(c.triangles.length())) {
      c.triangles.insertLast(Triangle());
    }
    Triangle @tri = c.triangles[c.active_triangles];
    tri.set(ax, ay, az, bx, by, bz, cx, cy, cz, col);

    double light_intensity =
        tri.nx * sun_dir.x + tri.ny * sun_dir.y + tri.nz * sun_dir.z;
    if (light_intensity < 0.15)
      light_intensity = 0.15;

    // Inlined multiply_color + direct assignments.
    uint a = (col >> 24) & 0xFF;
    uint r = uint(double((col >> 16) & 0xFF) * light_intensity);
    uint g = uint(double((col >> 8) & 0xFF) * light_intensity);
    uint b = uint(double(col & 0xFF) * light_intensity);

    tri.color = (a << 24) | (r << 16) | (g << 8) | b;
    tri.col_r = r;
    tri.col_g = g;
    tri.col_b = b;

    if (c.active_triangles == 0) {
      c.min_x = tri.min_x;
      c.max_x = tri.max_x;
      c.min_y = tri.min_y;
      c.max_y = tri.max_y;
      c.min_z = tri.min_z;
      c.max_z = tri.max_z;
    } else {
      if (tri.min_x < c.min_x)
        c.min_x = tri.min_x;
      if (tri.max_x > c.max_x)
        c.max_x = tri.max_x;
      if (tri.min_y < c.min_y)
        c.min_y = tri.min_y;
      if (tri.max_y > c.max_y)
        c.max_y = tri.max_y;
      if (tri.min_z < c.min_z)
        c.min_z = tri.min_z;
      if (tri.max_z > c.max_z)
        c.max_z = tri.max_z;
    }
    c.active_triangles++;
  }

  void emit_face(Chunk @c, int gx, int gy, int gz, int lx, int ly, int lz,
                 int dir) {
    uint col;
    bool is_spawn =
        (gx >= -4 && gx <= 8 && gy >= -1 && gy <= 1 && gz >= -1 && gz <= 5);
    if (is_spawn) {
      col = (dir == 5) ? 0xFF558855 : 0xFF2A2A2A;
    } else if (gz < -23) {
      double n_val =
          noise3d(gx * 0.05 + 100.0, gy * 0.05 - 200.0, gz * 0.05 + 300.0);
      if (n_val > 0.3) {
        col = (dir == 5) ? 0xFF2B5B84 : ((dir == 4) ? 0xFF1A3B5C : 0xFF224B6D);
      } else if (n_val > -0.2) {
        col = (dir == 5) ? 0xFF689EB8 : ((dir == 4) ? 0xFF45738E : 0xFF5688A3);
      } else {
        col = (dir == 5) ? 0xFF4A4E54 : ((dir == 4) ? 0xFF32353A : 0xFF3E4247);
      }
    } else if (gz < -11) {
      bool is_rock = false;
      if (gz < -17) {
        double rock_blend = (-17.0 - gz) * 0.2; // 0 at -17, 1 at -22
        if (rock_blend >= 1.0) {
          is_rock = true;
        } else {
          double dither_noise = noise3d(gx * 0.1, gy * 0.1, gz * 0.1);
          if (dither_noise + rock_blend * 1.5 > 0.8) {
            is_rock = true;
          }
        }
      }
      
      if (is_rock) {
        double rock_var = noise3d(gx * 0.05, gy * 0.05, gz * 0.05);
        if (rock_var > 0.0) {
          col = (dir == 5) ? 0xFF65686B : ((dir == 4) ? 0xFF434548 : 0xFF545659);
        } else {
          col = (dir == 5) ? 0xFF585B5E : ((dir == 4) ? 0xFF35373A : 0xFF46484B);
        }
      } else {
        double layer_noise = noise3d(gx * 0.04 + 100.0, gy * 0.04 - 150.0, gz * 0.25 + 50.0);
        double chunk_noise = noise3d(gx * 0.015, gy * 0.015, gz * 0.02);
        double combined = layer_noise * 0.6 + chunk_noise * 0.4;
        if (combined > 0.3) {
          col = (dir == 5) ? 0xFF8A6E53 : ((dir == 4) ? 0xFF54402D : 0xFF735A42);
        } else if (combined > 0.0) {
          col = (dir == 5) ? 0xFF755B42 : ((dir == 4) ? 0xFF453322 : 0xFF604933);
        } else if (combined > -0.3) {
          col = (dir == 5) ? 0xFF664832 : ((dir == 4) ? 0xFF3A2718 : 0xFF523926);
        } else {
          col = (dir == 5) ? 0xFF523826 : ((dir == 4) ? 0xFF2E1E14 : 0xFF402B1D);
        }
      }
    } else if (gz <= 0) {
      // Forest
      double n_val =
          noise3d(gx * 0.05 - 30.0, gy * 0.05 + 60.0, gz * 0.05 - 20.0);
      if (dir == 5) {
        if (n_val > 0.4) {
          col = 0xFFBEAAE3; // Light pink
        } else if (n_val > 0.1) {
          col = 0xFF4A7C4A; // Darker green
        } else if (n_val > -0.2) {
          col = 0xFF3D6B3D; // Deep forest green
        } else {
          col = 0xFF558855; // Original green
        }
      } else if (dir == 4) {
        col = 0xFF443322;
      } else {
        col = 0xFF665544;
      }
    } else if (gz <= 12) {
      // Highlands / Autumn Mix
      double n_val =
          noise3d(gx * 0.05 + 50.0, gy * 0.05 - 80.0, gz * 0.05 + 90.0);
      if (dir == 5) {
        if (n_val > 0.4) {
          col = 0xFF8B251D; // Deep Autumn Red
        } else if (n_val > 0.1) {
          col = 0xFF9E3128; // Autumn Red
        } else if (n_val > -0.15) {
          col = 0xFFC97C3A; // Autumn Orange
        } else if (n_val > -0.4) {
          col = 0xFFDCA045; // Bright Orange/Yellow
        } else if (n_val > -0.6) {
          col = 0xFF8DA365; // Highland Green
        } else {
          col = 0xFF7D9358; // Darker muted green
        }
      } else if (dir == 4) {
        col = 0xFF6A6A6A;
      } else {
        col = 0xFF7F7F7F;
      }
    } else {
      // Snowy Peaks / Alpine
      double n_val =
          noise3d(gx * 0.05 - 100.0, gy * 0.05 + 200.0, gz * 0.05 - 300.0);
      if (n_val > 0.4) {
        col = (dir == 5) ? 0xFFCDE2ED : ((dir == 4) ? 0xFF8398A8 : 0xFF9AACBE);
      } else {
        col = (dir == 5) ? 0xFFFAFAFE : ((dir == 4) ? 0xFF808B99 : 0xFF9AA4B0);
      }
    }

    uint h_in = uint(gx * 151 + gy * 233 + gz * 317 + dir * 113);
    int cv = int(fast_hash(h_in) * 30.0);
    int r = ((col >> 16) & 0xFF) + cv;
    if (r > 255)
      r = 255;
    int gr = ((col >> 8) & 0xFF) + cv;
    if (gr > 255)
      gr = 255;
    int b = (col & 0xFF) + cv;
    if (b > 255)
      b = 255;
    col = (0xFF000000) | (uint(r) << 16) | (uint(gr) << 8) | uint(b);

    // v_base + fixed cube-vert offsets {0,1,4,5,16,17,20,21}.
    // Verified against original mapping for all 6 dirs.
    int v_base = lx * 16 + ly * 4 + lz;
    int i1, i2, i3, i4;
    if (dir == 0) {                            // -X
      i1 = v_base;       i2 = v_base + 1;  i3 = v_base + 5;  i4 = v_base + 4;
    } else if (dir == 1) {                     // +X
      i1 = v_base + 16;  i2 = v_base + 20; i3 = v_base + 21; i4 = v_base + 17;
    } else if (dir == 2) {                     // -Y
      i1 = v_base;       i2 = v_base + 16; i3 = v_base + 17; i4 = v_base + 1;
    } else if (dir == 3) {                     // +Y
      i1 = v_base + 4;   i2 = v_base + 5;  i3 = v_base + 21; i4 = v_base + 20;
    } else if (dir == 4) {                     // -Z
      i1 = v_base;       i2 = v_base + 4;  i3 = v_base + 20; i4 = v_base + 16;
    } else if (dir == 5) {                     // +Z
      i1 = v_base + 1;   i2 = v_base + 17; i3 = v_base + 21; i4 = v_base + 5;
    }

    double v1x = vert_cache_x[i1], v1y = vert_cache_y[i1],
           v1z = vert_cache_z[i1];
    double v2x = vert_cache_x[i2], v2y = vert_cache_y[i2],
           v2z = vert_cache_z[i2];
    double v3x = vert_cache_x[i3], v3y = vert_cache_y[i3],
           v3z = vert_cache_z[i3];
    double v4x = vert_cache_x[i4], v4y = vert_cache_y[i4],
           v4z = vert_cache_z[i4];

    double d13_x = v1x - v3x, d13_y = v1y - v3y, d13_z = v1z - v3z;
    double dist13 = d13_x * d13_x + d13_y * d13_y + d13_z * d13_z;
    double d24_x = v2x - v4x, d24_y = v2y - v4y, d24_z = v2z - v4z;
    double dist24 = d24_x * d24_x + d24_y * d24_y + d24_z * d24_z;

    if (dist13 < dist24) {
      // Short diag: v1-v3 shared; leader=(v1,v2,v3), follower=(v1,v3,v4).
      add_triangle(c, v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z, col);
      add_triangle(c, v1x, v1y, v1z, v3x, v3y, v3z, v4x, v4y, v4z, col);
      Triangle @lead = c.triangles[c.active_triangles - 2];
      Triangle @foll = c.triangles[c.active_triangles - 1];
      lead.pair_leader = true;
      lead.pair_split_kind = 0;
      lead.pair_p4x = v4x;
      lead.pair_p4y = v4y;
      lead.pair_p4z = v4z;
      foll.pair_leader = false;
    } else {
      // Long diag: v2-v4 shared; leader=(v1,v2,v4), follower=(v2,v3,v4).
      add_triangle(c, v1x, v1y, v1z, v2x, v2y, v2z, v4x, v4y, v4z, col);
      add_triangle(c, v2x, v2y, v2z, v3x, v3y, v3z, v4x, v4y, v4z, col);
      Triangle @lead = c.triangles[c.active_triangles - 2];
      Triangle @foll = c.triangles[c.active_triangles - 1];
      lead.pair_leader = true;
      lead.pair_split_kind = 1;
      lead.pair_p4x = v3x;
      lead.pair_p4y = v3y;
      lead.pair_p4z = v3z;
      foll.pair_leader = false;
    }
  }
}

