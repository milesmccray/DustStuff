mixin class PlaneShadowLogic {
  // ---------------------------------------------------------------------------
  // Shadow system
  // ---------------------------------------------------------------------------
  // Projects simplified per-component silhouettes of the plane (wings,
  // fuselage, gear pants) onto the voxel terrain along -sun_dir. Each
  // silhouette is subdivided into a grid; every grid vertex raycasts down
  // to the local terrain top so the shadow mesh naturally wraps over
  // ridges, cliffs, and carved caves rather than tearing as a flat decal
  // would. Everything runs in scalar locals — no Vec3 allocations in the
  // hot loop — and every vertex's camera-space projection is computed
  // exactly once and shared between adjacent shadow quads.

  // 3D ray-march from (wx, wy, wz) along -sun_dir. Returns true and writes
  // world-space landing (lx, ly, lz) on first hit; false on void.
  //
  // Per-vertex ray-cast against the chunk triangle soup (the SAME triangles
  // the renderer draws). Cube-DDA against is_solid was wrong for warped
  // terrain — vertices noise-displaced up to ~970u from nominal positions.
  //
  // For each candidate chunk: slab-test the chunk AABB; if entered and
  // closer than best hit, do ray-plane intersection (accept BOTH faces —
  // sun rays don't care about facing), AABB-reject, barycentric inside
  // test. Keep the closest forward hit.
  //
  // NOTE: the previous "buried-sample fast-path" (which returned the
  // sample origin as the landing whenever is_solid reported the sample's
  // cube cell as occupied) was REMOVED here. It was responsible for the
  // "tail-shadow flashes locked to the plane's tail" artifact. Why:
  // is_solid is a cube-grid classifier (400-unit cells), while the
  // rendered terrain is warped up to ~970 world units from nominal cube
  // positions by get_vertex_pos_flat. A cube cell can be is_solid=true
  // while the actual visible triangles are far away, so silhouette
  // vertices briefly passing through such a cell during flight would
  // return "land at self". All 4 corners of a small silhouette (1x1
  // wheel/wing pant, narrow prop blade) can trigger this simultaneously,
  // producing a tight quad rendered AT the plane itself — it clears
  // every downstream guard (discontinuity rejection doesn't fire
  // because edges are short; the mode-B screen-overlap gate doesn't
  // fire because the quad's tx equals the plane's tx).
  //
  // If a silhouette vertex is actually embedded in rendered mesh (rare;
  // physics prevents sustained embedding), the front-face-only raymarch
  // below will either find a forward-facing triangle further along the
  // sun ray (still a valid landing), or return false — in which case
  // the emit loop skips any quad that touches this vertex, and the
  // adjacent quads cover. Both outcomes are strictly better than
  // "shadow locked to the plane body".

  // Build per-piece bundle + filter candidates. Given PLANE-LOCAL
  // corners (lx/ly/lz, length n) + plane basis: bundle axis origin =
  // world-space centroid; bundle radius = max perp distance from any
  // corner to centroid; filter keeps chunks with perp distance <=
  // (radius + half_diag). Strictly over-approximates; per-ray slab/
  // along-ray tests still run on every survivor.
  void shadow_set_piece_bundle_from_local(
      const array<double>& lx, const array<double>& ly,
      const array<double>& lz, int n) {
    // Position + basis sourced from frame-constant shadow_ctx_* class
    // members populated at top of draw_plane_shadow.
    double px  = shadow_ctx_px;  double py  = shadow_ctx_py;  double pz  = shadow_ctx_pz;
    double ofx = shadow_ctx_ofx; double ofy = shadow_ctx_ofy; double ofz = shadow_ctx_ofz;
    double orx = shadow_ctx_orx; double ory = shadow_ctx_ory; double orz = shadow_ctx_orz;
    double oux = shadow_ctx_oux; double ouy = shadow_ctx_ouy; double ouz = shadow_ctx_ouz;
    if (n <= 0) {
      // No corners provided — clear the filter so raymarch falls
      // back to the global candidate list. (sentinel -1)
      shadow_piece_ci_count = -1;
      // Invalidate per-piece reach cache; raymarch batch will fall
      // through to per-call precompute over identity.
      shadow_piece_reach_valid = false;
      return;
    }

    // TRIED AND REVERTED: per-piece filter cache across stable frames
    // (Option #2). Reuse rate ~1-2 frames per 20 at flight velocity,
    // neutral perf. Widening drift threshold reintroduces boundary
    // misclass risk. DON'T retry without a cheaper drift detector.

    // Pass 1: transform corners to world; accumulate centroid.
    double cx = 0.0, cy = 0.0, cz = 0.0;
    for (int i = 0; i < n; i++) {
      double lxi = lx[i], lyi = ly[i], lzi = lz[i];
      double wx = px + lxi * ofx + lyi * orx + lzi * oux;
      double wy = py + lxi * ofy + lyi * ory + lzi * ouy;
      double wz = pz + lxi * ofz + lyi * orz + lzi * ouz;
      shadow_bundle_wx[i] = wx;
      shadow_bundle_wy[i] = wy;
      shadow_bundle_wz[i] = wz;
      cx += wx; cy += wy; cz += wz;
    }
    double inv_n = 1.0 / double(n);
    cx *= inv_n; cy *= inv_n; cz *= inv_n;

    // Pass 2: max perp² distance from axis (perp² = |v|² - (v·d)²).
    // Also track min along-ray (centroid-relative) over corners for the
    // along-ray cull below.
    double dx = -sun_dir.x, dy = -sun_dir.y, dz = -sun_dir.z;
    double max_perp_sq = 0.0;
    double min_along_corner = 1e30;
    for (int i = 0; i < n; i++) {
      double vx = shadow_bundle_wx[i] - cx;
      double vy = shadow_bundle_wy[i] - cy;
      double vz = shadow_bundle_wz[i] - cz;
      double along = vx * dx + vy * dy + vz * dz;
      double perp_sq = vx * vx + vy * vy + vz * vz - along * along;
      if (perp_sq > max_perp_sq) max_perp_sq = perp_sq;
      if (along    < min_along_corner) min_along_corner = along;
    }
    // Take sqrt once, not per-chunk.
    double bundle_radius = sqrt(max_perp_sq);

    // Cross-piece bundle share (within frame): if prior call's bundle
    // is close to ours (center within 100u, radius within 50u), reuse
    // its kept set, mask (NOT bumping mask_gen), reach. Symmetric-diff
    // bound: kept-set delta is a shell ~150u wide; expected miss is
    // 0-2 boundary chunks per share-hit.
    if (shadow_piece_share_valid) {
      double d_cx = cx - shadow_piece_share_cx;
      double d_cy = cy - shadow_piece_share_cy;
      double d_cz = cz - shadow_piece_share_cz;
      double d_center_sq = d_cx * d_cx + d_cy * d_cy + d_cz * d_cz;
      double d_radius_abs = bundle_radius - shadow_piece_share_radius;
      if (d_radius_abs < 0.0) d_radius_abs = -d_radius_abs;
      if (d_center_sq < 10000.0 && d_radius_abs < 50.0) {
        // Reuse: ci_list, mask (gen unchanged), reach already populated.
        shadow_piece_ci_count    = shadow_piece_share_n_kept;
        shadow_piece_reach_top   = shadow_piece_share_reach_top;
        shadow_piece_reach_valid = shadow_piece_share_reach_valid;
        return;
      }
    }

    // Filter candidates. Uses per-chunk TIGHT-AABB center/half-diag
    // (not nominal 1200³ cell): get_vertex_pos_flat warps tris up to
    // ~970u from nominal, so a chunk centered at perp 1500 may have
    // tris at perp 50.
    int n_cand = shadow_candidate_count;
    if (int(shadow_piece_ci_list.length) < n_cand)
      shadow_piece_ci_list.resize(n_cand);
    // Chunk-membership mask for the fast-path cached-tri check (see
    // fast-path entry in shadow_raymarch). Rebuilt per-piece.
    if (int(shadow_piece_chunk_mask.length) < n_cand)
      shadow_piece_chunk_mask.resize(n_cand);
    // Generation-counter membership instead of per-piece zero-fill.
    // Bump gen, then writes use the new gen value; stale slots are
    // auto-invalidated by mismatch.
    //
    // Wraparound guard: at gen ≥ 2^30 do a one-shot full reset
    // (~26 hours of continuous play; reset itself is one pass over
    // the mask).
    const int SHADOW_MASK_GEN_RESET = 0x40000000;  // 2^30
    if (shadow_piece_mask_gen >= SHADOW_MASK_GEN_RESET) {
      int n_mask = int(shadow_piece_chunk_mask.length);
      for (int mci = 0; mci < n_mask; mci++) shadow_piece_chunk_mask[mci] = 0;
      shadow_piece_mask_gen = 0;
    }
    shadow_piece_mask_gen++;
    int mask_gen = shadow_piece_mask_gen;

    // Member-array handle hoist out of per-chunk filter loop.
    array<double> @l_tcx       = @shadow_cand_tcx;
    array<double> @l_tcy       = @shadow_cand_tcy;
    array<double> @l_tcz       = @shadow_cand_tcz;
    array<double> @l_half_diag = @shadow_cand_half_diag;
    // 1D along-sun extent (= |sx|·hx + |sy|·hy + |sz|·hz, ≤ 3D
    // half_diag by Cauchy-Schwarz) — tighter reject than half_diag.
    array<double> @l_along_ext = @shadow_cand_along_sun_extent;
    array<int>    @l_ci_list   = @shadow_piece_ci_list;
    array<int>    @l_mask      = @shadow_piece_chunk_mask;
    array<double> @l_chunk_dot_dir = @shadow_cand_chunk_dot_dir;

    int n_kept = 0;
    double reach_top = 0.0;
    bool   reach_valid = false;
    for (int ci = 0; ci < n_cand; ci++) {
      // Tight-AABB center (geometry-extent midpoint), read from the
      // populate-time cache.
      double tcx = l_tcx[ci];
      double tcy = l_tcy[ci];
      double tcz = l_tcz[ci];

      double vx = tcx - cx;
      double vy = tcy - cy;
      double vz = tcz - cz;
      double along = vx * dx + vy * dy + vz * dz;
      // Along-ray cull: any chunk whose along-sun-extent FAR face
      // (along + along_sun_extent) lies behind the farthest-back
      // corner (min_along_corner) is unreachable by every ray in
      // the bundle. Uses 1D along_sun_extent (tighter than 3D
      // half_diag by ~10-30%).
      double along_ext_ci = l_along_ext[ci];
      if (along + along_ext_ci < min_along_corner) continue;
      // Deferred half_diag fetch: along-cull above doesn't need it;
      // only the perp-cylinder test below does.
      double half_diag = l_half_diag[ci];
      double keep_radius = bundle_radius + half_diag;
      double keep_radius_sq = keep_radius * keep_radius;
      double perp_sq = vx * vx + vy * vy + vz * vz - along * along;
      if (perp_sq <= keep_radius_sq) {
        l_ci_list[n_kept++] = ci;
        l_mask[ci] = mask_gen;
        // reach_k inline; along_ext_ci reused from the cull.
        double reach_k = l_chunk_dot_dir[ci] + along_ext_ci;
        if (!reach_valid || reach_k > reach_top) {
          reach_top = reach_k;
          reach_valid = true;
        }
      }
    }
    shadow_piece_ci_count = n_kept;

    // Per-piece reach (= max_K(chunk_dot_dir + along_sun_extent) over
    // kept set) was folded into the filter loop above.
    shadow_piece_reach_top   = reach_top;
    shadow_piece_reach_valid = reach_valid;

    // Populate share cache for the next piece's reuse check.
    shadow_piece_share_valid       = true;
    shadow_piece_share_cx          = cx;
    shadow_piece_share_cy          = cy;
    shadow_piece_share_cz          = cz;
    shadow_piece_share_radius      = bundle_radius;
    shadow_piece_share_n_kept      = n_kept;
    shadow_piece_share_reach_top   = reach_top;
    shadow_piece_share_reach_valid = reach_valid;

    // TRIED AND REVERTED: Lever F per-piece oblique probe + cam-vis
    // check. Probe overhead ~800µs/frame paid always, skips only 5-10%
    // of frames. Net regression. DON'T retry without a cheaper
    // detection (e.g. reuse fade-gate anchor normals).
  }

  // ---- pcache reset helper ----
  // Bumps the hash generation counter so prior-piece hash slots auto-
  // invalidate, AND zeros pcache_count so Pass A starts with an empty
  // cache view. Wraparound guard: at gen >= 2^30 a one-shot full clear
  // of shadow_pcache_hash_gen[] lets the counter roll back to 0.
  void shadow_pcache_reset() {
    shadow_pcache_count = 0;
    if (shadow_pcache_hash_gen_cur >= SHADOW_PCACHE_HASH_GEN_RESET) {
      int hsize = int(shadow_pcache_hash_gen.length);
      for (int i = 0; i < hsize; i++) shadow_pcache_hash_gen[i] = 0;
      shadow_pcache_hash_gen_cur = 0;
    }
    shadow_pcache_hash_gen_cur++;
  }

  // Clear the piece filter (sentinel -1 = no filter active). Defensive;
  // next shadow_set_piece_bundle_from_local overwrites the list anyway.
  void shadow_clear_piece_bundle() {
    shadow_piece_ci_count = -1;
    // Also invalidate per-piece reach cache so a stray batch call
    // between clear and next set doesn't read stale reach.
    shadow_piece_reach_valid = false;
  }

  // Ray-bundle batched raymarch. Inputs in shadow_batch_wx/wy/wz[0..
  // ray_count-1]; outputs in shadow_batch_lx/ly/lz/hit/hit_plane_key/
  // void_reason. All rays share -sun_dir; iteration is (chunk × tri × ray).
  //
  // Phase 0 — per-ray init + direction-shared constants.
  // Phase 1 — per-ray fast path (per-piece sf_idx cache).
  // Phase 2 — outer chunk loop; per-ray slab pass builds live[]; inner
  //           tri loop walks chunk's sf_* slice; innermost ray loop.
  // Phase 3 — tail flush: void_reason, plane key, profile, fp cache.
  //
  // CORRECTNESS: every reject/hit path matches scalar shadow_raymarch.
  void shadow_raymarch_batch(int ray_count) {
    // Defensive cap; shadow_project_silhouette already guards n_verts>64.
    if (ray_count > 64) ray_count = 64;
    if (ray_count <= 0) return;

    // Direction-shared constants. Same ORIGIN_LIFT as scalar version.
    double dx = -sun_dir.x, dy = -sun_dir.y, dz = -sun_dir.z;
    double icpx = interp_camera_pos.x;
    double icpy = interp_camera_pos.y;
    double icpz = interp_camera_pos.z;
    double half_cs = shadow_half_cs;
    // Per-chunk tight half_diag (shadow_cand_half_diag[ci]) drives the
    // per-ray pre-reject. CAUTION: nominal-cell loose bound (half_cs * √3)
    // would under-cover terrain-warped tris (vertices ≈970u outside the
    // nominal 1200³ cell) and false-reject valid hits — DON'T revert.

    const double ORIGIN_LIFT = 20.0;
    const double INF = 1e30;
    double inv_dx = (dx != 0.0) ? 1.0 / dx : ((dx >= 0.0) ?  INF : -INF);
    double inv_dy = (dy != 0.0) ? 1.0 / dy : ((dy >= 0.0) ?  INF : -INF);
    double inv_dz = (dz != 0.0) ? 1.0 / dz : ((dz >= 0.0) ?  INF : -INF);

    // ---- Flat-array handle hoists (match scalar) ----
    array<double>     @sf_nx     = @shadow_cand_sf_nx;
    array<double>     @sf_ny     = @shadow_cand_sf_ny;
    array<double>     @sf_nz     = @shadow_cand_sf_nz;
    array<double>     @sf_pd     = @shadow_cand_sf_pd;
    array<double>     @sf_denom     = @shadow_cand_sf_denom;
    array<double>     @sf_inv_denom = @shadow_cand_sf_inv_denom;
    // eps recomputed inline as 1.0e-6 * fdenom after sf_denom load.
    array<double>     @sf_minx = @shadow_cand_sf_min_x;
    array<double>     @sf_maxx = @shadow_cand_sf_max_x;
    array<double>     @sf_miny = @shadow_cand_sf_min_y;
    array<double>     @sf_maxy = @shadow_cand_sf_max_y;
    array<double>     @sf_minz = @shadow_cand_sf_min_z;
    array<double>     @sf_maxz = @shadow_cand_sf_max_z;
    // sf_cx/cy/cz hold triangle centroid; sf_max_corner_sq holds
    // tri.bound_radius² (tight bounding sphere).
    array<double>     @sf_cx   = @shadow_cand_sf_cx;
    array<double>     @sf_cy   = @shadow_cand_sf_cy;
    array<double>     @sf_cz   = @shadow_cand_sf_cz;
    array<double>     @sf_max_corner_sq = @shadow_cand_sf_max_corner_sq;
    // Pre-projected (u,v) of triangle centroid.
    array<double>     @sf_cu   = @shadow_cand_sf_cu;
    array<double>     @sf_cv   = @shadow_cand_sf_cv;
    // Stage-2b barycentric flat-arrays.
    array<double>     @sf_invD = @shadow_cand_sf_invD;
    array<double>     @sf_p1x  = @shadow_cand_sf_p1x;
    array<double>     @sf_p1y  = @shadow_cand_sf_p1y;
    array<double>     @sf_p1z  = @shadow_cand_sf_p1z;
    array<double>     @sf_v0x  = @shadow_cand_sf_v0x;
    array<double>     @sf_v0y  = @shadow_cand_sf_v0y;
    array<double>     @sf_v0z  = @shadow_cand_sf_v0z;
    array<double>     @sf_v1x  = @shadow_cand_sf_v1x;
    array<double>     @sf_v1y  = @shadow_cand_sf_v1y;
    array<double>     @sf_v1z  = @shadow_cand_sf_v1z;
    array<double>     @sf_d00  = @shadow_cand_sf_d00;
    array<double>     @sf_d01  = @shadow_cand_sf_d01;
    array<double>     @sf_d11  = @shadow_cand_sf_d11;
    // Pre-quantized per-tri plane key (lazy-populated; Phase 3 reads).
    array<int64>      @sf_pkey = @shadow_cand_sf_packed_key;
    // Bucket-grid hoists.
    array<double>     @bk_origin_u   = @shadow_cand_bucket_origin_u;
    array<double>     @bk_origin_v   = @shadow_cand_bucket_origin_v;
    array<double>     @bk_inv_size_u = @shadow_cand_bucket_inv_size_u;
    array<double>     @bk_inv_size_v = @shadow_cand_bucket_inv_size_v;
    array<int>        @bk_tri_start  = @shadow_cand_bucket_tri_start;
    array<int>        @bk_tri_count  = @shadow_cand_bucket_tri_count;
    array<int>        @bk_tri_idx    = @shadow_cand_bucket_tri_idx;
    array<int>        @bk_live       = @shadow_batch_bucket_live;
    array<int>        @bk_live_count = @shadow_batch_bucket_live_count;
    // Touched-buckets sparse list (avoids 0..16 iteration in inner loop).
    array<int>        @bk_touched    = @shadow_batch_touched_buckets;
    // Flattened per-bucket parallel scratch. _bt written back on cam-vis
    // hits to preserve intra-bucket best_t tightening.
    array<double>     @bk_live_wx    = @shadow_batch_bucket_live_wx;
    array<double>     @bk_live_wy    = @shadow_batch_bucket_live_wy;
    array<double>     @bk_live_wz    = @shadow_batch_bucket_live_wz;
    array<double>     @bk_live_bt    = @shadow_batch_bucket_live_bt;
    // Per-slot scattered (u,v) projection for inner-loop 2D pre-reject.
    array<double>     @bk_live_u     = @shadow_batch_bucket_live_u;
    array<double>     @bk_live_v     = @shadow_batch_bucket_live_v;
    // Per-bucket Z-bounds for tri-level Z-cull. dz<0 (sun_dir.z>=0.1)
    // makes ray Z monotonic; inner tri loop short-circuits tris whose
    // [tri_min_z, tri_max_z] disjoint from [bk_z_min, bk_z_max].
    array<double>     @bk_z_min      = @shadow_batch_bk_z_min;
    array<double>     @bk_z_max      = @shadow_batch_bk_z_max;
    // Per-chunk metadata handles (member-dispatch hoist).
    array<double>     @cc_dot_dir       = @shadow_cand_chunk_dot_dir;
    array<double>     @cc_along_ext     = @shadow_cand_along_sun_extent;
    array<double>     @cc_along_ext_tail = @shadow_cand_max_along_sun_extent_tail;
    array<double>     @cc_t_near_x      = @shadow_cand_c_t_near_x;
    array<double>     @cc_t_far_x       = @shadow_cand_c_t_far_x;
    array<double>     @cc_t_near_y      = @shadow_cand_c_t_near_y;
    array<double>     @cc_t_far_y       = @shadow_cand_c_t_far_y;
    array<double>     @cc_t_near_z      = @shadow_cand_c_t_near_z;
    array<double>     @cc_t_far_z       = @shadow_cand_c_t_far_z;
    array<double>     @pcc_t_near_x     = @shadow_cand_pc_t_near_x;
    array<double>     @pcc_t_far_x      = @shadow_cand_pc_t_far_x;
    array<double>     @pcc_t_near_y     = @shadow_cand_pc_t_near_y;
    array<double>     @pcc_t_far_y      = @shadow_cand_pc_t_far_y;
    array<double>     @pcc_t_near_z     = @shadow_cand_pc_t_near_z;
    array<double>     @pcc_t_far_z      = @shadow_cand_pc_t_far_z;
    // Per-chunk no-warp flag (1 = tight AABB == nominal cell AABB;
    // pos-rescue can't recover anything new).
    array<int>        @cc_no_warp       = @shadow_cand_no_warp;
    array<double>     @bru           = @shadow_batch_perp_u;
    array<double>     @brv           = @shadow_batch_perp_v;
    // Per-ray R·d (along_t pre-reject); written Phase 0, used Phase 2.
    array<double>     @brdd          = @shadow_batch_ray_dot_dir;
    // Sun-perpendicular axes hoisted to locals for inner bucket-lookup.
    double pux = shadow_sun_perp_u_x;
    double puy = shadow_sun_perp_u_y;
    double puz = shadow_sun_perp_u_z;
    double pvx = shadow_sun_perp_v_x;
    double pvy = shadow_sun_perp_v_y;
    double pvz = shadow_sun_perp_v_z;
    // Batched state array hoists.
    array<double>     @bwx    = @shadow_batch_wx;
    array<double>     @bwy    = @shadow_batch_wy;
    array<double>     @bwz    = @shadow_batch_wz;
    // Lifted ray origin (origin - dx*ORIGIN_LIFT). bwx/y/z stays
    // unmodified post-batch so pcache can read them.
    array<double>     @lwx    = @shadow_batch_lwx;
    array<double>     @lwy    = @shadow_batch_lwy;
    array<double>     @lwz    = @shadow_batch_lwz;
    array<double>     @blx    = @shadow_batch_lx;
    array<double>     @bly    = @shadow_batch_ly;
    array<double>     @blz    = @shadow_batch_lz;
    array<double>     @bbt    = @shadow_batch_best_t;
    array<int>        @bwsf   = @shadow_batch_winner_sf_idx;
    array<int>        @bwci   = @shadow_batch_winner_ci;
    // Sparse active ray list. Phase 0 appends non-cached rays; Phase 2
    // uses swap-and-pop compaction; defensive `r < 0` guard kept.
    array<int>        @bactive_list = @shadow_batch_active_list;
    int bactive_count = 0;
    // Silhouette-output handles + cam scalars folded into Phase 3 tail.
    array<double>     @sh_vx  = @shadow_vx;
    array<double>     @sh_vy  = @shadow_vy;
    array<double>     @sh_vz  = @shadow_vz;
    // Validity encoded in sh_hpk[r] != 0 (provably nonzero on hit;
    // explicit 0 written on miss).
    array<int64>      @sh_hpk = @shadow_hit_plane_key;
    array<double>     @sh_tx  = @shadow_tx;
    array<double>     @sh_ty  = @shadow_ty;
    array<double>     @sh_tz  = @shadow_tz;
    double mcfx = shadow_cfx,  mcfy = shadow_cfy,  mcfz = shadow_cfz, mcdf = shadow_cdf;
    double mclx = shadow_clx,  mcly = shadow_cly,  mclz = shadow_clz, mcdl = shadow_cdl;
    double mcux = shadow_cux,  mcuy = shadow_cuy,  mcuz = shadow_cuz, mcdu = shadow_cdu;

    // Phase-B chunk-walk break state. pbrk_first_ci = break ci_it (-1
    // = no break). batch_max_rdd = max_r(R·d) for safety inequality.
    int    pbrk_first_ci         = -1;
    double batch_max_rdd         = 0.0;

    // Per-piece per-ray sf_idx cache. ray_cache_offset advances by
    // ray_count per sub-quad so triangle 2 doesn't overwrite tri 1.
    int piece_slot = shadow_active_piece_idx;
    int ray_cache_offset = shadow_piece_ray_cursor;
    if (ray_cache_offset + ray_count > SHADOW_LH_SLOTS_PER_PIECE) {
      // Ring-buffer wrap: overflow resets cursor to 0, overwriting the
      // OLDEST cached hits. ray_count<=64 keeps [0, ray_count) in-bounds.
      ray_cache_offset = 0;
    }
    int piece_base = piece_slot * SHADOW_LH_SLOTS_PER_PIECE + ray_cache_offset;
    // Use rebuild-tracked populated count, not .length (sf_* not trimmed).
    int sf_len = shadow_cand_sf_total;
    int piece_mask_len  = int(shadow_piece_chunk_mask.length);
    // Hoists for Phase 1's cidx-change branch. shadow_piece_mask_gen is
    // set once per piece and stays invariant for the duration of this
    // raymarch_batch call.
    array<int> @l_sf_chunk_ci_b1 = @shadow_cand_sf_chunk_ci;
    array<int> @l_piece_mask_b1  = @shadow_piece_chunk_mask;
    int        l_piece_mask_gen   = shadow_piece_mask_gen;
    array<int> @l_lh_sf_idx       = @shadow_last_hit_sf_idx;

    // ---- ci_list selection ----
    // Hoisted before Phase 0 so the per-ray reach precompute (below)
    // can iterate the piece-filtered candidate set instead of the full
    // candidate list. Phase 2 main loop reads the same locals.
    array<int> @ci_list;
    int npc;
    if (shadow_piece_ci_count >= 0) {
      @ci_list = @shadow_piece_ci_list;
      npc = shadow_piece_ci_count;
    } else {
      int ncc = shadow_candidate_count;
      if (int(shadow_identity_ci_list.length) < ncc) {
        shadow_identity_ci_list.resize(ncc);
        for (int idi = 0; idi < ncc; idi++) shadow_identity_ci_list[idi] = idi;
      }
      @ci_list = @shadow_identity_ci_list;
      npc = ncc;
    }

    // Per-batch reach (sentinel-anchor fix). Tightest upper bound on
    // hit-t for any ray in this batch; clamps bbt[r] below the global
    // shadow_max_ray_dist cap. Bound: tri_t <= max_K(center·d +
    // along_sun_extent) - R·d (1D extent ~10-30% tighter than 3D
    // half_diag). Hoisted to per-piece via piece-bundle setter; fallback
    // (no piece filter) keeps the per-call compute.
    double batch_reach_top;
    bool   batch_reach_valid;
    if (shadow_piece_ci_count >= 0 && shadow_piece_reach_valid) {
      batch_reach_top   = shadow_piece_reach_top;
      batch_reach_valid = true;
    } else {
      batch_reach_top   = 0.0;
      batch_reach_valid = false;
      for (int kk = 0; kk < npc; kk++) {
        uint kci = uint(ci_list[kk]);
        double reach_k = shadow_cand_chunk_dot_dir[kci]
                       + shadow_cand_along_sun_extent[kci];
        if (!batch_reach_valid || reach_k > batch_reach_top) {
          batch_reach_top = reach_k;
          batch_reach_valid = true;
        }
      }
    }

    // Cached-ray skip: pre-filled by project_silhouette via pcache hit.
    array<bool> @b_cached = @shadow_batch_cached;
    // In-queue alias map. Aliased rays (b_alias[r]>=0) are duplicates;
    // outputs filled by alias copy-back after raymarch — Phase 3 MUST
    // skip them to avoid corrupting last_hit_sf_idx with stale bwsf.
    array<int> @b_alias = @shadow_batch_alias_to;

    // ---- Phase 0: per-ray initialization ----
    for (int r = 0; r < ray_count; r++) {
      // Cached ray: skip Phase 0 init (Phase 1/2 won't visit; per-ray
      // reach clamp below would clobber cached bbt).
      if (b_cached[r]) {
        // Inactive by NOT appending to bactive_list.
        continue;
      }
      // Write ORIGIN_LIFT-shifted origin to lwx/y/z; bwx/y/z preserved
      // for post-batch pcache append.
      double wx_r = bwx[r] - dx * ORIGIN_LIFT;
      double wy_r = bwy[r] - dy * ORIGIN_LIFT;
      double wz_r = bwz[r] - dz * ORIGIN_LIFT;
      lwx[r] = wx_r;
      lwy[r] = wy_r;
      lwz[r] = wz_r;
      // Per-ray R·d (along_t pre-reject); inner loop reduces to one
      // subtraction. Reach clamp below depends on rdd_r.
      double rdd_r = wx_r * dx + wy_r * dy + wz_r * dz;
      brdd[r]     = rdd_r;
      // Per-ray reach clamp (sentinel-anchor fix). Tightens stage-1
      // reject for un-hit rays. Floor at 0 (degenerate at grid edges).
      double per_ray_reach = shadow_max_ray_dist;
      if (batch_reach_valid) {
        double reach_r = batch_reach_top - rdd_r;
        if (reach_r < per_ray_reach) per_ray_reach = reach_r;
        if (per_ray_reach < 0.0) per_ray_reach = 0.0;
      }
      bbt[r]   = per_ray_reach;
      // bwsf=-1 = validity sentinel (Phase 3 reads as hit_found = bwsf>=0).
      bwsf[r]  = -1;
      // bwci tracks chunk-index of best hit for break-safety scan (bun
      // regression sentinel).
      bwci[r]  = -1;
      // Per-ray (u,v) sun-perpendicular projection — constant along
      // parallel-ray travel.
      bru[r] = wx_r * pux + wy_r * puy + wz_r * puz;
      brv[r] = wx_r * pvx + wy_r * pvy + wz_r * pvz;
      // batch_max_rdd reduction folded inline.
      if (bactive_count == 0 || rdd_r > batch_max_rdd) batch_max_rdd = rdd_r;
      bactive_list[bactive_count++] = r;
    }


    // ---- Phase 1: per-ray fast path (per-ray sf_idx cache) ----
    // Each ray reads its own cached sf_idx. Same-cidx runs share
    // hoisted per-tri state. Matches scalar tri test (plane+AABB+bary+cam_f).
    {
      const double FP_AABB_EPS = 1e-3;
      // prev_cidx: -2 = none loaded (forces reload), >=0 = last
      // processed cidx (matching current ray reuses hoisted state).
      // cidx_runnable: filter+denom verdict for current prev_cidx.
      int prev_cidx = -2;
      bool cidx_runnable = false;
      // Per-cidx hoisted state — refreshed when cidx changes.
      double fnx = 0.0, fny = 0.0, fnz = 0.0, fpd = 0.0;
      // Pre-negation hoist (mirror of main-loop version).
      double fneg_nx = 0.0, fneg_ny = 0.0, fneg_nz = 0.0, fneg_pd = 0.0;
      double fdenom = 0.0, fdenom_eps = 0.0, f_inv_den = 0.0;
      double f_minx = 0.0, f_maxx = 0.0;
      double f_miny = 0.0, f_maxy = 0.0;
      double f_minz = 0.0, f_maxz = 0.0;
      // tri_fetched gates per-cidx-run reload of bary fields.
      bool   tri_fetched = false;
      double f_invD = 0.0;
      double f_p1x = 0.0, f_p1y = 0.0, f_p1z = 0.0;
      double f_v0x = 0.0, f_v0y = 0.0, f_v0z = 0.0;
      double f_v1x = 0.0, f_v1y = 0.0, f_v1z = 0.0;
      double f_d00 = 0.0, f_d01 = 0.0, f_d11 = 0.0;
      double f_ccx = 0.0, f_ccy = 0.0, f_ccz = 0.0;

      // Iterate sparse active list (Phase 1 only reads, no flips).
      for (int i = 0; i < bactive_count; i++) {
        int r = bactive_list[i];
        int cidx = l_lh_sf_idx[piece_base + r];
        if (cidx < 0 || cidx >= sf_len) {
          // Cold/stale slot. -2 prevents coincidental match next iter.
          prev_cidx = -2;
          continue;
        }
        if (cidx != prev_cidx) {
          // Cached tri must belong to a chunk currently in this piece's
          // filter (else stale hit gives wrong-pose result).
          bool excluded = false;
          if (shadow_piece_ci_count >= 0) {
            int cached_chunk_ci = l_sf_chunk_ci_b1[cidx];
            // Membership = mask cell == current gen.
            if (cached_chunk_ci < piece_mask_len &&
                l_piece_mask_b1[cached_chunk_ci] != l_piece_mask_gen) {
              excluded = true;
            }
          }
          if (excluded) {
            cidx_runnable = false;
          } else {
            // Reload 13 sf_* per-tri fields.
            fnx        = sf_nx[cidx];
            fny        = sf_ny[cidx];
            fnz        = sf_nz[cidx];
            fpd        = sf_pd[cidx];
            fneg_nx    = -fnx;
            fneg_ny    = -fny;
            fneg_nz    = -fnz;
            fneg_pd    = -fpd;
            fdenom     = sf_denom[cidx];
            fdenom_eps = 1.0e-6 * fdenom;
            f_inv_den  = sf_inv_denom[cidx];
            f_minx     = sf_minx[cidx];
            f_maxx     = sf_maxx[cidx];
            f_miny     = sf_miny[cidx];
            f_maxy     = sf_maxy[cidx];
            f_minz     = sf_minz[cidx];
            f_maxz     = sf_maxz[cidx];
            // Defensive sun-back check — guards divide-by-near-zero.
            cidx_runnable = (fdenom < -1e-9);
            tri_fetched = false;
          }
          prev_cidx = cidx;
        }
        if (!cidx_runnable) continue;

        // Read lifted origin (Phase 0 wrote lwx/y/z).
        double wx_r = lwx[r], wy_r = lwy[r], wz_r = lwz[r];
        double fnumer = fneg_nx * wx_r + fneg_ny * wy_r + fneg_nz * wz_r + fneg_pd;
        // Division-free stage-1.
        if (fnumer >= fdenom_eps || fnumer <= bbt[r] * fdenom) {
          continue;
        }
        double ft = fnumer * f_inv_den;
        double fhx = wx_r + dx * ft;
        double fhy = wy_r + dy * ft;
        double fhz = wz_r + dz * ft;
        if (fhx < f_minx - FP_AABB_EPS || fhx > f_maxx + FP_AABB_EPS ||
            fhy < f_miny - FP_AABB_EPS || fhy > f_maxy + FP_AABB_EPS ||
            fhz < f_minz - FP_AABB_EPS || fhz > f_maxz + FP_AABB_EPS) {
          continue;
        }
        // Bary + cam_f — sf_* fields hoisted once per same-cidx run.
        if (!tri_fetched) {
          f_invD = sf_invD[cidx];
          f_p1x = sf_p1x[cidx]; f_p1y = sf_p1y[cidx]; f_p1z = sf_p1z[cidx];
          f_v0x = sf_v0x[cidx]; f_v0y = sf_v0y[cidx]; f_v0z = sf_v0z[cidx];
          f_v1x = sf_v1x[cidx]; f_v1y = sf_v1y[cidx]; f_v1z = sf_v1z[cidx];
          f_d00 = sf_d00[cidx]; f_d01 = sf_d01[cidx]; f_d11 = sf_d11[cidx];
          f_ccx = sf_cx[cidx]; f_ccy = sf_cy[cidx]; f_ccz = sf_cz[cidx];
          tri_fetched = true;
        }
        if (f_invD == 0.0) {
          continue;
        }
        double f_v2x = fhx - f_p1x;
        double f_v2y = fhy - f_p1y;
        double f_v2z = fhz - f_p1z;
        double f_d20 = f_v2x * f_v0x + f_v2y * f_v0y + f_v2z * f_v0z;
        double f_d21 = f_v2x * f_v1x + f_v2y * f_v1y + f_v2z * f_v1z;
        double f_vb  = (f_d11 * f_d20 - f_d01 * f_d21) * f_invD;
        double f_wb  = (f_d00 * f_d21 - f_d01 * f_d20) * f_invD;
        double f_ub  = 1.0 - f_vb - f_wb;
        if (f_ub < -1e-4 || f_vb < -1e-4 || f_wb < -1e-4) {
          continue;
        }
        double f_cam_f = (f_ccx - icpx) * fnx +
                         (f_ccy - icpy) * fny +
                         (f_ccz - icpz) * fnz;
        if (f_cam_f < 0.0) {
          // Cam-visible seed; main loop may tighten.
          bbt[r]   = ft;
          blx[r]   = fhx; bly[r] = fhy; blz[r] = fhz;
          bwsf[r]  = cidx;  // lockstep validity write
          bwci[r] = 0;      // fast-path seed -> wci=0
        }
        // Cam-invis hits silently ignored on fast path.
      }
    }

    // ---- Phase 2: main loop (outer chunks, middle rays, inner tris) ----
    // Top-of-batch bk_live_count reset handles state leaked from prior
    // batches and the first chunk's start zero postcondition. Per-chunk
    // tail iterates touched list only. 16 = SHADOW_BUCKETS_PER_CHUNK.
    for (int bbi0 = 0; bbi0 < 16; bbi0++) {
      bk_live_count[bbi0] = 0;
    }
    // Carry-forward max_bbt_active for pre-middle-pass break check.
    // Monotonicity invariant: max_bbt_active(K-1) >= max_bbt_active(K)
    // because K's alive set is a subset of K-1's and hits only tighten
    // bbt[r] — pre-check with K-1's value is conservative (never false-
    // breaks). Init +inf so chunk 0 never fires.
    double max_bbt_carry = 1.0e30;
    for (int ci_it = 0; ci_it < npc; ci_it++) {
      uint ci = uint(ci_list[ci_it]);

      // ---- Chunk metadata hoist (ONCE per chunk) ----
      double chunk_dot_dir         = cc_dot_dir[ci];
      // 1D along-sun extent (tighter than 3D half_diag by ~10-30%).
      double chunk_half_diag_tight = cc_along_ext[ci];
      double chunk_half_diag_tail  = cc_along_ext_tail[ci];
      // No-warp flag — skip pos-rescue when tight==nominal AABB.
      bool   chunk_no_warp         = (cc_no_warp[ci] != 0);
      // Lazy fetch of slab + pos-AABB metadata.
      bool   slab_geom_fetched = false;
      double c_t_near_x = 0.0, c_t_far_x = 0.0;
      double c_t_near_y = 0.0, c_t_far_y = 0.0;
      double c_t_near_z = 0.0, c_t_far_z = 0.0;
      bool   pos_geom_fetched = false;
      double pc_t_near_x = 0.0, pc_t_far_x = 0.0;
      double pc_t_near_y = 0.0, pc_t_far_y = 0.0;
      double pc_t_near_z = 0.0, pc_t_far_z = 0.0;

      // Phase-B break gate runs AFTER middle pass; uses max_bbt_active
      // accumulated during the loop. Safety invariants for the break:
      //   - Sort monotonicity (low-32-bit pack — see
      //     feedback_as_int64_sort_quirk.md) means along_t grows along tail.
      //   - bbt[r] only shrinks (hits tighten it).
      //   - chunk_half_diag_tail non-increasing through the tail.
      //   - SAFETY_MARGIN=0.01 absorbs Stage-2a AABB_EPS*sqrt(3) slack.
      // bactive_list compaction is monotonic.
      int chunk_bucket_meta_base = int(ci) << 4;  // 16 buckets/chunk

      // Pre-middle-pass break check. Uses K-1's max_bbt as upper bound
      // on K's (proof above). Skipped on chunk 0 (carry == 1e30).
      if (pbrk_first_ci < 0 && ci_it > 0) {
        const double SAFETY_MARGIN_PRE = 0.01;
        if (chunk_dot_dir - batch_max_rdd
                > max_bbt_carry + chunk_half_diag_tail + SAFETY_MARGIN_PRE) {
          pbrk_first_ci = ci_it;
          break;
        }
      }

      // Lazy bucket-geometry fetch (first ray to reach scatter step).
      bool   bk_geom_fetched = false;
      double bk_ou = 0.0, bk_ov = 0.0, bk_isu = 0.0, bk_isv = 0.0;

      // ---- Middle per-ray pass: active-filter + max_bbt + slab + scatter ----
      // Single pass per ray:
      //   (1) bactive skip
      //   (2) along_t = chunk_dot_dir - brdd[r]
      //   (3) tail-bound active filter (clears bactive when along_t >
      //       bbt + tail_max)
      //   (4) max_bbt_active accumulation for break gate
      //   (5) per-chunk tight-bound pre-reject
      //   (6) slab test + position-AABB rescue
      //   (7) bucket scatter into bk_live[*]
      // Per-chunk bk_live_count + bk_z_min/max resets deferred to
      // first-ray-in-bucket; per-chunk tail walks bk_touched.
      int  live_count = 0;
      // -1.0 sentinel collapses any_active + max_bbt_active pair
      // (best_t_r is non-negative). Post-loop any_active = (max_bbt >= 0).
      double max_bbt_active = -1.0;
      // Touched-bucket list — chunks typically touch 3-4 of 16 buckets.
      int n_touched = 0;
      // Sparse active list with swap-and-pop compaction. Defensive
      // `r < 0` guard KEPT as dead code (cheap, latent-path protection).
      int i = 0;
      while (i < bactive_count) {
        int r = bactive_list[i];
        if (r < 0) { i++; continue; }
        double best_t_r = bbt[r];
        double rdd_r    = brdd[r];

        // (2) along_t — single compute, reused by (3) and (5).
        double along_t = chunk_dot_dir - rdd_r;

        // (3) Tail-bound active filter. Swap-and-pop: drop ray r,
        // do NOT advance i (swapped-in ray retests THIS chunk).
        if (along_t > best_t_r + chunk_half_diag_tail) {
          bactive_count--;
          bactive_list[i] = bactive_list[bactive_count];
          continue;  // re-test slot i
        }

        // (4) Track max_bbt over active rays (sentinel -1 folds gate).
        if (best_t_r > max_bbt_active) {
          max_bbt_active = best_t_r;
        }

        // (5) Per-chunk pre-reject (tight bound). CAUTION: along-back
        // doesn't kill bactive — ray could become interested in later
        // chunks where along_t grows positive again.
        if (along_t > best_t_r + chunk_half_diag_tight) {
          i++; continue;
        }
        if (along_t + chunk_half_diag_tight < 0.0) {
          i++; continue;
        }

        // (6)/(7) Survived pre-rejects; slab + bucket scatter. Bucket
        // scatter + Z-cull bounds use lifted coords (lwx/y/z) to match
        // inner tri loop's stage-1 numer = -plane*(lifted_origin).
        double wx_r = lwx[r], wy_r = lwy[r], wz_r = lwz[r];
        double rwx_inv_r   = wx_r * inv_dx;
        double rwy_inv_r   = wy_r * inv_dy;
        double rwz_inv_r   = wz_r * inv_dz;

        // Lazy fetch of cc_t_* slab metadata on first surviving ray.
        if (!slab_geom_fetched) {
          c_t_near_x = cc_t_near_x[ci];
          c_t_far_x  = cc_t_far_x[ci];
          c_t_near_y = cc_t_near_y[ci];
          c_t_far_y  = cc_t_far_y[ci];
          c_t_near_z = cc_t_near_z[ci];
          c_t_far_z  = cc_t_far_z[ci];
          slab_geom_fetched = true;
        }

        // Ray-AABB slab (tight). Near/far face selection hoisted to
        // per-chunk (sign of inv_d batch-constant — no per-ray swap).
        double tminc = c_t_near_x - rwx_inv_r;
        double tmaxc = c_t_far_x  - rwx_inv_r;
        double tmin_y_v = c_t_near_y - rwy_inv_r;
        double tmax_y_v = c_t_far_y  - rwy_inv_r;
        if (tmin_y_v > tminc) tminc = tmin_y_v;
        if (tmax_y_v < tmaxc) tmaxc = tmax_y_v;
        int slab_outcome;
        if (tminc > tmaxc) {
          slab_outcome = 0;
        } else {
          double tmin_z_v = c_t_near_z - rwz_inv_r;
          double tmax_z_v = c_t_far_z  - rwz_inv_r;
          if (tmin_z_v > tminc) tminc = tmin_z_v;
          if (tmax_z_v < tmaxc) tmaxc = tmax_z_v;
          if      (tminc > tmaxc)     slab_outcome = 0;
          else if (tmaxc < 0.0)       slab_outcome = 1;
          else if (tminc >= best_t_r) slab_outcome = 2;
          else                        slab_outcome = 3;
        }

        // Position-AABB rescue (outcome 0 only). Gated on !chunk_no_warp
        // — when tight==nominal, rescue would redo the failed test.
        if (slab_outcome == 0 && !chunk_no_warp) {
          // Lazy pcc_t_* fetch — first ray to reach rescue branch.
          if (!pos_geom_fetched) {
            pc_t_near_x = pcc_t_near_x[ci];
            pc_t_far_x  = pcc_t_far_x[ci];
            pc_t_near_y = pcc_t_near_y[ci];
            pc_t_far_y  = pcc_t_far_y[ci];
            pc_t_near_z = pcc_t_near_z[ci];
            pc_t_far_z  = pcc_t_far_z[ci];
            pos_geom_fetched = true;
          }
          double p_tminc = pc_t_near_x - rwx_inv_r;
          double p_tmaxc = pc_t_far_x  - rwx_inv_r;
          double p_tmin_y = pc_t_near_y - rwy_inv_r;
          double p_tmax_y = pc_t_far_y  - rwy_inv_r;
          if (p_tmin_y > p_tminc) p_tminc = p_tmin_y;
          if (p_tmax_y < p_tmaxc) p_tmaxc = p_tmax_y;
          if (p_tminc <= p_tmaxc) {
            double p_tmin_z = pc_t_near_z - rwz_inv_r;
            double p_tmax_z = pc_t_far_z  - rwz_inv_r;
            if (p_tmin_z > p_tminc) p_tminc = p_tmin_z;
            if (p_tmax_z < p_tmaxc) p_tmaxc = p_tmax_z;
            if (p_tminc <= p_tmaxc && p_tmaxc >= 0.0 && p_tminc < best_t_r) {
              slab_outcome = 4;
            }
          }
        }

        if (slab_outcome != 3 && slab_outcome != 4) {
          i++; continue;
        }

        // First slab-passing ray loads bucket-geometry locals.
        if (!bk_geom_fetched) {
          bk_ou  = bk_origin_u[ci];
          bk_ov  = bk_origin_v[ci];
          bk_isu = bk_inv_size_u[ci];
          bk_isv = bk_inv_size_v[ci];
          bk_geom_fetched = true;
        }

        // Bucket lookup (bu, bv). SHADOW_BUCKET_DIM=4 inlined as <<2.
        int bu = int((bru[r] - bk_ou) * bk_isu);
        int bv = int((brv[r] - bk_ov) * bk_isv);
        if (bu < 0) bu = 0;
        else if (bu >= 4) bu = 3;
        if (bv < 0) bv = 0;
        else if (bv >= 4) bv = 3;
        int bk = (bv << 2) + bu;  // SHADOW_BUCKET_DIM=4 -> shift by 2

        // Append to per-bucket sub-list with dense parallel cache.
        int prev_bk_count = bk_live_count[bk];
        // First ray in bucket: append touched, lazy-init Z-cull sentinels.
        if (prev_bk_count == 0) {
          bk_touched[n_touched++] = bk;
          bk_z_min[bk] = 1e30;
          bk_z_max[bk] = -1e30;
        }
        // 64 = bucket-strip size (per-chunk × per-bucket × 64 slots).
        int bk_slot = (bk << 6) + prev_bk_count;
        bk_live[bk_slot]    = r;
        bk_live_wx[bk_slot] = wx_r;
        bk_live_wy[bk_slot] = wy_r;
        bk_live_wz[bk_slot] = wz_r;
        bk_live_bt[bk_slot] = best_t_r;
        // Scatter (u,v) for inner-loop 2D pre-reject.
        bk_live_u[bk_slot]  = bru[r];
        bk_live_v[bk_slot]  = brv[r];
        bk_live_count[bk] = prev_bk_count + 1;
        // Per-bucket Z-bounds. Conservative — captures bbt at scatter
        // time. Tris missed by tightened bound walk through (false-
        // positive culls only; never miss a hittable tri).
        double z_reach = wz_r + dz * best_t_r;
        if (z_reach < bk_z_min[bk]) bk_z_min[bk] = z_reach;
        if (wz_r    > bk_z_max[bk]) bk_z_max[bk] = wz_r;
        live_count++;
        i++;  // success path — advance to next ray slot
      }
      // ---- Phase-B chunk-walk break gate (post-middle-pass) ----
      // Inner tri loop skipped on break. any_active = (max_bbt >= 0).
      if (pbrk_first_ci < 0) {
        if (max_bbt_active < 0.0) {
          // Every ray uninterested in this chunk + tail.
          pbrk_first_ci = ci_it;
          break;
        }
        max_bbt_carry = max_bbt_active;
        const double SAFETY_MARGIN = 0.01;
        if (chunk_dot_dir - batch_max_rdd
                > max_bbt_active + chunk_half_diag_tail + SAFETY_MARGIN) {
          pbrk_first_ci = ci_it;
          break;
        }
      }

      if (live_count == 0) continue;

      // Per-bucket inner tri loop. Nest: bucket → tri → ray. Touched
      // buckets only (typical 3-4 of 16 per chunk).
      const double AABB_EPS = 1e-3;
      for (int bk_idx = 0; bk_idx < n_touched; bk_idx++) {
        int bk_it = bk_touched[bk_idx];
        int bcount = bk_live_count[bk_it];
        // bcount > 0 guaranteed by touched-list semantics.
        int btri_start = bk_tri_start[chunk_bucket_meta_base + bk_it];
        int btri_count = bk_tri_count[chunk_bucket_meta_base + bk_it];
        if (btri_count == 0) continue;
        int bk_live_base = bk_it << 6;
        // Per-bucket Z-cull bounds. Read once per bucket. AABB_EPS-
        // equivalent slack handled by Stage 2a's tri AABB EPS.
        double b_z_min = bk_z_min[bk_it];
        double b_z_max = bk_z_max[bk_it];
        for (int k = 0; k < btri_count; k++) {
          int sf_idx = bk_tri_idx[btri_start + k];
          // Z-cull: skip whole tri pipeline when reachable Z range
          // disjoint from tri's Z extent (dz<0 monotonicity).
          double tri_min_z = sf_minz[sf_idx];
          double tri_max_z = sf_maxz[sf_idx];
          if (tri_max_z < b_z_min || tri_min_z > b_z_max) {
            continue;
          }
          // ---- Tri metadata hoist (ONCE per tri in this bucket) ----
          double nx      = sf_nx[sf_idx];
          double ny      = sf_ny[sf_idx];
          double nz      = sf_nz[sf_idx];
          double plane_d = sf_pd[sf_idx];
          // Pre-negation hoist: 4 NEGs/tri saves 1 NEG per (ray,tri).
          double neg_nx = -nx;
          double neg_ny = -ny;
          double neg_nz = -nz;
          double neg_pd = -plane_d;
          double denom     = sf_denom[sf_idx];
          double denom_eps = 1.0e-6 * denom;
          double inv_denom = sf_inv_denom[sf_idx];
          // (u,v)-of-centroid + R² hoisted unconditionally — 2D pre-
          // reject is FIRST per-ray check. sf_cx/cy/cz stay lazy.
          double t_cu_o  = sf_cu[sf_idx];
          double t_cv_o  = sf_cv[sf_idx];
          double t_mcs_o = sf_max_corner_sq[sf_idx];
          // Stage-2a centroid + XY AABB deferred to s2a_fetched gate.
          bool s2a_fetched = false;
          double tri_min_x = 0.0, tri_max_x = 0.0;
          double tri_min_y = 0.0, tri_max_y = 0.0;
          double s_cx_v = 0.0, s_cy_v = 0.0, s_cz_v = 0.0;

          // tri_fetched gates lazy bary+centroid load (~80% reject at 2a).
          bool tri_fetched = false;
          double invD = 0.0;
          double p1x = 0.0, p1y = 0.0, p1z = 0.0;
          double v0x = 0.0, v0y = 0.0, v0z = 0.0;
          double v1x = 0.0, v1y = 0.0, v1z = 0.0;
          double d00 = 0.0, d01 = 0.0, d11 = 0.0;
          double cx_t = 0.0, cy_t = 0.0, cz_t = 0.0;

          for (int lk = 0; lk < bcount; lk++) {
            int slot = bk_live_base + lk;

            // 2D bounding-circle pre-reject. Rays parallel to -sun_dir
            // → (u,v) invariant in t. du²+dv² > R² ⇒ 3D-dist² > R² for
            // all t (strict lower bound, zero false negatives).
            double ru = bk_live_u[slot];
            double rv = bk_live_v[slot];
            double du = ru - t_cu_o;
            double dv = rv - t_cv_o;
            if (du * du + dv * dv > t_mcs_o) {
              continue;
            }

            // INTENTIONAL READ ORDERING: bk_live_bt deferred past t0
            // cull so t0-rejects skip the array read.
            double wx_r = bk_live_wx[slot];
            double wy_r = bk_live_wy[slot];
            double wz_r = bk_live_wz[slot];

            // STAGE 1 — ray-plane solve (division-free reject).
            double numer = neg_nx * wx_r + neg_ny * wy_r + neg_nz * wz_r + neg_pd;
            if (numer >= denom_eps) {
              continue;
            }
            double best_t_r = bk_live_bt[slot];
            if (numer <= best_t_r * denom) {
              continue;
            }
            double t = numer * inv_denom;

            // STAGE 2a — sphere pre-reject + AABB.
            double hx = wx_r + dx * t;
            double hy = wy_r + dy * t;
            double hz = wz_r + dz * t;
            // First ray to reach Stage 2a loads the 6 sf_* fields.
            if (!s2a_fetched) {
              tri_min_x = sf_minx[sf_idx];
              tri_max_x = sf_maxx[sf_idx];
              tri_min_y = sf_miny[sf_idx];
              tri_max_y = sf_maxy[sf_idx];
              s_cx_v    = sf_cx[sf_idx];
              s_cy_v    = sf_cy[sf_idx];
              s_cz_v    = sf_cz[sf_idx];
              s2a_fetched = true;
            }
            double s_hcdx = hx - s_cx_v;
            double s_hcdy = hy - s_cy_v;
            double s_hcdz = hz - s_cz_v;
            double s_dist_sq = s_hcdx * s_hcdx
                             + s_hcdy * s_hcdy
                             + s_hcdz * s_hcdz;
            // 3D sphere kept — catches grazing-sun and large-t_hit cases
            // where 2D passes but 3D would reject.
            if (s_dist_sq > t_mcs_o) {
              continue;
            }
            if (hx < tri_min_x - AABB_EPS || hx > tri_max_x + AABB_EPS ||
                hy < tri_min_y - AABB_EPS || hy > tri_max_y + AABB_EPS ||
                hz < tri_min_z - AABB_EPS || hz > tri_max_z + AABB_EPS) {
              continue;
            }

            // STAGE 2b — bary + cam_f. sf_* fields hoisted once per
            // (tri, bucket).
            if (!tri_fetched) {
              invD = sf_invD[sf_idx];
              p1x = sf_p1x[sf_idx]; p1y = sf_p1y[sf_idx]; p1z = sf_p1z[sf_idx];
              v0x = sf_v0x[sf_idx]; v0y = sf_v0y[sf_idx]; v0z = sf_v0z[sf_idx];
              v1x = sf_v1x[sf_idx]; v1y = sf_v1y[sf_idx]; v1z = sf_v1z[sf_idx];
              d00 = sf_d00[sf_idx]; d01 = sf_d01[sf_idx]; d11 = sf_d11[sf_idx];
              // Reuse s_*_v centroid already loaded for sphere check.
              cx_t = s_cx_v; cy_t = s_cy_v; cz_t = s_cz_v;
              tri_fetched = true;
            }
            if (invD == 0.0) {
              continue;
            }
            double v2x = hx - p1x;
            double v2y = hy - p1y;
            double v2z = hz - p1z;
            double d20 = v2x * v0x + v2y * v0y + v2z * v0z;
            double d21 = v2x * v1x + v2y * v1y + v2z * v1z;
            double vb = (d11 * d20 - d01 * d21) * invD;
            double wb = (d00 * d21 - d01 * d20) * invD;
            double ub = 1.0 - vb - wb;
            if (ub < -1e-4 || vb < -1e-4 || wb < -1e-4) {
              continue;
            }

            double cam_f = (cx_t - icpx) * nx +
                           (cy_t - icpy) * ny +
                           (cz_t - icpz) * nz;
            if (cam_f >= 0.0) {
              continue;
            }
            // Cam-visible — update if new nearest.
            if (t < best_t_r) {
              int r = bk_live[slot];
              bbt[r]  = t;
              bk_live_bt[slot] = t;  // tighten intra-bucket reject
              blx[r]  = hx; bly[r] = hy; blz[r] = hz;
              bwsf[r] = sf_idx;  // lockstep validity write
              bwci[r] = ci_it;
            }
          }
        }
      }
      // End-of-chunk cleanup walks touched buckets only.
      for (int bk_clean = 0; bk_clean < n_touched; bk_clean++) {
        bk_live_count[bk_touched[bk_clean]] = 0;
      }
    }

    // ---- Phase 3: merged tail flush ----
    // Folds project_silhouette's Pass 2 (cam projection + sh_* writeback)
    // and adaptive-cap winner_t accumulator into one per-ray loop.
    double batch_max_wt = 0.0;
    for (int r = 0; r < ray_count; r++) {
      // Skip in-queue aliased rays — outputs filled by alias copy-back.
      // Running this body would corrupt shadow_last_hit_sf_idx + sh_*.
      // Pcache hits (b_cached=true, alias=-1) flow through normally.
      if (b_alias[r] >= 0) continue;
      // Lockstep: bwsf>=0 IFF cam-vis hit (Phase 0 init wrote -1).
      int bwsf_r = bwsf[r];
      bool hit_found_r = (bwsf_r >= 0);
      // bbt[r] read deferred to consumer branches (both predicates
      // imply hit — wci_r>=0 set in lockstep with bwsf_r>=0).

      // Cache writeback only on cam-visible hit; preserve prior on miss.
      if (hit_found_r) {
        l_lh_sf_idx[piece_base + r] = bwsf_r;
      }

      // ---- Folded Pass 2: silhouette outputs + camera projection ----
      if (hit_found_r) {
        double land_x = blx[r];
        double land_y = bly[r];
        double land_z = blz[r];
        double fz = land_z + 1.0;  // tiny lift to avoid coplanar z-fight
        sh_vx[r] = land_x;
        sh_vy[r] = land_y;
        sh_vz[r] = fz;
        // Lazy packed-key compute. sentinel pkey=0 is unambiguous (real
        // key always nonzero — sun-front + unit-normal + quantize floor
        // guarantee at least one 16-bit field nonzero). emit replay
        // reads sh_hpk!=0 as the validity predicate.
        int64 pkey = sf_pkey[bwsf_r];
        if (pkey == 0) {
          double l_tnx = sf_nx[bwsf_r];
          double l_tny = sf_ny[bwsf_r];
          double l_tnz = sf_nz[bwsf_r];
          double l_tpd = sf_pd[bwsf_r];
          int nx_q = int(l_tnx * 1024.0 + 32768.5) - 32768;
          int ny_q = int(l_tny * 1024.0 + 32768.5) - 32768;
          int nz_q = int(l_tnz * 1024.0 + 32768.5) - 32768;
          int d_q  = int(l_tpd * 16.0 + 1048576.5) - 1048576;
          pkey = (int64(nx_q & 0xFFFF) << 48) |
                 (int64(ny_q & 0xFFFF) << 32) |
                 (int64(nz_q & 0xFFFF) << 16) |
                  int64(d_q  & 0xFFFF);
          sf_pkey[bwsf_r] = pkey;
        }
        sh_hpk[r]   = pkey;
        // Adaptive-cap accumulator.
        double best_t_r = bbt[r];
        if (best_t_r > batch_max_wt) batch_max_wt = best_t_r;
        // Pre-project to camera space (shared by up to 4 quads).
        sh_tx[r] = land_x * mcfx + land_y * mcfy + fz * mcfz - mcdf;
        sh_ty[r] = land_x * mclx + land_y * mcly + fz * mclz - mcdl;
        sh_tz[r] = land_x * mcux + land_y * mcuy + fz * mcuz - mcdu;
      } else {
        // sh_hpk=0 sentinel — unreachable for real sun-front triangle.
        sh_hpk[r]   = 0;
      }
    }

    // Adaptive cap: per-batch winner_t max folded into frame_max.
    if (batch_max_wt > shadow_winner_t_frame_max)
      shadow_winner_t_frame_max = batch_max_wt;

    // Advance per-piece ray-cache cursor (modulo wraparound).
    int new_cursor = (ray_cache_offset + ray_count) % SHADOW_LH_SLOTS_PER_PIECE;
    shadow_piece_ray_cursor = new_cursor;

    // Publish sparse active-ray list size for pcache Pass-B insert.
    shadow_batch_active_count = bactive_count;
  }

  // Vertical ground probe for altitude-fade guard. Downward ray from
  // (wx, wy, start_z); returns z of nearest upward-facing tri below or
  // -1e18 sentinel on miss within MAX_DESCENT.
  //
  // Tri-mesh, not is_solid cube-grid (the cube classifier disagreed
  // with rendered geometry under terrain warping; was source of
  // altitude-spike glitches and fade pulses).
  //
  // Skips: |nz|<1e-9 (vertical) and nz<0 (ceilings — want floor below).
  // Plane clipped into voxel returns sentinel → ex=2 short-circuit.
  double shadow_ground_z_below(double wx, double wy, double start_z) {
    // Matches former cube-grid probe reach (64 × 400 = 25600).
    const double MAX_DESCENT = 25600.0;
    double best_t = MAX_DESCENT;
    bool   hit    = false;

    // Iterate the dense ready_chunks view (only generated chunks with
    // active_triangles > 0); drops the per-chunk null/!is_generated/
    // active_triangles==0 filter.
    array<Chunk @> @pop_all = @chunk_manager.ready_chunks;
    uint npa = pop_all.length();
    for (uint ci = 0; ci < npa; ci++) {
      Chunk @c = pop_all[ci];
      // Chunk XY/Z pre-filter (vertical ray needs XY-bbox coverage).
      if (wx < c.min_x || wx > c.max_x) continue;
      if (wy < c.min_y || wy > c.max_y) continue;
      if (c.min_z > start_z) continue;                          // chunk entirely above
      if (c.max_z < start_z - MAX_DESCENT) continue;            // beyond sentinel reach

      int tri_count = c.active_triangles;
      array<Triangle @> @chunk_tris = @c.triangles;
      for (int i = 0; i < tri_count; i++) {
        Triangle @tri = chunk_tris[i];
        double nz = tri.nz;
        // Upward-facing only; also kills tiny-nz t-solve blowup.
        if (nz < 1e-9) continue;

        // Triangle XY AABB prune before the plane-solve + bary work.
        const double AABB_EPS = 1e-3;
        if (wx < tri.min_x - AABB_EPS || wx > tri.max_x + AABB_EPS) continue;
        if (wy < tri.min_y - AABB_EPS || wy > tri.max_y + AABB_EPS) continue;

        // Vertical ray-plane: t = (n·o + d) / nz.
        double nx = tri.nx, ny = tri.ny;
        double t = (nx * wx + ny * wy + nz * start_z + tri.plane_d) / nz;
        // Tiny-negative t clamp for float noise (plane flush with tri).
        if (t < -1e-6) continue;
        if (t < 0.0)   t = 0.0;
        if (t >= best_t) continue;

        // Barycentric inside test (identical to shadow_raymarch's).
        double invD = tri.invDenom;
        if (invD == 0.0) continue;
        double hz = start_z - t;
        double v2x = wx - tri.p1x;
        double v2y = wy - tri.p1y;
        double v2z = hz - tri.p1z;
        double d20 = v2x * tri.v0x + v2y * tri.v0y + v2z * tri.v0z;
        double d21 = v2x * tri.v1x + v2y * tri.v1y + v2z * tri.v1z;
        double vb  = (tri.d11 * d20 - tri.d01 * d21) * invD;
        double wb  = (tri.d00 * d21 - tri.d01 * d20) * invD;
        double ub  = 1.0 - vb - wb;
        if (ub < -1e-4 || vb < -1e-4 || wb < -1e-4) continue;

        best_t = t;
        hit    = true;
      }
    }

    if (!hit) return -1e18;
    return start_z - best_t;
  }

  // Oblique probe along -sun_dir from (ox, oy, oz). Returns t at
  // nearest sun-front hit; MAX_T+1 sentinel on miss.
  //
  // max_t = caller's running MIN bound (chained probes propagate
  // tightening). Replaces altitude-based fade — oblique probe directly
  // measures plane-to-shadow distance, correct on walls + floors.
  // Accepts any sun-front tri (upward-only would miss shadows on walls).
  double shadow_distance_along_sun(double ox, double oy, double oz, double max_t) {
    // Reach cap; MAX_T+1 = miss sentinel.
    const double MAX_T = 25600.0;
    // Tight initial bound for aggressive slab/tri pruning.
    double best_t = (max_t < MAX_T) ? max_t : MAX_T;
    bool   hit    = false;
    // Winning normal published to shadow_oblique_normal_{x,y,z} for
    // multi-anchor cam-invis check (ex=6). Unchanged on miss.
    double best_nx = 0.0, best_ny = 0.0, best_nz = 0.0;

    double dx = -sun_dir.x, dy = -sun_dir.y, dz = -sun_dir.z;

    // Inverse direction for slab; zero → INF for parallel slabs.
    const double INF = 1e30;
    double inv_dx = (dx != 0.0) ? 1.0 / dx : ((dx >= 0.0) ?  INF : -INF);
    double inv_dy = (dy != 0.0) ? 1.0 / dy : ((dy >= 0.0) ?  INF : -INF);
    double inv_dz = (dz != 0.0) ? 1.0 / dz : ((dz >= 0.0) ?  INF : -INF);

    // Iterate the dense ready_chunks view (only generated chunks with
    // active_triangles > 0); see shadow_ground_z_below.
    array<Chunk @> @pop_all = @chunk_manager.ready_chunks;
    uint npa = pop_all.length();
    for (uint ci = 0; ci < npa; ci++) {
      Chunk @c = pop_all[ci];

      // Ray-AABB slab test against the chunk's geometry bbox.
      double tx1 = (c.min_x - ox) * inv_dx;
      double tx2 = (c.max_x - ox) * inv_dx;
      double tmin_x = (tx1 < tx2) ? tx1 : tx2;
      double tmax_x = (tx1 < tx2) ? tx2 : tx1;
      double ty1 = (c.min_y - oy) * inv_dy;
      double ty2 = (c.max_y - oy) * inv_dy;
      double tmin_y = (ty1 < ty2) ? ty1 : ty2;
      double tmax_y = (ty1 < ty2) ? ty2 : ty1;
      double tz1 = (c.min_z - oz) * inv_dz;
      double tz2 = (c.max_z - oz) * inv_dz;
      double tmin_z = (tz1 < tz2) ? tz1 : tz2;
      double tmax_z = (tz1 < tz2) ? tz2 : tz1;
      double tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
      if (tmin_z > tmin) tmin = tmin_z;
      double tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
      if (tmax_z < tmax) tmax = tmax_z;
      if (tmax < 0.0 || tmin > best_t || tmin > tmax) continue;

      int tri_count = c.active_triangles;
      array<Triangle @> @chunk_tris = @c.triangles;
      for (int i = 0; i < tri_count; i++) {
        Triangle @tri = chunk_tris[i];
        // Sun-front: n·sun_dir > 0; eps rejects parallel-ray blowup.
        // Uses hoisted dx/dy/dz (= -sun_dir.{x,y,z}) so n_dot_neg =
        // n·-sun_dir = -(n·sun_dir).
        double nx = tri.nx, ny = tri.ny, nz = tri.nz;
        double n_dot_neg = nx * dx + ny * dy + nz * dz;  // = -n_dot_sun
        if (n_dot_neg > -1e-9) continue;  // sun-back or parallel

        // Ray-plane: t = (n·o + plane_d) / (n·sun_dir) = -numer / n_dot_neg.
        double numer = nx * ox + ny * oy + nz * oz + tri.plane_d;
        double t = -numer / n_dot_neg;
        if (t < -1e-6) continue;
        if (t < 0.0)   t = 0.0;
        if (t >= best_t) continue;

        // Barycentric inside test (same math as shadow_raymarch).
        double invD = tri.invDenom;
        if (invD == 0.0) continue;
        double hx = ox + dx * t;
        double hy = oy + dy * t;
        double hz = oz + dz * t;
        double v2x = hx - tri.p1x;
        double v2y = hy - tri.p1y;
        double v2z = hz - tri.p1z;
        double d20 = v2x * tri.v0x + v2y * tri.v0y + v2z * tri.v0z;
        double d21 = v2x * tri.v1x + v2y * tri.v1y + v2z * tri.v1z;
        double vb  = (tri.d11 * d20 - tri.d01 * d21) * invD;
        double wb  = (tri.d00 * d21 - tri.d01 * d20) * invD;
        double ub  = 1.0 - vb - wb;
        if (ub < -1e-4 || vb < -1e-4 || wb < -1e-4) continue;

        best_t = t;
        hit    = true;
        best_nx = nx;
        best_ny = ny;
        best_nz = nz;
      }
    }

    if (!hit) return MAX_T + 1.0;
    // Publish hit normal for the multi-anchor cam-invis check. Each
    // call OVERWRITES these, so the caller (draw_plane_shadow) must
    // capture them into per-anchor locals immediately after each
    // probe call it wants to sample.
    shadow_oblique_normal_x = best_nx;
    shadow_oblique_normal_y = best_ny;
    shadow_oblique_normal_z = best_nz;
    return best_t;
  }

  // Hardcoded 4-anchor variant of multi-anchor batched probe. Unroll
  // hoists ax/ay/az + bt/bhit/bn* into locals; mask array becomes 4
  // bool locals. Sentinel: out_t = MAX_T+1.0 on miss.
  //
  // I/O contracts: shadow_probe_anchor_{x,y,z}[0..3] in;
  //   shadow_probe_out_t/nx/ny/nz/hit[0..3] out.
  void shadow_distance_along_sun_4(double max_t_shared) {
    // Anchor positions hoisted to locals.
    double ax0 = shadow_probe_anchor_x[0], ay0 = shadow_probe_anchor_y[0], az0 = shadow_probe_anchor_z[0];
    double ax1 = shadow_probe_anchor_x[1], ay1 = shadow_probe_anchor_y[1], az1 = shadow_probe_anchor_z[1];
    double ax2 = shadow_probe_anchor_x[2], ay2 = shadow_probe_anchor_y[2], az2 = shadow_probe_anchor_z[2];
    double ax3 = shadow_probe_anchor_x[3], ay3 = shadow_probe_anchor_y[3], az3 = shadow_probe_anchor_z[3];

    const double MAX_T = 25600.0;
    double cap = (max_t_shared < MAX_T) ? max_t_shared : MAX_T;

    // Per-anchor accumulators in locals (write-back at function tail).
    double bt0 = cap, bt1 = cap, bt2 = cap, bt3 = cap;
    bool   bhit0 = false, bhit1 = false, bhit2 = false, bhit3 = false;
    double bnx0 = 0.0, bny0 = 0.0, bnz0 = 0.0;
    double bnx1 = 0.0, bny1 = 0.0, bnz1 = 0.0;
    double bnx2 = 0.0, bny2 = 0.0, bnz2 = 0.0;
    double bnx3 = 0.0, bny3 = 0.0, bnz3 = 0.0;

    double dx = -sun_dir.x, dy = -sun_dir.y, dz = -sun_dir.z;
    // Same frame-cache as multi: inv_dx/dy/dz hits when sun_dir hasn't
    // rotated since the last probe call.
    double inv_dx;
    double inv_dy;
    double inv_dz;
    if (dx == shadow_inv_neg_sun_anchor_x &&
        dy == shadow_inv_neg_sun_anchor_y &&
        dz == shadow_inv_neg_sun_anchor_z) {
      inv_dx = shadow_inv_neg_sun_dir_x;
      inv_dy = shadow_inv_neg_sun_dir_y;
      inv_dz = shadow_inv_neg_sun_dir_z;
    } else {
      const double INF = 1e30;
      inv_dx = (dx != 0.0) ? 1.0 / dx : ((dx >= 0.0) ?  INF : -INF);
      inv_dy = (dy != 0.0) ? 1.0 / dy : ((dy >= 0.0) ?  INF : -INF);
      inv_dz = (dz != 0.0) ? 1.0 / dz : ((dz >= 0.0) ?  INF : -INF);
      shadow_inv_neg_sun_dir_x   = inv_dx;
      shadow_inv_neg_sun_dir_y   = inv_dy;
      shadow_inv_neg_sun_dir_z   = inv_dz;
      shadow_inv_neg_sun_anchor_x = dx;
      shadow_inv_neg_sun_anchor_y = dy;
      shadow_inv_neg_sun_anchor_z = dz;
    }

    // Sign-resolved slab bounds: inv_d* signs are constant for the
    // entire frame, so near/far face selection is constant. Precompute
    // sign once + pre-multiply each anchor by inv_d* to lift 12 muls +
    // 24 ternary evals OUT of the per-chunk hot loop.
    bool idx_pos = inv_dx >= 0.0;
    bool idy_pos = inv_dy >= 0.0;
    bool idz_pos = inv_dz >= 0.0;
    double ax0_inv_dx = ax0 * inv_dx, ay0_inv_dy = ay0 * inv_dy, az0_inv_dz = az0 * inv_dz;
    double ax1_inv_dx = ax1 * inv_dx, ay1_inv_dy = ay1 * inv_dy, az1_inv_dz = az1 * inv_dz;
    double ax2_inv_dx = ax2 * inv_dx, ay2_inv_dy = ay2 * inv_dy, az2_inv_dz = az2 * inv_dz;
    double ax3_inv_dx = ax3 * inv_dx, ay3_inv_dy = ay3 * inv_dy, az3_inv_dz = az3 * inv_dz;

    // Aggregate cluster slab pre-reject. 4 anchors (wingtips ±95u,
    // nose +30u, tail -15u) cluster tightly; fattened-chunk slab from
    // cluster centroid = exact union of 4 individual slab acceptances.
    double agg_min_ax = ax0, agg_max_ax = ax0;
    if (ax1 < agg_min_ax) agg_min_ax = ax1;
    if (ax1 > agg_max_ax) agg_max_ax = ax1;
    if (ax2 < agg_min_ax) agg_min_ax = ax2;
    if (ax2 > agg_max_ax) agg_max_ax = ax2;
    if (ax3 < agg_min_ax) agg_min_ax = ax3;
    if (ax3 > agg_max_ax) agg_max_ax = ax3;
    double agg_min_ay = ay0, agg_max_ay = ay0;
    if (ay1 < agg_min_ay) agg_min_ay = ay1;
    if (ay1 > agg_max_ay) agg_max_ay = ay1;
    if (ay2 < agg_min_ay) agg_min_ay = ay2;
    if (ay2 > agg_max_ay) agg_max_ay = ay2;
    if (ay3 < agg_min_ay) agg_min_ay = ay3;
    if (ay3 > agg_max_ay) agg_max_ay = ay3;
    double agg_min_az = az0, agg_max_az = az0;
    if (az1 < agg_min_az) agg_min_az = az1;
    if (az1 > agg_max_az) agg_max_az = az1;
    if (az2 < agg_min_az) agg_min_az = az2;
    if (az2 > agg_max_az) agg_max_az = az2;
    if (az3 < agg_min_az) agg_min_az = az3;
    if (az3 > agg_max_az) agg_max_az = az3;
    // Centroid + half-extent fatten chunk AABB by cluster radius.
    double agg_cx = (agg_min_ax + agg_max_ax) * 0.5;
    double agg_cy = (agg_min_ay + agg_max_ay) * 0.5;
    double agg_cz = (agg_min_az + agg_max_az) * 0.5;
    double agg_hx = (agg_max_ax - agg_min_ax) * 0.5;
    double agg_hy = (agg_max_ay - agg_min_ay) * 0.5;
    double agg_hz = (agg_max_az - agg_min_az) * 0.5;

    // Hoist anchor*inv_d and (half-extent * |inv_d|).
    double agg_cx_inv_dx = agg_cx * inv_dx;
    double agg_cy_inv_dy = agg_cy * inv_dy;
    double agg_cz_inv_dz = agg_cz * inv_dz;
    double abs_inv_dx = inv_dx >= 0.0 ? inv_dx : -inv_dx;
    double abs_inv_dy = inv_dy >= 0.0 ? inv_dy : -inv_dy;
    double abs_inv_dz = inv_dz >= 0.0 ? inv_dz : -inv_dz;
    double agg_h_x_abs_inv = agg_hx * abs_inv_dx;
    double agg_h_y_abs_inv = agg_hy * abs_inv_dy;
    double agg_h_z_abs_inv = agg_hz * abs_inv_dz;

    // Dense ready_chunks iteration; no per-chunk null/active filter.
    array<Chunk @> @pop_all = @chunk_manager.ready_chunks;
    uint npa = pop_all.length();
    for (uint ci = 0; ci < npa; ci++) {
      Chunk @c = pop_all[ci];

      double cmin_x = c.min_x, cmax_x = c.max_x;
      double cmin_y = c.min_y, cmax_y = c.max_y;
      double cmin_z = c.min_z, cmax_z = c.max_z;

      // Per-chunk sign-resolved slab faces shared across aggregate +
      // 4 unrolled anchor blocks.
      double cmin_x_inv = cmin_x * inv_dx;
      double cmax_x_inv = cmax_x * inv_dx;
      double cmin_y_inv = cmin_y * inv_dy;
      double cmax_y_inv = cmax_y * inv_dy;
      double cmin_z_inv = cmin_z * inv_dz;
      double cmax_z_inv = cmax_z * inv_dz;
      double c_near_x = idx_pos ? cmin_x_inv : cmax_x_inv;
      double c_far_x  = idx_pos ? cmax_x_inv : cmin_x_inv;
      double c_near_y = idy_pos ? cmin_y_inv : cmax_y_inv;
      double c_far_y  = idy_pos ? cmax_y_inv : cmin_y_inv;
      double c_near_z = idz_pos ? cmin_z_inv : cmax_z_inv;
      double c_far_z  = idz_pos ? cmax_z_inv : cmin_z_inv;

      // Aggregate slab pre-reject (cluster centroid vs fattened chunk).
      {
        double tmin_x = c_near_x - agg_h_x_abs_inv - agg_cx_inv_dx;
        double tmax_x = c_far_x  + agg_h_x_abs_inv - agg_cx_inv_dx;
        double tmin_y = c_near_y - agg_h_y_abs_inv - agg_cy_inv_dy;
        double tmax_y = c_far_y  + agg_h_y_abs_inv - agg_cy_inv_dy;
        double tmin_z = c_near_z - agg_h_z_abs_inv - agg_cz_inv_dz;
        double tmax_z = c_far_z  + agg_h_z_abs_inv - agg_cz_inv_dz;
        double agg_tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
        if (tmin_z > agg_tmin) agg_tmin = tmin_z;
        double agg_tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
        if (tmax_z < agg_tmax) agg_tmax = tmax_z;
        if (agg_tmax < 0.0 || agg_tmin > cap || agg_tmin > agg_tmax) continue;
      }

      // Per-anchor slab test, unrolled 4×.
      bool a0, a1, a2, a3;
      {
        double tmin_x = c_near_x - ax0_inv_dx;
        double tmax_x = c_far_x  - ax0_inv_dx;
        double tmin_y = c_near_y - ay0_inv_dy;
        double tmax_y = c_far_y  - ay0_inv_dy;
        double tmin_z = c_near_z - az0_inv_dz;
        double tmax_z = c_far_z  - az0_inv_dz;
        double tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
        if (tmin_z > tmin) tmin = tmin_z;
        double tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
        if (tmax_z < tmax) tmax = tmax_z;
        a0 = !(tmax < 0.0 || tmin > bt0 || tmin > tmax);
      }
      {
        double tmin_x = c_near_x - ax1_inv_dx;
        double tmax_x = c_far_x  - ax1_inv_dx;
        double tmin_y = c_near_y - ay1_inv_dy;
        double tmax_y = c_far_y  - ay1_inv_dy;
        double tmin_z = c_near_z - az1_inv_dz;
        double tmax_z = c_far_z  - az1_inv_dz;
        double tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
        if (tmin_z > tmin) tmin = tmin_z;
        double tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
        if (tmax_z < tmax) tmax = tmax_z;
        a1 = !(tmax < 0.0 || tmin > bt1 || tmin > tmax);
      }
      {
        double tmin_x = c_near_x - ax2_inv_dx;
        double tmax_x = c_far_x  - ax2_inv_dx;
        double tmin_y = c_near_y - ay2_inv_dy;
        double tmax_y = c_far_y  - ay2_inv_dy;
        double tmin_z = c_near_z - az2_inv_dz;
        double tmax_z = c_far_z  - az2_inv_dz;
        double tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
        if (tmin_z > tmin) tmin = tmin_z;
        double tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
        if (tmax_z < tmax) tmax = tmax_z;
        a2 = !(tmax < 0.0 || tmin > bt2 || tmin > tmax);
      }
      {
        double tmin_x = c_near_x - ax3_inv_dx;
        double tmax_x = c_far_x  - ax3_inv_dx;
        double tmin_y = c_near_y - ay3_inv_dy;
        double tmax_y = c_far_y  - ay3_inv_dy;
        double tmin_z = c_near_z - az3_inv_dz;
        double tmax_z = c_far_z  - az3_inv_dz;
        double tmin = (tmin_x > tmin_y) ? tmin_x : tmin_y;
        if (tmin_z > tmin) tmin = tmin_z;
        double tmax = (tmax_x < tmax_y) ? tmax_x : tmax_y;
        if (tmax_z < tmax) tmax = tmax_z;
        a3 = !(tmax < 0.0 || tmin > bt3 || tmin > tmax);
      }
      if (!a0 && !a1 && !a2 && !a3) continue;

      int tri_count = c.active_triangles;
      array<Triangle @> @chunk_tris = @c.triangles;
      for (int i = 0; i < tri_count; i++) {
        Triangle @tri = chunk_tris[i];
        double nx = tri.nx, ny = tri.ny, nz = tri.nz;
        double denom = nx * dx + ny * dy + nz * dz;  // = -n_dot_sun
        if (denom > -1e-9) continue;  // sun-back or parallel — skip

        double plane_d = tri.plane_d;
        // Division-free numer pre-reject; defer 1.0/denom past anchor gate.
        double eps_denom = 1e-6 * denom;  // denom<0 -> eps_denom<0
        double neg_denom = -denom;        // > 0 (>=1e-9)
        double invD    = tri.invDenom;
        if (invD == 0.0) continue;
        double inv_den = 0.0;
        bool inv_den_init = false;
        // Lazy bary fetch (~95% of sun-front tris fail all 4 anchors).
        double p1x = 0.0, p1y = 0.0, p1z = 0.0;
        double v0x = 0.0, v0y = 0.0, v0z = 0.0;
        double v1x = 0.0, v1y = 0.0, v1z = 0.0;
        double d00 = 0.0, d01 = 0.0, d11 = 0.0;

        // Per-anchor inner test, unrolled 4×.
        if (a0) {
          double numer = nx * ax0 + ny * ay0 + nz * az0 + plane_d;
          if (numer >= eps_denom && numer < bt0 * neg_denom) {
            if (!inv_den_init) {
              inv_den = 1.0 / denom; inv_den_init = true;
              p1x = tri.p1x; p1y = tri.p1y; p1z = tri.p1z;
              v0x = tri.v0x; v0y = tri.v0y; v0z = tri.v0z;
              v1x = tri.v1x; v1y = tri.v1y; v1z = tri.v1z;
              d00 = tri.d00; d01 = tri.d01; d11 = tri.d11;
            }
            double t = -numer * inv_den;
            if (t < 0.0) t = 0.0;
            double hx = ax0 + dx * t;
            double hy = ay0 + dy * t;
            double hz = az0 + dz * t;
            double v2x = hx - p1x;
            double v2y = hy - p1y;
            double v2z = hz - p1z;
            double d20 = v2x * v0x + v2y * v0y + v2z * v0z;
            double d21 = v2x * v1x + v2y * v1y + v2z * v1z;
            double vb  = (d11 * d20 - d01 * d21) * invD;
            double wb  = (d00 * d21 - d01 * d20) * invD;
            double ub  = 1.0 - vb - wb;
            if (ub >= -1e-4 && vb >= -1e-4 && wb >= -1e-4) {
              bt0 = t; bhit0 = true;
              bnx0 = nx; bny0 = ny; bnz0 = nz;
            }
          }
        }
        if (a1) {
          double numer = nx * ax1 + ny * ay1 + nz * az1 + plane_d;
          if (numer >= eps_denom && numer < bt1 * neg_denom) {
            if (!inv_den_init) {
              inv_den = 1.0 / denom; inv_den_init = true;
              p1x = tri.p1x; p1y = tri.p1y; p1z = tri.p1z;
              v0x = tri.v0x; v0y = tri.v0y; v0z = tri.v0z;
              v1x = tri.v1x; v1y = tri.v1y; v1z = tri.v1z;
              d00 = tri.d00; d01 = tri.d01; d11 = tri.d11;
            }
            double t = -numer * inv_den;
            if (t < 0.0) t = 0.0;
            double hx = ax1 + dx * t;
            double hy = ay1 + dy * t;
            double hz = az1 + dz * t;
            double v2x = hx - p1x;
            double v2y = hy - p1y;
            double v2z = hz - p1z;
            double d20 = v2x * v0x + v2y * v0y + v2z * v0z;
            double d21 = v2x * v1x + v2y * v1y + v2z * v1z;
            double vb  = (d11 * d20 - d01 * d21) * invD;
            double wb  = (d00 * d21 - d01 * d20) * invD;
            double ub  = 1.0 - vb - wb;
            if (ub >= -1e-4 && vb >= -1e-4 && wb >= -1e-4) {
              bt1 = t; bhit1 = true;
              bnx1 = nx; bny1 = ny; bnz1 = nz;
            }
          }
        }
        if (a2) {
          double numer = nx * ax2 + ny * ay2 + nz * az2 + plane_d;
          if (numer >= eps_denom && numer < bt2 * neg_denom) {
            if (!inv_den_init) {
              inv_den = 1.0 / denom; inv_den_init = true;
              p1x = tri.p1x; p1y = tri.p1y; p1z = tri.p1z;
              v0x = tri.v0x; v0y = tri.v0y; v0z = tri.v0z;
              v1x = tri.v1x; v1y = tri.v1y; v1z = tri.v1z;
              d00 = tri.d00; d01 = tri.d01; d11 = tri.d11;
            }
            double t = -numer * inv_den;
            if (t < 0.0) t = 0.0;
            double hx = ax2 + dx * t;
            double hy = ay2 + dy * t;
            double hz = az2 + dz * t;
            double v2x = hx - p1x;
            double v2y = hy - p1y;
            double v2z = hz - p1z;
            double d20 = v2x * v0x + v2y * v0y + v2z * v0z;
            double d21 = v2x * v1x + v2y * v1y + v2z * v1z;
            double vb  = (d11 * d20 - d01 * d21) * invD;
            double wb  = (d00 * d21 - d01 * d20) * invD;
            double ub  = 1.0 - vb - wb;
            if (ub >= -1e-4 && vb >= -1e-4 && wb >= -1e-4) {
              bt2 = t; bhit2 = true;
              bnx2 = nx; bny2 = ny; bnz2 = nz;
            }
          }
        }
        if (a3) {
          double numer = nx * ax3 + ny * ay3 + nz * az3 + plane_d;
          if (numer >= eps_denom && numer < bt3 * neg_denom) {
            if (!inv_den_init) {
              inv_den = 1.0 / denom; inv_den_init = true;
              p1x = tri.p1x; p1y = tri.p1y; p1z = tri.p1z;
              v0x = tri.v0x; v0y = tri.v0y; v0z = tri.v0z;
              v1x = tri.v1x; v1y = tri.v1y; v1z = tri.v1z;
              d00 = tri.d00; d01 = tri.d01; d11 = tri.d11;
            }
            double t = -numer * inv_den;
            if (t < 0.0) t = 0.0;
            double hx = ax3 + dx * t;
            double hy = ay3 + dy * t;
            double hz = az3 + dz * t;
            double v2x = hx - p1x;
            double v2y = hy - p1y;
            double v2z = hz - p1z;
            double d20 = v2x * v0x + v2y * v0y + v2z * v0z;
            double d21 = v2x * v1x + v2y * v1y + v2z * v1z;
            double vb  = (d11 * d20 - d01 * d21) * invD;
            double wb  = (d00 * d21 - d01 * d20) * invD;
            double ub  = 1.0 - vb - wb;
            if (ub >= -1e-4 && vb >= -1e-4 && wb >= -1e-4) {
              bt3 = t; bhit3 = true;
              bnx3 = nx; bny3 = ny; bnz3 = nz;
            }
          }
        }
      }
    }

    // Write back per-anchor accumulators (sentinel-pad on miss).
    array<double> @bt   = @shadow_probe_out_t;
    array<double> @bnx  = @shadow_probe_out_nx;
    array<double> @bny  = @shadow_probe_out_ny;
    array<double> @bnz  = @shadow_probe_out_nz;
    array<bool>   @bhit = @shadow_probe_out_hit;
    bt[0]  = bhit0 ? bt0 : (MAX_T + 1.0);
    bhit[0] = bhit0; bnx[0] = bnx0; bny[0] = bny0; bnz[0] = bnz0;
    bt[1]  = bhit1 ? bt1 : (MAX_T + 1.0);
    bhit[1] = bhit1; bnx[1] = bnx1; bny[1] = bny1; bnz[1] = bnz1;
    bt[2]  = bhit2 ? bt2 : (MAX_T + 1.0);
    bhit[2] = bhit2; bnx[2] = bnx2; bny[2] = bny2; bnz[2] = bnz2;
    bt[3]  = bhit3 ? bt3 : (MAX_T + 1.0);
    bhit[3] = bhit3; bnx[3] = bnx3; bny[3] = bny3; bnz[3] = bnz3;
  }

  // Emit pre-projected world-space quad directly into render queue.
  // Takes 4 indices into shadow_tx/ty/tz (avoids ~96B/call stack push).
  void shadow_emit_projected_quad(int i00, int i10, int i11, int i01,
                                  uint colour, double z_bias) {
    if (active_faces >= MAX_FACES)
      return;
    array<double> @sx = @shadow_tx;
    array<double> @sy = @shadow_ty;
    array<double> @sz = @shadow_tz;
    double tx1 = sx[i00], ty1 = sy[i00], tz1 = sz[i00];
    double tx2 = sx[i10], ty2 = sy[i10], tz2 = sz[i10];
    double tx3 = sx[i11], ty3 = sy[i11], tz3 = sz[i11];
    double tx4 = sx[i01], ty4 = sy[i01], tz4 = sz[i01];
    // Near-plane cull: reject quad if ANY corner behind cam near plane.
    // Stricter than ALL-behind because shadow grid quads span 10s-100s
    // of world units; clamping one behind-cam corner would paint a
    // huge glitchy slice. Adjacent grid quads cover the gap.
    if (tx1 < 0.1 || tx2 < 0.1 || tx3 < 0.1 || tx4 < 0.1) {
      return;
    }
    double sort_dist = (tx1 + tx2 + tx3 + tx4) * 0.25 - z_bias;

    int af = active_faces;
    int b  = af << 4;
    array<double> @rd = @rq_data;
    array<uint>   @rc = @rq_colour;
    array<int64>  @rs = @rq_sort_packed;
    rd[b]      = tx1;
    rd[b + 1]  = ty1;
    rd[b + 2]  = tz1;
    rd[b + 3]  = tx2;
    rd[b + 4]  = ty2;
    rd[b + 5]  = tz2;
    rd[b + 6]  = tx3;
    rd[b + 7]  = ty3;
    rd[b + 8]  = tz3;
    rd[b + 9]  = tx4;
    rd[b + 10] = ty4;
    rd[b + 11] = tz4;
    rc[af] = colour;
    rs[af] =
        (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(af | 0x8000);
    active_faces++;
  }

  // Unified solid-shape silhouette projector. CONVEX body in, terrain-
  // projected fan-tessellated silhouette out (no alpha-stacking).
  // Algorithm: Andrew's monotone chain + fan from H[0]. Convexity
  // required (fuselage + each wing half OK; union has armpits).
  // Split into hull-compute + fan-emit so fuselage hull serves as
  // wings' clip target without recomputing.

  // Convex hull in sun-projection space of plane-local 3D body verts.
  // Returns hull count; fills out_PU/PV (2D, CCW) and out_HX/HY/HZ.
  // Returns 0 on degenerate input.
  int compute_silhouette_hull_2d3d(
      const array<double>& BX, const array<double>& BY,
      const array<double>& BZ,
      array<double>& out_PU, array<double>& out_PV,
      array<double>& out_HX, array<double>& out_HY,
      array<double>& out_HZ) {
    // CONTRACT: callers consume returned count, NOT out_*.length.
    // Success path writes [0, hull_count) only; trailing stale data
    // is not read.
    int N = int(BX.length);
    if (N < 3) {
      return 0;
    }

    double sx = plane_local_sun.x;
    double sy = plane_local_sun.y;
    double sz = plane_local_sun.z;
    if (sz > -1e-6 && sz < 1e-6) {
      return 0;
    }

    double inv_sz = 1.0 / sz;
    double ksx = sx * inv_sz;
    double ksy = sy * inv_sz;

    // Hull-scratch member-array hoist (sized at class init: 32/64).
    array<double> @lhs_PU  = @shadow_hull_scratch_PU;
    array<double> @lhs_PV  = @shadow_hull_scratch_PV;
    array<int>    @lhs_idx = @shadow_hull_scratch_idx;
    array<int>    @lhs_H   = @shadow_hull_scratch_H;

    // Step 1: project body vertices along sun_dir onto z=0.
    for (int i = 0; i < N; i++) {
      lhs_PU[i] = BX[i] - BZ[i] * ksx;
      lhs_PV[i] = BY[i] - BZ[i] * ksy;
    }

    // Step 2a: insertion sort by (PU, PV). N <= 30. PU[b]/PV[b] are
    // invariant across the inner swap loop (b = idx[new_j] each iter)
    // — hoisted; only PU[a] re-read per step.
    for (int i = 0; i < N; i++) lhs_idx[i] = i;
    for (int i = 1; i < N; i++) {
      int b = lhs_idx[i];
      double pu_b = lhs_PU[b];
      double pv_b = lhs_PV[b];
      int j = i;
      while (j > 0) {
        int a = lhs_idx[j - 1];
        double pu_a = lhs_PU[a];
        bool ab_ordered =
            (pu_a < pu_b) ||
            (pu_a == pu_b &&
             lhs_PV[a] < pv_b);
        if (ab_ordered) break;
        lhs_idx[j - 1] = b;
        lhs_idx[j] = a;
        j--;
      }
    }

    // Step 2b: Andrew's monotone chain (strict CCW, drops collinear).
    int k = 0;
    for (int i = 0; i < N; i++) {
      int c = lhs_idx[i];
      double pu_c = lhs_PU[c];
      double pv_c = lhs_PV[c];
      while (k >= 2) {
        int a = lhs_H[k - 2], b = lhs_H[k - 1];
        double pu_a = lhs_PU[a];
        double pv_a = lhs_PV[a];
        double pu_b = lhs_PU[b];
        double pv_b = lhs_PV[b];
        double cross = (pu_b - pu_a) * (pv_c - pv_a) -
                       (pv_b - pv_a) * (pu_c - pu_a);
        if (cross <= 0.0) k--;
        else break;
      }
      lhs_H[k++] = c;
    }
    int lower_k = k + 1;
    for (int i = N - 2; i >= 0; i--) {
      int c = lhs_idx[i];
      double pu_c = lhs_PU[c];
      double pv_c = lhs_PV[c];
      while (k >= lower_k) {
        int a = lhs_H[k - 2], b = lhs_H[k - 1];
        double pu_a = lhs_PU[a];
        double pv_a = lhs_PV[a];
        double pu_b = lhs_PU[b];
        double pv_b = lhs_PV[b];
        double cross = (pu_b - pu_a) * (pv_c - pv_a) -
                       (pv_b - pv_a) * (pu_c - pu_a);
        if (cross <= 0.0) k--;
        else break;
      }
      lhs_H[k++] = c;
    }
    // The last vertex duplicates the first — drop it.
    int hull_count = k - 1;
    if (hull_count < 3) {
      return 0;
    }

    // Fill out arrays in CCW order, writing [0, hull_count) only.
    for (int i = 0; i < hull_count; i++) {
      int v = lhs_H[i];
      out_PU[i] = lhs_PU[v];
      out_PV[i] = lhs_PV[v];
      out_HX[i] = BX[v];
      out_HY[i] = BY[v];
      out_HZ[i] = BZ[v];
    }
    return hull_count;
  }

  // Hull cache key setter/clearer. piece_idx in [0,7) caches; else
  // bypass. aux = piece-specific shape scalar (see PlaneController.cpp).
  void set_shadow_hull_cache_key(int piece_idx, double aux) {
    shadow_cache_piece_idx = piece_idx;
    shadow_cache_aux       = aux;
  }
  void clear_shadow_hull_cache_key() {
    shadow_cache_piece_idx = -1;
    shadow_cache_aux       = 0.0;
  }

  // Cached variant. Hit serves stored hull; miss recomputes & stores.
  // Intra-frame outer→internal hits (wings/elevator) are the win;
  // cross-frame hits don't land (plane rotates ~0.003-0.007/frame).
  // piece_idx out of range bypasses (prop rotates).
  int compute_silhouette_hull_2d3d_cached(
      const array<double>& BX, const array<double>& BY,
      const array<double>& BZ,
      array<double>& out_PU, array<double>& out_PV,
      array<double>& out_HX, array<double>& out_HY,
      array<double>& out_HZ) {
    const int   HULL_CACHE_SLOTS  = 7;
    // MAX_V must >= max hull count of any piece. Fuselage's 20-corner
    // body → hull up to 20. WARNING: shrinking below a piece's max
    // hull count causes silent store-failure and persistent dropped
    // shadows; keep MAX_V >= 20.
    const int   HULL_CACHE_MAX_V  = 20;
    const double HULL_FP_TOL      = 1.0e-6;
    const double HULL_AUX_TOL     = 1.0e-6;

    int pi = shadow_cache_piece_idx;
    if (pi < 0 || pi >= HULL_CACHE_SLOTS) {
      // Cache bypass — prop or stray caller.
      return compute_silhouette_hull_2d3d(
          BX, BY, BZ, out_PU, out_PV, out_HX, out_HY, out_HZ);
    }

    double sx = plane_local_sun.x;
    double sy = plane_local_sun.y;
    double sz = plane_local_sun.z;
    double aux = shadow_cache_aux;

    // Hull-cache member-array hoist (reused HIT + MISS paths).
    array<double> @lhc_pu = @shadow_hull_cache_pu;
    array<double> @lhc_pv = @shadow_hull_cache_pv;
    array<double> @lhc_hx = @shadow_hull_cache_hx;
    array<double> @lhc_hy = @shadow_hull_cache_hy;
    array<double> @lhc_hz = @shadow_hull_cache_hz;

    if (shadow_hull_cache_valid[pi]) {
      double dsx = shadow_hull_cache_sx[pi]  - sx;
      double dsy = shadow_hull_cache_sy[pi]  - sy;
      double dsz = shadow_hull_cache_sz[pi]  - sz;
      double dau = shadow_hull_cache_aux[pi] - aux;
      if (dsx > -HULL_FP_TOL && dsx < HULL_FP_TOL &&
          dsy > -HULL_FP_TOL && dsy < HULL_FP_TOL &&
          dsz > -HULL_FP_TOL && dsz < HULL_FP_TOL &&
          dau > -HULL_AUX_TOL && dau < HULL_AUX_TOL) {
        // Cache HIT — copy into out arrays [0, n).
        int n = shadow_hull_cache_count[pi];
        if (n < 3) {
          return 0;
        }
        int base = pi * HULL_CACHE_MAX_V;
        for (int i = 0; i < n; i++) {
          out_PU[i] = lhc_pu[base + i];
          out_PV[i] = lhc_pv[base + i];
          out_HX[i] = lhc_hx[base + i];
          out_HY[i] = lhc_hy[base + i];
          out_HZ[i] = lhc_hz[base + i];
        }
        return n;
      }
    }

    // Cache MISS — compute fresh, then decide whether to store.
    int n = compute_silhouette_hull_2d3d(
        BX, BY, BZ, out_PU, out_PV, out_HX, out_HY, out_HZ);
    if (n >= 0 && n <= HULL_CACHE_MAX_V) {
      // Fits — store and mark valid.
      int base = pi * HULL_CACHE_MAX_V;
      for (int i = 0; i < n; i++) {
        lhc_pu[base + i] = out_PU[i];
        lhc_pv[base + i] = out_PV[i];
        lhc_hx[base + i] = out_HX[i];
        lhc_hy[base + i] = out_HY[i];
        lhc_hz[base + i] = out_HZ[i];
      }
      shadow_hull_cache_count[pi] = n;
      shadow_hull_cache_sx[pi]    = sx;
      shadow_hull_cache_sy[pi]    = sy;
      shadow_hull_cache_sz[pi]    = sz;
      shadow_hull_cache_aux[pi]   = aux;
      shadow_hull_cache_valid[pi] = true;
    } else {
      // Hull exceeds capacity — INVALIDATE (don't mark valid with
      // truncated count). Defensive against MAX_V regression: a
      // truncated store would silently break shadow rendering.
      shadow_hull_cache_valid[pi] = false;
    }
    return n;
  }

  // Fan-tessellate a polygon (count vertices) from vertex 0, emitting
  // each triangle (P[0], P[i], P[i+1]) as a degenerate quad via
  // shadow_project_silhouette. Valid for convex polygons AND for non-
  // convex polygons that are star-shaped from vertex 0 (i.e., every
  // point in the polygon is visible from P[0] without crossing the
  // boundary). hull_minus_convex satisfies the latter by rotating its
  // output so the vertex farthest from the clip-polygon centroid is at
  // index 0.
  void emit_silhouette_polygon_fan_from_v0(
      const array<double>& HX, const array<double>& HY,
      const array<double>& HZ, int count,
      int grid_nu, int grid_nv) {
    // shadow_project_silhouette reads shadow_ctx_* class members
    // directly; pos+basis+colour+z_bias not passed.
    if (count < 3) return;
    for (int i = 1; i <= count - 2; i++) {
      shadow_project_silhouette(
          HX[0], HY[0], HZ[0],
          HX[i], HY[i], HZ[i],
          HX[i + 1], HY[i + 1], HZ[i + 1],
          HX[0], HY[0], HZ[0],
          grid_nu, grid_nv);
    }
  }

  // Ear-clipping triangulation of a simple CCW polygon (may be non-
  // convex, must not self-intersect). Required for hull_minus_convex's
  // dent case (empty kernel — fan-from-anchor would alpha-stack).
  // Doubly-linked list via prev/next arrays. O(n^2), n <= ~15.
  // PU/PV: 2D for ear tests; HX/HY/HZ: 3D for raycasts.
  void emit_silhouette_polygon_earclip(
      const array<double>& PU, const array<double>& PV,
      const array<double>& HX, const array<double>& HY,
      const array<double>& HZ, int n,
      int grid_nu, int grid_nv) {
    // shadow_project_silhouette reads shadow_ctx_* class members
    // directly; pos+basis+colour+z_bias not passed.
    if (n < 3) return;

    // Fast path: n == 3 is already a triangle.
    if (n == 3) {
      shadow_project_silhouette(
          HX[0], HY[0], HZ[0],
          HX[1], HY[1], HZ[1],
          HX[2], HY[2], HZ[2],
          HX[0], HY[0], HZ[0],
          grid_nu, grid_nv);
      return;
    }

    // Linked-list ear-clip cycle. Uses ear_INNER scratch (NOT OUTER
    // — may be called nested under hull_minus_two_convex). Pre-sized 32.
    array<int> @lei_next = @shadow_ear_inner_next;
    array<int> @lei_prev = @shadow_ear_inner_prev;
    for (int i = 0; i < n; i++) {
      // Ternary wrap (AS modulo is expensive int-div; step is ±1).
      lei_next[i] = (i + 1 == n)  ? 0     : i + 1;
      lei_prev[i] = (i == 0)      ? n - 1 : i - 1;
    }
    int alive = n;

    // Reflex-vertex bitmask. Only reflex verts can lie inside an ear
    // triangle of a simple polygon (classic result). Pre-compute once;
    // unlink b only changes a's + c's neighborhoods. uint64 future-
    // proofs polygon size > 32.
    //
    // reflex_count drives all-convex fast-path; lei_reflex list drives
    // reflex-iterator (replaces full ring walk in inner ear-test).
    array<int> @lei_reflex = @shadow_ear_inner_reflex;
    uint64 reflex_mask = 0;
    int    reflex_count = 0;
    for (int i = 0; i < n; i++) {
      int iprev = lei_prev[i];
      int inext = lei_next[i];
      double dba_x = PU[i] - PU[iprev], dba_y = PV[i] - PV[iprev];
      double dcb_x = PU[inext] - PU[i], dcb_y = PV[inext] - PV[i];
      double cross_i = dba_x * dcb_y - dba_y * dcb_x;
      if (cross_i <= 1.0e-9) {
        reflex_mask |= (uint64(1) << i);
        lei_reflex[reflex_count++] = i;
      }
    }

    // Convex fast-path: if no vertex is reflex, emit as a fan from V0.
    //
    // UNREACHABLE NOTE: reflex_count == 0 is unreachable from current
    // call sites. Both callers feed convex-minus-convex output (W\F or
    // T\F2); tracing F's boundary CW within a CCW result makes every
    // F-vertex reflex. AABB-disjoint case (when this fast-path would
    // fire) is short-circuited upstream by W/F AABB pre-reject in
    // hull_minus_convex. Branch left as defensive zero-cost dead code
    // (1 compare/call) — would fire correctly for a future caller that
    // feeds a pre-known convex polygon.
    if (reflex_count == 0) {
      double v0x = HX[0], v0y = HY[0], v0z = HZ[0];
      for (int fi = 1; fi <= n - 2; fi++) {
        shadow_project_silhouette(
            v0x,         v0y,         v0z,
            HX[fi],      HY[fi],      HZ[fi],
            HX[fi + 1],  HY[fi + 1],  HZ[fi + 1],
            v0x,         v0y,         v0z,
            grid_nu, grid_nv);
      }
      return;
    }

    // Start scanning from vertex 0.
    int cur = 0;
    int guard = 0;
    int max_guard = 3 * n + 10;

    while (alive > 3 && guard < max_guard) {
      int a = lei_prev[cur];
      int b = cur;
      int c = lei_next[cur];

      double ax = PU[a], ay = PV[a];
      double bx = PU[b], by = PV[b];
      double cx = PU[c], cy = PV[c];

      // Hoist ear-edge deltas (invariant within inner scan).
      double dba_x = bx - ax, dba_y = by - ay;
      double dcb_x = cx - bx, dcb_y = cy - by;
      double dac_x = ax - cx, dac_y = ay - cy;

      // Convex (CCW) turn at b?
      double cross = dba_x * dcb_y - dba_y * dcb_x;
      bool is_convex = (cross > 1.0e-9);

      // No OTHER live vertex inside triangle (a, b, c)?
      bool is_ear = is_convex;
      if (is_ear) {
        // AABB pre-reject of candidate ear triangle.
        double ear_min_u = (ax < bx) ? ((ax < cx) ? ax : cx)
                                     : ((bx < cx) ? bx : cx);
        double ear_max_u = (ax > bx) ? ((ax > cx) ? ax : cx)
                                     : ((bx > cx) ? bx : cx);
        double ear_min_v = (ay < by) ? ((ay < cy) ? ay : cy)
                                     : ((by < cy) ? by : cy);
        double ear_max_v = (ay > by) ? ((ay > cy) ? ay : cy)
                                     : ((by > cy) ? by : cy);
        // Reflex-iterator: walk lei_reflex (alive reflex verts) only.
        // b is convex by gate; a/c may be reflex so checks stay.
        for (int ri = 0; ri < reflex_count; ri++) {
          int v = lei_reflex[ri];
          if (v == a || v == c) continue;
          double qx = PU[v], qy = PV[v];
          // AABB pre-reject — outside ear bbox ⇒ outside ear triangle.
          if (qx < ear_min_u || qx > ear_max_u ||
              qy < ear_min_v || qy > ear_max_v) continue;
          double s1 = dba_x * (qy - ay) - dba_y * (qx - ax);
          double s2 = dcb_x * (qy - by) - dcb_y * (qx - bx);
          double s3 = dac_x * (qy - cy) - dac_y * (qx - cx);
          // Strict interior (not on edge) counts as inside.
          if (s1 > 1.0e-9 && s2 > 1.0e-9 && s3 > 1.0e-9) {
            is_ear = false;
            break;
          }
        }
      }

      if (is_ear) {
        shadow_project_silhouette(
            HX[a], HY[a], HZ[a],
            HX[b], HY[b], HZ[b],
            HX[c], HY[c], HZ[c],
            HX[a], HY[a], HZ[a],
            grid_nu, grid_nv);
        // Capture pre-unlink reflex states (b convex by gate, bit=0).
        bool a_was_reflex = (reflex_mask & (uint64(1) << a)) != 0;
        bool c_was_reflex = (reflex_mask & (uint64(1) << c)) != 0;
        // Unlink b from ring.
        lei_next[a] = c;
        lei_prev[c] = a;
        alive--;
        // Update reflex_mask for a, c (only their neighborhoods changed).
        bool a_now_reflex;
        bool c_now_reflex;
        {
          int a_prev = lei_prev[a];
          double da_x = PU[a] - PU[a_prev], da_y = PV[a] - PV[a_prev];
          double dca_x = PU[c] - PU[a],     dca_y = PV[c] - PV[a];
          double cross_a = da_x * dca_y - da_y * dca_x;
          a_now_reflex = (cross_a <= 1.0e-9);
          if (a_now_reflex) reflex_mask |=  (uint64(1) << a);
          else              reflex_mask &= ~(uint64(1) << a);
          int c_next = lei_next[c];
          // dcc = dca after the unlink (c's prev IS a now).
          double dnc_x = PU[c_next] - PU[c], dnc_y = PV[c_next] - PV[c];
          double cross_c = dca_x * dnc_y - dca_y * dnc_x;
          c_now_reflex = (cross_c <= 1.0e-9);
          if (c_now_reflex) reflex_mask |=  (uint64(1) << c);
          else              reflex_mask &= ~(uint64(1) << c);
        }
        // Maintain lei_reflex sync with reflex_mask (a + c transitions).
        if (a_now_reflex && !a_was_reflex) {
          lei_reflex[reflex_count++] = a;
        } else if (!a_now_reflex && a_was_reflex) {
          for (int ri = 0; ri < reflex_count; ri++) {
            if (lei_reflex[ri] == a) {
              lei_reflex[ri] = lei_reflex[--reflex_count];
              break;
            }
          }
        }
        if (c_now_reflex && !c_was_reflex) {
          lei_reflex[reflex_count++] = c;
        } else if (!c_now_reflex && c_was_reflex) {
          for (int ri = 0; ri < reflex_count; ri++) {
            if (lei_reflex[ri] == c) {
              lei_reflex[ri] = lei_reflex[--reflex_count];
              break;
            }
          }
        }
        // Resume from a (a/c convexity may have shifted).
        cur = a;
        guard = 0;
      } else {
        cur = c;
        guard++;
      }
    }

    // Final triangle.
    if (alive == 3) {
      int a = cur;
      int b = lei_next[a];
      int c = lei_next[b];
      shadow_project_silhouette(
          HX[a], HY[a], HZ[a],
          HX[b], HY[b], HZ[b],
          HX[c], HY[c], HZ[c],
          HX[a], HY[a], HZ[a],
          grid_nu, grid_nv);
    }
    // alive>3 at guard = degenerate polygon; drop remaining tris.
  }

  // Point-in-convex-CCW-polygon test using pre-computed F-edge deltas.
  // Boundary = inside (avoids flapping at wing-root crossings).
  bool point_in_convex_ccw_polygon_with_deltas(
      double u, double v,
      const array<double>& PU, const array<double>& PV,
      const array<double>& DU, const array<double>& DV, int n) {
    for (int j = 0; j < n; j++) {
      double dx = DU[j];
      double dy = DV[j];
      double cross = dx * (v - PV[j]) - dy * (u - PU[j]);
      if (cross < -1e-9) return false;
    }
    return true;
  }

  // Compute W \ F in sun-projection space (W, F both convex CCW).
  // Emits possibly-non-convex simple polygon for ear-clip emission.
  //
  // Algorithm (edge-crossing Weiler-Atherton for convex ∖ convex):
  //   1. Find boundary crossings (0 or 2 by convex-curves lemma).
  //   2. 0 crossings + W[0] inside F → empty result (-1).
  //      0 crossings + W[0] outside → emit W (disjoint or F⊂W).
  //   3. 2 crossings: splice W's outside-F arc with F's inside-W arc.
  //      Sort by (w_edge, t_w) handles both standard mixed AND
  //      "dent case" (both crossings on same W edge, F pokes through).
  //
  // Ear clipping (not fan) is required because dent case produces
  // empty kernel — no single anchor works; any fan crosses F.
  //
  // Returns: -1 = W fully inside F (empty), 0 = degenerate input,
  // >0 = output vertex count. Disjoint/F⊂W/numerical fallback returns
  // W's own vertices unchanged.
  int compute_convex_minus_convex_polygon(
      const array<double>& WPU, const array<double>& WPV,
      const array<double>& WHX, const array<double>& WHY,
      const array<double>& WHZ, int nW,
      const array<double>& FPU, const array<double>& FPV,
      const array<double>& FHX, const array<double>& FHY,
      const array<double>& FHZ, int nF,
      array<double>& out_PU, array<double>& out_PV,
      array<double>& out_HX, array<double>& out_HY,
      array<double>& out_HZ) {
    // CONTRACT: out_*/shadow_cx_* pre-sized; callers MUST use returned
    // count, never out_*.length. Reset disjoint flag at entry.
    shadow_ccmc_was_disjoint = false;
    if (nW < 3 || nF < 3) return 0;

    // Top-level 2D AABB pre-reject; disjoint ⇒ outside-F branch.
    double w_min_u = WPU[0], w_max_u = WPU[0];
    double w_min_v = WPV[0], w_max_v = WPV[0];
    for (int i = 1; i < nW; i++) {
      double u = WPU[i], v = WPV[i];
      if (u < w_min_u) w_min_u = u; else if (u > w_max_u) w_max_u = u;
      if (v < w_min_v) w_min_v = v; else if (v > w_max_v) w_max_v = v;
    }
    // Cached fuselage AABB fast-path (handle pointer compare).
    double f_min_u, f_max_u, f_min_v, f_max_v;
    if (@FPU == @shadow_hull_out_fus_pu) {
      f_min_u = shadow_ctx_fus_min_u; f_max_u = shadow_ctx_fus_max_u;
      f_min_v = shadow_ctx_fus_min_v; f_max_v = shadow_ctx_fus_max_v;
    } else {
      f_min_u = FPU[0]; f_max_u = FPU[0];
      f_min_v = FPV[0]; f_max_v = FPV[0];
      for (int i = 1; i < nF; i++) {
        double u = FPU[i], v = FPV[i];
        if (u < f_min_u) f_min_u = u; else if (u > f_max_u) f_max_u = u;
        if (v < f_min_v) f_min_v = v; else if (v > f_max_v) f_max_v = v;
      }
    }
    if (w_max_u < f_min_u || w_min_u > f_max_u ||
        w_max_v < f_min_v || w_min_v > f_max_v) {
      shadow_ccmc_was_disjoint = true;
      int out_n = 0;
      for (int i = 0; i < nW; i++) {
        out_PU[out_n] = WPU[i]; out_PV[out_n] = WPV[i];
        out_HX[out_n] = WHX[i]; out_HY[out_n] = WHY[i];
        out_HZ[out_n] = WHZ[i];
        out_n++;
      }
      return out_n;
    }

    array<int>    @lcx_we = @shadow_cx_w_edge;
    array<double> @lcx_tw = @shadow_cx_t_w;
    array<int>    @lcx_fe = @shadow_cx_f_edge;
    // F-edge delta pre-pass (invariant across nW outer iters; nF <= 32).
    array<double> @lcx_f_du = @shadow_cx_f_du;
    array<double> @lcx_f_dv = @shadow_cx_f_dv;
    for (int j = 0; j < nF; j++) {
      int jnext = (j + 1 == nF) ? 0 : j + 1;
      lcx_f_du[j] = FPU[jnext] - FPU[j];
      lcx_f_dv[j] = FPV[jnext] - FPV[j];
    }

    // Step 1: W×F boundary crossings as (w_edge, t_w, f_edge).
    int ncx = 0;
    for (int i = 0; i < nW; i++) {
      int inext = (i + 1 == nW) ? 0 : i + 1;
      double wu1 = WPU[i], wv1 = WPV[i];
      double wu2 = WPU[inext], wv2 = WPV[inext];
      // Per-W-edge AABB pre-reject (most W edges in dent/partial cases
      // miss F bbox even when polygons overlap).
      double w_edge_min_u, w_edge_max_u;
      if (wu1 < wu2) { w_edge_min_u = wu1; w_edge_max_u = wu2; }
      else           { w_edge_min_u = wu2; w_edge_max_u = wu1; }
      double w_edge_min_v, w_edge_max_v;
      if (wv1 < wv2) { w_edge_min_v = wv1; w_edge_max_v = wv2; }
      else           { w_edge_min_v = wv2; w_edge_max_v = wv1; }
      if (w_edge_max_u < f_min_u || w_edge_min_u > f_max_u ||
          w_edge_max_v < f_min_v || w_edge_min_v > f_max_v) {
        continue;  // edge isolated from F — no crossings possible
      }
      double dwu = wu2 - wu1, dwv = wv2 - wv1;
      for (int j = 0; j < nF; j++) {
        double fu1 = FPU[j], fv1 = FPV[j];
        double dfu = lcx_f_du[j], dfv = lcx_f_dv[j];
        double det = dfu * dwv - dwu * dfv;
        if (det > -1e-12 && det < 1e-12) continue;  // parallel
        double dx = fu1 - wu1;
        double dy = fv1 - wv1;
        // Division-free pre-reject. ~95% reject pre-division; num_f
        // deferred past num_w gate.
        double eps_det = 1e-7 * det;
        double bound_lo, bound_hi;
        if (det > 0.0) { bound_lo = eps_det;       bound_hi = det - eps_det; }
        else           { bound_lo = det - eps_det; bound_hi = eps_det;       }
        double num_w = dfu * dy - dfv * dx;
        if (num_w < bound_lo || num_w > bound_hi) continue;
        double num_f = dwu * dy - dwv * dx;
        if (num_f < bound_lo || num_f > bound_hi) continue;
        double t_w = num_w / det;
        lcx_we[ncx] = i;
        lcx_tw[ncx] = t_w;
        lcx_fe[ncx] = j;
        ncx++;
      }
    }
    int nc = ncx;

    int out_n = 0;

    // Step 2: 0 crossings — disjoint, W⊂F, or F⊂W.
    if (nc == 0) {
      if (point_in_convex_ccw_polygon_with_deltas(
              WPU[0], WPV[0], FPU, FPV, lcx_f_du, lcx_f_dv, nF)) {
        return -1;  // W fully inside F — empty result.
      }
      // Disjoint or F⊂W. Signal to hull_minus_two_convex (routes around
      // ear-clipper). Copy W unchanged.
      shadow_ccmc_was_disjoint = true;
      for (int i = 0; i < nW; i++) {
        out_PU[out_n] = WPU[i]; out_PV[out_n] = WPV[i];
        out_HX[out_n] = WHX[i]; out_HY[out_n] = WHY[i];
        out_HZ[out_n] = WHZ[i];
        out_n++;
      }
      return out_n;
    }

    // Step 3: expect exactly 2 crossings. Anything else = numerical
    // noise (tangent edges, coincident vertices). Fall back to W.
    if (nc != 2) {
      for (int i = 0; i < nW; i++) {
        out_PU[out_n] = WPU[i]; out_PV[out_n] = WPV[i];
        out_HX[out_n] = WHX[i]; out_HY[out_n] = WHY[i];
        out_HZ[out_n] = WHZ[i];
        out_n++;
      }
      return out_n;
    }

    // Sort the 2 crossings into CCW-traversal order along W.
    int i0 = 0, i1 = 1;
    if (lcx_we[0] > lcx_we[1] ||
        (lcx_we[0] == lcx_we[1] && lcx_tw[0] > lcx_tw[1])) {
      i0 = 1; i1 = 0;
    }
    int c0_we = lcx_we[i0]; double c0_tw = lcx_tw[i0]; int c0_fe = lcx_fe[i0];
    int c1_we = lcx_we[i1]; double c1_tw = lcx_tw[i1]; int c1_fe = lcx_fe[i1];

    // Enter vs exit: test point just CCW-past c0 on W's boundary.
    double test_u = 0.0, test_v = 0.0;
    const double eps = 1.0e-4;
    if (c0_tw + eps < 1.0) {
      int c0_next = (c0_we + 1 == nW) ? 0 : c0_we + 1;
      test_u = WPU[c0_we] + (c0_tw + eps) * (WPU[c0_next] - WPU[c0_we]);
      test_v = WPV[c0_we] + (c0_tw + eps) * (WPV[c0_next] - WPV[c0_we]);
    } else {
      int ne = (c0_we + 1 == nW) ? 0 : c0_we + 1;
      int ne_next = (ne + 1 == nW) ? 0 : ne + 1;
      test_u = WPU[ne] + eps * (WPU[ne_next] - WPU[ne]);
      test_v = WPV[ne] + eps * (WPV[ne_next] - WPV[ne]);
    }
    bool c0_is_enter =
        point_in_convex_ccw_polygon_with_deltas(
            test_u, test_v, FPU, FPV, lcx_f_du, lcx_f_dv, nF);

    int enter_idx, exit_idx, f_enter_edge, f_exit_edge;
    double t_enter, t_exit;
    if (c0_is_enter) {
      enter_idx = c0_we; t_enter = c0_tw; f_enter_edge = c0_fe;
      exit_idx  = c1_we; t_exit  = c1_tw; f_exit_edge  = c1_fe;
    } else {
      enter_idx = c1_we; t_enter = c1_tw; f_enter_edge = c1_fe;
      exit_idx  = c0_we; t_exit  = c0_tw; f_exit_edge  = c0_fe;
    }

    int enter_next = (enter_idx + 1 == nW) ? 0 : enter_idx + 1;
    int exit_next  = (exit_idx  + 1 == nW) ? 0 : exit_idx  + 1;

    // Interpolate 2D and 3D at P_enter and P_exit along W's edges.
    double p_enter_pu = WPU[enter_idx] + t_enter * (WPU[enter_next] - WPU[enter_idx]);
    double p_enter_pv = WPV[enter_idx] + t_enter * (WPV[enter_next] - WPV[enter_idx]);
    double p_enter_hx = WHX[enter_idx] + t_enter * (WHX[enter_next] - WHX[enter_idx]);
    double p_enter_hy = WHY[enter_idx] + t_enter * (WHY[enter_next] - WHY[enter_idx]);
    double p_enter_hz = WHZ[enter_idx] + t_enter * (WHZ[enter_next] - WHZ[enter_idx]);

    double p_exit_pu = WPU[exit_idx] + t_exit * (WPU[exit_next] - WPU[exit_idx]);
    double p_exit_pv = WPV[exit_idx] + t_exit * (WPV[exit_next] - WPV[exit_idx]);
    double p_exit_hx = WHX[exit_idx] + t_exit * (WHX[exit_next] - WHX[exit_idx]);
    double p_exit_hy = WHY[exit_idx] + t_exit * (WHY[exit_next] - WHY[exit_idx]);
    double p_exit_hz = WHZ[exit_idx] + t_exit * (WHZ[exit_next] - WHZ[exit_idx]);

    // Build P = W \ F.
    // W CCW arc from exit_next through outside vertices to enter_idx.
    int cur = exit_next;
    int guard = 0;
    while (true) {
      out_PU[out_n] = WPU[cur]; out_PV[out_n] = WPV[cur];
      out_HX[out_n] = WHX[cur]; out_HY[out_n] = WHY[cur];
      out_HZ[out_n] = WHZ[cur];
      out_n++;
      if (cur == enter_idx) break;
      cur = (cur + 1 == nW) ? 0 : cur + 1;
      guard++;
      if (guard > nW + 2) break;
    }
    // P_enter on W's boundary.
    out_PU[out_n] = p_enter_pu; out_PV[out_n] = p_enter_pv;
    out_HX[out_n] = p_enter_hx; out_HY[out_n] = p_enter_hy;
    out_HZ[out_n] = p_enter_hz;
    out_n++;
    // F CW arc from F[f_enter_edge] back to F[f_exit_edge+1].
    // Same-edge case skips arc (no F verts between crossings).
    if (f_enter_edge != f_exit_edge) {
      int j = f_enter_edge;
      int j_stop = (f_exit_edge + 1 == nF) ? 0 : f_exit_edge + 1;
      guard = 0;
      while (true) {
        out_PU[out_n] = FPU[j]; out_PV[out_n] = FPV[j];
        out_HX[out_n] = FHX[j]; out_HY[out_n] = FHY[j];
        out_HZ[out_n] = FHZ[j];
        out_n++;
        if (j == j_stop) break;
        j = (j == 0) ? nF - 1 : j - 1;
        guard++;
        if (guard > nF + 2) break;
      }
    }
    // P_exit on W's boundary.
    out_PU[out_n] = p_exit_pu; out_PV[out_n] = p_exit_pv;
    out_HX[out_n] = p_exit_hx; out_HY[out_n] = p_exit_hy;
    out_HZ[out_n] = p_exit_hz;
    out_n++;

    return out_n;
  }

  // Emit triangle T clipped against convex F2 (used by
  // hull_minus_two_convex). T \ F2 via convex-minus-convex; results
  // through emit_silhouette_polygon_earclip.
  void emit_tri_clipped_against_F2(
      double t0_pu, double t0_pv, double t0_hx, double t0_hy, double t0_hz,
      double t1_pu, double t1_pv, double t1_hx, double t1_hy, double t1_hz,
      double t2_pu, double t2_pv, double t2_hx, double t2_hy, double t2_hz,
      const array<double>& F2PU, const array<double>& F2PV,
      const array<double>& F2HX, const array<double>& F2HY,
      const array<double>& F2HZ, int nF2,
      double f2_min_u, double f2_max_u,
      double f2_min_v, double f2_max_v,
      int grid_nu, int grid_nv) {
    // Downstream emit reads shadow_ctx_* directly.
    if (nF2 < 3) {
      // No valid F2: emit T as a degenerate quad.
      shadow_project_silhouette(
          t0_hx, t0_hy, t0_hz,
          t1_hx, t1_hy, t1_hz,
          t2_hx, t2_hy, t2_hz,
          t0_hx, t0_hy, t0_hz,
          grid_nu, grid_nv);
      return;
    }
    // 2D AABB pre-reject + zero-copy direct emit when T disjoint from
    // F2 (common: pant/tw ears vs opposite-side F2). T-inside-F2
    // cannot collide here (T⊂F2 ⇒ AABB(T)⊂AABB(F2)).
    double t_min_u = (t0_pu < t1_pu)
                     ? ((t0_pu < t2_pu) ? t0_pu : t2_pu)
                     : ((t1_pu < t2_pu) ? t1_pu : t2_pu);
    double t_max_u = (t0_pu > t1_pu)
                     ? ((t0_pu > t2_pu) ? t0_pu : t2_pu)
                     : ((t1_pu > t2_pu) ? t1_pu : t2_pu);
    double t_min_v = (t0_pv < t1_pv)
                     ? ((t0_pv < t2_pv) ? t0_pv : t2_pv)
                     : ((t1_pv < t2_pv) ? t1_pv : t2_pv);
    double t_max_v = (t0_pv > t1_pv)
                     ? ((t0_pv > t2_pv) ? t0_pv : t2_pv)
                     : ((t1_pv > t2_pv) ? t1_pv : t2_pv);
    if (t_max_u < f2_min_u || t_min_u > f2_max_u ||
        t_max_v < f2_min_v || t_min_v > f2_max_v) {
      // Disjoint — direct emit, bypass WA + clipB + earclip.
      shadow_project_silhouette(
          t0_hx, t0_hy, t0_hz,
          t1_hx, t1_hy, t1_hz,
          t2_hx, t2_hy, t2_hz,
          t0_hx, t0_hy, t0_hz,
          grid_nu, grid_nv);
      return;
    }
    // Build T arrays (3 verts) in scratch.
    shadow_tri_PU[0] = t0_pu; shadow_tri_PV[0] = t0_pv;
    shadow_tri_HX[0] = t0_hx; shadow_tri_HY[0] = t0_hy; shadow_tri_HZ[0] = t0_hz;
    shadow_tri_PU[1] = t1_pu; shadow_tri_PV[1] = t1_pv;
    shadow_tri_HX[1] = t1_hx; shadow_tri_HY[1] = t1_hy; shadow_tri_HZ[1] = t1_hz;
    shadow_tri_PU[2] = t2_pu; shadow_tri_PV[2] = t2_pv;
    shadow_tri_HX[2] = t2_hx; shadow_tri_HY[2] = t2_hy; shadow_tri_HZ[2] = t2_hz;

    // R = T \ F2 into clipB_* (clipA_* is live with outer P1).
    int nR = compute_convex_minus_convex_polygon(
        shadow_tri_PU, shadow_tri_PV, shadow_tri_HX, shadow_tri_HY, shadow_tri_HZ, 3,
        F2PU, F2PV, F2HX, F2HY, F2HZ, nF2,
        shadow_clipB_PU, shadow_clipB_PV,
        shadow_clipB_HX, shadow_clipB_HY, shadow_clipB_HZ);
    if (nR == -1) return;        // T fully inside F2 — skip.
    if (nR < 3) return;          // Degenerate; drop.
    // earclip uses ear_INNER (outer P1's ear_outer stays intact).
    emit_silhouette_polygon_earclip(
        shadow_clipB_PU, shadow_clipB_PV,
        shadow_clipB_HX, shadow_clipB_HY, shadow_clipB_HZ, nR,
        grid_nu, grid_nv);
  }

  // Emit (W \ F1) \ F2 where W = convex body hull, F1/F2 = two
  // independent convex CCW clips. Gear pants/tail-wheel can overlap
  // BOTH fuselage AND wing/elevator; (F1 ∪ F2) over-clips the bridge.
  //
  // Algorithm: P1 = W\F1 (non-convex), ear-clip into tris, each ear
  // T → T\F2 (convex\convex stays robust).
  void shadow_project_silhouette_hull_minus_two_convex(
      const array<double>& BX, const array<double>& BY,
      const array<double>& BZ,
      const array<double>& F1PU, const array<double>& F1PV,
      const array<double>& F1HX, const array<double>& F1HY,
      const array<double>& F1HZ,
      int nF1,
      const array<double>& F2PU, const array<double>& F2PV,
      const array<double>& F2HX, const array<double>& F2HY,
      const array<double>& F2HZ,
      int nF2,
      int grid_nu, int grid_nv) {
    // nF1/nF2 explicit counts. Caller must call set_shadow_hull_cache_key
    // first for cache hit.
    int nW = compute_silhouette_hull_2d3d_cached(
        BX, BY, BZ, shadow_W_PU, shadow_W_PV,
        shadow_W_HX, shadow_W_HY, shadow_W_HZ);
    if (nW < 3) return;

    // Step 1: P1 = W \ F1 into clipA_*.
    int nP1 = (nF1 >= 3)
        ? compute_convex_minus_convex_polygon(
              shadow_W_PU, shadow_W_PV,
              shadow_W_HX, shadow_W_HY, shadow_W_HZ, nW,
              F1PU, F1PV, F1HX, F1HY, F1HZ, nF1,
              shadow_clipA_PU, shadow_clipA_PV,
              shadow_clipA_HX, shadow_clipA_HY, shadow_clipA_HZ)
        : 0;
    if (nP1 == -1) return;  // W fully inside F1, nothing to emit.

    // W/clipA/ear-outer hoist (after early -1 return).
    array<double> @lW_PU  = @shadow_W_PU;
    array<double> @lW_PV  = @shadow_W_PV;
    array<double> @lW_HX  = @shadow_W_HX;
    array<double> @lW_HY  = @shadow_W_HY;
    array<double> @lW_HZ  = @shadow_W_HZ;
    array<double> @lcA_PU = @shadow_clipA_PU;
    array<double> @lcA_PV = @shadow_clipA_PV;
    array<double> @lcA_HX = @shadow_clipA_HX;
    array<double> @lcA_HY = @shadow_clipA_HY;
    array<double> @lcA_HZ = @shadow_clipA_HZ;
    array<int>    @leo_next = @shadow_ear_outer_next;
    array<int>    @leo_prev = @shadow_ear_outer_prev;

    // Disjoint short-circuit: P1 == W (convex), route to single-clip
    // hull_minus_convex with W \ F2 and skip ear-clip + per-tri F2.
    // F⊂W case (rare): same path; F1 dropped, F2 still clipped.
    if (shadow_ccmc_was_disjoint) {
      shadow_project_silhouette_hull_minus_convex(
          BX, BY, BZ,
          F2PU, F2PV, F2HX, F2HY, F2HZ, nF2,
          grid_nu, grid_nv);
      return;
    }

    if (nP1 < 3) {
      // Degenerate path: fall back to P1 = W (indexed-write into clipA_*).
      for (int i = 0; i < nW; i++) {
        lcA_PU[i] = lW_PU[i];
        lcA_PV[i] = lW_PV[i];
        lcA_HX[i] = lW_HX[i];
        lcA_HY[i] = lW_HY[i];
        lcA_HZ[i] = lW_HZ[i];
      }
      nP1 = nW;
    }

    // Step 2: ear-clip P1 with ear_OUTER scratch; per ear T → T\F2.
    if (nP1 < 3) return;

    // F2 2D bbox computed once (invariant across ears).
    double f2_min_u = F2PU[0], f2_max_u = F2PU[0];
    double f2_min_v = F2PV[0], f2_max_v = F2PV[0];
    for (int fi = 1; fi < nF2; fi++) {
      double fu = F2PU[fi], fv = F2PV[fi];
      if (fu < f2_min_u) f2_min_u = fu; else if (fu > f2_max_u) f2_max_u = fu;
      if (fv < f2_min_v) f2_min_v = fv; else if (fv > f2_max_v) f2_max_v = fv;
    }

    // Pre-sized 32; nP1 ≤ nW + nF1 ≈ 26.
    for (int i = 0; i < nP1; i++) {
      // Ternary wrap (AS modulo is expensive; step is ±1).
      leo_next[i] = (i + 1 == nP1) ? 0       : i + 1;
      leo_prev[i] = (i == 0)       ? nP1 - 1 : i - 1;
    }
    int alive = nP1;
    int cur = 0;
    int guard = 0;
    int max_guard = 3 * nP1 + 10;

    // Reflex-vertex bitmask — sibling of lei_* site. uint64 future-
    // proofs if hulls grow past 32 (nP1 stays ≤32 empirically).
    //
    // TRIED AND REVERTED: porting reflex-iterator (lei_reflex list)
    // to this site caused hl/bn spikes. Root cause: tracing F1's
    // boundary CW within CCW W produces a reflex-HEAVY polygon
    // (reflex_count ≈ 8-12) so per-ear maintenance dominates iter
    // savings. lei_* T∖F2 polygon is small AND reflex-light → iterator
    // wins there but NOT here. DON'T retry without measured reflex_count
    // distribution AND a sublinear maintenance scheme.
    uint64 reflex_mask = 0;
    for (int i = 0; i < nP1; i++) {
      int iprev = leo_prev[i];
      int inext = leo_next[i];
      double dba_x = lcA_PU[i] - lcA_PU[iprev], dba_y = lcA_PV[i] - lcA_PV[iprev];
      double dcb_x = lcA_PU[inext] - lcA_PU[i], dcb_y = lcA_PV[inext] - lcA_PV[i];
      double cross_i = dba_x * dcb_y - dba_y * dcb_x;
      if (cross_i <= 1.0e-9) reflex_mask |= (uint64(1) << i);
    }

    while (alive > 3 && guard < max_guard) {
      int a = leo_prev[cur];
      int b = cur;
      int c = leo_next[cur];

      double ax = lcA_PU[a], ay = lcA_PV[a];
      double bx = lcA_PU[b], by = lcA_PV[b];
      double cx = lcA_PU[c], cy = lcA_PV[c];

      // Hoist ear-edge deltas (sibling of lei_*).
      double dba_x = bx - ax, dba_y = by - ay;
      double dcb_x = cx - bx, dcb_y = cy - by;
      double dac_x = ax - cx, dac_y = ay - cy;

      double cross = dba_x * dcb_y - dba_y * dcb_x;
      bool is_convex = (cross > 1.0e-9);
      bool is_ear = is_convex;
      if (is_ear) {
        double ear_min_u = (ax < bx) ? ((ax < cx) ? ax : cx)
                                     : ((bx < cx) ? bx : cx);
        double ear_max_u = (ax > bx) ? ((ax > cx) ? ax : cx)
                                     : ((bx > cx) ? bx : cx);
        double ear_min_v = (ay < by) ? ((ay < cy) ? ay : cy)
                                     : ((by < cy) ? by : cy);
        double ear_max_v = (ay > by) ? ((ay > cy) ? ay : cy)
                                     : ((by > cy) ? by : cy);
        int v = leo_next[c];
        while (v != a) {
          // Reflex-vertex pre-filter.
          if ((reflex_mask & (uint64(1) << v)) == 0) {
            v = leo_next[v];
            continue;
          }
          double qx = lcA_PU[v], qy = lcA_PV[v];
          if (qx < ear_min_u || qx > ear_max_u ||
              qy < ear_min_v || qy > ear_max_v) {
            v = leo_next[v];
            continue;
          }
          double s1 = dba_x * (qy - ay) - dba_y * (qx - ax);
          double s2 = dcb_x * (qy - by) - dcb_y * (qx - bx);
          double s3 = dac_x * (qy - cy) - dac_y * (qx - cx);
          if (s1 > 1.0e-9 && s2 > 1.0e-9 && s3 > 1.0e-9) {
            is_ear = false;
            break;
          }
          v = leo_next[v];
        }
      }

      if (is_ear) {
        emit_tri_clipped_against_F2(
            lcA_PU[a], lcA_PV[a], lcA_HX[a], lcA_HY[a], lcA_HZ[a],
            lcA_PU[b], lcA_PV[b], lcA_HX[b], lcA_HY[b], lcA_HZ[b],
            lcA_PU[c], lcA_PV[c], lcA_HX[c], lcA_HY[c], lcA_HZ[c],
            F2PU, F2PV, F2HX, F2HY, F2HZ, nF2,
            f2_min_u, f2_max_u, f2_min_v, f2_max_v,
            grid_nu, grid_nv);
        leo_next[a] = c;
        leo_prev[c] = a;
        alive--;
        // Update reflex_mask for a, c.
        {
          int a_prev = leo_prev[a];
          double da_x = lcA_PU[a] - lcA_PU[a_prev];
          double da_y = lcA_PV[a] - lcA_PV[a_prev];
          double dca_x = lcA_PU[c] - lcA_PU[a];
          double dca_y = lcA_PV[c] - lcA_PV[a];
          double cross_a = da_x * dca_y - da_y * dca_x;
          if (cross_a > 1.0e-9) reflex_mask &= ~(uint64(1) << a);
          else                  reflex_mask |=  (uint64(1) << a);
          int c_next = leo_next[c];
          // dcc = dca after the unlink (c's prev IS a now).
          double dnc_x = lcA_PU[c_next] - lcA_PU[c];
          double dnc_y = lcA_PV[c_next] - lcA_PV[c];
          double cross_c = dca_x * dnc_y - dca_y * dnc_x;
          if (cross_c > 1.0e-9) reflex_mask &= ~(uint64(1) << c);
          else                  reflex_mask |=  (uint64(1) << c);
        }
        cur = a;
        guard = 0;
      } else {
        cur = c;
        guard++;
      }
    }

    if (alive == 3) {
      int a = cur;
      int b = leo_next[a];
      int c = leo_next[b];
      emit_tri_clipped_against_F2(
          lcA_PU[a], lcA_PV[a], lcA_HX[a], lcA_HY[a], lcA_HZ[a],
          lcA_PU[b], lcA_PV[b], lcA_HX[b], lcA_HY[b], lcA_HZ[b],
          lcA_PU[c], lcA_PV[c], lcA_HX[c], lcA_HY[c], lcA_HZ[c],
          F2PU, F2PV, F2HX, F2HY, F2HZ, nF2,
          f2_min_u, f2_max_u, f2_min_v, f2_max_v,
          grid_nu, grid_nv);
    }
  }

  void shadow_project_silhouette_hull_minus_convex(
      const array<double>& BX, const array<double>& BY,
      const array<double>& BZ,
      const array<double>& FPU, const array<double>& FPV,
      const array<double>& FHX, const array<double>& FHY,
      const array<double>& FHZ,
      int nF,
      int grid_nu, int grid_nv) {
    // nF explicit — FPU.length returns CAPACITY not populated count.
    if (nF < 3) return;

    // Step 1: B hull -> W. Caller should have called
    // set_shadow_hull_cache_key first; piece_idx<0 bypasses cache.
    // Shares W scratch with hull_minus_two_convex (never nested).
    array<double> @lW_PU  = @shadow_W_PU;
    array<double> @lW_PV  = @shadow_W_PV;
    array<double> @lW_HX  = @shadow_W_HX;
    array<double> @lW_HY  = @shadow_W_HY;
    array<double> @lW_HZ  = @shadow_W_HZ;
    array<double> @lcA_PU = @shadow_clipA_PU;
    array<double> @lcA_PV = @shadow_clipA_PV;
    array<double> @lcA_HX = @shadow_clipA_HX;
    array<double> @lcA_HY = @shadow_clipA_HY;
    array<double> @lcA_HZ = @shadow_clipA_HZ;
    array<int>    @lcx_we = @shadow_cx_w_edge;
    array<double> @lcx_tw = @shadow_cx_t_w;
    array<int>    @lcx_fe = @shadow_cx_f_edge;
    // F-edge delta hoist (invariant across nW iters).
    array<double> @lcx_f_du = @shadow_cx_f_du;
    array<double> @lcx_f_dv = @shadow_cx_f_dv;

    int nW = compute_silhouette_hull_2d3d_cached(
        BX, BY, BZ, lW_PU, lW_PV, lW_HX, lW_HY, lW_HZ);
    if (nW < 3) return;

    // 2D AABB pre-reject. f_min/max stay in scope for per-W-edge
    // pre-reject in crossings loop. Cached fuselage AABB fast-path
    // via handle pointer compare (fallback for future non-fus callers).
    double f_min_u, f_max_u, f_min_v, f_max_v;
    if (@FPU == @shadow_hull_out_fus_pu) {
      f_min_u = shadow_ctx_fus_min_u; f_max_u = shadow_ctx_fus_max_u;
      f_min_v = shadow_ctx_fus_min_v; f_max_v = shadow_ctx_fus_max_v;
    } else {
      f_min_u = FPU[0]; f_max_u = FPU[0];
      f_min_v = FPV[0]; f_max_v = FPV[0];
      for (int fi = 1; fi < nF; fi++) {
        double pu = FPU[fi], pv = FPV[fi];
        if (pu < f_min_u) f_min_u = pu; else if (pu > f_max_u) f_max_u = pu;
        if (pv < f_min_v) f_min_v = pv; else if (pv > f_max_v) f_max_v = pv;
      }
    }
    {
      double w_min_u = lW_PU[0], w_max_u = lW_PU[0];
      double w_min_v = lW_PV[0], w_max_v = lW_PV[0];
      for (int wi = 1; wi < nW; wi++) {
        double pu = lW_PU[wi], pv = lW_PV[wi];
        if (pu < w_min_u) w_min_u = pu; else if (pu > w_max_u) w_max_u = pu;
        if (pv < w_min_v) w_min_v = pv; else if (pv > w_max_v) w_max_v = pv;
      }
      if (w_max_u < f_min_u || w_min_u > f_max_u ||
          w_max_v < f_min_v || w_min_v > f_max_v) {
        // Disjoint — fan-emit W and skip the WA scan + cross-check.
        emit_silhouette_polygon_fan_from_v0(
            lW_HX, lW_HY, lW_HZ, nW,
            grid_nu, grid_nv);
        return;
      }
    }

    // Step 2: W×F boundary crossings (w_edge, t_w, f_edge). Strict-
    // interior intersection (t in (eps, 1-eps)) avoids vertex double-
    // counting. F-edge delta pre-pass.
    for (int j = 0; j < nF; j++) {
      int jnext = (j + 1 == nF) ? 0 : j + 1;
      lcx_f_du[j] = FPU[jnext] - FPU[j];
      lcx_f_dv[j] = FPV[jnext] - FPV[j];
    }
    int ncx = 0;
    for (int i = 0; i < nW; i++) {
      int inext = (i + 1 == nW) ? 0 : i + 1;
      double wu1 = lW_PU[i], wv1 = lW_PV[i];
      double wu2 = lW_PU[inext], wv2 = lW_PV[inext];
      // Per-W-edge AABB pre-reject (reuses F's bbox).
      double w_edge_min_u, w_edge_max_u;
      if (wu1 < wu2) { w_edge_min_u = wu1; w_edge_max_u = wu2; }
      else           { w_edge_min_u = wu2; w_edge_max_u = wu1; }
      double w_edge_min_v, w_edge_max_v;
      if (wv1 < wv2) { w_edge_min_v = wv1; w_edge_max_v = wv2; }
      else           { w_edge_min_v = wv2; w_edge_max_v = wv1; }
      if (w_edge_max_u < f_min_u || w_edge_min_u > f_max_u ||
          w_edge_max_v < f_min_v || w_edge_min_v > f_max_v) {
        continue;  // edge isolated from F — no crossings possible
      }
      double dwu = wu2 - wu1, dwv = wv2 - wv1;
      for (int j = 0; j < nF; j++) {
        double fu1 = FPU[j], fv1 = FPV[j];
        double dfu = lcx_f_du[j], dfv = lcx_f_dv[j];
        double det = dfu * dwv - dwu * dfv;
        if (det > -1e-12 && det < 1e-12) continue;  // parallel
        double dx = fu1 - wu1;
        double dy = fv1 - wv1;
        // Division-free eps_det pre-reject; num_f deferred past num_w.
        double eps_det = 1e-7 * det;
        double bound_lo, bound_hi;
        if (det > 0.0) { bound_lo = eps_det;       bound_hi = det - eps_det; }
        else           { bound_lo = det - eps_det; bound_hi = eps_det;       }
        double num_w = dfu * dy - dfv * dx;
        if (num_w < bound_lo || num_w > bound_hi) continue;
        double num_f = dwu * dy - dwv * dx;
        if (num_f < bound_lo || num_f > bound_hi) continue;
        double t_w = num_w / det;
        lcx_we[ncx] = i;
        lcx_tw[ncx] = t_w;
        lcx_fe[ncx] = j;
        ncx++;
      }
    }
    int nc = ncx;

    // Step 3: 0 crossings — disjoint, W⊂F, or F⊂W.
    if (nc == 0) {
      if (point_in_convex_ccw_polygon_with_deltas(
              lW_PU[0], lW_PV[0], FPU, FPV, lcx_f_du, lcx_f_dv, nF)) {
        return;  // W fully inside F.
      }
      // Disjoint or F⊂W (F-inside-W alpha-stacks; rare).
      emit_silhouette_polygon_fan_from_v0(
          lW_HX, lW_HY, lW_HZ, nW,
          grid_nu, grid_nv);
      return;
    }

    // Step 4: nc != 2 = numerical noise; fall back to W.
    if (nc != 2) {
      emit_silhouette_polygon_fan_from_v0(
          lW_HX, lW_HY, lW_HZ, nW,
          grid_nu, grid_nv);
      return;
    }

    // Sort by (w_edge, t_w) — handles mixed AND dent cases.
    int i0 = 0, i1 = 1;
    if (lcx_we[0] > lcx_we[1] ||
        (lcx_we[0] == lcx_we[1] && lcx_tw[0] > lcx_tw[1])) {
      i0 = 1; i1 = 0;
    }
    int c0_we = lcx_we[i0];
    double c0_tw = lcx_tw[i0];
    int c0_fe = lcx_fe[i0];
    int c1_we = lcx_we[i1];
    double c1_tw = lcx_tw[i1];
    int c1_fe = lcx_fe[i1];

    // Enter classification: test point just CCW-past c0; inside F → c0 enter.
    double test_u = 0.0, test_v = 0.0;
    const double eps = 1.0e-4;
    if (c0_tw + eps < 1.0) {
      int c0_next = (c0_we + 1 == nW) ? 0 : c0_we + 1;
      test_u = lW_PU[c0_we] + (c0_tw + eps) * (lW_PU[c0_next] - lW_PU[c0_we]);
      test_v = lW_PV[c0_we] + (c0_tw + eps) * (lW_PV[c0_next] - lW_PV[c0_we]);
    } else {
      int ne = (c0_we + 1 == nW) ? 0 : c0_we + 1;
      int ne_next = (ne + 1 == nW) ? 0 : ne + 1;
      test_u = lW_PU[ne] + eps * (lW_PU[ne_next] - lW_PU[ne]);
      test_v = lW_PV[ne] + eps * (lW_PV[ne_next] - lW_PV[ne]);
    }
    bool c0_is_enter =
        point_in_convex_ccw_polygon_with_deltas(
            test_u, test_v, FPU, FPV, lcx_f_du, lcx_f_dv, nF);

    int enter_idx, exit_idx, f_enter_edge, f_exit_edge;
    double t_enter, t_exit;
    if (c0_is_enter) {
      enter_idx = c0_we; t_enter = c0_tw; f_enter_edge = c0_fe;
      exit_idx  = c1_we; t_exit  = c1_tw; f_exit_edge  = c1_fe;
    } else {
      enter_idx = c1_we; t_enter = c1_tw; f_enter_edge = c1_fe;
      exit_idx  = c0_we; t_exit  = c0_tw; f_exit_edge  = c0_fe;
    }

    int enter_next = (enter_idx + 1 == nW) ? 0 : enter_idx + 1;
    int exit_next  = (exit_idx  + 1 == nW) ? 0 : exit_idx  + 1;

    // Interpolate 2D and 3D at P_enter and P_exit along W's edges.
    double p_enter_pu = lW_PU[enter_idx] + t_enter * (lW_PU[enter_next] - lW_PU[enter_idx]);
    double p_enter_pv = lW_PV[enter_idx] + t_enter * (lW_PV[enter_next] - lW_PV[enter_idx]);
    double p_enter_hx = lW_HX[enter_idx] + t_enter * (lW_HX[enter_next] - lW_HX[enter_idx]);
    double p_enter_hy = lW_HY[enter_idx] + t_enter * (lW_HY[enter_next] - lW_HY[enter_idx]);
    double p_enter_hz = lW_HZ[enter_idx] + t_enter * (lW_HZ[enter_next] - lW_HZ[enter_idx]);

    double p_exit_pu = lW_PU[exit_idx] + t_exit * (lW_PU[exit_next] - lW_PU[exit_idx]);
    double p_exit_pv = lW_PV[exit_idx] + t_exit * (lW_PV[exit_next] - lW_PV[exit_idx]);
    double p_exit_hx = lW_HX[exit_idx] + t_exit * (lW_HX[exit_next] - lW_HX[exit_idx]);
    double p_exit_hy = lW_HY[exit_idx] + t_exit * (lW_HY[exit_next] - lW_HY[exit_idx]);
    double p_exit_hz = lW_HZ[exit_idx] + t_exit * (lW_HZ[exit_next] - lW_HZ[exit_idx]);

    // Step 5: build P = W \ F in shadow_clipA_*.
    int nP = 0;

    // W CCW arc from exit_next through outside vertices to enter_idx.
    int cur = exit_next;
    int guard = 0;
    while (true) {
      lcA_PU[nP] = lW_PU[cur];
      lcA_PV[nP] = lW_PV[cur];
      lcA_HX[nP] = lW_HX[cur];
      lcA_HY[nP] = lW_HY[cur];
      lcA_HZ[nP] = lW_HZ[cur];
      nP++;
      if (cur == enter_idx) break;
      cur = (cur + 1 == nW) ? 0 : cur + 1;
      guard++;
      if (guard > nW + 2) break;  // safety: shouldn't trip
    }

    // P_enter (intersection on W's boundary, entering F).
    lcA_PU[nP] = p_enter_pu;
    lcA_PV[nP] = p_enter_pv;
    lcA_HX[nP] = p_enter_hx;
    lcA_HY[nP] = p_enter_hy;
    lcA_HZ[nP] = p_enter_hz;
    nP++;

    // F CW arc from F[f_enter_edge] back to F[(f_exit_edge+1) % nF].
    // Same-edge case skips arc — no F verts between crossings (without
    // guard, would walk entire F hull into the difference polygon).
    if (f_enter_edge != f_exit_edge) {
      int j = f_enter_edge;
      int j_stop = (f_exit_edge + 1 == nF) ? 0 : f_exit_edge + 1;
      guard = 0;
      while (true) {
        lcA_PU[nP] = FPU[j];
        lcA_PV[nP] = FPV[j];
        lcA_HX[nP] = FHX[j];
        lcA_HY[nP] = FHY[j];
        lcA_HZ[nP] = FHZ[j];
        nP++;
        if (j == j_stop) break;
        j = (j == 0) ? nF - 1 : j - 1;
        guard++;
        if (guard > nF + 2) break;
      }
    }

    // P_exit (intersection on W's boundary, exiting F).
    lcA_PU[nP] = p_exit_pu;
    lcA_PV[nP] = p_exit_pv;
    lcA_HX[nP] = p_exit_hx;
    lcA_HY[nP] = p_exit_hy;
    lcA_HZ[nP] = p_exit_hz;
    nP++;

    if (nP < 3) return;

    // Step 6: ear-clip P. Fan-anchor would FAIL for dent case (empty
    // kernel) → slim alpha-stacking wedge. Ear-clip handles it.
    emit_silhouette_polygon_earclip(
        lcA_PU, lcA_PV, lcA_HX, lcA_HY, lcA_HZ, nP,
        grid_nu, grid_nv);
  }

  // Emit a coalesced run of cells [u_start, u_end) sharing one plane
  // key. Skips disco/gate-2 (guaranteed planar).
  void shadow_emit_run(int row, int row_next,
                       int u_start, int u_end,
                       uint colour, double z_bias) {
    int i00 = row + u_start;
    int i10 = row + u_end;
    int i11 = row_next + u_end;
    int i01 = row_next + u_start;
    shadow_emit_projected_quad(i00, i10, i11, i01, colour, z_bias);
  }

  // Project one silhouette quad onto terrain. Subdivides into nu×nv
  // grid; each vertex raymarches along -sun_dir; emits up to nu*nv quads.
  //
  // Deferred-emit super-batching: queues the quad's rays + per-quad
  // emit spec; shadow_flush_silhouette_queue runs raymarch + emit
  // replay over the piece's queue. Auto-flushes on 64-ray or 32-quad
  // overflow. Many small project_silhouette calls (earclip /
  // hull_minus_convex) coalesce into one raymarch batch per piece.
  //
  // In-queue dedup: open-addressing hash; duplicates aliased back to
  // first occurrence (alias_to[r]=src; cached=true), flush copies src
  // outputs before emit. Pcache hash retained for cross-super-batch
  // case (piece overflow into multiple super-batches).
  void shadow_project_silhouette(
      double lx1, double ly1, double lz1,
      double lx2, double ly2, double lz2,
      double lx3, double ly3, double lz3,
      double lx4, double ly4, double lz4,
      int nu, int nv) {
    // Position + basis + colour + z_bias from shadow_ctx_*.
    double px  = shadow_ctx_px;  double py  = shadow_ctx_py;  double pz  = shadow_ctx_pz;
    double ofx = shadow_ctx_ofx; double ofy = shadow_ctx_ofy; double ofz = shadow_ctx_ofz;
    double orx = shadow_ctx_orx; double ory = shadow_ctx_ory; double orz = shadow_ctx_orz;
    double oux = shadow_ctx_oux; double ouy = shadow_ctx_ouy; double ouz = shadow_ctx_ouz;
    uint   colour = shadow_ctx_colour;
    double z_bias = shadow_ctx_z_bias;
    int nu1 = nu + 1, nv1 = nv + 1;
    int n_verts = nu1 * nv1;
    // Paranoia: silhouette grids are picked by the caller to stay ≤64.
    if (n_verts > 64) return;

    // Auto-flush if queue can't hold this quad (64-ray or 32-quad cap).
    if (shadow_batch_queue_size + n_verts > 64 ||
        shadow_q_count >= SHADOW_Q_CAPACITY) {
      shadow_flush_silhouette_queue();
    }

    int base = shadow_batch_queue_size;

    double inv_nu = 1.0 / double(nu);
    double inv_nv = 1.0 / double(nv);

    // Per-cell plane-local span for discontinuity rejection. ALL 4
    // edges measured — skewed hexagon-split sub-quads have far-corner
    // cells 5-10× larger than near-origin; 2-edge measure dropped the
    // sun-side half at certain angles.
    double span_u1_x = lx2 - lx1, span_u1_y = ly2 - ly1, span_u1_z = lz2 - lz1;
    double span_u2_x = lx3 - lx4, span_u2_y = ly3 - ly4, span_u2_z = lz3 - lz4;
    double span_v1_x = lx4 - lx1, span_v1_y = ly4 - ly1, span_v1_z = lz4 - lz1;
    double span_v2_x = lx3 - lx2, span_v2_y = ly3 - ly2, span_v2_z = lz3 - lz2;
    double cell_u1_sq =
        (span_u1_x * span_u1_x + span_u1_y * span_u1_y + span_u1_z * span_u1_z) *
        (inv_nu * inv_nu);
    double cell_u2_sq =
        (span_u2_x * span_u2_x + span_u2_y * span_u2_y + span_u2_z * span_u2_z) *
        (inv_nu * inv_nu);
    double cell_v1_sq =
        (span_v1_x * span_v1_x + span_v1_y * span_v1_y + span_v1_z * span_v1_z) *
        (inv_nv * inv_nv);
    double cell_v2_sq =
        (span_v2_x * span_v2_x + span_v2_y * span_v2_y + span_v2_z * span_v2_z) *
        (inv_nv * inv_nv);
    double max_cell_sq = cell_u1_sq;
    if (cell_u2_sq > max_cell_sq) max_cell_sq = cell_u2_sq;
    if (cell_v1_sq > max_cell_sq) max_cell_sq = cell_v1_sq;
    if (cell_v2_sq > max_cell_sq) max_cell_sq = cell_v2_sq;
    // 3x linear / 9x squared: catches "flying carpet" terrain-break
    // bridging.
    double max_edge_sq_tight = max_cell_sq * 9.0;

    // Pass 1: fill batch_wx/wy/wz with in-queue dedup. Misses fall
    // through to pcache hash (cross-super-batch caching).
    array<double> @lb_wx     = @shadow_batch_wx;
    array<double> @lb_wy     = @shadow_batch_wy;
    array<double> @lb_wz     = @shadow_batch_wz;
    array<bool>   @lb_cached = @shadow_batch_cached;
    array<int>    @lb_alias  = @shadow_batch_alias_to;
    // Sparse alias list — flush's copy-back iterates [0..count) only.
    // Accumulates across multiple project_silhouette calls in a batch.
    array<int>    @lb_alias_list = @shadow_batch_alias_list;
    int alias_count_local = shadow_batch_alias_count;
    // In-queue dedup hash; lqh_gen[slot] != qh_gen ⇒ empty (stale gen).
    array<int> @lqh_idx = @shadow_batch_q_hash_idx;
    array<int> @lqh_gen = @shadow_batch_q_hash_gen;
    int qh_gen  = shadow_batch_q_hash_gen_cur;
    int qhmask  = SHADOW_BATCH_Q_HASH_SIZE - 1;
    int qhsize  = SHADOW_BATCH_Q_HASH_SIZE;

    // Pcache hoists (cross-super-batch dedup).
    int pc_count_now = shadow_pcache_count;
    array<double> @lpc_wx   = @shadow_pcache_wx;
    array<double> @lpc_wy   = @shadow_pcache_wy;
    array<double> @lpc_wz   = @shadow_pcache_wz;
    array<double> @lpc_bbt  = @shadow_pcache_bbt;
    array<double> @lpc_blx  = @shadow_pcache_blx;
    array<double> @lpc_bly  = @shadow_pcache_bly;
    array<double> @lpc_blz  = @shadow_pcache_blz;
    array<int>    @lpc_bwsf = @shadow_pcache_bwsf;
    array<int>    @lpc_h_idx = @shadow_pcache_hash_idx;
    array<int>    @lpc_h_gen = @shadow_pcache_hash_gen;
    int hash_gen = shadow_pcache_hash_gen_cur;
    int hmask = SHADOW_PCACHE_HASH_SIZE - 1;
    // Internal batch-state targets.
    array<double> @lb_bbt   = @shadow_batch_best_t;
    array<double> @lb_blx   = @shadow_batch_lx;
    array<double> @lb_bly   = @shadow_batch_ly;
    array<double> @lb_blz   = @shadow_batch_lz;
    array<int>    @lb_bwsf  = @shadow_batch_winner_sf_idx;
    array<int>    @lb_bwci  = @shadow_batch_winner_ci;

    int alias_hit_local = 0;
    int pcache_hit_local = 0;

    // Pre-transform 4 plane-local corners into world coords ONCE
    // (bilinear weights sum to 1, px/py/pz factors out — saves 9
    // muls/vert). Bit-exact: identical formula across vertices keeps
    // shared-corner outputs bit-equal for in-queue hash equality.
    double wx1 = px + lx1 * ofx + ly1 * orx + lz1 * oux;
    double wy1 = py + lx1 * ofy + ly1 * ory + lz1 * ouy;
    double wz1 = pz + lx1 * ofz + ly1 * orz + lz1 * ouz;
    double wx2 = px + lx2 * ofx + ly2 * orx + lz2 * oux;
    double wy2 = py + lx2 * ofy + ly2 * ory + lz2 * ouy;
    double wz2 = pz + lx2 * ofz + ly2 * orz + lz2 * ouz;
    double wx3 = px + lx3 * ofx + ly3 * orx + lz3 * oux;
    double wy3 = py + lx3 * ofy + ly3 * ory + lz3 * ouy;
    double wz3 = pz + lx3 * ofz + ly3 * orz + lz3 * ouz;
    double wx4 = px + lx4 * ofx + ly4 * orx + lz4 * oux;
    double wy4 = py + lx4 * ofy + ly4 * ory + lz4 * ouy;
    double wz4 = pz + lx4 * ofz + ly4 * orz + lz4 * ouz;

    for (int v = 0; v < nv1; v++) {
      double fv = double(v) * inv_nv;
      double one_minus_fv = 1.0 - fv;
      // Factored bilinear: (1-fu)(1-fv)W1 + fu(1-fv)W2 + fu*fv*W3 +
      // (1-fu)fv*W4 = (1-fu)[(1-fv)W1 + fv*W4] + fu[(1-fv)W2 + fv*W3]
      // — v factors out, brackets become row endpoints. Inner: 6+3
      // (was 16+9). Bit-equality preserved (same formula).
      double row_wx_lo = one_minus_fv * wx1 + fv * wx4;
      double row_wx_hi = one_minus_fv * wx2 + fv * wx3;
      double row_wy_lo = one_minus_fv * wy1 + fv * wy4;
      double row_wy_hi = one_minus_fv * wy2 + fv * wy3;
      double row_wz_lo = one_minus_fv * wz1 + fv * wz4;
      double row_wz_hi = one_minus_fv * wz2 + fv * wz3;
      for (int u = 0; u < nu1; u++) {
        double fu = double(u) * inv_nu;
        double one_minus_fu = 1.0 - fu;
        int idx = base + v * nu1 + u;

        // Linear interp between row's u=0 and u=1 endpoints.
        double wx_q = one_minus_fu * row_wx_lo + fu * row_wx_hi;
        double wy_q = one_minus_fu * row_wy_lo + fu * row_wy_hi;
        double wz_q = one_minus_fu * row_wz_lo + fu * row_wz_hi;
        lb_wx[idx] = wx_q;
        lb_wy[idx] = wy_q;
        lb_wz[idx] = wz_q;

        // In-queue dedup hash-table lookup. Bit-exact via deterministic
        // bilinear+basis transform. Open-addressing 128-slot (≤50% load).
        int ix_q = int(wx_q);
        int iy_q = int(wy_q);
        int iz_q = int(wz_q);
        int hq = (ix_q * 73856093) ^ (iy_q * 19349663) ^ (iz_q * 83492791);
        int hq_start = hq & qhmask;
        int matched = -1;
        // Capture empty_slot during probe for miss-path insert reuse.
        int empty_slot = -1;
        for (int probe = 0; probe < qhsize; probe++) {
          int slot = (hq_start + probe) & qhmask;
          if (lqh_gen[slot] != qh_gen) {
            empty_slot = slot;
            break;  // empty slot → miss
          }
          int j = lqh_idx[slot];
          if (lb_wx[j] == wx_q && lb_wy[j] == wy_q && lb_wz[j] == wz_q) {
            matched = j;
            break;
          }
        }
        if (matched >= 0) {
          // In-queue dup: alias to source. Phase 0 skips init for
          // cached=true; flush copies sh_* before quad emit.
          //
          // SAFE DEFAULTS: pre-set bwci=-1 and bwsf=-1 so post-raymarch
          // sweeps see neutral values for never-init'd alias slots.
          // Phase 3 `if (b_alias[r] >= 0) continue;` covers writebacks.
          lb_cached[idx] = true;
          lb_alias[idx]  = matched;
          lb_bwsf[idx]   = -1;
          lb_bwci[idx]   = -1;
          // Register this alias for flush's sparse walk.
          lb_alias_list[alias_count_local++] = idx;
          alias_hit_local++;
          continue;
        }

        // MISS: insert via captured empty_slot. 128>≤64 guarantees
        // empty_slot>=0; defensive >=0 fallback for pathological cases.
        if (empty_slot >= 0) {
          lqh_idx[empty_slot] = idx;
          lqh_gen[empty_slot] = qh_gen;
        }

        // Pcache scan (cross-super-batch within piece). Gated on
        // pc_count_now>0; cruise frames skip entirely. Hash key
        // shared (pcache 256-bucket vs in-queue 128).
        int found_k = -1;
        if (pc_count_now > 0) {
          int h_start = hq & hmask;
          for (int probe = 0; probe < SHADOW_PCACHE_HASH_SIZE; probe++) {
            int slot = (h_start + probe) & hmask;
            if (lpc_h_gen[slot] != hash_gen) break;  // stale gen → empty
            int k = lpc_h_idx[slot];
            if (lpc_wx[k] == wx_q && lpc_wy[k] == wy_q && lpc_wz[k] == wz_q) {
              found_k = k;
              break;
            }
          }
        }
        if (found_k >= 0) {
          int k = found_k;
          // Pcache hit: pre-fill batch fields; lb_alias=-1 (no copy-back).
          lb_bbt[idx]   = lpc_bbt[k];
          lb_blx[idx]   = lpc_blx[k];
          lb_bly[idx]   = lpc_bly[k];
          lb_blz[idx]   = lpc_blz[k];
          lb_bwsf[idx]  = lpc_bwsf[k];
          lb_bwci[idx]  = -1;  // safe sentinel
          lb_cached[idx] = true;
          lb_alias[idx]  = -1;
          pcache_hit_local++;
        } else {
          // Miss: queue for raymarch. Pcache insert deferred to flush.
          lb_cached[idx] = false;
          lb_alias[idx]  = -1;
        }
      }
    }
    // Store quad spec for flush's emit-replay.
    int q = shadow_q_count;
    shadow_q_idx_base[q]          = base;
    shadow_q_nu[q]                = nu;
    shadow_q_nv[q]                = nv;
    shadow_q_max_edge_sq_tight[q] = max_edge_sq_tight;
    shadow_q_colour[q]            = colour;
    shadow_q_z_bias[q]            = z_bias;
    shadow_q_count = q + 1;

    shadow_batch_queue_size = base + n_verts;
    shadow_batch_alias_count = alias_count_local;

    // Bisect toggle: false flushes per-quad to isolate regressions.
    if (!SHADOW_USE_SUPER_BATCH) {
      shadow_flush_silhouette_queue();
    }
  }

  // Deferred-emit flush. Drains queue: batched raymarch, alias copy-
  // back, pcache Pass-B insert, per-quad emit replay (run-coalesce +
  // disco reject + projected quad submit). Called: auto-flush in
  // project_silhouette on overflow; each per-piece entry (before
  // pcache_reset so prior piece's queue drains under its bundle);
  // after last piece (PD) at emit-phase end. Idempotent on empty queue.
  void shadow_flush_silhouette_queue() {
    if (shadow_batch_queue_size <= 0) return;

    int total_rays = shadow_batch_queue_size;
    int q_total    = shadow_q_count;

    shadow_raymarch_batch(total_rays);

    // Alias copy-back: in-queue aliases need source's post-raymarch
    // sh_* fields copied to alias idx (Phase 3 wrote at SOURCE idx).
    // Pcache hits already pre-filled internal batch fields and don't
    // need this — Phase 3 picked them up.
    array<int>    @lb_alias = @shadow_batch_alias_to;
    array<int64>  @sh_hpk   = @shadow_hit_plane_key;
    array<double> @sh_vx    = @shadow_vx;
    array<double> @sh_vy    = @shadow_vy;
    array<double> @sh_vz    = @shadow_vz;
    array<double> @sh_tx    = @shadow_tx;
    array<double> @sh_ty    = @shadow_ty;
    array<double> @sh_tz    = @shadow_tz;
    // Walk sparse alias list (appended on each alias hit).
    array<int> @lb_alias_list = @shadow_batch_alias_list;
    int alias_count = shadow_batch_alias_count;
    for (int j = 0; j < alias_count; j++) {
      int r = lb_alias_list[j];
      int src = lb_alias[r];
      sh_hpk[r]   = sh_hpk[src];
      sh_vx[r]    = sh_vx[src];
      sh_vy[r]    = sh_vy[src];
      sh_vz[r]    = sh_vz[src];
      sh_tx[r]    = sh_tx[src];
      sh_ty[r]    = sh_ty[src];
      sh_tz[r]    = sh_tz[src];
    }

    // Pcache Pass-B insert: non-cached/non-aliased rays (those that
    // actually raymarched) into pcache for next super-batch's dedup.
    // Sparse iteration over active_list supplies exactly those rays.
    array<double> @lb_wx_b   = @shadow_batch_wx;
    array<double> @lb_wy_b   = @shadow_batch_wy;
    array<double> @lb_wz_b   = @shadow_batch_wz;
    array<double> @lb_bbt_b    = @shadow_batch_best_t;
    array<double> @lb_blx_b    = @shadow_batch_lx;
    array<double> @lb_bly_b    = @shadow_batch_ly;
    array<double> @lb_blz_b    = @shadow_batch_lz;
    array<int>    @lb_bwsf_b   = @shadow_batch_winner_sf_idx;
    array<double> @lpc_wx   = @shadow_pcache_wx;
    array<double> @lpc_wy   = @shadow_pcache_wy;
    array<double> @lpc_wz   = @shadow_pcache_wz;
    array<double> @lpc_bbt  = @shadow_pcache_bbt;
    array<double> @lpc_blx  = @shadow_pcache_blx;
    array<double> @lpc_bly  = @shadow_pcache_bly;
    array<double> @lpc_blz  = @shadow_pcache_blz;
    array<int>    @lpc_bwsf = @shadow_pcache_bwsf;
    array<int>    @lpc_h_idx = @shadow_pcache_hash_idx;
    array<int>    @lpc_h_gen = @shadow_pcache_hash_gen;
    int hash_gen = shadow_pcache_hash_gen_cur;
    int hmask = SHADOW_PCACHE_HASH_SIZE - 1;
    int next_slot = shadow_pcache_count;
    array<int> @lb_active = @shadow_batch_active_list;
    int active_count = shadow_batch_active_count;
    for (int j = 0; j < active_count; j++) {
      int r = lb_active[j];
      // Defensive r<0 guard (compaction shouldn't leave sentinels).
      if (r < 0) continue;
      if (next_slot >= SHADOW_PCACHE_CAP) break;
      double wx_q = lb_wx_b[r];
      double wy_q = lb_wy_b[r];
      double wz_q = lb_wz_b[r];
      lpc_wx[next_slot]   = wx_q;
      lpc_wy[next_slot]   = wy_q;
      lpc_wz[next_slot]   = wz_q;
      // Validity travels via lpc_bwsf below.
      lpc_bbt[next_slot]   = lb_bbt_b[r];
      lpc_blx[next_slot]   = lb_blx_b[r];
      lpc_bly[next_slot]   = lb_bly_b[r];
      lpc_blz[next_slot]   = lb_blz_b[r];
      lpc_bwsf[next_slot]  = lb_bwsf_b[r];
      // Hash insert: linear probe, claim first stale-gen slot.
      int ix = int(wx_q);
      int iy = int(wy_q);
      int iz = int(wz_q);
      int h = (ix * 73856093) ^ (iy * 19349663) ^ (iz * 83492791);
      int h_start = h & hmask;
      for (int probe = 0; probe < SHADOW_PCACHE_HASH_SIZE; probe++) {
        int slot = (h_start + probe) & hmask;
        if (lpc_h_gen[slot] != hash_gen) {
          lpc_h_idx[slot] = next_slot;
          lpc_h_gen[slot] = hash_gen;
          break;
        }
      }
      next_slot++;
    }
    shadow_pcache_count = next_slot;

    // Per-quad emit replay (rebased indices: qbase + v*q_nu1 + u).
    array<int>    @lq_idx_base = @shadow_q_idx_base;
    array<int>    @lq_nu       = @shadow_q_nu;
    array<int>    @lq_nv       = @shadow_q_nv;
    array<double> @lq_max_e_sq = @shadow_q_max_edge_sq_tight;
    array<uint>   @lq_colour   = @shadow_q_colour;
    array<double> @lq_z_bias   = @shadow_q_z_bias;
    for (int q = 0; q < q_total; q++) {
      int qbase = lq_idx_base[q];
      int q_nu  = lq_nu[q];
      int q_nv  = lq_nv[q];
      int q_nu1 = q_nu + 1;
      double max_edge_sq_tight_q = lq_max_e_sq[q];
      uint   colour_q   = lq_colour[q];
      double z_bias_q   = lq_z_bias[q];

      // Emit cells; row-greedy coalesce same-plane-key runs (lower sort
      // cost). Mixed cells fall through to single-cell + disco/gate-2.
      for (int v = 0; v < q_nv; v++) {
        int row = qbase + v * q_nu1;
        int row_next = row + q_nu1;

        // run_start < 0 = no active run. run_key=0 sentinel.
        int   run_start = -1;
        int64 run_key   = 0;

        // Rolling cell cache: cell u's RIGHT column = cell u+1's LEFT,
        // so hoist sh_hpk into next-iter left locals (uniform-key runs
        // save 4 hpk reads per iter). sh_vx/y/z + sh_tx/y/z deliberately
        // NOT cached (only loaded on non-uniform disco/emit path).
        int64 k_l_top = sh_hpk[row];
        int64 k_l_bot = sh_hpk[row_next];

        for (int u = 0; u < q_nu; u++) {
          int i00 = row + u;
          int i10 = i00 + 1;
          int i01 = row_next + u;
          int i11 = i01 + 1;

          // Right column also becomes next iter's left column.
          int64 k_r_top = sh_hpk[i10];
          int64 k_r_bot = sh_hpk[i11];

          // all_valid ⇔ all 4 keys nonzero (pkey=0 = miss sentinel).
          bool all_valid = (k_l_top != 0) && (k_r_top != 0) &&
                           (k_r_bot != 0) && (k_l_bot != 0);
          int64 k00 = all_valid ? k_l_top : int64(0);
          bool uniform = all_valid &&
                         k_r_top == k00 &&
                         k_r_bot == k00 &&
                         k_l_bot == k00;

          // do-while(false) ensures end-of-iter cache rotation fires
          // on every path; inner `break` exits the do-block, falls
          // through to rotation.
          do {
            if (uniform) {
              if (run_start < 0) {
                run_start = u;
                run_key   = k00;
              } else if (k00 != run_key) {
                shadow_emit_run(row, row_next, run_start, u, colour_q, z_bias_q);
                run_start = u;
                run_key   = k00;
              }
              break;
            }

            // Not a run candidate — flush pending then single-cell path.
            if (run_start >= 0) {
              shadow_emit_run(row, row_next, run_start, u, colour_q, z_bias_q);
              run_start = -1;
              run_key   = 0;
            }

            // Any corner in the void -> skip; neighbouring quads cover.
            if (!all_valid) {
              break;
            }

            // DISCO REJECT: if any quad edge is much longer than cell size,
            // the rays straddle a terrain break ("flying carpet"). Reach
            // here only on non-uniform plane keys. Threshold tight=3×
            // separates connected transitions from disconnected bridges.
            double ax = sh_vx[i00], ay = sh_vy[i00], az = sh_vz[i00];
            double bx = sh_vx[i10], by = sh_vy[i10], bz = sh_vz[i10];
            double cx_ = sh_vx[i11], cy_ = sh_vy[i11], cz_ = sh_vz[i11];
            double dx_ = sh_vx[i01], dy_ = sh_vy[i01], dz_ = sh_vz[i01];
            double e1x = bx - ax,  e1y = by - ay,  e1z = bz - az;
            double e2x = cx_ - bx, e2y = cy_ - by, e2z = cz_ - bz;
            double e3x = dx_ - cx_, e3y = dy_ - cy_, e3z = dz_ - cz_;
            double e4x = ax - dx_, e4y = ay - dy_, e4z = az - dz_;
            double e1_sq = e1x * e1x + e1y * e1y + e1z * e1z;
            double e2_sq = e2x * e2x + e2y * e2y + e2z * e2z;
            double e3_sq = e3x * e3x + e3y * e3y + e3z * e3z;
            double e4_sq = e4x * e4x + e4y * e4y + e4z * e4z;
            if (e1_sq > max_edge_sq_tight_q || e2_sq > max_edge_sq_tight_q ||
                e3_sq > max_edge_sq_tight_q || e4_sq > max_edge_sq_tight_q) {
              break;
            }

            shadow_emit_projected_quad(i00, i10, i11, i01, colour_q, z_bias_q);
          } while (false);

          // Rotate: right column → next iter's left column.
          k_l_top = k_r_top; k_l_bot = k_r_bot;
        }

        // End of row — flush trailing run.
        if (run_start >= 0) {
          shadow_emit_run(row, row_next, run_start, q_nu, colour_q, z_bias_q);
        }
      }
    }

    // Reset queue state for next super-batch.
    shadow_batch_queue_size = 0;
    shadow_q_count          = 0;
    shadow_batch_alias_count = 0;
    // Bump in-queue hash gen so 128 slots auto-invalidate on next
    // super-batch lookups. Wraparound guard at 2^30 (full clear).
    if (shadow_batch_q_hash_gen_cur >= SHADOW_BATCH_Q_HASH_GEN_RESET) {
      int qhsize = int(shadow_batch_q_hash_gen.length);
      for (int qhi = 0; qhi < qhsize; qhi++) shadow_batch_q_hash_gen[qhi] = 0;
      shadow_batch_q_hash_gen_cur = 0;
    }
    shadow_batch_q_hash_gen_cur++;
  }


  // Top-level shadow render. Called once per frame immediately before
  // draw_plane() so shadow polygons share the sort pass. Hoists camera/
  // plane/sun scalars to locals; dispatches per-component silhouettes.
  void draw_plane_shadow() {
    // Master enable: driven by the engine's Script FX Level video
    // setting. 0=Off, 1=Low → no shadow; 2=Medium, 3=High → shadow on.
    // Read live (NOT the cached fx_level) so the player can toggle
    // shadows mid-session by changing the video setting — every frame
    // is independent so there's no hysteresis to protect. Fog and
    // chunk-load horizon use the cached fx_level instead because those
    // commit per-session state (loaded chunks at one radius, derived
    // fog_end_sq) that can't safely re-arrange mid-flight.
    // Defensive null check (g set in PlaneController constructor).
    if (g !is null && g.get_script_fx_level() < 2) return;

    // Defensive frame-top resets (-1 = no filter active).
    shadow_piece_ci_count = -1;
    shadow_piece_reach_valid = false;
    // Defensive ray-cache cursor reset (symmetry vs per-piece resets).
    shadow_piece_ray_cursor = 0;
    // Drain any residual queue from prior frame (defensive).
    shadow_batch_queue_size = 0;
    shadow_q_count          = 0;
    shadow_batch_alias_count = 0;
    // Cross-piece bundle share: invalidate at frame top (cand count
    // may have changed at rebuild → cached ci would be wrong).
    shadow_piece_share_valid       = false;
    shadow_piece_share_reach_valid = false;
    shadow_pcache_reset();

    // Adaptive cap: roll prev frame's winner_t max into decay history.
    // Decay 0.985 ≈ 46-frame half-life.
    //
    // CAUTION: only fold when frame_max > 0. Long ex=6/ex=4 chains
    // (cam-invis / oblique-fade early-exits) used to decay history
    // toward zero across pauses; when rendering resumed the cap
    // dropped to floor and >floor rays nohit catastrophically. Holding
    // history steady during pauses preserves last known-good cap.
    if (shadow_winner_t_frame_max > 0.0) {
      const double SHADOW_WINNER_T_DECAY = 0.985;
      // Fast-decay for proximity-recovery (cruise→canyon descent).
      // frame_max=MAX ensures trigger only when ALL rays had short hits.
      // 0.4 ratio ignores 0.5-0.9 normal jitter; 0.85 rate ≈ 4-frame
      // half-life. Set THRESH=0.0 to disable (A/B diagnostic).
      const double SHADOW_CAP_FAST_DECAY_RATIO_THRESH = 0.4;
      const double SHADOW_CAP_FAST_DECAY_RATE         = 0.85;
      double decay_rate = SHADOW_WINNER_T_DECAY;
      if (shadow_winner_t_max_history > 0.0
          && shadow_winner_t_frame_max
              < shadow_winner_t_max_history * SHADOW_CAP_FAST_DECAY_RATIO_THRESH) {
        decay_rate = SHADOW_CAP_FAST_DECAY_RATE;
      }
      double rolled = shadow_winner_t_max_history * decay_rate;
      if (shadow_winner_t_frame_max > rolled)
        rolled = shadow_winner_t_frame_max;
      shadow_winner_t_max_history = rolled;
    }
    shadow_winner_t_frame_max = 0.0;

    // Refresh chunk_size half-extent (constant mid-flight).
    shadow_half_cs = chunk_manager.chunk_size * 0.5;

    // Hoist camera scalars (consumed by raymarch_batch Phase 3 tail).
    shadow_cfx = cam_fwd_vec.x;  shadow_cfy = cam_fwd_vec.y;  shadow_cfz = cam_fwd_vec.z;
    shadow_clx = cam_left_vec.x; shadow_cly = cam_left_vec.y; shadow_clz = cam_left_vec.z;
    shadow_cux = cam_up_vec.x;   shadow_cuy = cam_up_vec.y;   shadow_cuz = cam_up_vec.z;
    shadow_cdf = cam_dot_fwd;    shadow_cdl = cam_dot_left;   shadow_cdu = cam_dot_up;
    // Vertical probe for deep-burial guard.
    double dbg_ground_below = shadow_ground_z_below(
        interp_pos.x, interp_pos.y, interp_pos.z);
    double dbg_altitude = (dbg_ground_below > -1e17)
        ? (interp_pos.z - dbg_ground_below)
        : -1.0;

    // Sun-too-low guard: skip grazing-degenerate shadows.
    if (sun_dir.z < 0.1) return;

    double px = interp_pos.x, py = interp_pos.y, pz = interp_pos.z;

    // World-space plane basis (hoisted for fade-gate anchors).
    double ofx, ofy, ofz, orx, ory, orz, oux, ouy, ouz;
    interp_orientation.get_basis(ofx, ofy, ofz, orx, ory, orz, oux, ouy, ouz);

    // Publish position + basis to ctx members so silhouette emit chain
    // reads them as members (drops 12 doubles per call push).
    shadow_ctx_px  = px;  shadow_ctx_py  = py;  shadow_ctx_pz  = pz;
    shadow_ctx_ofx = ofx; shadow_ctx_ofy = ofy; shadow_ctx_ofz = ofz;
    shadow_ctx_orx = orx; shadow_ctx_ory = ory; shadow_ctx_orz = orz;
    shadow_ctx_oux = oux; shadow_ctx_ouy = ouy; shadow_ctx_ouz = ouz;

    // Adaptive grid LOD. Coalescer merges 2x2→1 on flat ground so 1x1
    // is pure perf. Pants/wheel/prop emit 1x1 always. Tunables:
    // shadow_lod_far_dist / shadow_grid_near / shadow_grid_far.
    double cam_dx = interp_pos.x - interp_camera_pos.x;
    double cam_dy = interp_pos.y - interp_camera_pos.y;
    double cam_dz = interp_pos.z - interp_camera_pos.z;
    double cam_plane_dist_sq =
        cam_dx * cam_dx + cam_dy * cam_dy + cam_dz * cam_dz;
    double shadow_lod_far_dist =
        (sc !is null) ? double(sc.shadow_lod_far_dist) : 800.0;
    double SHADOW_LOD_FAR_SQ = shadow_lod_far_dist * shadow_lod_far_dist;
    int shadow_grid_near =
        (sc !is null) ? int(sc.shadow_grid_near) : 2;
    int shadow_grid_far =
        (sc !is null) ? int(sc.shadow_grid_far)  : 1;
    // Defensive: zero grid would emit no rays.
    if (shadow_grid_near < 1) shadow_grid_near = 1;
    if (shadow_grid_far  < 1) shadow_grid_far  = 1;
    int shadow_primary_grid =
        (cam_plane_dist_sq > SHADOW_LOD_FAR_SQ) ? shadow_grid_far : shadow_grid_near;

    // Fade gate: multi-anchor oblique sun-direction probe. Metric =
    // MIN over 5 anchors (origin + 4 silhouette extents) of distance
    // along -sun_dir to nearest sun-front triangle. 5 anchors prevents
    // single-origin from threading gaps and missing every catcher.
    // Fade window FADE_START_T..FADE_END_T; FADE_END_T also = shadow
    // "fog horizon" cull. Tunables: shadow_fade_start/end_dist.
    double FADE_START_T = (sc !is null) ? double(sc.shadow_fade_start_dist) : 800.0;
    double FADE_END_T   = (sc !is null) ? double(sc.shadow_fade_end_dist)   : 1600.0;
    // Defensive ordering — keep the ramp denominator positive.
    if (FADE_END_T <= FADE_START_T) FADE_END_T = FADE_START_T + 1.0;
    double shadow_t = shadow_distance_along_sun(px, py, pz, 25601.0);

    // Hoist 4 silhouette-anchor world coords once (shared by ex=6
    // early-out and always-run probe).
    double anc_x0 = px + orx * 95.0, anc_y0 = py + ory * 95.0, anc_z0 = pz + orz * 95.0;  // wingtip R
    double anc_x1 = px - orx * 95.0, anc_y1 = py - ory * 95.0, anc_z1 = pz - orz * 95.0;  // wingtip L
    double anc_x2 = px + ofx * 30.0, anc_y2 = py + ofy * 30.0, anc_z2 = pz + ofz * 30.0;  // nose
    double anc_x3 = px - ofx * 15.0, anc_y3 = py - ofy * 15.0, anc_z3 = pz - ofz * 15.0;  // tail

    // Multi-anchor cam-invis early-out (ex=6). Runs only when origin
    // landing is cam-invisible. Up to 4 unchained anchor probes
    // (chain max_t would make "no new hit" ambiguous). Skip only if
    // every hit is cam-invis. Pays only on cam-invis origin (common
    // in chase-cam-from-below — the scenario we want to skip).
    if (shadow_t < 25600.0) {
      double o_nx = shadow_oblique_normal_x;
      double o_ny = shadow_oblique_normal_y;
      double o_nz = shadow_oblique_normal_z;
      double ndx = -sun_dir.x, ndy = -sun_dir.y, ndz = -sun_dir.z;
      double ohx = px + ndx * shadow_t;
      double ohy = py + ndy * shadow_t;
      double ohz = pz + ndz * shadow_t;
      double ocam_f = (ohx - interp_camera_pos.x) * o_nx
                    + (ohy - interp_camera_pos.y) * o_ny
                    + (ohz - interp_camera_pos.z) * o_nz;

      if (ocam_f > 0.0) {
        // Origin cam-invis. Batch-probe 4 anchors (chunk walk
        // amortized 4×). Loses per-anchor short-circuit; bounded ≤4.
        shadow_probe_anchor_x[0] = anc_x0;  // wingtip R
        shadow_probe_anchor_y[0] = anc_y0;
        shadow_probe_anchor_z[0] = anc_z0;
        shadow_probe_anchor_x[1] = anc_x1;  // wingtip L
        shadow_probe_anchor_y[1] = anc_y1;
        shadow_probe_anchor_z[1] = anc_z1;
        shadow_probe_anchor_x[2] = anc_x2;  // nose
        shadow_probe_anchor_y[2] = anc_y2;
        shadow_probe_anchor_z[2] = anc_z2;
        shadow_probe_anchor_x[3] = anc_x3;  // tail
        shadow_probe_anchor_y[3] = anc_y3;
        shadow_probe_anchor_z[3] = anc_z3;
        shadow_distance_along_sun_4(25601.0);

        // First cam-visible anchor aborts the skip.
        bool any_cam_visible = false;
        for (int a = 0; a < 4; a++) {
          double ta = shadow_probe_out_t[a];
          if (ta >= 25600.0) continue;  // miss
          double ax = shadow_probe_anchor_x[a];
          double ay = shadow_probe_anchor_y[a];
          double az = shadow_probe_anchor_z[a];
          double hx = ax + ndx * ta;
          double hy = ay + ndy * ta;
          double hz = az + ndz * ta;
          double cf = (hx - interp_camera_pos.x) * shadow_probe_out_nx[a]
                    + (hy - interp_camera_pos.y) * shadow_probe_out_ny[a]
                    + (hz - interp_camera_pos.z) * shadow_probe_out_nz[a];
          if (cf <= 0.0) { any_cam_visible = true; break; }
        }

        if (!any_cam_visible) {
          // Consensus: origin + every anchor that hit all agree
          // the catcher is cam-invisible. Skip the pass.
          return;
        }
      }
    }

    // Always-run multi-anchor probe: (1) tightens shadow_t fade-gate
    // min with anchor hits; (2) per-piece cam-invis detection — per-
    // anchor hit normals flag back-facing pieces. Cap = max(shadow_t,
    // 1000u) so cam-invis has reach. FS NEVER SKIPS (fuselage spans
    // cam-vis/invis boundaries; nose-anchor can't characterize).
    const double MIN_PROBE_CAP = 1000.0;
    double probe_cap_f2 = (shadow_t > MIN_PROBE_CAP) ? shadow_t : MIN_PROBE_CAP;
    shadow_probe_anchor_x[0] = anc_x0;  // wingtip R
    shadow_probe_anchor_y[0] = anc_y0;
    shadow_probe_anchor_z[0] = anc_z0;
    shadow_probe_anchor_x[1] = anc_x1;  // wingtip L
    shadow_probe_anchor_y[1] = anc_y1;
    shadow_probe_anchor_z[1] = anc_z1;
    shadow_probe_anchor_x[2] = anc_x2;  // nose
    shadow_probe_anchor_y[2] = anc_y2;
    shadow_probe_anchor_z[2] = anc_z2;
    shadow_probe_anchor_x[3] = anc_x3;  // tail
    shadow_probe_anchor_y[3] = anc_y3;
    shadow_probe_anchor_z[3] = anc_z3;
    shadow_distance_along_sun_4(probe_cap_f2);
    // Fade-gate min: tighten shadow_t with anchor hits.
    for (int a = 0; a < 4; a++) {
      double ta = shadow_probe_out_t[a];
      if (ta < shadow_t) shadow_t = ta;
    }

    // Per-anchor cam-vis check. cf > 0 ⇒ back-facing ⇒ cam-invisible.
    // Misses leave anchor_cam_invis=false (assume cam-vis, avoid false-skip).
    {
      double ndx_pp = -sun_dir.x;
      double ndy_pp = -sun_dir.y;
      double ndz_pp = -sun_dir.z;
      double cpx = interp_camera_pos.x;
      double cpy = interp_camera_pos.y;
      double cpz = interp_camera_pos.z;
      for (int a = 0; a < 4; a++) {
        shadow_anchor_cam_invis[a] = false;
        double ta = shadow_probe_out_t[a];
        if (ta >= probe_cap_f2) continue;  // miss
        double ax = shadow_probe_anchor_x[a];
        double ay = shadow_probe_anchor_y[a];
        double az = shadow_probe_anchor_z[a];
        double hx = ax + ndx_pp * ta;
        double hy = ay + ndy_pp * ta;
        double hz = az + ndz_pp * ta;
        double cf = (hx - cpx) * shadow_probe_out_nx[a]
                  + (hy - cpy) * shadow_probe_out_ny[a]
                  + (hz - cpz) * shadow_probe_out_nz[a];
        if (cf > 0.0) shadow_anchor_cam_invis[a] = true;
      }
    }
    // Per-piece skip = anchor cam-invis OR anchor too-far. Mapping:
    //   WL=0 → anc 1   WR=1 → anc 0    FS=2 → NEVER SKIP
    //   PR=3 → anc 3   LP=4 → anc 1    RP=5 → anc 0
    //   TW=6 → anc 3   PD=7 → anc 2
    //
    // CAUTION: tf gate MUST exclude miss sentinel (25601 > 1600 would
    // false-cull). Miss = "no info from this anchor" (e.g. wingtip
    // dipped below runway can't hit upward tris from below) — treat
    // as no-skip. Without this guard, runway-roll oscillation culled
    // wing/pant pair for the entire roll.
    const double PROBE_MISS_T = 25600.0;
    bool tf0 = shadow_probe_out_t[0] > FADE_END_T && shadow_probe_out_t[0] <= PROBE_MISS_T;
    bool tf1 = shadow_probe_out_t[1] > FADE_END_T && shadow_probe_out_t[1] <= PROBE_MISS_T;
    bool tf2 = shadow_probe_out_t[2] > FADE_END_T && shadow_probe_out_t[2] <= PROBE_MISS_T;
    bool tf3 = shadow_probe_out_t[3] > FADE_END_T && shadow_probe_out_t[3] <= PROBE_MISS_T;
    shadow_piece_skip[0] = shadow_anchor_cam_invis[1] || tf1;
    shadow_piece_skip[1] = shadow_anchor_cam_invis[0] || tf0;
    shadow_piece_skip[2] = false;
    shadow_piece_skip[3] = shadow_anchor_cam_invis[3] || tf3;
    shadow_piece_skip[4] = shadow_anchor_cam_invis[1] || tf1;
    shadow_piece_skip[5] = shadow_anchor_cam_invis[0] || tf0;
    shadow_piece_skip[6] = shadow_anchor_cam_invis[3] || tf3;
    shadow_piece_skip[7] = shadow_anchor_cam_invis[2] || tf2;

    // Buried-plane guard: vertical sentinel + oblique miss → cut pass.
    if (dbg_ground_below <= -1e17 && shadow_t > 25600.0) {
      return;
    }
    // Deep-burial: alt < -500 = inside thick mesa.
    if (dbg_ground_below > -1e17 && dbg_altitude < -500.0) {
      return;
    }

    // Oblique-distance fade window.
    if (shadow_t >= FADE_END_T) {
      return;
    }
    double fade = 1.0;
    if (shadow_t > FADE_START_T)
      fade = (FADE_END_T - shadow_t) / (FADE_END_T - FADE_START_T);
    // Peak 0xB0; 8-unit floor kills barely-visible tail.
    uint base_alpha = uint(176.0 * fade);
    if (base_alpha < 8) {
      return;
    }
    uint shadow_colour = (base_alpha << 24) | 0x00101820; // dark blue-grey
    shadow_ctx_colour = shadow_colour;

    // shadow_max_ray_dist = clamp(cap_dyn, floor, ceil) where
    // floor = max(SHADOW_CAP_FLOOR, shadow_t + MARGIN); dyn = history
    // * MULT + MARGIN; ceil = shadow_t + 1000 clamped at 10000.
    //
    // TRIED AND REVERTED — DON'T retry without solving global-cache
    // constraint:
    //   v1: global SHADOW_REACH_FLOOR=4000 unconditional lift —
    //       inflated cand 50→300, dropped FPS floor 60→40.
    //   v2: per-piece reach[8] — cache still expanded to 100-150
    //       chunks on canyon flights (any piece's reach drives the
    //       GLOBAL cache up).
    // Chunk cache is GLOBAL. Pathology left as visual artifact
    // (occasional wing-tip miss over canyon edges).
    double cap_ceil = shadow_t + 1000.0;
    if (cap_ceil > 10000.0) cap_ceil = 10000.0;
    const double SHADOW_CAP_FLOOR             = 800.0;
    const double SHADOW_CAP_SHADOW_T_MARGIN   = 200.0;
    const double SHADOW_CAP_HISTORY_MULT      = 1.2;
    // History margin 200 (was 400 — cruise frame margin 400-600u).
    // Revert to 400 if frame-1/fade-recovery shows mact > 0.95.
    const double SHADOW_CAP_HISTORY_MARGIN    = 200.0;
    double cap_floor = SHADOW_CAP_FLOOR;
    if (shadow_t + SHADOW_CAP_SHADOW_T_MARGIN > cap_floor)
      cap_floor = shadow_t + SHADOW_CAP_SHADOW_T_MARGIN;
    double cap_dyn = shadow_winner_t_max_history * SHADOW_CAP_HISTORY_MULT
                   + SHADOW_CAP_HISTORY_MARGIN;
    double cap_chosen = cap_dyn;
    if (cap_chosen < cap_floor) cap_chosen = cap_floor;
    if (cap_chosen > cap_ceil)  cap_chosen = cap_ceil;
    shadow_max_ray_dist = cap_chosen;

    // Pre-filter chunks. IMPORTANT: uses POSITION AABB (c.center ±
    // chunk_size/2), NOT geometry AABB — sparse chunks can have
    // isolated voxels near far edge (false-negative drops chunks
    // with tris along ray path).
    double search_radius = shadow_max_ray_dist + 150.0;
    double half_cs = shadow_half_cs;

    // Cache-reuse gate: bucket radius 100u + 300u margin + 200u plane-
    // drift hysteresis. Per-ray slab handles over-included chunks.
    //
    // TRIED AND REVERTED: widening BUCKET to 200u. cand_kept inflated
    // 24→41-62 (brief max_ray_dist spikes round up to next 200,
    // cache_radius stays inflated until next rebuild). DON'T retry
    // without bounding BOTH rebuild frequency AND post-rebuild cand_kept.
    const double CAND_RADIUS_BUCKET = 100.0;   // quantization step
    const double CAND_MARGIN        = 300.0;   // extra slack kept in cache
    const double CAND_MOVE_THRESH   = 200.0;   // plane-drift rebuild trigger
    double radius_bucket =
        ceil(search_radius / CAND_RADIUS_BUCKET) * CAND_RADIUS_BUCKET;
    double cache_radius = radius_bucket + CAND_MARGIN;

    double dxa = px - shadow_cand_anchor_x;
    double dya = py - shadow_cand_anchor_y;
    double dza = pz - shadow_cand_anchor_z;
    double d2a = dxa * dxa + dya * dya + dza * dza;
    // Sun stability: sun_dir-dependent sf-tri filter requires this.
    double dsx = sun_dir.x - shadow_cand_sun_anchor_x;
    double dsy = sun_dir.y - shadow_cand_sun_anchor_y;
    double dsz = sun_dir.z - shadow_cand_sun_anchor_z;
    bool sun_stable = (dsx * dsx + dsy * dsy + dsz * dsz) < 1.0e-8;
    bool cache_fresh = (shadow_cand_radius_last == radius_bucket)
                    && (d2a <= CAND_MOVE_THRESH * CAND_MOVE_THRESH)
                    && (shadow_candidate_count > 0 || d2a == 0.0)
                    && sun_stable;
    // First-frame sentinel: radius_last starts at -1.
    if (shadow_cand_radius_last < 0.0) cache_fresh = false;

    if (cache_fresh) {
      // Reuse cache; per-ray slab handles stale "far" entries.
    } else {
      // Rebuild. Don't resize(0) shadow_cand_* — keep high-water mark
      // length; consumers iterate by candidate_count/sf_total counters.
      //
      // CONTRACT: bucket_tri_idx_count is COUNT (not length); MUST
      // reset to 0 (populate appends from index 0).
      double cache_radius_sq = cache_radius * cache_radius;
      shadow_candidate_count = 0;
      shadow_cand_bucket_tri_idx_count = 0;
      // Invalidate ray coherency cache (sf_idx tied to prior layout).
      int n_lh_slots = int(shadow_last_hit_sf_idx.length);
      for (int ssi = 0; ssi < n_lh_slots; ssi++)
        shadow_last_hit_sf_idx[ssi] = -1;

      // sf_* indexed writes (10× cheaper than insertLast). sf_total
      // counter persisted to shadow_cand_sf_total — downstream MUST
      // use sf_total, not .length. Pre-pass below sums EXACT active
      // tris so sf_* resize fires once per rebuild.
      int sf_total = 0;

      // Bucket sf-index storage; reserve_hint auto-tunes with ~25%
      // headroom for tri/bucket overlap (avg 1.3-1.5×). Stays grow-on-
      // demand since actual overlap is bucket-Pass-1-determined.
      int btri_cap = shadow_cand_bucket_tri_idx_reserve_hint;
      if (btri_cap < 512) btri_cap = 512;
      if (int(shadow_cand_bucket_tri_idx.length) < btri_cap)
        shadow_cand_bucket_tri_idx.resize(btri_cap);

      // Sun-perpendicular axes (once per rebuild). Picking the smallest
      // -sun_dir axis as cross-seed keeps |u| >= sqrt(2/3) ≈ 0.816.
      {
        double mdx = -sun_dir.x, mdy = -sun_dir.y, mdz = -sun_dir.z;
        double absx = (mdx < 0.0 ? -mdx : mdx);
        double absy = (mdy < 0.0 ? -mdy : mdy);
        double absz = (mdz < 0.0 ? -mdz : mdz);
        double ax_x = 0.0, ax_y = 0.0, ax_z = 0.0;
        if (absx <= absy && absx <= absz)      ax_x = 1.0;
        else if (absy <= absx && absy <= absz) ax_y = 1.0;
        else                                   ax_z = 1.0;
        // u = ax × (-sun_dir).
        double u_x = ax_y * mdz - ax_z * mdy;
        double u_y = ax_z * mdx - ax_x * mdz;
        double u_z = ax_x * mdy - ax_y * mdx;
        double u_len_sq = u_x * u_x + u_y * u_y + u_z * u_z;
        double inv_u    = 1.0 / sqrt(u_len_sq);
        u_x *= inv_u; u_y *= inv_u; u_z *= inv_u;
        // v = (-sun_dir) × u (unit-length, orthogonal to both).
        double v_x = mdy * u_z - mdz * u_y;
        double v_y = mdz * u_x - mdx * u_z;
        double v_z = mdx * u_y - mdy * u_x;
        shadow_sun_perp_u_x = u_x;
        shadow_sun_perp_u_y = u_y;
        shadow_sun_perp_u_z = u_z;
        shadow_sun_perp_v_x = v_x;
        shadow_sun_perp_v_y = v_y;
        shadow_sun_perp_v_z = v_z;
      }

      // (u,v) basis + abs hoisted for bucket populate's AABB project.
      double pux  = shadow_sun_perp_u_x;
      double puy  = shadow_sun_perp_u_y;
      double puz  = shadow_sun_perp_u_z;
      double pvx  = shadow_sun_perp_v_x;
      double pvy  = shadow_sun_perp_v_y;
      double pvz  = shadow_sun_perp_v_z;
      double apux = (pux < 0.0 ? -pux : pux);
      double apuy = (puy < 0.0 ? -puy : puy);
      double apuz = (puz < 0.0 ? -puz : puz);
      double apvx = (pvx < 0.0 ? -pvx : pvx);
      double apvy = (pvy < 0.0 ? -pvy : pvy);
      double apvz = (pvz < 0.0 ? -pvz : pvz);

      // Hoist sun_dir for per-tri sun-front filter.
      double sdx = sun_dir.x, sdy = sun_dir.y, sdz = sun_dir.z;
      // Dense ready_chunks (generated + active_tris>0; no null canaries).
      array<Chunk @> @pop_all = @chunk_manager.ready_chunks;
      uint npa = pop_all.length();

      // PRE-PASS: filter, count, exact-once size. kept_chunk_ci holds
      // pop_all indices (drops AddRef + GC). Sum of active_triangles
      // bounds sf_total exactly (sun-back filter trims further).
      if (int(shadow_kept_chunk_ci.length) < int(npa)) {
        shadow_kept_chunk_ci.resize(int(npa));
        shadow_kept_chunk_tri_count.resize(int(npa));
      }
      int kept_count_pp = 0;
      int exact_tri_capacity = 0;
      for (uint ci = 0; ci < npa; ci++) {
        Chunk @c = pop_all[ci];
        // Closest point on chunk-POSITION AABB (1200³ cell, not geom AABB).
        double ccx_pp = c.center.x, ccy_pp = c.center.y, ccz_pp = c.center.z;
        double pmin_x = ccx_pp - half_cs, pmax_x = ccx_pp + half_cs;
        double pmin_y = ccy_pp - half_cs, pmax_y = ccy_pp + half_cs;
        double pmin_z = ccz_pp - half_cs, pmax_z = ccz_pp + half_cs;
        double cx_pp = (px < pmin_x) ? pmin_x : ((px > pmax_x) ? pmax_x : px);
        double cy_pp = (py < pmin_y) ? pmin_y : ((py > pmax_y) ? pmax_y : py);
        double cz_pp = (pz < pmin_z) ? pmin_z : ((pz > pmax_z) ? pmax_z : pz);
        double ddx_pp = px - cx_pp, ddy_pp = py - cy_pp, ddz_pp = pz - cz_pp;
        double d2 = ddx_pp * ddx_pp + ddy_pp * ddy_pp + ddz_pp * ddz_pp;
        if (d2 > cache_radius_sq) continue;
        shadow_kept_chunk_ci[kept_count_pp] = int(ci);
        int tc_pp = c.active_triangles;
        shadow_kept_chunk_tri_count[kept_count_pp] = tc_pp;
        exact_tri_capacity += tc_pp;
        kept_count_pp++;
      }
      shadow_kept_count = kept_count_pp;

      // Exact-once grow-only resize. half_diag is canary for per-chunk
      // bank. 1.5× reserve amortize covers ~50% future growth.
      if (int(shadow_cand_half_diag.length) < kept_count_pp) {
        int safe_chunk_cap = kept_count_pp + (kept_count_pp >> 1);
        shadow_cand_half_diag.resize(safe_chunk_cap);
        // Tight-AABB midpoints for piece-bundle filter.
        shadow_cand_tcx.resize(safe_chunk_cap);
        shadow_cand_tcy.resize(safe_chunk_cap);
        shadow_cand_tcz.resize(safe_chunk_cap);
        // 1D along-sun extent for tighter pre-reject + break gate.
        shadow_cand_along_sun_extent.resize(safe_chunk_cap);
        shadow_cand_sf_start.resize(safe_chunk_cap);
        shadow_cand_sf_count.resize(safe_chunk_cap);
        shadow_cand_bucket_origin_u.resize(safe_chunk_cap);
        shadow_cand_bucket_origin_v.resize(safe_chunk_cap);
        shadow_cand_bucket_inv_size_u.resize(safe_chunk_cap);
        shadow_cand_bucket_inv_size_v.resize(safe_chunk_cap);
        // Sun-direction-derived per-chunk caches.
        shadow_cand_chunk_dot_dir.resize(safe_chunk_cap);
        shadow_cand_c_t_near_x.resize(safe_chunk_cap);
        shadow_cand_c_t_far_x.resize(safe_chunk_cap);
        shadow_cand_c_t_near_y.resize(safe_chunk_cap);
        shadow_cand_c_t_far_y.resize(safe_chunk_cap);
        shadow_cand_c_t_near_z.resize(safe_chunk_cap);
        shadow_cand_c_t_far_z.resize(safe_chunk_cap);
        shadow_cand_pc_t_near_x.resize(safe_chunk_cap);
        shadow_cand_pc_t_far_x.resize(safe_chunk_cap);
        shadow_cand_pc_t_near_y.resize(safe_chunk_cap);
        shadow_cand_pc_t_far_y.resize(safe_chunk_cap);
        shadow_cand_pc_t_near_z.resize(safe_chunk_cap);
        shadow_cand_pc_t_far_z.resize(safe_chunk_cap);
        shadow_cand_no_warp.resize(safe_chunk_cap);
        // Bucket meta sized to safe_chunk_cap (consistent with gate).
        int bucket_meta_cap = safe_chunk_cap * SHADOW_BUCKETS_PER_CHUNK;
        shadow_cand_bucket_tri_start.resize(bucket_meta_cap);
        shadow_cand_bucket_tri_count.resize(bucket_meta_cap);
      }
      // sf_* bank pre-grow (1.5× reserve across 31 parallel arrays).
      if (int(shadow_cand_sf_chunk_ci.length) < exact_tri_capacity) {
        int safe_tri_cap = exact_tri_capacity + (exact_tri_capacity >> 1);
        shadow_cand_sf_chunk_ci.resize(safe_tri_cap);
      }
      if (int(shadow_cand_sf_nx.length) < exact_tri_capacity) {
        int safe_tri_cap = exact_tri_capacity + (exact_tri_capacity >> 1);
        shadow_cand_sf_nx.resize(safe_tri_cap);
        shadow_cand_sf_ny.resize(safe_tri_cap);
        shadow_cand_sf_nz.resize(safe_tri_cap);
        shadow_cand_sf_pd.resize(safe_tri_cap);
        shadow_cand_sf_denom.resize(safe_tri_cap);
        shadow_cand_sf_inv_denom.resize(safe_tri_cap);
        shadow_cand_sf_min_x.resize(safe_tri_cap);
        shadow_cand_sf_max_x.resize(safe_tri_cap);
        shadow_cand_sf_min_y.resize(safe_tri_cap);
        shadow_cand_sf_max_y.resize(safe_tri_cap);
        shadow_cand_sf_min_z.resize(safe_tri_cap);
        shadow_cand_sf_max_z.resize(safe_tri_cap);
        shadow_cand_sf_cx.resize(safe_tri_cap);
        shadow_cand_sf_cy.resize(safe_tri_cap);
        shadow_cand_sf_cz.resize(safe_tri_cap);
        shadow_cand_sf_max_corner_sq.resize(safe_tri_cap);
        // Pre-projected (u,v) of triangle centroid.
        shadow_cand_sf_cu.resize(safe_tri_cap);
        shadow_cand_sf_cv.resize(safe_tri_cap);
        shadow_cand_sf_invD.resize(safe_tri_cap);
        shadow_cand_sf_p1x.resize(safe_tri_cap);
        shadow_cand_sf_p1y.resize(safe_tri_cap);
        shadow_cand_sf_p1z.resize(safe_tri_cap);
        shadow_cand_sf_v0x.resize(safe_tri_cap);
        shadow_cand_sf_v0y.resize(safe_tri_cap);
        shadow_cand_sf_v0z.resize(safe_tri_cap);
        shadow_cand_sf_v1x.resize(safe_tri_cap);
        shadow_cand_sf_v1y.resize(safe_tri_cap);
        shadow_cand_sf_v1z.resize(safe_tri_cap);
        shadow_cand_sf_d00.resize(safe_tri_cap);
        shadow_cand_sf_d01.resize(safe_tri_cap);
        shadow_cand_sf_d11.resize(safe_tri_cap);
        shadow_cand_sf_packed_key.resize(safe_tri_cap);
      }
      // Deterministic btri pre-size: 2× exact_tri_capacity (avg
      // overlap ~1.3-1.5×; long-thin tris fall back to in-loop grow).
      {
        int safe_btri_cap = exact_tri_capacity * 2;
        if (safe_btri_cap < 512) safe_btri_cap = 512;
        if (int(shadow_cand_bucket_tri_idx.length) < safe_btri_cap)
          shadow_cand_bucket_tri_idx.resize(safe_btri_cap);
      }

      // Sort-first chunk ordering. Key = mid·-sun_dir, packed in low
      // 32 bits per AS sortAsc quirk (feedback_as_int64_sort_quirk.md).
      shadow_cand_sort_packed.resize(kept_count_pp);
      const double CHUNK_SORT_KEY_SCALE = 100000.0;
      const int64  CHUNK_SORT_LOW32_MASK = (int64(1) << 32) - int64(1);
      for (int sk = 0; sk < kept_count_pp; sk++) {
        Chunk @ckc = @pop_all[shadow_kept_chunk_ci[sk]];
        double tri_cx_sort = (ckc.min_x + ckc.max_x) * 0.5;
        double tri_cy_sort = (ckc.min_y + ckc.max_y) * 0.5;
        double tri_cz_sort = (ckc.min_z + ckc.max_z) * 0.5;
        double key_d = -(sdx * tri_cx_sort
                       + sdy * tri_cy_sort
                       + sdz * tri_cz_sort);
        int   ki32 = int(key_d * CHUNK_SORT_KEY_SCALE);
        int64 ki_low = int64(ki32) & CHUNK_SORT_LOW32_MASK;
        shadow_cand_sort_packed[sk] = (int64(sk) << 32) | ki_low;
      }
      shadow_cand_sort_packed.sortAsc();

      // Slab inv_d cache. Sun constant within cache lifetime.
      const double SLAB_INF = 1e30;
      double pop_dx = -sun_dir.x, pop_dy = -sun_dir.y, pop_dz = -sun_dir.z;
      double pop_inv_dx = (pop_dx != 0.0) ? 1.0 / pop_dx
                          : ((pop_dx >= 0.0) ?  SLAB_INF : -SLAB_INF);
      double pop_inv_dy = (pop_dy != 0.0) ? 1.0 / pop_dy
                          : ((pop_dy >= 0.0) ?  SLAB_INF : -SLAB_INF);
      double pop_inv_dz = (pop_dz != 0.0) ? 1.0 / pop_dz
                          : ((pop_dz >= 0.0) ?  SLAB_INF : -SLAB_INF);
      bool pop_idx_pos = (pop_inv_dx >= 0.0);
      bool pop_idy_pos = (pop_inv_dy >= 0.0);
      bool pop_idz_pos = (pop_inv_dz >= 0.0);
      // |-sun_dir| for per-chunk along-sun extent compute.
      double abs_pop_dx = (pop_dx < 0.0) ? -pop_dx : pop_dx;
      double abs_pop_dy = (pop_dy < 0.0) ? -pop_dy : pop_dy;
      double abs_pop_dz = (pop_dz < 0.0) ? -pop_dz : pop_dz;

      // Member-array handle hoist (~31 sf_* per-tri arrays). Handles
      // remain valid across in-loop resize (AS array identity preserved).
      array<double> @l_sf_nx          = @shadow_cand_sf_nx;
      array<double> @l_sf_ny          = @shadow_cand_sf_ny;
      array<double> @l_sf_nz          = @shadow_cand_sf_nz;
      array<double> @l_sf_pd          = @shadow_cand_sf_pd;
      array<double> @l_sf_denom       = @shadow_cand_sf_denom;
      array<double> @l_sf_inv_denom   = @shadow_cand_sf_inv_denom;
      array<double> @l_sf_min_x       = @shadow_cand_sf_min_x;
      array<double> @l_sf_max_x       = @shadow_cand_sf_max_x;
      array<double> @l_sf_min_y       = @shadow_cand_sf_min_y;
      array<double> @l_sf_max_y       = @shadow_cand_sf_max_y;
      array<double> @l_sf_min_z       = @shadow_cand_sf_min_z;
      array<double> @l_sf_max_z       = @shadow_cand_sf_max_z;
      array<double> @l_sf_cx          = @shadow_cand_sf_cx;
      array<double> @l_sf_cy          = @shadow_cand_sf_cy;
      array<double> @l_sf_cz          = @shadow_cand_sf_cz;
      array<double> @l_sf_max_corner_sq = @shadow_cand_sf_max_corner_sq;
      // Pre-projected (u,v) of triangle centroid.
      array<double> @l_sf_cu          = @shadow_cand_sf_cu;
      array<double> @l_sf_cv          = @shadow_cand_sf_cv;
      array<double> @l_sf_invD        = @shadow_cand_sf_invD;
      array<double> @l_sf_p1x         = @shadow_cand_sf_p1x;
      array<double> @l_sf_p1y         = @shadow_cand_sf_p1y;
      array<double> @l_sf_p1z         = @shadow_cand_sf_p1z;
      array<double> @l_sf_v0x         = @shadow_cand_sf_v0x;
      array<double> @l_sf_v0y         = @shadow_cand_sf_v0y;
      array<double> @l_sf_v0z         = @shadow_cand_sf_v0z;
      array<double> @l_sf_v1x         = @shadow_cand_sf_v1x;
      array<double> @l_sf_v1y         = @shadow_cand_sf_v1y;
      array<double> @l_sf_v1z         = @shadow_cand_sf_v1z;
      array<double> @l_sf_d00         = @shadow_cand_sf_d00;
      array<double> @l_sf_d01         = @shadow_cand_sf_d01;
      array<double> @l_sf_d11         = @shadow_cand_sf_d11;
      array<int64>  @l_sf_packed_key  = @shadow_cand_sf_packed_key;
      array<int>    @l_sf_chunk_ci    = @shadow_cand_sf_chunk_ci;
      // Bucket-pass scratch.
      array<int>    @l_bucket_bounds  = @shadow_cand_scratch_bucket_bounds;
      array<int>    @l_bucket_count   = @shadow_bucket_build_count;
      // Bucket meta arrays (meta-block loop + Pass-2 scatter).
      array<int>    @l_bucket_tri_start  = @shadow_cand_bucket_tri_start;
      array<int>    @l_bucket_tri_count  = @shadow_cand_bucket_tri_count;
      array<int>    @l_bucket_build_cur  = @shadow_bucket_build_cursor;
      array<int>    @l_bucket_tri_idx    = @shadow_cand_bucket_tri_idx;
      // Chunk-level meta arrays (sized at pre-pass; identity preserved).
      array<double> @l_cand_half_diag  = @shadow_cand_half_diag;
      array<double> @l_cand_along_ext  = @shadow_cand_along_sun_extent;
      array<double> @l_cand_tcx        = @shadow_cand_tcx;
      array<double> @l_cand_tcy        = @shadow_cand_tcy;
      array<double> @l_cand_tcz        = @shadow_cand_tcz;
      array<double> @l_cand_chunk_dot_dir = @shadow_cand_chunk_dot_dir;
      array<double> @l_cand_c_t_near_x = @shadow_cand_c_t_near_x;
      array<double> @l_cand_c_t_far_x  = @shadow_cand_c_t_far_x;
      array<double> @l_cand_c_t_near_y = @shadow_cand_c_t_near_y;
      array<double> @l_cand_c_t_far_y  = @shadow_cand_c_t_far_y;
      array<double> @l_cand_c_t_near_z = @shadow_cand_c_t_near_z;
      array<double> @l_cand_c_t_far_z  = @shadow_cand_c_t_far_z;
      array<double> @l_cand_pc_t_near_x = @shadow_cand_pc_t_near_x;
      array<double> @l_cand_pc_t_far_x  = @shadow_cand_pc_t_far_x;
      array<double> @l_cand_pc_t_near_y = @shadow_cand_pc_t_near_y;
      array<double> @l_cand_pc_t_far_y  = @shadow_cand_pc_t_far_y;
      array<double> @l_cand_pc_t_near_z = @shadow_cand_pc_t_near_z;
      array<double> @l_cand_pc_t_far_z  = @shadow_cand_pc_t_far_z;
      array<int>    @l_cand_no_warp     = @shadow_cand_no_warp;
      array<double> @l_cand_bucket_origin_u   = @shadow_cand_bucket_origin_u;
      array<double> @l_cand_bucket_origin_v   = @shadow_cand_bucket_origin_v;
      array<double> @l_cand_bucket_inv_size_u = @shadow_cand_bucket_inv_size_u;
      array<double> @l_cand_bucket_inv_size_v = @shadow_cand_bucket_inv_size_v;
      array<int>    @l_cand_sf_start   = @shadow_cand_sf_start;
      array<int>    @l_cand_sf_count   = @shadow_cand_sf_count;
      array<int>    @l_kept_chunk_tri_count = @shadow_kept_chunk_tri_count;
      array<double> @l_cand_along_ext_tail = @shadow_cand_max_along_sun_extent_tail;

      // Populate pass: walk in SORTED order, write to sorted slot ck=s.
      // sf_chunk_ci written inline. Pre-loop seed bucket_count[*] once
      // (per-chunk meta block resets at tail). 16 buckets/chunk.
      for (int b = 0; b < 16; b++)
        l_bucket_count[b] = 0;
      for (int s_iter = 0; s_iter < kept_count_pp; s_iter++) {
        int kept_i = int(shadow_cand_sort_packed[s_iter] >> 32);
        Chunk @c = @pop_all[shadow_kept_chunk_ci[kept_i]];
        int ck = s_iter;  // direct sorted slot
        double ccx = c.center.x, ccy = c.center.y, ccz = c.center.z;
        // Flatten chunk fields into parallel arrays.
        double cminx_v = c.min_x, cmaxx_v = c.max_x;
        double cminy_v = c.min_y, cmaxy_v = c.max_y;
        double cminz_v = c.min_z, cmaxz_v = c.max_z;
        // Precompute tight-AABB half-diag once per chunk.
        {
          double _ehx = (cmaxx_v - cminx_v) * 0.5;
          double _ehy = (cmaxy_v - cminy_v) * 0.5;
          double _ehz = (cmaxz_v - cminz_v) * 0.5;
          l_cand_half_diag[ck] =
              sqrt(_ehx * _ehx + _ehy * _ehy + _ehz * _ehz);
          // 1D-along-sun extent: |sx|·hx + |sy|·hy + |sz|·hz. Strictly
          // <= 3D half_diag by Cauchy-Schwarz; tighter for pre-reject +
          // break-gate (both bound offset_along_sun from chunk centroid).
          l_cand_along_ext[ck] =
              abs_pop_dx * _ehx + abs_pop_dy * _ehy + abs_pop_dz * _ehz;
        }
        // chunk_dot_dir = tight_mid · -sun_dir. CAUTION: pair tight
        // mid with tight half_diag — pairing nominal center with tight
        // half_diag could under-bound by ~970u along sun axis on warped
        // chunks.
        double tmid_x = (cminx_v + cmaxx_v) * 0.5;
        double tmid_y = (cminy_v + cmaxy_v) * 0.5;
        double tmid_z = (cminz_v + cmaxz_v) * 0.5;
        // Cache midpoints for the piece-bundle filter (free here).
        l_cand_tcx[ck] = tmid_x;
        l_cand_tcy[ck] = tmid_y;
        l_cand_tcz[ck] = tmid_z;
        l_cand_chunk_dot_dir[ck] =
            tmid_x * pop_dx + tmid_y * pop_dy + tmid_z * pop_dz;
        // Pre-mul'd sign-resolved slab bounds. Tight AABB (geometry
        // extent) and pc (1200³ position cell) cached separately.
        double c_min_x_inv = cminx_v * pop_inv_dx;
        double c_max_x_inv = cmaxx_v * pop_inv_dx;
        double c_min_y_inv = cminy_v * pop_inv_dy;
        double c_max_y_inv = cmaxy_v * pop_inv_dy;
        double c_min_z_inv = cminz_v * pop_inv_dz;
        double c_max_z_inv = cmaxz_v * pop_inv_dz;
        l_cand_c_t_near_x[ck] = pop_idx_pos ? c_min_x_inv : c_max_x_inv;
        l_cand_c_t_far_x[ck]  = pop_idx_pos ? c_max_x_inv : c_min_x_inv;
        l_cand_c_t_near_y[ck] = pop_idy_pos ? c_min_y_inv : c_max_y_inv;
        l_cand_c_t_far_y[ck]  = pop_idy_pos ? c_max_y_inv : c_min_y_inv;
        l_cand_c_t_near_z[ck] = pop_idz_pos ? c_min_z_inv : c_max_z_inv;
        l_cand_c_t_far_z[ck]  = pop_idz_pos ? c_max_z_inv : c_min_z_inv;
        double pcmin_x = ccx - half_cs, pcmax_x = ccx + half_cs;
        double pcmin_y = ccy - half_cs, pcmax_y = ccy + half_cs;
        double pcmin_z = ccz - half_cs, pcmax_z = ccz + half_cs;
        double pc_min_x_inv = pcmin_x * pop_inv_dx;
        double pc_max_x_inv = pcmax_x * pop_inv_dx;
        double pc_min_y_inv = pcmin_y * pop_inv_dy;
        double pc_max_y_inv = pcmax_y * pop_inv_dy;
        double pc_min_z_inv = pcmin_z * pop_inv_dz;
        double pc_max_z_inv = pcmax_z * pop_inv_dz;
        l_cand_pc_t_near_x[ck] = pop_idx_pos ? pc_min_x_inv : pc_max_x_inv;
        l_cand_pc_t_far_x[ck]  = pop_idx_pos ? pc_max_x_inv : pc_min_x_inv;
        l_cand_pc_t_near_y[ck] = pop_idy_pos ? pc_min_y_inv : pc_max_y_inv;
        l_cand_pc_t_far_y[ck]  = pop_idy_pos ? pc_max_y_inv : pc_min_y_inv;
        l_cand_pc_t_near_z[ck] = pop_idz_pos ? pc_min_z_inv : pc_max_z_inv;
        l_cand_pc_t_far_z[ck]  = pop_idz_pos ? pc_max_z_inv : pc_min_z_inv;
        // No-warp flag — true when tight AABB matches nominal cell on
        // all 3 axes. Tight is always contained in nominal so only one-
        // sided check is needed. When set, per-ray pos-rescue is skipped.
        const double NO_WARP_EPS = 1.0e-6;
        bool no_warp = (cminx_v - pcmin_x <= NO_WARP_EPS)
                    && (pcmax_x - cmaxx_v <= NO_WARP_EPS)
                    && (cminy_v - pcmin_y <= NO_WARP_EPS)
                    && (pcmax_y - cmaxy_v <= NO_WARP_EPS)
                    && (cminz_v - pcmin_z <= NO_WARP_EPS)
                    && (pcmax_z - cmaxz_v <= NO_WARP_EPS);
        l_cand_no_warp[ck] = no_warp ? 1 : 0;
        // Pre-filter sun-front tris (n·sun_dir > 1e-9). Raymarch reads
        // pre-filtered sf_* and skips the per-ray sun-back check.
        l_cand_sf_start[ck] = sf_total;
        int tri_count = l_kept_chunk_tri_count[kept_i];
        array<Triangle @> @chunk_tris = @c.triangles;

        // ---- Bucket geometry hoist ----
        // Depends only on chunk AABB (not per-tri data); computed
        // before the per-tri loop so bucket Pass 1 can fuse with
        // populate. Reuses cminx_v..cmaxz_v locals (no array re-read).
        double cu_lo = (pux >= 0.0 ? pux * cminx_v : pux * cmaxx_v)
                     + (puy >= 0.0 ? puy * cminy_v : puy * cmaxy_v)
                     + (puz >= 0.0 ? puz * cminz_v : puz * cmaxz_v);
        double cu_hi = (pux >= 0.0 ? pux * cmaxx_v : pux * cminx_v)
                     + (puy >= 0.0 ? puy * cmaxy_v : puy * cminy_v)
                     + (puz >= 0.0 ? puz * cmaxz_v : puz * cminz_v);
        double cv_lo = (pvx >= 0.0 ? pvx * cminx_v : pvx * cmaxx_v)
                     + (pvy >= 0.0 ? pvy * cminy_v : pvy * cmaxy_v)
                     + (pvz >= 0.0 ? pvz * cminz_v : pvz * cmaxz_v);
        double cv_hi = (pvx >= 0.0 ? pvx * cmaxx_v : pvx * cminx_v)
                     + (pvy >= 0.0 ? pvy * cmaxy_v : pvy * cminy_v)
                     + (pvz >= 0.0 ? pvz * cmaxz_v : pvz * cminz_v);
        double cu_size = cu_hi - cu_lo;
        double cv_size = cv_hi - cv_lo;
        // 4.0 = SHADOW_BUCKET_DIM (compile-time constant).
        double inv_su = (cu_size > 1e-9)
                        ? (4.0 / cu_size) : 0.0;
        double inv_sv = (cv_size > 1e-9)
                        ? (4.0 / cv_size) : 0.0;
        l_cand_bucket_origin_u[ck]   = cu_lo;
        l_cand_bucket_origin_v[ck]   = cv_lo;
        l_cand_bucket_inv_size_u[ck] = inv_su;
        l_cand_bucket_inv_size_v[ck] = inv_sv;

        // Bounds-cache pre-grow (4 ints per tri). Sized off chunk
        // tri_count (upper bound for sf_added) so the fused loop never
        // resizes mid-iteration. Once steady-state, this never resizes.
        int needed_bounds_cap = tri_count * 4;
        if (needed_bounds_cap > int(shadow_cand_scratch_bucket_bounds.length)) {
          int new_bounds_cap = needed_bounds_cap + (needed_bounds_cap >> 1);
          shadow_cand_scratch_bucket_bounds.resize(new_bounds_cap);
        }
        // ---- Single-pass sun-front append + FUSED bucket Pass 1 ----
        // Bucket Pass 1 fused into populate loop, reusing tminx/tmaxx
        // locals just loaded for sf_min/max writes. chunk_rel_i tracks
        // chunk-relative tri index for the bucket bounds scratch.
        int sf_chunk_start = sf_total;  // first sf_idx for this chunk
        int chunk_rel_i = 0;
        for (int ti = 0; ti < tri_count; ti++) {
          Triangle @tri = chunk_tris[ti];
          double tnx = tri.nx, tny = tri.ny, tnz = tri.nz;
          double n_dot_sun = tnx * sdx + tny * sdy + tnz * sdz;
          if (n_dot_sun < 1e-9) continue;  // sun-back or parallel; skip
          double denom = -n_dot_sun;
          double tminx = tri.min_x, tmaxx = tri.max_x;
          double tminy = tri.min_y, tmaxy = tri.max_y;
          double tminz = tri.min_z, tmaxz = tri.max_z;
          double tplane_d = tri.plane_d;
          l_sf_nx[sf_total]    = tnx;
          l_sf_ny[sf_total]    = tny;
          l_sf_nz[sf_total]    = tnz;
          l_sf_pd[sf_total]    = tplane_d;
          l_sf_denom[sf_total]     = denom;
          l_sf_inv_denom[sf_total] = 1.0 / denom;
          // Lazy populate of sf_packed_key: write 0 sentinel; Phase 3
          // computes + caches on first hit per sf_idx in this rebuild
          // epoch.
          //
          // Sentinel safety: 0 is unreachable as a real packed key —
          // sun-front + unit-normal + 16-bit-quantize-floor invariants
          // (a unit normal has at least one component with |x|≥1/√3 →
          // |x_q|≥591 → at least one 16-bit field nonzero).
          //
          // Branchless bias-trick (round half UP via `int(x + bias) -
          // bias`) preserved at the Phase 3 compute site; bias 32768
          // covers x*1024 ∈ [-1024, 1024], 1048576 covers d*16 up to
          // ±1M (terrain elevation × 16 reaches ~65000).
          l_sf_packed_key[sf_total] = int64(0);
          l_sf_min_x[sf_total] = tminx;
          l_sf_max_x[sf_total] = tmaxx;
          l_sf_min_y[sf_total] = tminy;
          l_sf_max_y[sf_total] = tmaxy;
          l_sf_min_z[sf_total] = tminz;
          l_sf_max_z[sf_total] = tmaxz;
          // EXACT triangle centroid + tri.bound_radius² (precomputed
          // tight bounding sphere). Stage 2b cam_f reads sf_cx/cy/cz.
          double bound_r = tri.bound_radius;
          double t_cx_v  = tri.c_x;
          double t_cy_v  = tri.c_y;
          double t_cz_v  = tri.c_z;
          l_sf_cx[sf_total] = t_cx_v;
          l_sf_cy[sf_total] = t_cy_v;
          l_sf_cz[sf_total] = t_cz_v;
          l_sf_max_corner_sq[sf_total] = bound_r * bound_r;
          // Pre-project EXACT centroid (NOT AABB midpoint — 2D pre-
          // reject needs the same centroid tri.bound_radius is around).
          l_sf_cu[sf_total] = pux * t_cx_v + puy * t_cy_v + puz * t_cz_v;
          l_sf_cv[sf_total] = pvx * t_cx_v + pvy * t_cy_v + pvz * t_cz_v;
          // Stage 2b bary fields flattened.
          l_sf_invD[sf_total] = tri.invDenom;
          l_sf_p1x[sf_total]  = tri.p1x;
          l_sf_p1y[sf_total]  = tri.p1y;
          l_sf_p1z[sf_total]  = tri.p1z;
          l_sf_v0x[sf_total]  = tri.v0x;
          l_sf_v0y[sf_total]  = tri.v0y;
          l_sf_v0z[sf_total]  = tri.v0z;
          l_sf_v1x[sf_total]  = tri.v1x;
          l_sf_v1y[sf_total]  = tri.v1y;
          l_sf_v1z[sf_total]  = tri.v1z;
          l_sf_d00[sf_total]  = tri.d00;
          l_sf_d01[sf_total]  = tri.d01;
          l_sf_d11[sf_total]  = tri.d11;
          // sf_chunk_ci written inline in sorted slot (ck IS the final
          // sorted slot — no post-sort fixup needed).
          l_sf_chunk_ci[sf_total] = ck;

          // ---- Fused bucket Pass 1 ----
          // Compute the (u, v) bucket bounds rect for this tri using
          // the AABB MIDPOINT + half-extent (NOT the triangle centroid;
          // bucket projection wants the AABB midpoint for branchless
          // center+extent math). Reuses tminx/tmaxx etc. from sf_min/
          // max writes above (pure register reuse).
          double tcx_b = (tminx + tmaxx) * 0.5;
          double tcy_b = (tminy + tmaxy) * 0.5;
          double tcz_b = (tminz + tmaxz) * 0.5;
          double thx_b = tmaxx - tcx_b;
          double thy_b = tmaxy - tcy_b;
          double thz_b = tmaxz - tcz_b;
          double cu = pux * tcx_b + puy * tcy_b + puz * tcz_b;
          double cv = pvx * tcx_b + pvy * tcy_b + pvz * tcz_b;
          double eu = apux * thx_b + apuy * thy_b + apuz * thz_b;
          double ev = apvx * thx_b + apvy * thy_b + apvz * thz_b;
          int bu_lo = int(((cu - eu) - cu_lo) * inv_su);
          int bu_hi = int(((cu + eu) - cu_lo) * inv_su);
          int bv_lo = int(((cv - ev) - cv_lo) * inv_sv);
          int bv_hi = int(((cv + ev) - cv_lo) * inv_sv);
          // 4 = SHADOW_BUCKET_DIM (compile-time constant).
          if (bu_lo < 0) bu_lo = 0;
          if (bv_lo < 0) bv_lo = 0;
          if (bu_hi >= 4) bu_hi = 3;
          if (bv_hi >= 4) bv_hi = 3;
          if (bu_hi < bu_lo) bu_hi = bu_lo;
          if (bv_hi < bv_lo) bv_hi = bv_lo;
          // Cache the 4 quantized bounds for Pass 2 (which still runs
          // standalone after this loop — it scatters sf indices into
          // bucket_tri_idx using the meta block).
          int boff = chunk_rel_i * 4;
          l_bucket_bounds[boff + 0] = bu_lo;
          l_bucket_bounds[boff + 1] = bu_hi;
          l_bucket_bounds[boff + 2] = bv_lo;
          l_bucket_bounds[boff + 3] = bv_hi;
          // Single-bucket fast path: most tris land in one bucket;
          // short-circuit saves the double loop overhead. Multi-bucket
          // case lifts `bv << 2` (= bv * SHADOW_BUCKET_DIM=4) out of
          // the inner u-loop.
          if (bu_lo == bu_hi && bv_lo == bv_hi) {
            l_bucket_count[(bv_lo << 2) + bu_lo]++;
          } else {
            for (int bv = bv_lo; bv <= bv_hi; bv++) {
              int row_base = bv << 2;
              for (int bu = bu_lo; bu <= bu_hi; bu++) {
                l_bucket_count[row_base + bu]++;
              }
            }
          }

          chunk_rel_i++;
          sf_total++;
        }
        int sf_added = sf_total - sf_chunk_start;  // == chunk_rel_i

        // ---- Bucket meta block + Pass 2 scatter ----
        // Runs unconditionally (sf_added==0 ⇒ counts all 0 ⇒ Pass 2
        // is 0-iter). 16 = SHADOW_BUCKETS_PER_CHUNK -> << 4.
        int chunk_bucket_meta_base = ck << 4;
        int chunk_btri_start = shadow_cand_bucket_tri_idx_count;
        int chunk_btri_offset = 0;
        for (int b = 0; b < 16; b++) {
          l_bucket_tri_start[chunk_bucket_meta_base + b]
              = chunk_btri_start + chunk_btri_offset;
          int build_count_b = l_bucket_count[b];
          l_bucket_tri_count[chunk_bucket_meta_base + b]
              = build_count_b;
          // Reset l_bucket_count[b] for next chunk's Pass 1.
          l_bucket_count[b] = 0;
          l_bucket_build_cur[b] = 0;
          chunk_btri_offset += build_count_b;
        }
        int needed = chunk_btri_start + chunk_btri_offset;
        int btri_cap_now = int(l_bucket_tri_idx.length);
        if (needed > btri_cap_now) {
          int new_cap = needed + (needed >> 1);
          if (new_cap < btri_cap_now * 2) new_cap = btri_cap_now * 2;
          // resize() preserves identity (see H1 hoist comment); the
          // l_bucket_tri_idx handle remains valid past this grow.
          l_bucket_tri_idx.resize(new_cap);
        }

        // Pass 2: distribute via cached bounds (no re-project).
        for (int i = 0; i < sf_added; i++) {
          int sf_idx = sf_chunk_start + i;
          int boff = i * 4;
          int bu_lo = l_bucket_bounds[boff + 0];
          int bu_hi = l_bucket_bounds[boff + 1];
          int bv_lo = l_bucket_bounds[boff + 2];
          int bv_hi = l_bucket_bounds[boff + 3];
          // Single-bucket short-circuit (mirrors Pass 1 above).
          if (bu_lo == bu_hi && bv_lo == bv_hi) {
            int b = (bv_lo << 2) + bu_lo;
            int slot = l_bucket_tri_start[chunk_bucket_meta_base + b]
                     + l_bucket_build_cur[b];
            l_bucket_tri_idx[slot] = sf_idx;
            l_bucket_build_cur[b]++;
          } else {
            for (int bv = bv_lo; bv <= bv_hi; bv++) {
              int row_base = bv << 2;
              for (int bu = bu_lo; bu <= bu_hi; bu++) {
                int b = row_base + bu;
                int slot = l_bucket_tri_start[chunk_bucket_meta_base + b]
                         + l_bucket_build_cur[b];
                l_bucket_tri_idx[slot] = sf_idx;
                l_bucket_build_cur[b]++;
              }
            }
          }
        }
        shadow_cand_bucket_tri_idx_count = chunk_btri_start + chunk_btri_offset;

        // Within-chunk sort (Lever 2) tried & reverted: 8-12ms cost,
        // marginal tB improvement (within-chunk along-sun extent is
        // small). To revive: sort keys+perm-indices, or bucket-sort.

        l_cand_sf_count[ck] = sf_added;
        // Advance count AFTER all per-chunk writes land at slot ck.
        shadow_candidate_count++;
      }

      // Populated-count handoff. Arrays sized by the pre-pass (exact-
      // once). The bucket_tri_idx hint stays because that array's
      // overlap factor (~1.3-1.5×) only emerges from bucket Pass 1 and
      // can still mid-loop grow rarely.
      shadow_cand_sf_total = sf_total;
      shadow_cand_bucket_tri_idx_reserve_hint =
          shadow_cand_bucket_tri_idx_count
          + (shadow_cand_bucket_tri_idx_count >> 2);

      // ---- Tail-max along-sun extent ----
      // Phase-B break safety relies on sort monotonicity, tight
      // tri-AABB containment, and tail-max half_diag dominance — sort
      // key uses int64 pack + sortAsc per
      // feedback_as_int64_sort_quirk.md (low-32 packing rationale).
      int ncand = shadow_candidate_count;

      // Tail-max along-sun extent: tail[i] = max(extent[i..ncand-1]).
      // Used by chunk-walk break safety inequality — bound must cover
      // every later chunk, not just the current one. 1D along-sun
      // extent is tighter than 3D half_diag (kept for the bundle
      // filter which needs 3D euclidean distance).
      if (int(shadow_cand_max_along_sun_extent_tail.length) < ncand)
        shadow_cand_max_along_sun_extent_tail.resize(ncand);
      if (ncand > 0) {
        double running_max_se = l_cand_along_ext[ncand - 1];
        l_cand_along_ext_tail[ncand - 1] = running_max_se;
        for (int ti = ncand - 2; ti >= 0; ti--) {
          double se = l_cand_along_ext[ti];
          if (se > running_max_se) running_max_se = se;
          l_cand_along_ext_tail[ti] = running_max_se;
        }
      }

      // TRIED AND REVERTED at this spot: within-chunk tri-sort.
      // Sort overhead 1.0-1.5ms/rebuild; tB-reject rate unchanged
      // (25-45%); FPS floor regressed. DON'T retry — see
      // project_shadow_perf_state.md for the autopsy.

      // Anchor the cache to this frame's plane position, bucket, and
      // sun direction. Any of these drifting enough will invalidate the
      // cache and force a rebuild.
      shadow_cand_anchor_x     = px;
      shadow_cand_anchor_y     = py;
      shadow_cand_anchor_z     = pz;
      shadow_cand_radius_last  = radius_bucket;
      shadow_cand_sun_anchor_x = sun_dir.x;
      shadow_cand_sun_anchor_y = sun_dir.y;
      shadow_cand_sun_anchor_z = sun_dir.z;
      // shadow_kept_chunk_ci is array<int> (no GC roots); stale slots
      // overwritten on next rebuild. shadow_kept_count reset for
      // cleanliness only.
      shadow_kept_count = 0;
    }

    // ---- Plane body angular AABBs (cross decomposition) ----
    // Plane is a CROSS; single AABB has ~60% empty quadrants that wrongly
    // reject wingtip shadows. Two AABBs (wings + fus+vtail); quad passes
    // gate 2 only if outside BOTH. Excludes gear/tw/prop (small/at-ground).
    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;
    double cdf = cam_dot_fwd, cdl = cam_dot_left, cdu = cam_dot_up;
    for (int pp = 0; pp < 2; pp++) {
      double xmin = shadow_part_x_min[pp], xmax = shadow_part_x_max[pp];
      double ymin = shadow_part_y_min[pp], ymax = shadow_part_y_max[pp];
      double zmin = shadow_part_z_min[pp], zmax = shadow_part_z_max[pp];
      double ty_min =  1e30, ty_max = -1e30;
      double tz_min =  1e30, tz_max = -1e30;
      bool   part_ok = true;
      for (int ci = 0; ci < 8; ci++) {
        // Unpack bit-field corner index into the three ±-axis bounds.
        double lx = ((ci & 1) != 0) ? xmax : xmin;
        double ly = ((ci & 2) != 0) ? ymax : ymin;
        double lz = ((ci & 4) != 0) ? zmax : zmin;
        // Plane-local → world (canonical transform).
        double wx = px + lx * ofx + ly * orx + lz * oux;
        double wy = py + lx * ofy + ly * ory + lz * ouy;
        double wz = pz + lx * ofz + ly * orz + lz * ouz;
        double tx = wx * cfx + wy * cfy + wz * cfz - cdf;
        double ty = wx * clx + wy * cly + wz * clz - cdl;
        double tz = wx * cux + wy * cuy + wz * cuz - cdu;
        // Disable part's AABB on near-plane corner; shadow_project's
        // own avg_tx>1.0 guard handles camera-inside-plane.
        if (tx < 1.0) { part_ok = false; break; }
        double inv_tx = 1.0 / tx;
        double ang_ty = ty * inv_tx;
        double ang_tz = tz * inv_tx;
        if (ang_ty < ty_min) ty_min = ang_ty;
        if (ang_ty > ty_max) ty_max = ang_ty;
        if (ang_tz < tz_min) tz_min = ang_tz;
        if (ang_tz > tz_max) tz_max = ang_tz;
      }
      plane_part_ty_min[pp] = ty_min;
      plane_part_ty_max[pp] = ty_max;
      plane_part_tz_min[pp] = tz_min;
      plane_part_tz_max[pp] = tz_max;
      plane_part_valid[pp]  = part_ok;
    }

    // Z_BIAS=290 (plane=300, terrain=0).
    //
    // KNOWN TRADE-OFF: a rare corner-cell shadow clip persists at 290.
    // Bumping shadow back to 400 + plane to 410 fully eliminates the
    // clip but enlarges the plane false-front zone vs near-camera
    // prisms/walls — painter's algorithm can't satisfy both with a
    // scalar bias. Cleaner fix is layer bits in math_core.cpp sort key.
    const double Z_BIAS = 290.0;
    // Publish to ctx for the silhouette emit chain.
    shadow_ctx_z_bias = Z_BIAS;

    // SHADOW SILHOUETTE PIPELINE. Pieces 0..7:
    //   0,1 wings (wing\fus)       4,5 gear pants ((pant\fus)\wing)
    //   2   fuselage (convex fan)   6   tail wheel ((tw\fus)\elev)
    //   3   hstab+elevator (\fus)   7   prop 3 blades (\fus)
    // Per-piece (piece_hull \ fuselage_hull) avoids alpha stacking.
    // Body hull arrays are class members (no per-frame GC); pL/pR/tw
    // z-arrays update in-place from suspension compression.
    array<double> @fus_only_pu = @shadow_hull_out_fus_pu;
    array<double> @fus_only_pv = @shadow_hull_out_fus_pv;
    array<double> @fus_only_hx = @shadow_hull_out_fus_hx;
    array<double> @fus_only_hy = @shadow_hull_out_fus_hy;
    array<double> @fus_only_hz = @shadow_hull_out_fus_hz;
    set_shadow_hull_cache_key(2, 0.0);
    int fus_only_n = compute_silhouette_hull_2d3d_cached(
        shadow_hull_fus_bx, shadow_hull_fus_by, shadow_hull_fus_bz,
        fus_only_pu, fus_only_pv,
        fus_only_hx, fus_only_hy, fus_only_hz);

    // Cache fuselage 2D AABB once/frame; consumed by ccmc and
    // hull_minus_convex via @FPU==@shadow_hull_out_fus_pu fast-path.
    if (fus_only_n > 0) {
      double fmnu = fus_only_pu[0], fmxu = fmnu;
      double fmnv = fus_only_pv[0], fmxv = fmnv;
      for (int fi = 1; fi < fus_only_n; fi++) {
        double pu = fus_only_pu[fi], pv = fus_only_pv[fi];
        if (pu < fmnu) fmnu = pu; else if (pu > fmxu) fmxu = pu;
        if (pv < fmnv) fmnv = pv; else if (pv > fmxv) fmxv = pv;
      }
      shadow_ctx_fus_min_u = fmnu;
      shadow_ctx_fus_max_u = fmxu;
      shadow_ctx_fus_min_v = fmnv;
      shadow_ctx_fus_max_v = fmxv;
    }

    // Emit fuselage as convex fan. FS is FIRST piece (pre-flush no-op).
    shadow_flush_silhouette_queue();
    shadow_active_piece_idx = 2;
    shadow_piece_ray_cursor = 0;  // reset per-piece ray-cache cursor.
    shadow_pcache_reset();        // also bumps pcache hash gen.
    // Narrow candidate list via fuselage corner bundle.
    shadow_set_piece_bundle_from_local(
        shadow_hull_fus_bx, shadow_hull_fus_by, shadow_hull_fus_bz,
        int(shadow_hull_fus_bx.length));
    emit_silhouette_polygon_fan_from_v0(
        fus_only_hx, fus_only_hy, fus_only_hz, fus_only_n,
        shadow_primary_grid, shadow_primary_grid);

    // Wings clip against fuselage in projection space (replaces y=±11
    // inboard snap that broke at angled sun). 8 corners per wing.
    //
    // Left wing's hull also kept so left pant can clip against it.
    // Cached in slot 0 (wL).
    array<double> @wL_pu = @shadow_hull_out_wL_pu;
    array<double> @wL_pv = @shadow_hull_out_wL_pv;
    array<double> @wL_hx = @shadow_hull_out_wL_hx;
    array<double> @wL_hy = @shadow_hull_out_wL_hy;
    array<double> @wL_hz = @shadow_hull_out_wL_hz;
    // Hull deferred inside !skip[0]. pL (piece 4) shares anchor 1 with
    // wL — when wL skips, pL also skips, so wL_n=0 is never consumed.
    int wL_n = 0;
    if (!shadow_piece_skip[0]) {
      set_shadow_hull_cache_key(0, 0.0);
      wL_n = compute_silhouette_hull_2d3d_cached(
          shadow_hull_wL_bx, shadow_hull_wL_by, shadow_hull_wL_bz,
          wL_pu, wL_pv,
          wL_hx, wL_hy, wL_hz);
      // Drain prior piece's queue under its bundle/ci_count.
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 0;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_wL_bx, shadow_hull_wL_by, shadow_hull_wL_bz,
          int(shadow_hull_wL_bx.length));
      shadow_project_silhouette_hull_minus_convex(
          shadow_hull_wL_bx, shadow_hull_wL_by, shadow_hull_wL_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          shadow_primary_grid, shadow_primary_grid);
    }

    // ---- Right wing (slot 1) ----
    // Hull deferred inside !skip[1] (pR shares anchor 0 with wR).
    array<double> @wR_pu = @shadow_hull_out_wR_pu;
    array<double> @wR_pv = @shadow_hull_out_wR_pv;
    array<double> @wR_hx = @shadow_hull_out_wR_hx;
    array<double> @wR_hy = @shadow_hull_out_wR_hy;
    array<double> @wR_hz = @shadow_hull_out_wR_hz;
    int wR_n = 0;
    if (!shadow_piece_skip[1]) {
      set_shadow_hull_cache_key(1, 0.0);
      wR_n = compute_silhouette_hull_2d3d_cached(
          shadow_hull_wR_bx, shadow_hull_wR_by, shadow_hull_wR_bz,
          wR_pu, wR_pv,
          wR_hx, wR_hy, wR_hz);
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 1;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_wR_bx, shadow_hull_wR_by, shadow_hull_wR_bz,
          int(shadow_hull_wR_bx.length));
      shadow_project_silhouette_hull_minus_convex(
          shadow_hull_wR_bx, shadow_hull_wR_by, shadow_hull_wR_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          shadow_primary_grid, shadow_primary_grid);
    }

    // Small pieces use hull-minus-convex / hull-minus-two-convex.
    // Clip targets: el→fus (dent), pL/pR→fus+wing, tw→fus+elev.

    // ---- HStab + elevator (slot 3, "PR") ----
    // x∈[-60,-32], y∈[-22.5,22.5], z∈[3,5]. Hull deferred inside
    // !skip[3] (tw shares anchor 3 with el).
    array<double> @el_pu = @shadow_hull_out_el_pu;
    array<double> @el_pv = @shadow_hull_out_el_pv;
    array<double> @el_hx = @shadow_hull_out_el_hx;
    array<double> @el_hy = @shadow_hull_out_el_hy;
    array<double> @el_hz = @shadow_hull_out_el_hz;
    int el_n = 0;
    if (!shadow_piece_skip[3]) {
      set_shadow_hull_cache_key(3, 0.0);
      el_n = compute_silhouette_hull_2d3d_cached(
          shadow_hull_el_bx, shadow_hull_el_by, shadow_hull_el_bz,
          el_pu, el_pv,
          el_hx, el_hy, el_hz);
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 3;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_el_bx, shadow_hull_el_by, shadow_hull_el_bz,
          int(shadow_hull_el_bx.length));
      shadow_project_silhouette_hull_minus_convex(
          shadow_hull_el_bx, shadow_hull_el_by, shadow_hull_el_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          shadow_primary_grid, shadow_primary_grid);
    }

    // ---- Left pant ----
    // x∈[13,27], y∈[-21,-15], z∈[pant_z_L±4].
    double pant_z_L = -25.0 + vis_comp_L;
    {
      double zlo = pant_z_L - 4.0;
      double zhi = pant_z_L + 4.0;
      shadow_hull_pL_bz[0] = zlo; shadow_hull_pL_bz[1] = zlo;
      shadow_hull_pL_bz[2] = zhi; shadow_hull_pL_bz[3] = zhi;
      shadow_hull_pL_bz[4] = zlo; shadow_hull_pL_bz[5] = zlo;
      shadow_hull_pL_bz[6] = zhi; shadow_hull_pL_bz[7] = zhi;
    }
    // (pL \ fus) \ wL. Pant overlaps wing AND fuselage at angled sun.
    if (!shadow_piece_skip[4]) {
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 4;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_pL_bx, shadow_hull_pL_by, shadow_hull_pL_bz,
          int(shadow_hull_pL_bx.length));
      // Cache slot 4 with aux=pant_z_L (captures vis_comp_L).
      set_shadow_hull_cache_key(4, pant_z_L);
      shadow_project_silhouette_hull_minus_two_convex(
          shadow_hull_pL_bx, shadow_hull_pL_by, shadow_hull_pL_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          wL_pu, wL_pv,
          wL_hx, wL_hy, wL_hz,
          wL_n,
          1, 1);
    }

    // ---- Right pant (mirror of left) ----
    double pant_z_R = -25.0 + vis_comp_R;
    {
      double zlo = pant_z_R - 4.0;
      double zhi = pant_z_R + 4.0;
      shadow_hull_pR_bz[0] = zlo; shadow_hull_pR_bz[1] = zlo;
      shadow_hull_pR_bz[2] = zhi; shadow_hull_pR_bz[3] = zhi;
      shadow_hull_pR_bz[4] = zlo; shadow_hull_pR_bz[5] = zlo;
      shadow_hull_pR_bz[6] = zhi; shadow_hull_pR_bz[7] = zhi;
    }
    // (pR \ fus) \ wR.
    if (!shadow_piece_skip[5]) {
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 5;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_pR_bx, shadow_hull_pR_by, shadow_hull_pR_bz,
          int(shadow_hull_pR_bx.length));
      set_shadow_hull_cache_key(5, pant_z_R);
      shadow_project_silhouette_hull_minus_two_convex(
          shadow_hull_pR_bx, shadow_hull_pR_by, shadow_hull_pR_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          wR_pu, wR_pv,
          wR_hx, wR_hy, wR_hz,
          wR_n,
          1, 1);
    }

    // ---- Tail wheel ----
    // x∈[-45,-39], y∈[-1.5,1.5], z∈[wheel_z_T±3].
    double wheel_z_T = -16.0 + vis_comp_T;
    {
      double zlo = wheel_z_T - 3.0;
      double zhi = wheel_z_T + 3.0;
      shadow_hull_tw_bz[0] = zlo; shadow_hull_tw_bz[1] = zlo;
      shadow_hull_tw_bz[2] = zhi; shadow_hull_tw_bz[3] = zhi;
      shadow_hull_tw_bz[4] = zlo; shadow_hull_tw_bz[5] = zlo;
      shadow_hull_tw_bz[6] = zhi; shadow_hull_tw_bz[7] = zhi;
    }
    // (tw \ fus) \ elevator.
    if (!shadow_piece_skip[6]) {
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 6;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      shadow_set_piece_bundle_from_local(
          shadow_hull_tw_bx, shadow_hull_tw_by, shadow_hull_tw_bz,
          int(shadow_hull_tw_bx.length));
      set_shadow_hull_cache_key(6, wheel_z_T);
      shadow_project_silhouette_hull_minus_two_convex(
          shadow_hull_tw_bx, shadow_hull_tw_by, shadow_hull_tw_bz,
          fus_only_pu, fus_only_pv,
          fus_only_hx, fus_only_hy, fus_only_hz,
          fus_only_n,
          el_pu, el_pv,
          el_hx, el_hy, el_hz,
          el_n,
          1, 1);
    }

    // ---- Prop: 3 blades at 120° spacing ----
    // Center (77,0,-2), tip_r=32.5, half_w=2.0. Each blade = quad
    // clipped against fuselage. Edge-on sun → degenerate → no emit.
    double prop_cx = 77.0;
    double prop_cy =  0.0;
    double prop_cz = -2.0;
    double prop_tip_r  = 32.5;  // matches submit_box_rotated half-span
    double prop_half_w =  2.0;  // matches submit_box_rotated thickness/2
    double prop_two_pi_third = 6.2831853071795864769 / 3.0;
    if (!shadow_piece_skip[7]) {
      shadow_flush_silhouette_queue();
      shadow_active_piece_idx = 7;
      shadow_piece_ray_cursor = 0;
      shadow_pcache_reset();
      // Prop-disc envelope bounds all 3 blades.
      shadow_set_piece_bundle_from_local(
          shadow_hull_prop_env_bx, shadow_hull_prop_env_by, shadow_hull_prop_env_bz,
          int(shadow_hull_prop_env_bx.length));
      // Prop rotates every frame → bypass hull cache.
      clear_shadow_hull_cache_key();
      // blade_bx static (=prop_cx=77). WARNING: if prop_cx becomes
      // dynamic, write blade_bx too.
      for (int bi = 0; bi < 3; bi++) {
        double theta = prop_angle + prop_two_pi_third * double(bi);
        double ct = cos(theta);
        double st = sin(theta);
        double dy =  ct, dz = st;   // radial  (hub → tip)
        double ty = -st, tz = ct;   // tangent (blade width)
        shadow_hull_blade_by[0] = prop_cy                     - prop_half_w * ty;  // hub_L
        shadow_hull_blade_by[1] = prop_cy                     + prop_half_w * ty;  // hub_R
        shadow_hull_blade_by[2] = prop_cy + prop_tip_r * dy   + prop_half_w * ty;  // tip_R
        shadow_hull_blade_by[3] = prop_cy + prop_tip_r * dy   - prop_half_w * ty;  // tip_L
        shadow_hull_blade_bz[0] = prop_cz                     - prop_half_w * tz;
        shadow_hull_blade_bz[1] = prop_cz                     + prop_half_w * tz;
        shadow_hull_blade_bz[2] = prop_cz + prop_tip_r * dz   + prop_half_w * tz;
        shadow_hull_blade_bz[3] = prop_cz + prop_tip_r * dz   - prop_half_w * tz;
        shadow_project_silhouette_hull_minus_convex(
            shadow_hull_blade_bx, shadow_hull_blade_by, shadow_hull_blade_bz,
            fus_only_pu, fus_only_pv,
            fus_only_hx, fus_only_hy, fus_only_hz,
            fus_only_n,
            1, 1);
      }
    }
    // Final drain after PD (else last piece's rays leak to next frame).
    shadow_flush_silhouette_queue();
  }
}