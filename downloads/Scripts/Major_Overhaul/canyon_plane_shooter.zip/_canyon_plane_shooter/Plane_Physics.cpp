mixin class PlanePhysicsLogic {

  void step() {
    frame_id++;
    // Wingtip-trail per-frame state — set true by apply_point_collision
    // on spark threshold, consumed by update_trails after substeps.
    // Reset here so any substep within the frame can promote it.
    wing_touch_L_frame = false;
    wing_touch_R_frame = false;

    // Hoist .length() once; backward iter + swap-pop preserves order.
    int fp_n = int(floating_prisms.length());
    for (int i = fp_n - 1; i >= 0; i--) {
      FloatingPrism @fp = floating_prisms[i];
      fp.life += DT_D;
      if (check_prism_collision(fp)) {
        // Impact effect at captured body-point hit position: orange shard
        // burst + prism-color smoke crescent, then shatter_prism. Plane
        // body vel drives tangential burst smear and crescent orientation.
        spawn_plane_prism_impact_fragments(fp, last_prism_hit_x,
                                           last_prism_hit_y,
                                           last_prism_hit_z, vel);
        spawn_plane_prism_impact_smoke_crescent(
            fp, last_prism_hit_x, last_prism_hit_y, last_prism_hit_z, vel);
        shatter_prism(fp, pos, vel);
        free_prism(fp);
        @floating_prisms[i] = @floating_prisms[fp_n - 1];
        floating_prisms.removeLast();
        fp_n--;
        // HUD counter — bumped on every shatter_prism site so the bottom-
        // right hex-grid stays in lockstep with the impact effect.
        prisms_destroyed++;
        maybe_end_level_on_prisms_complete();
      }
    }

    // Apple collection — 2-phase lifecycle:
    //   PHASE 1 (collected=false): sphere collision; hit → smoke,
    //     collected=true, capture base_scale/base_tz, spike spin_rate.
    //   PHASE 2 (collected=true): advance collect_t; shrink (1-t^2)
    //     and drift tz; final despawn frees StlInstance + Apple.
    const double APPLE_COLLECT_DURATION  = 0.40;  // seconds
    const double APPLE_COLLECT_SPIN_RATE = 12.0;  // rad/s during animation
    const double APPLE_COLLECT_RISE      = 0.0;   // upward drift over window
                                                  // (0 = shrink in place)

    int ap_n = int(apples.length());
    for (int i = ap_n - 1; i >= 0; i--) {
      Apple @ap = apples[i];

      if (ap.collected) {
        ap.collect_t += float(DT_D);
        if (double(ap.collect_t) >= APPLE_COLLECT_DURATION) {
          // Final despawn — remove paired visual by handle equality
          // then swap-pop. Linear scan fine (apples sparse, per-hit).
          if (ap.inst !is null) {
            int sn = int(stl_instances.length());
            for (int s = 0; s < sn; s++) {
              if (stl_instances[s] is ap.inst) {
                @stl_instances[s] = @stl_instances[sn - 1];
                stl_instances.removeLast();
                break;
              }
            }
          }
          free_apple(ap);
          @apples[i] = @apples[ap_n - 1];
          apples.removeLast();
          ap_n--;
        } else {
          // Animate t in [0,1). Ease-out scale (1-t^2) keeps the apple
          // readable through ~half the window before smoke covers despawn.
          double t = double(ap.collect_t) / APPLE_COLLECT_DURATION;
          if (ap.inst !is null) {
            ap.inst.scale = ap.base_scale * (1.0 - t * t);
            ap.inst.tz    = ap.base_tz + APPLE_COLLECT_RISE * t;
          }
        }
        continue;
      }

      // PHASE 1: not yet collected — run collision check.
      if (check_apple_collision(ap)) {
        // Smoke first so we capture the apple's position before any
        // bookkeeping mutates state. spawn_apple_collect_smoke is a
        // Plane_VFX mixin method on the same controller — direct call.
        spawn_apple_collect_smoke(ap.pos.x, ap.pos.y, ap.pos.z);

        // Replay credit — synthesize hitbox at paired apple entity.
        // No-op when entity_id==0. Fires once per apple at collection edge.
        hitTheApple(ap.entity_id);

        ap.collected = true;
        ap.collect_t = 0.0f;
        if (ap.inst !is null) {
          ap.base_scale     = ap.inst.scale;
          ap.base_tz        = ap.inst.tz;
          ap.inst.spin_rate = APPLE_COLLECT_SPIN_RATE;
        }
        // Don't despawn yet — animation runs across subsequent frames.
      }
    }

    // Update spinning STL instances. Skip static (spin_rate=0). Bake
    // skipped beyond fog_end OR outside camera frustum (render culls
    // by same criteria). spin_angle advance also skipped — no
    // perceptual discontinuity. Camera state is LAST frame's.
    double si_fes = fog_end_sq;
    double si_h_fov = double(current_h_fov);
    double cfx = cam_fwd_vec.x, cfy = cam_fwd_vec.y, cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;

    // Frustum plane normals (inward-pointing) for fwd/left/right.
    // h_fov is tan(half-FOV).
    double nx_l = si_h_fov * cfx + clx,
           ny_l = si_h_fov * cfy + cly,
           nz_l = si_h_fov * cfz + clz;
    double nx_r = si_h_fov * cfx - clx,
           ny_r = si_h_fov * cfy - cly,
           nz_r = si_h_fov * cfz - clz;
    // Abs-of-normal vectors for AABB-radius projection (|n|·half_extent
    // gives the AABB's extent along the plane normal, used to fatten
    // the centroid-vs-plane test by the AABB's worst-case reach).
    double af_x = cfx < 0.0 ? -cfx : cfx;
    double af_y = cfy < 0.0 ? -cfy : cfy;
    double af_z = cfz < 0.0 ? -cfz : cfz;
    double al_x = nx_l < 0.0 ? -nx_l : nx_l;
    double al_y = ny_l < 0.0 ? -ny_l : ny_l;
    double al_z = nz_l < 0.0 ? -nz_l : nz_l;
    double ar_x = nx_r < 0.0 ? -nx_r : nx_r;
    double ar_y = ny_r < 0.0 ? -ny_r : ny_r;
    double ar_z = nz_r < 0.0 ? -nz_r : nz_r;
    // First-frame guard: cam_fwd_vec is zero before the first
    // update_camera. Skip frustum culling on that single frame —
    // distance gate alone is enough; everything bakes once cold.
    bool cam_ready = (cfx * cfx + cfy * cfy + cfz * cfz) > 0.5;

    double cam_x = camera_pos.x;
    double cam_y = camera_pos.y;
    double cam_z = camera_pos.z;

    int si_n = int(stl_instances.length());
    for (int i = 0; i < si_n; i++) {
      StlInstance @sinst = stl_instances[i];
      if (sinst.spin_rate == 0.0) continue;

      // (a) fog-distance gate — measured from plane (matches the
      // pattern used by other entity types in step()).
      double si_dx = sinst.tx - pos.x;
      double si_dy = sinst.ty - pos.y;
      double si_dz = sinst.tz - pos.z;
      if (si_dx * si_dx + si_dy * si_dy + si_dz * si_dz > si_fes)
        continue;

      // (b) frustum gate — AABB vs 3 planes from camera. Stale AABB
      // during skip is acceptable (apple ~spherical, jitter << radius;
      // same AABB feeds render path's identical check).
      if (cam_ready) {
        double iccx = (sinst.world_min_x + sinst.world_max_x) * 0.5;
        double iccy = (sinst.world_min_y + sinst.world_max_y) * 0.5;
        double iccz = (sinst.world_min_z + sinst.world_max_z) * 0.5;
        double ihx  = sinst.world_max_x - iccx;
        double ihy  = sinst.world_max_y - iccy;
        double ihz  = sinst.world_max_z - iccz;
        double tcx_i = iccx - cam_x;
        double tcy_i = iccy - cam_y;
        double tcz_i = iccz - cam_z;

        // Forward plane (behind camera reject).
        double cf_i = tcx_i * cfx + tcy_i * cfy + tcz_i * cfz;
        double rf_i = ihx * af_x + ihy * af_y + ihz * af_z;
        if (cf_i + rf_i < 0.0) continue;

        // Left plane.
        double cl_i = tcx_i * nx_l + tcy_i * ny_l + tcz_i * nz_l;
        double rl_i = ihx * al_x + ihy * al_y + ihz * al_z;
        if (cl_i + rl_i < 0.0) continue;

        // Right plane.
        double cr_i = tcx_i * nx_r + tcy_i * ny_r + tcz_i * nz_r;
        double rr_i = ihx * ar_x + ihy * ar_y + ihz * ar_z;
        if (cr_i + rr_i < 0.0) continue;
      }

      sinst.spin_angle += sinst.spin_rate * DT_D;
      sinst.bake_world_transform(false);
    }

    int pf_n = int(prism_fragments.length());
    for (int i = pf_n - 1; i >= 0; i--) {
      PrismFragment @f = prism_fragments[i];
      double dx = f.pos.x - pos.x;
      double dy = f.pos.y - pos.y;
      double dz = f.pos.z - pos.z;
      if (dx * dx + dy * dy + dz * dz > fog_end_sq) {
        free_prism_fragment(f);
        @prism_fragments[i] = @prism_fragments[pf_n - 1];
        prism_fragments.removeLast();
        pf_n--;
        continue;
      }
      f.life -= DT_D * 0.25; // slower fade
      if (f.life <= 0) {
        free_prism_fragment(f);
        @prism_fragments[i] = @prism_fragments[pf_n - 1];
        prism_fragments.removeLast();
        pf_n--;
      } else {
        f.pos.x += f.vel.x * DT_D;
        f.pos.y += f.vel.y * DT_D;
        f.pos.z += f.vel.z * DT_D;

        double ha = f.spin_speed * (DT_D * 0.5);
        double sha = sin(ha);
        double qw = cos(ha);
        double qx = f.spin_axis.x * sha;
        double qy = f.spin_axis.y * sha;
        double qz = f.spin_axis.z * sha;

        double nw = qw * f.rot.w - qx * f.rot.x - qy * f.rot.y - qz * f.rot.z;
        double nx = qw * f.rot.x + qx * f.rot.w + qy * f.rot.z - qz * f.rot.y;
        double ny = qw * f.rot.y - qx * f.rot.z + qy * f.rot.w + qz * f.rot.x;
        double nz = qw * f.rot.z + qx * f.rot.y - qy * f.rot.x + qz * f.rot.w;
        f.rot.w = nw;
        f.rot.x = nx;
        f.rot.y = ny;
        f.rot.z = nz;
        f.rot.normalize();
      }
    }

    // Request chunks around player. Level-0 (Off) trims load sphere
    // by 1 chunk per axis to match reduced fog horizon. sphere_max
    // chosen so corner chunks still load. unload_far_chunks at 5
    // chunks regardless; hysteresis holds either way.
    int pcx, pcy, pcz;
    chunk_manager.get_chunk_coords(pos.x, pos.y, pos.z, pcx, pcy, pcz);
    int load_radius, z_range, z_period, sphere_max;
    if (fx_level <= 0) {
      load_radius = 3; z_range = 3; z_period = 7; sphere_max = 13;
    } else {
      load_radius = 4; z_range = 4; z_period = 9; sphere_max = 20;
    }
    int target_z = int(frame_id % uint(z_period)) - z_range;
    for (int x = -load_radius; x <= load_radius; x++) {
      for (int y = -load_radius; y <= load_radius; y++) {
        if (x * x + y * y + target_z * target_z <= sphere_max) {
          chunk_manager.request_chunk(pcx + x, pcy + y, pcz + target_z);
        }
      }
    }

    // process_queue enqueues prism candidates; resolve_pending_prisms
    // evaluates remaining gates (density/mesh/existing) once neighbor
    // chunks have meshed. Gate 3 deterministic on seed.
    // `sc` is null between ctor and init() — guard before reads.
    uint ppc = (sc !is null) ? sc.prism_per_super_cell : uint(4);
    uint pss = (sc !is null) ? sc.prism_spawn_seed     : uint(70);
    // Placement tuning knobs (main.cpp [text] fields). Cast float UI
    // fields to double for the spawn-offset / clearance arithmetic.
    double pr_dm = (sc !is null) ? double(sc.pr_dist_min)  : 2000.0;
    double pr_tn = (sc !is null) ? double(sc.pr_terr_min)  : 1000.0;
    double pr_tx = (sc !is null) ? double(sc.pr_terr_max)  : 2400.0;
    double pr_tc = (sc !is null) ? double(sc.pr_tri_clear) :  280.0;
    uint   pr_dt = (sc !is null) ? sc.pr_dens_tol          : uint(1);
    chunk_manager.process_queue(pos, cam_fwd_vec.x, cam_fwd_vec.y,
                                cam_fwd_vec.z, ppc, pss);
    chunk_manager.resolve_pending_prisms(floating_prisms, prism_pool, pss,
                                         pr_dm, pr_tn, pr_tx, pr_tc, pr_dt);
    double pf_x, pf_y, pf_z;
    orientation.rotate_scalar(1, 0, 0, pf_x, pf_y, pf_z);

    if ((frame_id % 8) == 0)
      chunk_manager.unload_far_chunks(pos);

    update_active_physics_set();

    prev_pos = pos;
    prev_orientation = orientation;
    prev_camera_pos = camera_pos;
    prev_camera_orientation = camera_orientation;

    prev_aileron_L = aileron_L;
    prev_aileron_R = aileron_R;
    prev_elevator = elevator;
    prev_rudder = rudder;
    prev_flap_extension = flap_extension;

    float raw_mouse_x = g.mouse_x_hud(0, false),
          raw_mouse_y = g.mouse_y_hud(0, false);
    float raw_width = g.hud_screen_width(false),
          raw_height = g.hud_screen_height(false);
    float mouse_hud_x = (raw_mouse_x / raw_width) * 1600.0f,
          mouse_hud_y = (raw_mouse_y / raw_height) * 900.0f;
    int mst = g.mouse_state(0);
    bool left_down = (mst & 0x4) != 0;
    bool right_down = (mst & 0x1) != 0 || (mst & 0x2) != 0 || (mst & 0x8) != 0;
    // Middle (scroll-wheel) click — bit 0x10 per dustscript Mouse decode.
    // Used to drive the screenshot-thumbnail pan composer.
    bool middle_down = (mst & 0x10) != 0;

    if (gun_cooldown > 0.0)
      gun_cooldown -= DT;

    if (right_down && !prev_right_down && gun_cooldown <= 0.0) {
      double px = pos.x, py = pos.y, pz = pos.z;
      double nose_ox, nose_oy, nose_oz;
      orientation.rotate_scalar(100.0, 0.0, -5.0, nose_ox, nose_oy, nose_oz);
      px += nose_ox;
      py += nose_oy;
      pz += nose_oz;

      double fwd_x, fwd_y, fwd_z;
      orientation.get_forward(fwd_x, fwd_y, fwd_z);

      Projectile @p = get_projectile();
      p.pos.set(px, py, pz);
      // Shoot forward quick but visible + combine with plane velocity
      double speed = 4000.0;
      p.vel.set(vel.x + fwd_x * speed, vel.y + fwd_y * speed,
                vel.z + fwd_z * speed);
      p.life = 4.0; // 4 seconds max life
      p.color = lerp_color(0xFFFFFFFF, col_primary,
                           0.35); // White tinged with primary color
      projectiles.insertLast(p);

      // Add a tiny bit of angular velocity kick for firing feedback!
      angular_velocity.y += 0.5;

      gun_cooldown = 0.21; // semi-auto throttle
    }
    prev_right_down = right_down;

    // ---- Left-drag rotate + double-click reset ----
    bool left_press_edge = left_down && ((last_mouse_st & 0x4) == 0);
    if (left_press_edge) {
      // Double-click: two left-presses within 0.4s, second press while
      // middle NOT held (reset only fires in lock mode, not while panning).
      if (left_press_age < 0.4 && !middle_down) {
        // FULL RESET: drop lock, zero pivot + mouse offsets so spring
        // has nothing to decay. Camera returns to default orbit-around-
        // plane mode in next frame's smoothing.
        rotation_locked    = false;
        pivot_offset_x     = 0.0;
        pivot_offset_y     = 0.0;
        pivot_offset_z     = 0.0;
        mouse_yaw_offset   = 0.0;
        mouse_pitch_offset = 0.0;
      }
      left_press_age = 0.0;
      last_mouse_x = mouse_hud_x;
      last_mouse_y = mouse_hud_y;
    } else if (left_down) {
      // Drag: same yaw/pitch update whether locked or not. When locked,
      // spring stays suppressed below so dragged-to value persists.
      float dx = mouse_hud_x - last_mouse_x, dy = mouse_hud_y - last_mouse_y;
      mouse_yaw_offset -= dx * 0.005;
      mouse_pitch_offset -= dy * 0.005;
      // OPTIMIZATION: Inlined math_clamp ternary
      double _mp_max = PI / 2.1;
      mouse_pitch_offset = (mouse_pitch_offset < -_mp_max) ? -_mp_max
                         : ((mouse_pitch_offset > _mp_max) ? _mp_max : mouse_pitch_offset);
      last_mouse_x = mouse_hud_x;
      last_mouse_y = mouse_hud_y;
    } else if (!rotation_locked && !middle_down) {
      // Spring to center only in default mode. middle_down clause
      // covers single-frame race where middle is pressed THIS frame
      // but rotation_locked not yet latched (handler runs below).
      mouse_yaw_offset += (0.0 - mouse_yaw_offset) * 5.0 * DT;
      mouse_pitch_offset += (0.0 - mouse_pitch_offset) * 5.0 * DT;
    }
    left_press_age += DT;

    // ---- Middle-mouse: latch lock on press edge, accumulate drag delta ----
    // Press edge captures dragged-to rotation; lock persists until
    // double-left-click reset.
    screenshot_pan_dx_pending = 0.0;
    screenshot_pan_dy_pending = 0.0;
    if (middle_down) {
      if ((last_mouse_st & 0x10) == 0) {
        // Press edge — latch the lock and seed cursor anchor; no delta yet.
        rotation_locked = true;
        last_mid_mouse_x = mouse_hud_x;
        last_mid_mouse_y = mouse_hud_y;
      } else {
        screenshot_pan_dx_pending = mouse_hud_x - last_mid_mouse_x;
        screenshot_pan_dy_pending = mouse_hud_y - last_mid_mouse_y;
        last_mid_mouse_x = mouse_hud_x;
        last_mid_mouse_y = mouse_hud_y;
      }
    }
    last_mouse_st = mst;

    const double x_intent = self.x_intent(), y_intent = self.y_intent();

    bool current_dash = self.dash_intent() > 0;
    if (current_dash && !prev_dash) {
      dash_timer = dash_duration;
      brake_timer = 0.0;
    }

    bool current_jump = self.jump_intent() > 0;
    // Release clears any lockout so a subsequent press is a fresh press.
    if (!current_jump) {
      jump_brake_cancel_locked = false;
    }

    bool current_taunt = self.taunt_intent() > 0;
    if (current_taunt && !prev_taunt) {
      brake_timer = 2.0;
      dash_timer = 0.0;
      engine_thrust = max(0.0, engine_thrust - max_thrust * 0.35);
      // If jump was already held at the moment taunt was pressed, lock out
      // that held jump from canceling the air-brake. The player must release
      // jump and press it again to cancel the taunt state.
      if (current_jump) {
        jump_brake_cancel_locked = true;
      }
    }
    prev_taunt = current_taunt;

    if ((current_jump && !jump_brake_cancel_locked) || dash_timer > 0.0) {
      engine_thrust = min(engine_thrust + 300000.0 * DT, max_thrust);
      brake_timer = 0.0;
    }

    prev_jump = current_jump;

    if (brake_timer > 0.0)
      brake_timer -= DT;
    if (dash_timer > 0.0)
      dash_timer -= DT;

    double boost_factor = 1.0;
    if (dash_timer > 0) {
      double elapsed = dash_duration - dash_timer;
      if (elapsed < 0.4)
        boost_factor = 1.0 + (elapsed * 2.5);
      else if (dash_timer < 0.8)
        boost_factor = 1.0 + (dash_timer * 1.25);
      else
        boost_factor = 2.0;
    }

    double target_flap = (brake_timer > 0.0) ? 1.0 : 0.0;
    flap_extension += (target_flap - flap_extension) * 5.0 * DT;

    double raw_yaw_intent = 0.0;
    if (self.light_intent() > 0)
      raw_yaw_intent += 1.0;
    if (self.heavy_intent() > 0)
      raw_yaw_intent -= 1.0;
    const double yaw_base_torque = 10000000.0;
    const double yaw_max_torque = 24000000.0;
    const double yaw_base_authority = yaw_base_torque / yaw_max_torque;
    const double yaw_charge_rate = 6.0;
    const double yaw_release_rate = 18.0;

    if (raw_yaw_intent > 0.0) {
      // Press (or reversal into +): snap to +base, then ramp to +1.
      if (yaw_input < yaw_base_authority)
        yaw_input = yaw_base_authority;
      yaw_input += (1.0 - yaw_input) * yaw_charge_rate * DT;
    } else if (raw_yaw_intent < 0.0) {
      // Press (or reversal into -): snap to -base, then ramp to -1.
      if (yaw_input > -yaw_base_authority)
        yaw_input = -yaw_base_authority;
      yaw_input += (-1.0 - yaw_input) * yaw_charge_rate * DT;
    } else {
      // Released: damp quickly back toward neutral.
      yaw_input += (0.0 - yaw_input) * yaw_release_rate * DT;
    }

    // --- Pitch / Roll smoothed ramping and release ----------------------
    // Same staging pattern as yaw, per axis: snap to base authority on press,
    // ramp exp toward full while held, damp back on release. Roll/pitch use
    // slightly faster rates and higher base authority than yaw for responsive
    // feel — playtested, do not flatten.
    const double roll_base_authority = 0.5;
    const double roll_charge_rate = 8.0;
    const double roll_release_rate = 20.0;
    const double pitch_base_authority = 0.5;
    const double pitch_charge_rate = 8.0;
    const double pitch_release_rate = 20.0;

    if (x_intent > 0.0) {
      if (roll_input < roll_base_authority)
        roll_input = roll_base_authority;
      roll_input += (1.0 - roll_input) * roll_charge_rate * DT;
    } else if (x_intent < 0.0) {
      if (roll_input > -roll_base_authority)
        roll_input = -roll_base_authority;
      roll_input += (-1.0 - roll_input) * roll_charge_rate * DT;
    } else {
      roll_input += (0.0 - roll_input) * roll_release_rate * DT;
    }

    if (y_intent > 0.0) {
      if (pitch_input < pitch_base_authority)
        pitch_input = pitch_base_authority;
      pitch_input += (1.0 - pitch_input) * pitch_charge_rate * DT;
    } else if (y_intent < 0.0) {
      if (pitch_input > -pitch_base_authority)
        pitch_input = -pitch_base_authority;
      pitch_input += (-1.0 - pitch_input) * pitch_charge_rate * DT;
    } else {
      pitch_input += (0.0 - pitch_input) * pitch_release_rate * DT;
    }

    // --- Long-hold roll authority --------------------------------------
    // When roll_input saturates ±1 AND player holds same dir, slow
    // accumulator builds extra authority; drains faster on release/
    // reversal. Multiplier on roll torque + aileron deflection (NOT
    // on reversal-boost compare). engage_thresh blocks dabs.
    const double roll_hold_gain = 0.6;
    const double roll_hold_charge_rate = 1.5;
    const double roll_hold_release_rate = 6.0;
    const double roll_hold_engage_thresh = 0.95;

    bool roll_holding_same_dir =
        (x_intent > 0.0 && roll_input >=  roll_hold_engage_thresh) ||
        (x_intent < 0.0 && roll_input <= -roll_hold_engage_thresh);
    double roll_hold_target = roll_holding_same_dir ? 1.0 : 0.0;
    double roll_hold_rate = (roll_hold_target > roll_hold_charge)
                                ? roll_hold_charge_rate
                                : roll_hold_release_rate;
    roll_hold_charge += (roll_hold_target - roll_hold_charge) * roll_hold_rate * DT;

    const double roll_hold_mult = 1.0 + roll_hold_charge * roll_hold_gain;

    // --- Reversal-authority boost ---------------------------------------
    // Pilot inputs opposite to body-frame rotation → bounded smoothed
    // torque boost. Mult=1.0 in steady flight; grows only when fighting
    // a hard turn. Playtested tuning.
    const double auth_rate_ref = 1.5;
    const double auth_attack_rate = 8.0;
    const double auth_decay_rate = 4.0;
    const double roll_boost_gain = 0.40;
    const double yaw_boost_gain = 0.40;

    double body_wx, body_wy, body_wz;
    orientation.inverse_rotate_scalar(angular_velocity.x, angular_velocity.y,
                                        angular_velocity.z, body_wx, body_wy,
                                        body_wz);

    double roll_target_boost = 0.0;
    if (roll_input != 0.0) {
      // rate_against > 0 means body is rotating opposite to commanded roll.
      double rate_against = (roll_input > 0.0 ? -body_wx : body_wx);
      if (rate_against > 0.0) {
        // OPTIMIZATION: Inlined math_clamp ternary (clamp 0..1)
        double _rt = rate_against / auth_rate_ref;
        roll_target_boost = (_rt < 0.0) ? 0.0 : ((_rt > 1.0) ? 1.0 : _rt);
      }
    }
    double yaw_target_boost = 0.0;
    if (yaw_input != 0.0) {
      double rate_against = (yaw_input > 0.0 ? -body_wz : body_wz);
      if (rate_against > 0.0) {
        // OPTIMIZATION: Inlined math_clamp ternary (clamp 0..1)
        double _yt = rate_against / auth_rate_ref;
        yaw_target_boost = (_yt < 0.0) ? 0.0 : ((_yt > 1.0) ? 1.0 : _yt);
      }
    }

    double roll_k = (roll_target_boost > roll_reversal_boost) ? auth_attack_rate
                                                              : auth_decay_rate;
    double yaw_k = (yaw_target_boost > yaw_reversal_boost) ? auth_attack_rate
                                                           : auth_decay_rate;
    roll_reversal_boost +=
        (roll_target_boost - roll_reversal_boost) * roll_k * DT;
    yaw_reversal_boost += (yaw_target_boost - yaw_reversal_boost) * yaw_k * DT;

    const double roll_auth_mult = 1.0 + roll_reversal_boost * roll_boost_gain;
    const double yaw_auth_mult = 1.0 + yaw_reversal_boost * yaw_boost_gain;

    double target_ail_L = roll_input * 0.3 * roll_hold_mult,
           target_ail_R = roll_input * 0.3 * roll_hold_mult,
           target_elev = pitch_input * 0.4, target_rud = -yaw_input * 0.4;
    aileron_L += (target_ail_L - aileron_L) * 15.0 * DT;
    aileron_R += (target_ail_R - aileron_R) * 15.0 * DT;
    elevator += (target_elev - elevator) * 15.0 * DT;
    rudder += (target_rud - rudder) * 15.0 * DT;

    const int substeps = 4;
    const double sub_dt = DT * 0.25;

    double comp_L = 0, comp_R = 0, comp_T = 0;
    bool touch_L = false, touch_R = false, touch_T = false;

    for (int i = 0; i < substeps; i++) {
      double tf_x = 0, tf_y = 0, tf_z = -gravity * mass;
      double tt_x = 0, tt_y = 0, tt_z = 0;
      double pr_x, pr_y, pr_z, pu_x, pu_y, pu_z;
      orientation.get_basis(pf_x, pf_y, pf_z, pr_x, pr_y, pr_z, pu_x, pu_y,
                            pu_z);
      double eff_thrust = engine_thrust * boost_factor;
      tf_x += pf_x * eff_thrust;
      tf_y += pf_y * eff_thrust;
      tf_z += pf_z * eff_thrust;

      double v_fwd = vel.x * pf_x + vel.y * pf_y + vel.z * pf_z;
      double v_up = vel.x * pu_x + vel.y * pu_y + vel.z * pu_z;
      double v_right = vel.x * pr_x + vel.y * pr_y + vel.z * pr_z;
      double v_sq = v_fwd * v_fwd + v_up * v_up + v_right * v_right,
             v_mag = sqrt(v_sq);
      double q = v_sq * 12.0;

      double aoa = 0.0;
      if (abs(v_fwd) > 5.0) {
        aoa = atan2(-v_up, abs(v_fwd));
      }
      double CL = (0.15 + (0.2 * flap_extension)) + 5.0 * aoa;
      if (aoa > 0.25)
        CL = max(0.0, CL - (aoa - 0.25) * 15.0);
      if (aoa < -0.25)
        CL = min(0.0, CL - (aoa + 0.25) * 15.0);

      double lift_dx = pu_x, lift_dy = pu_y, lift_dz = pu_z;
      if (v_mag > 5.0) {
        double vp_x = pf_x * v_fwd + pu_x * v_up,
               vp_y = pf_y * v_fwd + pu_y * v_up,
               vp_z = pf_z * v_fwd + pu_z * v_up;
        double vp_m = sqrt(vp_x * vp_x + vp_y * vp_y + vp_z * vp_z);
        if (vp_m > 1e-9) {
          double inv_vp = 1.0 / vp_m;
          vp_x *= inv_vp;
          vp_y *= inv_vp;
          vp_z *= inv_vp;
        }
        lift_dx = vp_y * pr_z - vp_z * pr_y;
        lift_dy = vp_z * pr_x - vp_x * pr_z;
        lift_dz = vp_x * pr_y - vp_y * pr_x;
        double ld_m =
            sqrt(lift_dx * lift_dx + lift_dy * lift_dy + lift_dz * lift_dz);
        if (ld_m > 1e-9) {
          double inv_ld = 1.0 / ld_m;
          lift_dx *= inv_ld;
          lift_dy *= inv_ld;
          lift_dz *= inv_ld;
        } else {
          lift_dx = pu_x;
          lift_dy = pu_y;
          lift_dz = pu_z;
        }
      }

      // Bluff-body drag uses sin(aoa)^2 (caps at AoA=π/2, sin²=1.0)
      // not aoa² (unbounded). Identical within ~2% through stall band
      // (|aoa|<0.25) so cruise feel unchanged; broadside CD~1.3 vs
      // ~3.05 lifts flat-fall terminal from ~127 to ~194 u/s.
      double s_aoa = sin(aoa);
      double CD =
          (0.1 + (0.05 * flap_extension)) + 1.2 * s_aoa * s_aoa + 0.05 * CL * CL;
      double drag_x = 0, drag_y = 0, drag_z = 0;
      if (v_mag > 5.0) {
        double drag_mult = -(q * CD) * (1.0 / v_mag);
        drag_x = vel.x * drag_mult;
        drag_y = vel.y * drag_mult;
        drag_z = vel.z * drag_mult;
      }

      tf_x += lift_dx * (q * CL) + drag_x;
      tf_y += lift_dy * (q * CL) + drag_y;
      tf_z += lift_dz * (q * CL) + drag_z;

      double slip_angle = 0.0;
      if (v_mag > 5.0) {
        slip_angle = atan2(v_right, max(abs(v_fwd), 1.0));

        double s1 = slip_angle * q * 50.0;
        // OPTIMIZATION: Inlined math_clamp ternary (clamp -0.5..0.5)
        double _aoa_c = (aoa < -0.5) ? -0.5 : ((aoa > 0.5) ? 0.5 : aoa);
        double s2 = _aoa_c * q * 20.0;
        double s3 = -slip_angle * q * 10.0;

        tt_x += pu_x * s1 + pr_x * s2 + pf_x * s3;
        tt_y += pu_y * s1 + pr_y * s2 + pf_y * s3;
        tt_z += pu_z * s1 + pr_z * s2 + pf_z * s3;

        double vr_mag = -v_right * abs(v_right) * 5.0;
        tf_x += pr_x * vr_mag;
        tf_y += pr_y * vr_mag;
        tf_z += pr_z * vr_mag;
      }

      double tail_steer = yaw_input * 0.8;
      double brake_input_val = (brake_timer > 0.0) ? 1.0 : 0.0;

      double dfx, dfy, dfz, dtx, dty, dtz;
      apply_wheel_physics(20, -18, -28, 6.0, 90000.0, 6000.0, 0.02, 0.8, 1.5,
                          0.0, brake_input_val, pf_x, pf_y, pf_z, pr_x, pr_y,
                          pr_z, pu_x, pu_y, pu_z, dfx, dfy, dfz, dtx, dty, dtz,
                          comp_L, touch_L, contact_L);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      apply_wheel_physics(20, 18, -28, 6.0, 90000.0, 6000.0, 0.02, 0.8, 1.5,
                          0.0, brake_input_val, pf_x, pf_y, pf_z, pr_x, pr_y,
                          pr_z, pu_x, pu_y, pu_z, dfx, dfy, dfz, dtx, dty, dtz,
                          comp_R, touch_R, contact_R);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      apply_wheel_physics(-40, 0, -25, 4.0, 45000.0, 3000.0, 0.05, 0.5, 1.0,
                          -tail_steer, brake_input_val, pf_x, pf_y, pf_z, pr_x,
                          pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy, dfz, dtx, dty,
                          dtz, comp_T, touch_T, contact_T);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;

      apply_point_collision(0, 0, 0, 20.0, 200000.0, 10000.0, 0.8, pf_x, pf_y,
                            pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy,
                            dfz, dtx, dty, dtz);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      apply_point_collision(60, 0, 0, 10.0, 200000.0, 10000.0, 0.8, pf_x, pf_y,
                            pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy,
                            dfz, dtx, dty, dtz);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      // Left wingtip — pass spawn_impact_sparks=true so geometry hits
      // emit a speed-scaled spark burst (see apply_point_collision body).
      apply_point_collision(20, -75, 5, 5.0, 200000.0, 10000.0, 0.8, pf_x, pf_y,
                            pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy,
                            dfz, dtx, dty, dtz, true);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      // Right wingtip — same speed-scaled spark burst on geometry hit.
      apply_point_collision(20, 75, 5, 5.0, 200000.0, 10000.0, 0.8, pf_x, pf_y,
                            pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy,
                            dfz, dtx, dty, dtz, true);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      apply_point_collision(-40, 0, -25, 5.0, 200000.0, 10000.0, 0.8, pf_x,
                            pf_y, pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx,
                            dfy, dfz, dtx, dty, dtz);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;
      apply_point_collision(-40, 0, -5, 5.0, 200000.0, 10000.0, 0.8, pf_x, pf_y,
                            pf_z, pr_x, pr_y, pr_z, pu_x, pu_y, pu_z, dfx, dfy,
                            dfz, dtx, dty, dtz);
      tf_x += dfx;
      tf_y += dfy;
      tf_z += dfz;
      tt_x += dtx;
      tt_y += dty;
      tt_z += dtz;

      double effective_airspeed =
          max(v_fwd, (engine_thrust / max_thrust) * 100.0);
      // OPTIMIZATION: Inlined math_clamp ternary (clamp 2..8)
      double _ae = (effective_airspeed * effective_airspeed) * 0.00001111111111111111;
      double aero_effect = (_ae < 2.0) ? 2.0 : ((_ae > 8.0) ? 8.0 : _ae);
      double cm_x = (roll_input * 10000000.0 * roll_auth_mult * roll_hold_mult -
                     yaw_input * 1200000.0) *
                    aero_effect,
             cm_y = -pitch_input * 9000000.0 * aero_effect,
             cm_z = yaw_input * yaw_max_torque * yaw_auth_mult * aero_effect;
      double rw_x, rw_y, rw_z;
      orientation.rotate_scalar(cm_x, cm_y, cm_z, rw_x, rw_y, rw_z);
      tt_x += rw_x;
      tt_y += rw_y;
      tt_z += rw_z;

      vel.scale_in_place(1.0 - linear_air_damping * sub_dt);
      double lo_x, lo_y, lo_z;
      orientation.inverse_rotate_scalar(angular_velocity.x,
                                          angular_velocity.y,
                                          angular_velocity.z, lo_x, lo_y, lo_z);
      double damping_factor = 1.0 + (v_mag * 0.006666666666666667);
      lo_x *= (1.0 - angular_air_damping.x * damping_factor * sub_dt);
      lo_y *= (1.0 - angular_air_damping.y * damping_factor * sub_dt);
      lo_z *= (1.0 - angular_air_damping.z * damping_factor * sub_dt);
      orientation.rotate_scalar(lo_x, lo_y, lo_z, angular_velocity.x,
                                angular_velocity.y, angular_velocity.z);

      // Replace divisions with inverse multipliers
      double dt_inv_mass = sub_dt * inv_mass;
      vel.x += tf_x * dt_inv_mass;
      vel.y += tf_y * dt_inv_mass;
      vel.z += tf_z * dt_inv_mass;

      // High-speed tunnel guard: clip inward component of vel if any
      // body point's swept path would cross a tri. No-op at normal
      // speeds. MUST run AFTER force-driven vel update and BEFORE
      // position integration. See clip_swept_tunneling for invariants.
      clip_swept_tunneling(sub_dt, pf_x, pf_y, pf_z, pr_x, pr_y, pr_z, pu_x,
                           pu_y, pu_z);

      pos.x += vel.x * sub_dt;
      pos.y += vel.y * sub_dt;
      pos.z += vel.z * sub_dt;

      double lt_x, lt_y, lt_z;
      orientation.inverse_rotate_scalar(tt_x, tt_y, tt_z, lt_x, lt_y, lt_z);

      // Replace divisions here as well
      double dt_inv_ix = sub_dt * inv_inertia.x;
      double dt_inv_iy = sub_dt * inv_inertia.y;
      double dt_inv_iz = sub_dt * inv_inertia.z;
      double la_x = lt_x * dt_inv_ix;
      double la_y = lt_y * dt_inv_iy;
      double la_z = lt_z * dt_inv_iz;
      double dw_x, dw_y, dw_z;
      orientation.rotate_scalar(la_x, la_y, la_z, dw_x, dw_y, dw_z);
      angular_velocity.x += dw_x;
      angular_velocity.y += dw_y;
      angular_velocity.z += dw_z;

      double ang_mag = angular_velocity.magnitude();
      double angle = ang_mag * sub_dt;
      if (angle > 1e-9) {
        double inv_mag = 1.0 / ang_mag;
        double ax = angular_velocity.x * inv_mag;
        double ay = angular_velocity.y * inv_mag;
        double az = angular_velocity.z * inv_mag;
        double ha = angle * 0.5;
        double s = sin(ha);
        q_rot_1.w = cos(ha);
        q_rot_1.x = ax * s;
        q_rot_1.y = ay * s;
        q_rot_1.z = az * s;
        double nw = q_rot_1.w * orientation.w - q_rot_1.x * orientation.x -
                    q_rot_1.y * orientation.y - q_rot_1.z * orientation.z;
        double nx = q_rot_1.w * orientation.x + q_rot_1.x * orientation.w +
                    q_rot_1.y * orientation.z - q_rot_1.z * orientation.y;
        double ny = q_rot_1.w * orientation.y - q_rot_1.x * orientation.z +
                    q_rot_1.y * orientation.w + q_rot_1.z * orientation.x;
        double nz = q_rot_1.w * orientation.z + q_rot_1.x * orientation.y -
                    q_rot_1.y * orientation.x + q_rot_1.z * orientation.w;
        orientation.w = nw;
        orientation.x = nx;
        orientation.y = ny;
        orientation.z = nz;
        orientation.normalize();
      }
      prop_angle += (10.0 + (engine_thrust / max_thrust) * 50.0) * sub_dt;
    }

    vis_comp_L += (comp_L - vis_comp_L) * 15.0 * DT;
    vis_comp_R += (comp_R - vis_comp_R) * 15.0 * DT;
    vis_comp_T += (comp_T - vis_comp_T) * 15.0 * DT;

    update_trails(touch_L, touch_R, touch_T, contact_L, contact_R, contact_T);
    // DISABLED for cull-bug: engine onscreen-cull drops draw() past
    // ~5000u from level camera (no hit_rectangle/base_rectangle).
    // Restore + pair with self.hit_rectangle/base_rectangle once fixed.
    // self.set_xy(float(pos.x), float(pos.y));
    update_camera();
    prev_dash = current_dash;

    // Controls-overlay HUD — accumulate idle time / observe input edges.
    // Cheap (handful of method calls + arithmetic). See Plane_HUD.cpp.
    step_controls_hud();
  }

  // Swept-path tunnel guard. MUST run AFTER linear vel update and
  // BEFORE position integration. Removes inward-normal LINEAR vel
  // component on confirmed sweep-tri cross. Tangential motion +
  // apply_point_collision spring/damp preserved. Fires only past
  // apply_point_collision's rescue limit (r*1.5 side / r*10 floor).
  void clip_swept_tunneling(double sub_dt, double bfx, double bfy, double bfz,
                            double brx, double bry, double brz, double bux,
                            double buy, double buz) {
    // Key collision points: (lx, ly, lz, r) — mirrors apply_point_collision
    // / apply_wheel_physics call sites. Shared positions use larger radius.
    array<double> pts_lx = {0.0, 60.0, 20.0,  20.0, -40.0, -40.0, 20.0, 20.0};
    array<double> pts_ly = {0.0,  0.0, -75.0, 75.0,   0.0,   0.0, -18.0, 18.0};
    array<double> pts_lz = {0.0,  0.0,   5.0,  5.0, -25.0,  -5.0, -28.0, -28.0};
    array<double> pts_r  = {20.0, 10.0, 5.0,  5.0,   5.0,   5.0,   6.0,  6.0};
    const int NUM_POINTS = 8;

    // Inverse of 60u physics-grid cell side (math_core.cpp).
    const double inv_cell_size = INV_PHYSICS_CELL_60;

    for (int k = 0; k < NUM_POINTS; k++) {
      double lx = pts_lx[k], ly = pts_ly[k], lz = pts_lz[k], r = pts_r[k];
      double wox = lx * bfx + ly * brx + lz * bux;
      double woy = lx * bfy + ly * bry + lz * buy;
      double woz = lx * bfz + ly * brz + lz * buz;
      double wpx = pos.x + wox, wpy = pos.y + woy, wpz = pos.z + woz;

      // Point velocity = linear vel + angular_velocity × body-offset.
      double avx = angular_velocity.x, avy = angular_velocity.y,
             avz = angular_velocity.z;
      double crx = avy * woz - avz * woy;
      double cry = avz * wox - avx * woz;
      double crz = avx * woy - avy * wox;
      double pvx = vel.x + crx, pvy = vel.y + cry, pvz = vel.z + crz;

      double dx = pvx * sub_dt, dy = pvy * sub_dt, dz = pvz * sub_dt;
      double tx_sq = dx * dx + dy * dy + dz * dz;

      // Small-translation early-out: below r/2 per substep, tunneling
      // past r*1.5 is impossible; apply_point_collision handles it.
      if (tx_sq < r * r * 0.25)
        continue;

      double end_x = wpx + dx, end_y = wpy + dy, end_z = wpz + dz;

      double min_x = (wpx < end_x) ? wpx - r : end_x - r;
      double max_x = (wpx > end_x) ? wpx + r : end_x + r;
      double min_y = (wpy < end_y) ? wpy - r : end_y - r;
      double max_y = (wpy > end_y) ? wpy + r : end_y + r;
      double min_z = (wpz < end_z) ? wpz - r : end_z - r;
      double max_z = (wpz > end_z) ? wpz + r : end_z + r;

      current_query_id++;

      int p_min_gx = int((min_x - physics_grid_min_x) * inv_cell_size);
      int p_max_gx = int((max_x - physics_grid_min_x) * inv_cell_size);
      int p_min_gy = int((min_y - physics_grid_min_y) * inv_cell_size);
      int p_max_gy = int((max_y - physics_grid_min_y) * inv_cell_size);
      int p_min_gz = int((min_z - physics_grid_min_z) * inv_cell_size);
      int p_max_gz = int((max_z - physics_grid_min_z) * inv_cell_size);
      if (p_min_gx < 0) p_min_gx = 0;
      if (p_max_gx > 3) p_max_gx = 3;
      if (p_min_gy < 0) p_min_gy = 0;
      if (p_max_gy > 3) p_max_gy = 3;
      if (p_min_gz < 0) p_min_gz = 0;
      if (p_max_gz > 3) p_max_gz = 3;

      for (int gx = p_min_gx; gx <= p_max_gx; gx++) {
        for (int gy = p_min_gy; gy <= p_max_gy; gy++) {
          for (int gz = p_min_gz; gz <= p_max_gz; gz++) {
            int cell_idx = gx * 16 + gy * 4 + gz;

            int cell_len =
                (physics_grid_gen[cell_idx] == physics_grid_current_gen)
                    ? physics_grid_count[cell_idx]
                    : 0;
            int base_idx = cell_idx * 256;

            for (int i = 0; i < cell_len; i++) {
              Triangle @tri = physics_grid[base_idx + i];

              if (tri.last_query_id == current_query_id)
                continue;
              tri.last_query_id = current_query_id;

              if (max_x < tri.min_x || min_x > tri.max_x ||
                  max_y < tri.min_y || min_y > tri.max_y ||
                  max_z < tri.min_z || min_z > tri.max_z)
                continue;
              if (tri.invDenom == 0.0)
                continue;

              // Hoist tri normal — used 6× across ps/pe/limit/hd/proj/vn
              // (~18 dispatches per tri-that-passes-AABB). Read once into
              // doubles; AS member dispatch ≈ indexed array access cost.
              double tnx = tri.nx, tny = tri.ny, tnz = tri.nz;

              double ps =
                  wpx * tnx + wpy * tny + wpz * tnz + tri.plane_d;
              double pe = end_x * tnx + end_y * tny + end_z * tnz +
                          tri.plane_d;

              // Matches apply_point_collision's back-side rescue limit so we
              // only fire in the regime the existing collision misses.
              double limit = (tnz > 0.5) ? -r * 10.0 : -r * 1.5;
              if (ps <= 0.0 || pe >= limit)
                continue;

              double denom = ps - pe;
              if (denom < 1e-9)
                continue;

              // t_entry: fraction of the segment where the sphere *surface*
              // (not the center) first touches the plane, i.e. plane_dist == r.
              double t_entry = (ps - r) / denom;
              if (t_entry < 0.0) t_entry = 0.0;
              if (t_entry > 1.0) continue;

              // Project the entry point onto the triangle plane for the
              // in-triangle barycentric test.
              double hx = wpx + dx * t_entry;
              double hy = wpy + dy * t_entry;
              double hz = wpz + dz * t_entry;
              double hd =
                  hx * tnx + hy * tny + hz * tnz + tri.plane_d;
              double projx = hx - tnx * hd;
              double projy = hy - tny * hd;
              double projz = hz - tnz * hd;

              double v2x = projx - tri.p1x, v2y = projy - tri.p1y,
                     v2z = projz - tri.p1z;
              double d20 = v2x * tri.v0x + v2y * tri.v0y + v2z * tri.v0z;
              double d21 = v2x * tri.v1x + v2y * tri.v1y + v2z * tri.v1z;
              double vb = (tri.d11 * d20 - tri.d01 * d21) * tri.invDenom;
              double wb = (tri.d00 * d21 - tri.d01 * d20) * tri.invDenom;
              double ub = 1.0 - vb - wb;
              // Small tolerance catches edge clips that a neighbour tri
              // will take over next substep — prevents escape through edges.
              const double TOL = 0.05;
              if (ub < -TOL || vb < -TOL || wb < -TOL)
                continue;

              // Confirmed tunnel — clip only inward LINEAR vel along
              // tri normal. Angular vel + tangential motion preserved.
              double vn =
                  vel.x * tnx + vel.y * tny + vel.z * tnz;
              if (vn < 0.0) {
                vel.x -= tnx * vn;
                vel.y -= tny * vn;
                vel.z -= tnz * vn;
              }
            }
          }
        }
      }
    }
  }


  // spawn_impact_sparks: hit emits speed-scaled spark burst at contact.
  // Only wingtips pass true; fuselage/nose/tails silent so belly slide
  // doesn't fountain particles.
  void apply_point_collision(double lx, double ly, double lz, double r,
                             double k, double c, double friction, double bfx,
                             double bfy, double bfz, double brx, double bry,
                             double brz, double bux, double buy, double buz,
                             double &out df_x, double &out df_y,
                             double &out df_z, double &out dt_x,
                             double &out dt_y, double &out dt_z,
                             bool spawn_impact_sparks = false) {
    double wox = lx * bfx + ly * brx + lz * bux;
    double woy = lx * bfy + ly * bry + lz * buy;
    double woz = lx * bfz + ly * brz + lz * buz;
    double wpx = pos.x + wox, wpy = pos.y + woy, wpz = pos.z + woz;
    double max_penetration = -1.0;
    double hit_nx = 0, hit_ny = 0, hit_nz = 1;

    double avx = angular_velocity.x, avy = angular_velocity.y,
           avz = angular_velocity.z;
    double crx = avy * woz - avz * woy;
    double cry = avz * wox - avx * woz;
    double crz = avx * woy - avy * wox;
    double pvx = vel.x + crx, pvy = vel.y + cry, pvz = vel.z + crz;

    double pad_xy = r * 3.0;
    double pad_z = r * 12.0;
    double min_x = wpx - pad_xy, max_x = wpx + pad_xy;
    double min_y = wpy - pad_xy, max_y = wpy + pad_xy;
    double min_z = wpz - pad_z, max_z = wpz + pad_z;

    current_query_id++;

    // Inverse of 60u physics-grid cell side (math_core.cpp).
    const double inv_cell_size = INV_PHYSICS_CELL_60;
    int p_min_gx = int((min_x - physics_grid_min_x) * inv_cell_size);
    int p_max_gx = int((max_x - physics_grid_min_x) * inv_cell_size);
    int p_min_gy = int((min_y - physics_grid_min_y) * inv_cell_size);
    int p_max_gy = int((max_y - physics_grid_min_y) * inv_cell_size);
    int p_min_gz = int((min_z - physics_grid_min_z) * inv_cell_size);
    int p_max_gz = int((max_z - physics_grid_min_z) * inv_cell_size);

    if (p_min_gx < 0)
      p_min_gx = 0;
    if (p_max_gx > 3)
      p_max_gx = 3;
    if (p_min_gy < 0)
      p_min_gy = 0;
    if (p_max_gy > 3)
      p_max_gy = 3;
    if (p_min_gz < 0)
      p_min_gz = 0;
    if (p_max_gz > 3)
      p_max_gz = 3;

    for (int gx = p_min_gx; gx <= p_max_gx; gx++) {
      for (int gy = p_min_gy; gy <= p_max_gy; gy++) {
        for (int gz = p_min_gz; gz <= p_max_gz; gz++) {
          int cell_idx = gx * 16 + gy * 4 + gz;

          int cell_len =
              (physics_grid_gen[cell_idx] == physics_grid_current_gen)
                  ? physics_grid_count[cell_idx]
                  : 0;
          int base_idx = cell_idx * 256;

          for (int i = 0; i < cell_len; i++) {
            Triangle @tri = physics_grid[base_idx + i];

            if (tri.last_query_id == current_query_id)
              continue;
            tri.last_query_id = current_query_id;

            if (max_x < tri.min_x || min_x > tri.max_x || max_y < tri.min_y ||
                min_y > tri.max_y || max_z < tri.min_z || min_z > tri.max_z)
              continue;

            // Hoist tri normal — used in plane_dist (3×), limit (1×),
            // proj_xyz (3×), and the n_use defaults (3×) — ~10 member
            // dispatches per tri-that-passes-AABB collapsed to 3 reads.
            double tnx = tri.nx, tny = tri.ny, tnz = tri.nz;

            double plane_dist =
                wpx * tnx + wpy * tny + wpz * tnz + tri.plane_d;
            double limit = (tnz > 0.5) ? -r * 10.0 : -r * 1.5;

            if (plane_dist < r && plane_dist > limit) {
              double proj_x = wpx - tnx * plane_dist;
              double proj_y = wpy - tny * plane_dist;
              double proj_z = wpz - tnz * plane_dist;
              double v2_x = proj_x - tri.p1x, v2_y = proj_y - tri.p1y,
                     v2_z = proj_z - tri.p1z;
              double d20 = v2_x * tri.v0x + v2_y * tri.v0y + v2_z * tri.v0z;
              double d21 = v2_x * tri.v1x + v2_y * tri.v1y + v2_z * tri.v1z;
              bool is_inside = false;
              double u_bary = -1.0, v_bary = -1.0, w_bary = -1.0;
              if (tri.invDenom != 0.0) {
                v_bary = (tri.d11 * d20 - tri.d01 * d21) * tri.invDenom;
                w_bary = (tri.d00 * d21 - tri.d01 * d20) * tri.invDenom;
                u_bary = 1.0 - v_bary - w_bary;
                if (u_bary >= -1e-4 && v_bary >= -1e-4 && w_bary >= -1e-4)
                  is_inside = true;
              }
              double penetration = -1.0;
              double n_use_x = tnx, n_use_y = tny, n_use_z = tnz;
              if (is_inside) {
                penetration = r - plane_dist;
              } else {
                double cl_x, cl_y, cl_z;
                if (tri.invDenom != 0.0) {
                  closest_point_on_triangle_edges(wpx, wpy, wpz, tri, u_bary,
                                                  v_bary, w_bary, cl_x, cl_y,
                                                  cl_z);
                } else {
                  closest_point_on_triangle_degenerate(wpx, wpy, wpz, tri, cl_x,
                                                       cl_y, cl_z);
                }
                double diff_x = wpx - cl_x, diff_y = wpy - cl_y,
                       diff_z = wpz - cl_z;
                double dist_sq =
                    diff_x * diff_x + diff_y * diff_y + diff_z * diff_z;
                if (dist_sq < r * r) {
                  double dist = sqrt(dist_sq);
                  penetration = r - dist;
                  if (dist > 1e-4) {
                    n_use_x = diff_x / dist;
                    n_use_y = diff_y / dist;
                    n_use_z = diff_z / dist;
                  }
                }
              }
              if (penetration > max_penetration) {
                max_penetration = penetration;
                hit_nx = n_use_x;
                hit_ny = n_use_y;
                hit_nz = n_use_z;
              }
            }
          }
        }
      }
    }

    if (max_penetration > 0) {
      double effective_pen = max_penetration;
      if (effective_pen > r * 2.5)
        effective_pen = r * 2.5;
      double spring_f = effective_pen * k;
      double damp_f = -(pvx * hit_nx + pvy * hit_ny + pvz * hit_nz) * c;
      double susp_f = spring_f + damp_f;
      if (susp_f < 0)
        susp_f = 0;
      double fx = hit_nx * susp_f, fy = hit_ny * susp_f, fz = hit_nz * susp_f;

      double dot_pv_n = pvx * hit_nx + pvy * hit_ny + pvz * hit_nz;
      double tvx = pvx - hit_nx * dot_pv_n;
      double tvy = pvy - hit_ny * dot_pv_n;
      double tvz = pvz - hit_nz * dot_pv_n;
      double t_speed = sqrt(tvx * tvx + tvy * tvy + tvz * tvz);
      if (t_speed > 1e-4) {
        double damp_factor = 20000.0;
        double req_fric = t_speed * damp_factor;
        double max_fric = friction * susp_f;
        double fric_force = (req_fric > max_fric) ? max_fric : req_fric;
        double fric_mag = -fric_force * (1.0 / t_speed);
        fx += tvx * fric_mag;
        fy += tvy * fric_mag;
        fz += tvz * fric_mag;
      }

      // ---- Wingtip impact / shear sparks ----
      // Slam (|dot_pv_n|) and slide (t_speed*0.20) unified into one
      // spark_drive; sliding reads ~70% of slam so head-on pops more
      // than scrapes. no_gravity + streak, white→hot-orange palette.
      if (spawn_impact_sparks) {
        double impact_speed = (dot_pv_n < 0) ? -dot_pv_n : dot_pv_n;
        double shear_drive = t_speed * 0.20;
        double spark_drive =
            (impact_speed > shear_drive) ? impact_speed : shear_drive;

        if (spark_drive > 50.0) {
          int spark_count = 1 + int(spark_drive * 0.018);
          if (spark_count > 5)
            spark_count = 5;

          // Project contact onto wing model (sphere ~15u inboard of
          // real tip): pull to surface, clamp chord/span, +2u along
          // +hit_n to avoid z-fight.
          double surf_offset = r - max_penetration;
          if (surf_offset < 0.0)
            surf_offset = 0.0;
          double sw_dx = wox - hit_nx * surf_offset;
          double sw_dy = woy - hit_ny * surf_offset;
          double sw_dz = woz - hit_nz * surf_offset;
          double surf_lx = sw_dx * bfx + sw_dy * bfy + sw_dz * bfz;
          double surf_ly = sw_dx * brx + sw_dy * bry + sw_dz * brz;

          double wing_lx = (surf_lx < 5.0)
                               ? 5.0
                               : (surf_lx > 23.0 ? 23.0 : surf_lx);
          double wing_ly;
          if (ly < 0.0) {
            // Left wing — ly extent [−90, −10].
            wing_ly = (surf_ly < -90.0)
                          ? -90.0
                          : (surf_ly > -10.0 ? -10.0 : surf_ly);
          } else {
            // Right wing — ly extent [10, 90].
            wing_ly = (surf_ly < 10.0)
                          ? 10.0
                          : (surf_ly > 90.0 ? 90.0 : surf_ly);
          }
          double wing_lz = 5.0;

          double wing_wox = wing_lx * bfx + wing_ly * brx + wing_lz * bux;
          double wing_woy = wing_lx * bfy + wing_ly * bry + wing_lz * buy;
          double wing_woz = wing_lx * bfz + wing_ly * brz + wing_lz * buz;
          double sx = pos.x + wing_wox + hit_nx * 2.0;
          double sy = pos.y + wing_woy + hit_ny * 2.0;
          double sz = pos.z + wing_woz + hit_nz * 2.0;

          // Wingtip trail point on surface (no +hit_n*2 lift —
          // queue_wheel_trails adds its own +0.5z). Frame-touch flag
          // OR'd across substeps; consumed by update_trails after.
          if (ly < 0.0) {
            wing_touch_L_frame = true;
            wing_contact_L.x = pos.x + wing_wox;
            wing_contact_L.y = pos.y + wing_woy;
            wing_contact_L.z = pos.z + wing_woz;
          } else {
            wing_touch_R_frame = true;
            wing_contact_R.x = pos.x + wing_wox;
            wing_contact_R.y = pos.y + wing_woy;
            wing_contact_R.z = pos.z + wing_woz;
          }

          // Per-impact hash seeds derived from the wing-projected spawn
          // point so each contact site looks distinct as the contact
          // walks along the wing during a slide.
          uint h_seed_x = uint(sx * 10.0);
          uint h_seed_y = uint(sy * 10.0);
          uint h_seed_z = uint(sz * 10.0);

          for (int j = 0; j < spark_count; j++) {
            Particle @part = get_particle();
            part.pos.x = sx;
            part.pos.y = sy;
            part.pos.z = sz;

            double hvx = fast_hash(h_seed_x ^ uint(j * 333)) * 2.0 - 1.0;
            double hvy = fast_hash(h_seed_y ^ uint(j * 666)) * 2.0 - 1.0;
            double hvz = fast_hash(h_seed_z ^ uint(j * 999)) * 2.0 - 1.0;
            double h_dot_n = hvx * hit_nx + hvy * hit_ny + hvz * hit_nz;
            double radially_x = hvx - h_dot_n * hit_nx,
                   radially_y = hvy - h_dot_n * hit_ny,
                   radially_z = hvz - h_dot_n * hit_nz;
            double r_len = sqrt(radially_x * radially_x +
                                radially_y * radially_y +
                                radially_z * radially_z);
            if (r_len > 1e-4) {
              double inv_rlen = 1.0 / r_len;
              radially_x *= inv_rlen;
              radially_y *= inv_rlen;
              radially_z *= inv_rlen;
            }

            // radial_force tracks spark_drive (slide-fan); out_force
            // tracks only impact_speed (sliding hugs ground).
            double radial_force = (0.3 + fast_hash(uint(j * 123)) * 0.7) *
                                  (spark_drive * 0.30 + 50.0);
            double out_force = (0.2 + fast_hash(uint(j * 111)) * 0.8) *
                               (impact_speed * 0.30 + 25.0);

            // 20% tangential drift makes sparks streak along the
            // direction the wing is sliding (classic spark-trail).
            part.vel.set(
                tvx * 0.20 + radially_x * radial_force + hit_nx * out_force,
                tvy * 0.20 + radially_y * radial_force + hit_ny * out_force,
                tvz * 0.20 + radially_z * radial_force + hit_nz * out_force);

            part.life = 0.15 + fast_hash(uint(j + 100)) * 0.25;
            // Bias to col_primary (0.55..1.0) for tinted sparks
            // with occasional near-white flashes.
            double t_blend = 0.55 + fast_hash(uint(j + 200)) * 0.45;
            part.color = lerp_color(0xFFFFFFFF, col_primary, t_blend);
            part.no_gravity = true;
            part.streak = true;
            particles.insertLast(part);
          }
        }
      }

      df_x = fx;
      df_y = fy;
      df_z = fz;
      dt_x = woy * fz - woz * fy;
      dt_y = woz * fx - wox * fz;
      dt_z = wox * fy - woy * fx;
      return;
    }
    df_x = 0;
    df_y = 0;
    df_z = 0;
    dt_x = 0;
    dt_y = 0;
    dt_z = 0;
  }


  void update_active_physics_set() {
    double plane_radius = 120.0;

    // Snap to 60u increments (matches physics grid cell size).
    double snapped_x = floor(pos.x * INV_PHYSICS_CELL_60) * 60.0;
    double snapped_y = floor(pos.y * INV_PHYSICS_CELL_60) * 60.0;
    double snapped_z = floor(pos.z * INV_PHYSICS_CELL_60) * 60.0;

    double min_pos_x = snapped_x - plane_radius,
           min_pos_y = snapped_y - plane_radius,
           min_pos_z = snapped_z - plane_radius;

    // Skip if snapped collision grid hasn't moved.
    if (abs(physics_grid_min_x - min_pos_x) < 1.0 &&
        abs(physics_grid_min_y - min_pos_y) < 1.0 &&
        abs(physics_grid_min_z - min_pos_z) < 1.0) {
      return;
    }

    physics_grid_min_x = min_pos_x;
    physics_grid_min_y = min_pos_y;
    physics_grid_min_z = min_pos_z;

    active_physics_count = 0;

    physics_grid_current_gen++;
    if (physics_grid_current_gen == 0) {
      for (int i = 0; i < 64; i++)
        physics_grid_gen[i] = 0;
      physics_grid_current_gen = 1;
    }

    double max_pos_x = min_pos_x + 240.0, max_pos_y = min_pos_y + 240.0,
           max_pos_z = min_pos_z + 240.0;

    double chunk_search_radius = plane_radius + 250.0;
    double search_min_x = pos.x - chunk_search_radius,
           search_min_y = pos.y - chunk_search_radius,
           search_min_z = pos.z - chunk_search_radius;
    double search_max_x = pos.x + chunk_search_radius,
           search_max_y = pos.y + chunk_search_radius,
           search_max_z = pos.z + chunk_search_radius;

    double c_pad = 50.0;
    // Inverse of 60u physics-grid cell side; declared file-scope in
    // math_core.cpp.
    const double inv_cell_size = INV_PHYSICS_CELL_60;

    // Hoist grid center & half-extent for branch-free AABB-vs-plane
    // test below. Physics grid is a 240u cube.
    double cx_grid = (min_pos_x + max_pos_x) * 0.5;
    double cy_grid = (min_pos_y + max_pos_y) * 0.5;
    double cz_grid = (min_pos_z + max_pos_z) * 0.5;
    double hx_grid = 120.0, hy_grid = 120.0, hz_grid = 120.0;

    // Iterate ready_chunks (tightly-packed view of generated + non-empty
    // chunks). Replaces populated_chunks scan + null/gen/empty filter
    // (covered by ready_chunks invariant). See
    // project_codebase_audit_2026_05_05.md.
    array<Chunk @> @rdy_chunks = @chunk_manager.ready_chunks;
    uint npc = rdy_chunks.length();

    // Hoist active_physics_triangles.length() and bump apt_len locally
    // on grow (array only grows via insertLast).
    int apt_len = int(active_physics_triangles.length());

    for (uint ci = 0; ci < npc; ci++) {
      Chunk @c = rdy_chunks[ci];
      // AABB overlap vs search box — cheap, all scalars.
      if (c.max_x < search_min_x || c.min_x > search_max_x) continue;
      if (c.max_y < search_min_y || c.min_y > search_max_y) continue;
      if (c.max_z < search_min_z || c.min_z > search_max_z) continue;

      int tri_count = c.active_triangles;
      // Hoist triangle array handle (skip `c.triangles` per-iter lookup).
      array<Triangle @> @chunk_tris = @c.triangles;
      for (int i = 0; i < tri_count; i++) {
        Triangle @tri = chunk_tris[i];

        // Branch-free AABB-vs-plane early reject.
        // d_center = grid-center signed dist; radius = grid-half projected
        // onto |n|. (d_center - radius) > c_pad ⇒ entirely on positive
        // side beyond collision pad.
        double n_x = tri.nx, n_y = tri.ny, n_z = tri.nz;
        double d_center = cx_grid * n_x + cy_grid * n_y + cz_grid * n_z + tri.plane_d;
        double radius   = hx_grid * tri.abs_nx + hy_grid * tri.abs_ny + hz_grid * tri.abs_nz;
        if (d_center - radius > c_pad) continue;

        if (max_pos_x < tri.min_x || min_pos_x > tri.max_x ||
            max_pos_y < tri.min_y || min_pos_y > tri.max_y ||
            max_pos_z < tri.min_z || min_pos_z > tri.max_z)
          continue;

        if (active_physics_count >= apt_len) {
          active_physics_triangles.insertLast(@tri);
          apt_len++;
        } else {
          @active_physics_triangles[active_physics_count] = @tri;
        }
        active_physics_count++;

        int min_gx =
            int((tri.min_x - physics_grid_min_x) * inv_cell_size);
        int max_gx =
            int((tri.max_x - physics_grid_min_x) * inv_cell_size);
        int min_gy =
            int((tri.min_y - physics_grid_min_y) * inv_cell_size);
        int max_gy =
            int((tri.max_y - physics_grid_min_y) * inv_cell_size);
        int min_gz =
            int((tri.min_z - physics_grid_min_z) * inv_cell_size);
        int max_gz =
            int((tri.max_z - physics_grid_min_z) * inv_cell_size);

        if (min_gx < 0)
          min_gx = 0;
        if (max_gx > 3)
          max_gx = 3;
        if (min_gy < 0)
          min_gy = 0;
        if (max_gy > 3)
          max_gy = 3;
        if (min_gz < 0)
          min_gz = 0;
        if (max_gz > 3)
          max_gz = 3;

        // Progressive cell-base hoist (gx*16 invariant in gy/gz; +gy*4
        // invariant in gz; cell_idx<<8 const per cell).
        for (int gx = min_gx; gx <= max_gx; gx++) {
          int base_x = gx * 16;
          for (int gy = min_gy; gy <= max_gy; gy++) {
            int base_xy = base_x + gy * 4;
            for (int gz = min_gz; gz <= max_gz; gz++) {
              int cell_idx = base_xy + gz;
              int count =
                  (physics_grid_gen[cell_idx] == physics_grid_current_gen)
                      ? physics_grid_count[cell_idx]
                      : 0;

              // Cap at 256 triangles per cell to prevent flat array
              // bounds exception
              if (count < 256) {
                int slot = (cell_idx << 8) + count;
                @physics_grid[slot] = @tri;
                physics_grid_count[cell_idx] = count + 1;
                physics_grid_gen[cell_idx] = physics_grid_current_gen;
              }
            }
          }
        }
      }
    }
  }
  void apply_wheel_physics(double lx, double ly, double lz, double r, double k,
                           double c, double mu_roll, double mu_brake,
                           double mu_side, double steer_angle,
                           double brake_input, double bfx, double bfy,
                           double bfz, double brx, double bry, double brz,
                           double bux, double buy, double buz, double &out df_x,
                           double &out df_y, double &out df_z, double &out dt_x,
                           double &out dt_y, double &out dt_z,
                           double &out out_comp, bool &out out_touch,
                           Vec3 &out out_contact) {
    double wox = lx * bfx + ly * brx + lz * bux;
    double woy = lx * bfy + ly * bry + lz * buy;
    double woz = lx * bfz + ly * brz + lz * buz;
    double wpx = pos.x + wox, wpy = pos.y + woy, wpz = pos.z + woz;

    double max_penetration = -1.0;
    double hit_nx = 0, hit_ny = 0, hit_nz = 1;

    double avx = angular_velocity.x, avy = angular_velocity.y,
           avz = angular_velocity.z;
    double crx = avy * woz - avz * woy;
    double cry = avz * wox - avx * woz;
    double crz = avx * woy - avy * wox;
    double pvx = vel.x + crx, pvy = vel.y + cry, pvz = vel.z + crz;

    out_comp = 0.0;
    out_touch = false;
    out_contact.x = wpx;
    out_contact.y = wpy;
    out_contact.z = wpz - r;

    double pad_xy = r * 3.0;
    double pad_z = r * 12.0;
    double min_x = wpx - pad_xy, max_x = wpx + pad_xy;
    double min_y = wpy - pad_xy, max_y = wpy + pad_xy;
    double min_z = wpz - pad_z, max_z = wpz + pad_z;

    current_query_id++;

    // Inverse of 60u physics-grid cell side (math_core.cpp).
    const double inv_cell_size = INV_PHYSICS_CELL_60;
    int p_min_gx = int((min_x - physics_grid_min_x) * inv_cell_size);
    int p_max_gx = int((max_x - physics_grid_min_x) * inv_cell_size);
    int p_min_gy = int((min_y - physics_grid_min_y) * inv_cell_size);
    int p_max_gy = int((max_y - physics_grid_min_y) * inv_cell_size);
    int p_min_gz = int((min_z - physics_grid_min_z) * inv_cell_size);
    int p_max_gz = int((max_z - physics_grid_min_z) * inv_cell_size);

    if (p_min_gx < 0)
      p_min_gx = 0;
    if (p_max_gx > 3)
      p_max_gx = 3;
    if (p_min_gy < 0)
      p_min_gy = 0;
    if (p_max_gy > 3)
      p_max_gy = 3;
    if (p_min_gz < 0)
      p_min_gz = 0;
    if (p_max_gz > 3)
      p_max_gz = 3;

    for (int gx = p_min_gx; gx <= p_max_gx; gx++) {
      for (int gy = p_min_gy; gy <= p_max_gy; gy++) {
        for (int gz = p_min_gz; gz <= p_max_gz; gz++) {
          int cell_idx = gx * 16 + gy * 4 + gz;

          int cell_len =
              (physics_grid_gen[cell_idx] == physics_grid_current_gen)
                  ? physics_grid_count[cell_idx]
                  : 0;
          int base_idx = cell_idx * 256;

          for (int i = 0; i < cell_len; i++) {
            Triangle @tri = physics_grid[base_idx + i];

            if (tri.last_query_id == current_query_id)
              continue;
            tri.last_query_id = current_query_id;

            if (max_x < tri.min_x || min_x > tri.max_x || max_y < tri.min_y ||
                min_y > tri.max_y || max_z < tri.min_z || min_z > tri.max_z)
              continue;

            // Hoist tri normal — used in plane_dist (3×), limit (1×),
            // proj_xyz (3×), and the n_use defaults (3×) — ~10 member
            // dispatches per tri-that-passes-AABB collapsed to 3 reads.
            double tnx = tri.nx, tny = tri.ny, tnz = tri.nz;

            double plane_dist =
                wpx * tnx + wpy * tny + wpz * tnz + tri.plane_d;
            double limit = (tnz > 0.5) ? -r * 10.0 : -r * 1.5;

            if (plane_dist < r && plane_dist > limit) {
              double proj_x = wpx - tnx * plane_dist;
              double proj_y = wpy - tny * plane_dist;
              double proj_z = wpz - tnz * plane_dist;
              double v2_x = proj_x - tri.p1x, v2_y = proj_y - tri.p1y,
                     v2_z = proj_z - tri.p1z;
              double d20 = v2_x * tri.v0x + v2_y * tri.v0y + v2_z * tri.v0z;
              double d21 = v2_x * tri.v1x + v2_y * tri.v1y + v2_z * tri.v1z;
              bool is_inside = false;
              double u_bary = -1.0, v_bary = -1.0, w_bary = -1.0;
              if (tri.invDenom != 0.0) {
                v_bary = (tri.d11 * d20 - tri.d01 * d21) * tri.invDenom;
                w_bary = (tri.d00 * d21 - tri.d01 * d20) * tri.invDenom;
                u_bary = 1.0 - v_bary - w_bary;
                if (u_bary >= -1e-4 && v_bary >= -1e-4 && w_bary >= -1e-4)
                  is_inside = true;
              }
              double penetration = -1.0;
              double n_use_x = tnx, n_use_y = tny, n_use_z = tnz;
              if (is_inside) {
                penetration = r - plane_dist;
              } else {
                double cl_x, cl_y, cl_z;
                if (tri.invDenom != 0.0) {
                  closest_point_on_triangle_edges(wpx, wpy, wpz, tri, u_bary,
                                                  v_bary, w_bary, cl_x, cl_y,
                                                  cl_z);
                } else {
                  closest_point_on_triangle_degenerate(wpx, wpy, wpz, tri, cl_x,
                                                       cl_y, cl_z);
                }
                double diff_x = wpx - cl_x, diff_y = wpy - cl_y,
                       diff_z = wpz - cl_z;
                double dist_sq =
                    diff_x * diff_x + diff_y * diff_y + diff_z * diff_z;
                if (dist_sq < r * r) {
                  double dist = sqrt(dist_sq);
                  penetration = r - dist;
                  if (dist > 1e-4) {
                    n_use_x = diff_x / dist;
                    n_use_y = diff_y / dist;
                    n_use_z = diff_z / dist;
                  }
                }
              }
              if (penetration > max_penetration) {
                max_penetration = penetration;
                hit_nx = n_use_x;
                hit_ny = n_use_y;
                hit_nz = n_use_z;
              }
            }
          }
        }
      }
    }

    if (max_penetration > 0) {
      out_comp = max_penetration;
      out_touch = true;
      out_contact.x = wpx - hit_nx * (r - max_penetration);
      out_contact.y = wpy - hit_ny * (r - max_penetration);
      out_contact.z = wpz - hit_nz * (r - max_penetration);

      double effective_pen = max_penetration;
      if (effective_pen > r * 2.5)
        effective_pen = r * 2.5;
      double spring_f = effective_pen * k;
      double damp_f = -(pvx * hit_nx + pvy * hit_ny + pvz * hit_nz) * c;
      double susp_f = spring_f + damp_f;
      if (susp_f < 0)
        susp_f = 0;
      double fx = hit_nx * susp_f, fy = hit_ny * susp_f, fz = hit_nz * susp_f;

      double dot_pv_n = pvx * hit_nx + pvy * hit_ny + pvz * hit_nz;
      double tvx = pvx - hit_nx * dot_pv_n;
      double tvy = pvy - hit_ny * dot_pv_n;
      double tvz = pvz - hit_nz * dot_pv_n;
      double t_speed = sqrt(tvx * tvx + tvy * tvy + tvz * tvz);

      if (t_speed > 1e-4) {
        double fwd_lx, fwd_ly, fwd_lz;
        if (steer_angle != 0.0) {
          double sa_h = steer_angle * 0.5;
          double sr_w = cos(sa_h), sr_z = sin(sa_h);
          double rx = sr_w * sr_w - sr_z * sr_z;
          double ry = 2.0 * sr_w * sr_z;
          orientation.rotate_scalar(rx, ry, 0.0, fwd_lx, fwd_ly, fwd_lz);
        } else {
          orientation.rotate_scalar(1.0, 0.0, 0.0, fwd_lx, fwd_ly, fwd_lz);
        }

        double dot_fwd_n = fwd_lx * hit_nx + fwd_ly * hit_ny + fwd_lz * hit_nz;
        fwd_lx -= hit_nx * dot_fwd_n;
        fwd_ly -= hit_ny * dot_fwd_n;
        fwd_lz -= hit_nz * dot_fwd_n;

        double flen = sqrt(fwd_lx * fwd_lx + fwd_ly * fwd_ly + fwd_lz * fwd_lz);
        if (flen > 1e-9) {
          double inv_f = 1.0 / flen;
          fwd_lx *= inv_f;
          fwd_ly *= inv_f;
          fwd_lz *= inv_f;
        } else {
          fwd_lx = 0;
          fwd_ly = 0;
          fwd_lz = 0;
        }

        double right_x = hit_ny * fwd_lz - hit_nz * fwd_ly;
        double right_y = hit_nz * fwd_lx - hit_nx * fwd_lz;
        double right_z = hit_nx * fwd_ly - hit_ny * fwd_lx;
        double rlen =
            sqrt(right_x * right_x + right_y * right_y + right_z * right_z);
        if (rlen > 1e-9) {
          double inv_r = 1.0 / rlen;
          right_x *= inv_r;
          right_y *= inv_r;
          right_z *= inv_r;
        } else {
          right_x = 0;
          right_y = 0;
          right_z = 0;
        }

        double v_fwd = tvx * fwd_lx + tvy * fwd_ly + tvz * fwd_lz;
        double v_right = tvx * right_x + tvy * right_y + tvz * right_z;

        double fwd_damping = 50.0 + 5000.0 * brake_input;
        double fwd_force_mag = -v_fwd * fwd_damping;
        double max_fwd_friction = susp_f * (mu_roll + mu_brake * brake_input);

        if (fwd_force_mag > max_fwd_friction)
          fwd_force_mag = max_fwd_friction;
        if (fwd_force_mag < -max_fwd_friction)
          fwd_force_mag = -max_fwd_friction;

        double lat_damping = 10000.0;
        double lat_force_mag = -v_right * lat_damping;
        double max_lat_friction = susp_f * mu_side;

        if (lat_force_mag > max_lat_friction)
          lat_force_mag = max_lat_friction;
        if (lat_force_mag < -max_lat_friction)
          lat_force_mag = -max_lat_friction;

        fx += fwd_lx * fwd_force_mag + right_x * lat_force_mag;
        fy += fwd_ly * fwd_force_mag + right_y * lat_force_mag;
        fz += fwd_lz * fwd_force_mag + right_z * lat_force_mag;
      }
      df_x = fx;
      df_y = fy;
      df_z = fz;
      dt_x = woy * fz - woz * fy;
      dt_y = woz * fx - wox * fz;
      dt_z = wox * fy - woy * fx;
      return;
    }
    df_x = 0;
    df_y = 0;
    df_z = 0;
    dt_x = 0;
    dt_y = 0;
    dt_z = 0;
  }


  bool check_prism_collision(FloatingPrism @p) {
    double plane_to_prism_sq = (p.pos.x - pos.x) * (p.pos.x - pos.x) +
                               (p.pos.y - pos.y) * (p.pos.y - pos.y) +
                               (p.pos.z - pos.z) * (p.pos.z - pos.z);
    double max_reach = 120.0 + p.size * 2.0;
    if (plane_to_prism_sq > max_reach * max_reach)
      return false;

    double phi = 1.6180339887 * p.size;
    double one = 1.0 * p.size;
    double r_bound = phi + 5.0; // Max radius of prism

    bool any_in_range = false;

    for (int pt = 0; pt < 6; pt++) {
      double wox, woy, woz;
      orientation.rotate_scalar(cpc_pts_lx[pt], cpc_pts_ly[pt], cpc_pts_lz[pt],
                                wox, woy, woz);
      cpc_wpts_x[pt] = pos.x + wox;
      cpc_wpts_y[pt] = pos.y + woy;
      cpc_wpts_z[pt] = pos.z + woz;

      // Previous-frame world position of the same body point, using
      // prev_orientation so sweep segment reflects translation+rotation.
      double p_wox, p_woy, p_woz;
      prev_orientation.rotate_scalar(cpc_pts_lx[pt], cpc_pts_ly[pt],
                                     cpc_pts_lz[pt], p_wox, p_woy, p_woz);
      cpc_prev_wpts_x[pt] = prev_pos.x + p_wox;
      cpc_prev_wpts_y[pt] = prev_pos.y + p_woy;
      cpc_prev_wpts_z[pt] = prev_pos.z + p_woz;

      double r = cpc_pts_r[pt] + r_bound;

      // Segment-based broadphase: dist from prism center to swept
      // segment within (r+r_bound). Catches high-speed fly-throughs.
      double abx = cpc_wpts_x[pt] - cpc_prev_wpts_x[pt];
      double aby = cpc_wpts_y[pt] - cpc_prev_wpts_y[pt];
      double abz = cpc_wpts_z[pt] - cpc_prev_wpts_z[pt];
      double ab_sq = abx * abx + aby * aby + abz * abz;
      double t_proj = 0.0;
      if (ab_sq > 1e-9) {
        double apx = p.pos.x - cpc_prev_wpts_x[pt];
        double apy = p.pos.y - cpc_prev_wpts_y[pt];
        double apz = p.pos.z - cpc_prev_wpts_z[pt];
        t_proj = (apx * abx + apy * aby + apz * abz) / ab_sq;
        if (t_proj < 0.0) t_proj = 0.0;
        if (t_proj > 1.0) t_proj = 1.0;
      }
      double cx = cpc_prev_wpts_x[pt] + abx * t_proj;
      double cy = cpc_prev_wpts_y[pt] + aby * t_proj;
      double cz = cpc_prev_wpts_z[pt] + abz * t_proj;
      double sdx = p.pos.x - cx;
      double sdy = p.pos.y - cy;
      double sdz = p.pos.z - cz;

      if (sdx * sdx + sdy * sdy + sdz * sdz <= r * r) {
        cpc_in_range[pt] = true;
        any_in_range = true;
      } else {
        cpc_in_range[pt] = false;
      }
    }

    if (!any_in_range)
      return false;

    double ha = p.life * 0.75;
    double sha = sin(ha);
    q_rot_1.w = cos(ha);
    q_rot_1.x = sha * 0.3;
    q_rot_1.y = sha * 0.5;
    q_rot_1.z = sha * 0.8;
    q_rot_1.normalize();

    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    q_rot_1.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double o_rx = one * rx, o_ry = one * ry, o_rz = one * rz;
    double p_ux = phi * ux, p_uy = phi * uy, p_uz = phi * uz;

    double o_fx = one * fx, o_fy = one * fy, o_fz = one * fz;
    double p_rx = phi * rx, p_ry = phi * ry, p_rz = phi * rz;

    double p_fx = phi * fx, p_fy = phi * fy, p_fz = phi * fz;
    double o_ux = one * ux, o_uy = one * uy, o_uz = one * uz;

    array<Vec3> @v = @temp_prism_v;
    double px = 0, py = 0, pz = 0;

    v[0].set(px + o_rx + p_ux, py + o_ry + p_uy, pz + o_rz + p_uz);
    v[1].set(px - o_rx + p_ux, py - o_ry + p_uy, pz - o_rz + p_uz);
    v[2].set(px + o_rx - p_ux, py + o_ry - p_uy, pz + o_rz - p_uz);
    v[3].set(px - o_rx - p_ux, py - o_ry - p_uy, pz - o_rz - p_uz);

    v[4].set(px + o_fx + p_rx, py + o_fy + p_ry, pz + o_fz + p_rz);
    v[5].set(px - o_fx + p_rx, py - o_fy + p_ry, pz - o_fz + p_rz);
    v[6].set(px + o_fx - p_rx, py + o_fy - p_ry, pz + o_fz - p_rz);
    v[7].set(px - o_fx - p_rx, py - o_fy - p_ry, pz - o_fz - p_rz);

    v[8].set(px + p_fx + o_ux, py + p_fy + o_uy, pz + p_fz + o_uz);
    v[9].set(px - p_fx + o_ux, py - p_fy + o_uy, pz - p_fz + o_uz);
    v[10].set(px + p_fx - o_ux, py + p_fy - o_uy, pz + p_fz - o_uz);
    v[11].set(px - p_fx - o_ux, py - p_fy - o_uy, pz - p_fz - o_uz);

    for (int k = 0; k < 12; k++) {
      v[k].x += p.pos.x;
      v[k].y += p.pos.y;
      v[k].z += p.pos.z;
    }

    array<Triangle> @tris = @temp_prism_tris;
    tris[0].set(v[0].x, v[0].y, v[0].z, v[1].x, v[1].y, v[1].z, v[8].x, v[8].y,
                v[8].z);
    tris[1].set(v[0].x, v[0].y, v[0].z, v[8].x, v[8].y, v[8].z, v[4].x, v[4].y,
                v[4].z);
    tris[2].set(v[0].x, v[0].y, v[0].z, v[4].x, v[4].y, v[4].z, v[5].x, v[5].y,
                v[5].z);
    tris[3].set(v[0].x, v[0].y, v[0].z, v[5].x, v[5].y, v[5].z, v[9].x, v[9].y,
                v[9].z);
    tris[4].set(v[0].x, v[0].y, v[0].z, v[9].x, v[9].y, v[9].z, v[1].x, v[1].y,
                v[1].z);
    tris[5].set(v[3].x, v[3].y, v[3].z, v[11].x, v[11].y, v[11].z, v[7].x,
                v[7].y, v[7].z);
    tris[6].set(v[3].x, v[3].y, v[3].z, v[7].x, v[7].y, v[7].z, v[6].x, v[6].y,
                v[6].z);
    tris[7].set(v[3].x, v[3].y, v[3].z, v[6].x, v[6].y, v[6].z, v[10].x,
                v[10].y, v[10].z);
    tris[8].set(v[3].x, v[3].y, v[3].z, v[10].x, v[10].y, v[10].z, v[2].x,
                v[2].y, v[2].z);
    tris[9].set(v[3].x, v[3].y, v[3].z, v[2].x, v[2].y, v[2].z, v[11].x,
                v[11].y, v[11].z);
    tris[10].set(v[1].x, v[1].y, v[1].z, v[8].x, v[8].y, v[8].z, v[6].x, v[6].y,
                 v[6].z);
    tris[11].set(v[8].x, v[8].y, v[8].z, v[4].x, v[4].y, v[4].z, v[10].x,
                 v[10].y, v[10].z);
    tris[12].set(v[4].x, v[4].y, v[4].z, v[5].x, v[5].y, v[5].z, v[2].x, v[2].y,
                 v[2].z);
    tris[13].set(v[5].x, v[5].y, v[5].z, v[9].x, v[9].y, v[9].z, v[11].x,
                 v[11].y, v[11].z);
    tris[14].set(v[9].x, v[9].y, v[9].z, v[1].x, v[1].y, v[1].z, v[7].x, v[7].y,
                 v[7].z);
    tris[15].set(v[10].x, v[10].y, v[10].z, v[6].x, v[6].y, v[6].z, v[8].x,
                 v[8].y, v[8].z);
    tris[16].set(v[2].x, v[2].y, v[2].z, v[10].x, v[10].y, v[10].z, v[4].x,
                 v[4].y, v[4].z);
    tris[17].set(v[11].x, v[11].y, v[11].z, v[2].x, v[2].y, v[2].z, v[5].x,
                 v[5].y, v[5].z);
    tris[18].set(v[7].x, v[7].y, v[7].z, v[11].x, v[11].y, v[11].z, v[9].x,
                 v[9].y, v[9].z);
    tris[19].set(v[6].x, v[6].y, v[6].z, v[7].x, v[7].y, v[7].z, v[1].x, v[1].y,
                 v[1].z);

    for (int pt = 0; pt < 6; pt++) {
      if (!cpc_in_range[pt])
        continue;

      double wpx = cpc_wpts_x[pt];
      double wpy = cpc_wpts_y[pt];
      double wpz = cpc_wpts_z[pt];
      double r = cpc_pts_r[pt];

      bool inside_all = true;
      // Cheap plane-distance early-out: closest tri-surface point is
      // ≥ |plane_dist| away, so |plane_dist| >= r → no intersection.
      // inside_all still needs the SIGN, so update before skipping.
      for (int t = 0; t < 20; t++) {
        double plane_dist = wpx * tris[t].nx + wpy * tris[t].ny +
                            wpz * tris[t].nz + tris[t].plane_d;
        if (plane_dist > 0)
          inside_all = false;
        if (plane_dist >= r || plane_dist <= -r)
          continue;

        double cl_x, cl_y, cl_z;
        closest_point_on_triangle_dist(wpx, wpy, wpz, plane_dist, tris[t], cl_x,
                                       cl_y, cl_z);
        double dx = wpx - cl_x;
        double dy = wpy - cl_y;
        double dz = wpz - cl_z;
        if (dx * dx + dy * dy + dz * dz < r * r) {
          last_prism_hit_x = wpx;
          last_prism_hit_y = wpy;
          last_prism_hit_z = wpz;
          return true;
        }
      }
      if (inside_all) {
        last_prism_hit_x = wpx;
        last_prism_hit_y = wpy;
        last_prism_hit_z = wpz;
        return true;
      }

      // Swept-sphere-vs-convex-prism tunnel test for body points
      // outside at both endpoints but pierced between. Each face
      // n_i·P(t)+d_i<=r → linear clamp on t; non-empty over [0,1] = hit.
      double ppx = cpc_prev_wpts_x[pt];
      double ppy = cpc_prev_wpts_y[pt];
      double ppz = cpc_prev_wpts_z[pt];
      double sx = wpx - ppx;
      double sy = wpy - ppy;
      double sz = wpz - ppz;
      double t_min = 0.0, t_max = 1.0;
      bool separated = false;
      for (int t = 0; t < 20; t++) {
        double a = ppx * tris[t].nx + ppy * tris[t].ny + ppz * tris[t].nz +
                   tris[t].plane_d;
        double b = sx * tris[t].nx + sy * tris[t].ny + sz * tris[t].nz;
        if (b > 1e-12) {
          // n_i·P(t) grows with t — upper-bounds t.
          double tb = (r - a) / b;
          if (tb < t_max) t_max = tb;
        } else if (b < -1e-12) {
          // n_i·P(t) shrinks with t — lower-bounds t.
          double tb = (r - a) / b;
          if (tb > t_min) t_min = tb;
        } else {
          // Segment parallel to this face: constraint is constant in t.
          // If already separated by more than r, no t can fix it.
          if (a > r) {
            separated = true;
            break;
          }
        }
        if (t_min > t_max) {
          separated = true;
          break;
        }
      }
      if (!separated) {
        // Tunnel hit — record segment-entry world pos so smoke spawns
        // at actual entry, not post-pierce end-of-frame.
        double t_hit = t_min;
        if (t_hit < 0.0) t_hit = 0.0;
        if (t_hit > 1.0) t_hit = 1.0;
        last_prism_hit_x = ppx + sx * t_hit;
        last_prism_hit_y = ppy + sy * t_hit;
        last_prism_hit_z = ppz + sz * t_hit;
        return true;
      }
    }
    return false;
  }


  // Sphere-collision check for an Apple. Reuses the swept-segment
  // broadphase from check_prism_collision (apple hitbox IS the sphere,
  // no polyhedral fine-test). Tight ~80u radius set per-spawn.
  bool check_apple_collision(Apple @a) {
    if (a.collected) return false;

    // Cheap center-to-center reject. 120u = worst-case body-offset
    // (cpc_pts_lx max=60, r=20).
    double max_reach = 120.0 + double(a.size);
    double dxc = a.pos.x - pos.x;
    double dyc = a.pos.y - pos.y;
    double dzc = a.pos.z - pos.z;
    if (dxc * dxc + dyc * dyc + dzc * dzc > max_reach * max_reach)
      return false;

    double r_apple = double(a.size);

    for (int pt = 0; pt < 6; pt++) {
      // Current-frame world position of body point pt.
      double wox, woy, woz;
      orientation.rotate_scalar(cpc_pts_lx[pt], cpc_pts_ly[pt],
                                cpc_pts_lz[pt], wox, woy, woz);
      double wx = pos.x + wox;
      double wy = pos.y + woy;
      double wz = pos.z + woz;

      // Previous-frame world position via prev_orientation/prev_pos.
      double p_wox, p_woy, p_woz;
      prev_orientation.rotate_scalar(cpc_pts_lx[pt], cpc_pts_ly[pt],
                                     cpc_pts_lz[pt], p_wox, p_woy, p_woz);
      double pwx = prev_pos.x + p_wox;
      double pwy = prev_pos.y + p_woy;
      double pwz = prev_pos.z + p_woz;

      // Combined radius — body-point hit radius + apple sphere radius.
      double r = cpc_pts_r[pt] + r_apple;

      // Segment-vs-point distance: shortest distance from apple center
      // to the swept segment [prev -> curr] of this body point.
      double abx = wx - pwx;
      double aby = wy - pwy;
      double abz = wz - pwz;
      double ab_sq = abx * abx + aby * aby + abz * abz;
      double t_proj = 0.0;
      if (ab_sq > 1e-9) {
        double apx = a.pos.x - pwx;
        double apy = a.pos.y - pwy;
        double apz = a.pos.z - pwz;
        t_proj = (apx * abx + apy * aby + apz * abz) / ab_sq;
        if (t_proj < 0.0) t_proj = 0.0;
        if (t_proj > 1.0) t_proj = 1.0;
      }
      double cx = pwx + abx * t_proj;
      double cy = pwy + aby * t_proj;
      double cz = pwz + abz * t_proj;
      double sdx = a.pos.x - cx;
      double sdy = a.pos.y - cy;
      double sdz = a.pos.z - cz;
      if (sdx * sdx + sdy * sdy + sdz * sdz <= r * r) {
        return true;
      }
    }
    return false;
  }


  void update_camera() {
    // Locals consumed by catchup_gain shelf below:
    //   raw_diff_yaw  : shortest-path diff (pre-nudge, pre-cap).
    //   nudge_fired   : diametric-opposite damping fired (suppress catchup).
    //   target_use_pf : atan2 target meaningful (hl > 0.02).
    double raw_diff_yaw  = 0.0;
    bool   nudge_fired   = false;
    bool   target_use_pf = false;

    double pf_x, pf_y, pf_z;
    orientation.get_forward(pf_x, pf_y, pf_z);

    double horiz_len = sqrt(pf_x * pf_x + pf_y * pf_y);

    double target_yaw = camera_yaw;
    if (horiz_len > 0.02) {
      target_yaw = atan2(pf_y, pf_x);
      target_use_pf = true;
    }

    // (Fix #5) Singular-crossing rebase. On tu false→true recovery, if
    // |target_yaw - camera_yaw| (wrapped) exceeds π/2, treat as atan2
    // representation flip from pole transit (not real lag). Absorb delta
    // into camera_yaw with compensating subtraction on
    // camera_pole_yaw_offset so final_camera_yaw is visually identical
    // across the rebase. camera_yaw_rate intentionally NOT touched —
    // angular momentum stays continuous (bezier-motion rule). π/2 gate
    // filters real banked-turn lags (never approach π) from flips (≈π).
    if (!camera_prev_target_use_pf && target_use_pf) {
      double rebase = target_yaw - camera_yaw;
      while (rebase > PI) rebase -= 2.0 * PI;
      while (rebase < -PI) rebase += 2.0 * PI;
      if (rebase > 0.5 * PI || rebase < -0.5 * PI) {
        camera_yaw            += rebase;
        camera_pole_yaw_offset -= rebase;
      }
    }
    // (Fix #6) Continuous in-pole rebase. Inside sustained pole transit,
    // target_yaw rotates fast due to gimbal-lock magnification (small
    // pf_horizontal → large atan2 rate). yaw_weight suppression slows
    // chase enough in-zone, but lag accumulates and snaps closed at
    // pole exit (~1.6 rad/s "instant 180"). Fix: every frame in deep
    // pole zone, rebase camera_yaw to target_yaw with compensating
    // camera_pole_yaw_offset. On exit cy=ty already, no lag to chase.
    // gf>0.7 matches camera_gimbal_armed threshold so rebase fires
    // across the same band the catchup latch arms in.
    if (target_use_pf && camera_gimbal_factor > 0.7) {
      double rebase6 = target_yaw - camera_yaw;
      while (rebase6 > PI) rebase6 -= 2.0 * PI;
      while (rebase6 < -PI) rebase6 += 2.0 * PI;
      camera_yaw            += rebase6;
      camera_pole_yaw_offset -= rebase6;
    }
    // (Fix #7) Out-of-pole relaxation of camera_pole_yaw_offset. Without
    // this, in-pole rebases accumulate into the offset and persist
    // indefinitely as a permanent visual yaw offset.
    //
    // First normalize offset to (-π, π] so decay takes the shorter
    // angular path. Smoothstep gate gf=0.7→0.0 (decay disabled while
    // Fix #6 is active in pole; ramps to full rate as pole relaxes).
    // Decay rate 2.0 rad/sec; ±π clears in ~1.6s plus ramp-in.
    while (camera_pole_yaw_offset > PI)  camera_pole_yaw_offset -= 2.0 * PI;
    while (camera_pole_yaw_offset < -PI) camera_pole_yaw_offset += 2.0 * PI;
    double pole_gate = 0.0;
    if (camera_gimbal_factor < 0.7) {
      double t = (0.7 - camera_gimbal_factor) * (1.0 / 0.7);
      if (t > 1.0) t = 1.0;
      pole_gate = t * t * (3.0 - 2.0 * t);
    }
    double pole_decay_step = 2.0 * pole_gate * DT;
    if (camera_pole_yaw_offset > pole_decay_step) {
      camera_pole_yaw_offset -= pole_decay_step;
    } else if (camera_pole_yaw_offset < -pole_decay_step) {
      camera_pole_yaw_offset += pole_decay_step;
    } else {
      camera_pole_yaw_offset = 0.0;
    }
    camera_prev_target_use_pf = target_use_pf;

    double diff_yaw = target_yaw - camera_yaw;
    while (diff_yaw > PI)
      diff_yaw -= 2.0 * PI;
    while (diff_yaw < -PI)
      diff_yaw += 2.0 * PI;
    raw_diff_yaw = diff_yaw;

    // Consistent rotation direction at diametric opposite (prevents
    // L/R stutter on 180° flips). Damp by gimbal proximity so sustained
    // near-vertical flight doesn't accumulate spin from repeated nudges.
    if (diff_yaw > PI - 0.05 || diff_yaw < -PI + 0.05) {
      diff_yaw = (PI - 0.05) * (1.0 - camera_gimbal_factor);
      nudge_fired = true;
    }

    // Cap maximum angular rotation step to prevent high-speed whipping on
    // inversions
    double max_diff = 1.0;
    if (diff_yaw > max_diff)
      diff_yaw = max_diff;
    if (diff_yaw < -max_diff)
      diff_yaw = -max_diff;

    // Suppress relative-vertical gimbal discontinuities and
    // noise-amplified swivel during sustained near-vertical flight.
    double cu_x = -cos(camera_yaw) * sin(camera_pitch);
    double cu_y = -sin(camera_yaw) * sin(camera_pitch);
    double cu_z = cos(camera_pitch);
    double relative_verticality = pf_x * cu_x + pf_y * cu_y + pf_z * cu_z;

    // Asymmetric LPF on gimbal proximity: fast entry (~50ms), slow
    // exit (~280ms). Two indicators max()'d — (pf·camera_up)² (transit)
    // and pf_z² (sustained dive/climb keeps dead zone armed).
    double rel_vert_sq = relative_verticality * relative_verticality;
    double world_vert_sq = pf_z * pf_z;
    double gimbal_raw = (rel_vert_sq > world_vert_sq) ? rel_vert_sq
                                                      : world_vert_sq;
    double entry_step = 18.0 * DT;
    double exit_step = 3.5 * DT;
    if (entry_step > 1.0)
      entry_step = 1.0;
    if (exit_step > 1.0)
      exit_step = 1.0;
    if (gimbal_raw > camera_gimbal_factor) {
      camera_gimbal_factor += (gimbal_raw - camera_gimbal_factor) * entry_step;
    } else {
      camera_gimbal_factor += (gimbal_raw - camera_gimbal_factor) * exit_step;
    }

    // Smoothstep (cubic) dropoff — gentler than quartic at dead-zone edge.
    double a = 1.0 - camera_gimbal_factor;
    if (a < 0.0)
      a = 0.0;
    if (a > 1.0)
      a = 1.0;
    double alignment = a * a * (3.0 - 2.0 * a);

    // Floor alignment so camera always makes progress through the
    // singularity (avoids freeze+catchup two-motion pattern).
    const double ALIGN_FLOOR = 0.10;
    alignment = ALIGN_FLOOR + (1.0 - ALIGN_FLOOR) * alignment;

    // Blend horiz_len*alignment toward alignment-only as gimbal_factor
    // rises — keeps drive alive through the pole.
    double yaw_weight_normal = horiz_len * alignment;
    double yaw_weight_pole = alignment;
    double yaw_weight =
        yaw_weight_normal +
        (yaw_weight_pole - yaw_weight_normal) * camera_gimbal_factor;

    // ---- Catchup gain shelf ----
    // Shelf on |raw_dr| modulating catchup params after post-pole lag.
    // Motion stays rate-filter-driven (bezier-motion rule). Gated
    // armed && tu && !nudge. Shape: <0.3→0; 0.3..1.5 smoothstep↑1;
    // 1.5..2.5 plateau; 2.5..3.0 smoothstep↓0; >3.0→0 (nudge window).
    // At gain=1 effective_du picks up raw lag, yaw_weight loses
    // alignment suppression, MAX_YAW_RATE lifts +3. rate_filter UNTOUCHED.
    double abs_raw_dr = (raw_diff_yaw < 0) ? -raw_diff_yaw : raw_diff_yaw;
    // Level-triggered arming. Per-step magnitude is bounded by Fix #3
    // below; the cap, not the latch state, prevents spin. (Earlier
    // edge-triggered "Fix #2" reverted — disabled catchup during
    // sustained balance-at-pole flight.)
    if (camera_gimbal_factor > 0.7) {
      camera_gimbal_armed = true;
    }
    double catchup_gain = 0.0;
    if (camera_catchup_enabled && camera_gimbal_armed
        && target_use_pf && !nudge_fired
        && abs_raw_dr > 0.3 && abs_raw_dr < 3.0) {
      // Low edge: ramp 0→1 across [0.3, 1.5].
      double t_low = (abs_raw_dr - 0.3) / 1.2;
      if (t_low > 1.0) t_low = 1.0;
      if (t_low < 0.0) t_low = 0.0;
      double low_gain = t_low * t_low * (3.0 - 2.0 * t_low);
      // High edge: ramp 1→0 across [2.5, 3.0]. Tighter band so we
      // disengage cleanly before nudge re-engages.
      double t_high = (3.0 - abs_raw_dr) / 0.5;
      if (t_high > 1.0) t_high = 1.0;
      if (t_high < 0.0) t_high = 0.0;
      double high_gain = t_high * t_high * (3.0 - 2.0 * t_high);
      catchup_gain = low_gain * high_gain;
    }
    // Disarm when caught up + exited dead zone. Two-condition gate
    // keeps latch through brief re-entry if pole only briefly cleared.
    if (camera_gimbal_armed && abs_raw_dr < 0.2
        && camera_gimbal_factor < 0.2) {
      camera_gimbal_armed = false;
    }

    // Apply gain modulation: blend yaw_weight toward natural (no
    // dead-zone suppression) and effective_du toward raw lag.
    double yaw_weight_natural = horiz_len; // alignment removed (≈1.0)
    double yaw_weight_blended = yaw_weight
        + (yaw_weight_natural - yaw_weight) * catchup_gain;
    double effective_du = diff_yaw
        + (raw_diff_yaw - diff_yaw) * catchup_gain;
    // (Fix #3) Keep max_diff per-step cap even when catchup fires.
    // Without this, cg=1 → effective_du = raw_diff_yaw (±π), bypassing
    // the cap that prevents high-speed whipping on inversions. Catchup
    // still gets its boost via yb→horiz_len blend.
    if (effective_du > max_diff) effective_du = max_diff;
    if (effective_du < -max_diff) effective_du = -max_diff;

    // Snap-mode (camera_smoothing>=0.999) leaves these at zero defaults.
    double target_rate   = 0.0;
    double MAX_YAW_RATE  = 0.0;
    double rate_filter   = 0.0;
    if (camera_smoothing >= 0.999) {
      camera_yaw = target_yaw;
      camera_yaw_rate = 0.0;
    } else {
      // Desired angular velocity to track the plane.
      target_rate = effective_du * 4.0 * yaw_weight_blended;
      // (Fix #4) Cap target_rate magnitude during high catchup. Fix #3
      // bounds effective_du, but yb→horiz_len blend still allows
      // ~4 rad/s in horizontal flight — felt jarring. Cap at 1.5 rad/s
      // (~86°/sec peak) when cg>0.3 keeps catchup aggressive but
      // bounded. Normal banking (cg=0) unaffected.
      if (catchup_gain > 0.3) {
        const double CATCHUP_TR_CAP = 1.5;
        if (target_rate > CATCHUP_TR_CAP) target_rate = CATCHUP_TR_CAP;
        if (target_rate < -CATCHUP_TR_CAP) target_rate = -CATCHUP_TR_CAP;
      }

      // Filter angular VELOCITY (not position): smooths rate transitions
      // at dead-zone boundaries. Intentionally NOT modulated by
      // catchup_gain — constant filter pace is what makes ramps smooth.
      rate_filter = (5.0 + 5.0 * camera_gimbal_factor) * DT;
      if (rate_filter > 1.0)
        rate_filter = 1.0;
      camera_yaw_rate += (target_rate - camera_yaw_rate) * rate_filter;

      // Yaw rate ceiling. 3.0 baseline; raised inside gimbal window
      // (up to ~5.5) and during catchup (+3 additive).
      MAX_YAW_RATE = 3.0 + 2.5 * camera_gimbal_factor
                   + 3.0 * catchup_gain;
      if (camera_yaw_rate > MAX_YAW_RATE)
        camera_yaw_rate = MAX_YAW_RATE;
      if (camera_yaw_rate < -MAX_YAW_RATE)
        camera_yaw_rate = -MAX_YAW_RATE;

      camera_yaw += camera_yaw_rate * DT;
    }

    double best_z = -10000;
    for (int i = 0; i < active_physics_count; i++) {
      Triangle @tri = active_physics_triangles[i];
      if (tri.nz > 0.05) {
        double inv_nz = 1.0 / tri.nz;
        double hit_z = tri.p1z + (pos.x - tri.p1x) * (-tri.nx * inv_nz) +
                       (pos.y - tri.p1y) * (-tri.ny * inv_nz);
        if (hit_z < pos.z && hit_z > best_z)
          best_z = hit_z;
      }
    }

    bool is_steep =
        (vel.z > 50.0 || vel.z < -50.0 || pf_z > 0.1 || pf_z < -0.1);

    if (camera_smoothing >= 0.999) {
      camera_lock_timer = is_steep ? 1.0 : 0.0;
      camera_lock_blend = camera_lock_timer;
    } else {
      if (is_steep) {
        camera_lock_timer += DT * 0.5; // Requires 2 seconds to break lock
      } else {
        camera_lock_timer -= DT * 0.5; // Requires 2 seconds to engage lock
      }
      // OPTIMIZATION: Inlined math_clamp ternary (clamp 0..1)
      camera_lock_timer = (camera_lock_timer < 0.0) ? 0.0
                        : ((camera_lock_timer > 1.0) ? 1.0 : camera_lock_timer);

      // Smoothly apply the target blend so the camera eases into the pitch
      camera_lock_blend += (camera_lock_timer - camera_lock_blend) * 1.5 * DT;
    }

    double raw_target_pitch = atan2(pf_z, horiz_len);
    double target_pitch = raw_target_pitch * camera_lock_blend;

    if (camera_smoothing >= 0.999) {
      camera_pitch = target_pitch;
    } else {
      camera_pitch += (target_pitch - camera_pitch) * 3.0 * DT;
    }

    double final_camera_yaw = camera_yaw + mouse_yaw_offset
                            + camera_pole_yaw_offset;

    // OPTIMIZATION: Inlined math_clamp ternary
    double _fcp = camera_pitch + mouse_pitch_offset;
    double _fcp_max = PI / 2.1;
    double final_camera_pitch = (_fcp < -_fcp_max) ? -_fcp_max
                              : ((_fcp > _fcp_max) ? _fcp_max : _fcp);

    double hp = final_camera_pitch * 0.5;
    static_pitch_rot.w = cos(hp);
    static_pitch_rot.x = 0;
    static_pitch_rot.y = -sin(hp);
    static_pitch_rot.z = 0;

    double hy = final_camera_yaw * 0.5;
    static_yaw_rot.w = cos(hy);
    static_yaw_rot.x = 0;
    static_yaw_rot.y = 0;
    static_yaw_rot.z = sin(hy);

    double px, py, pz;
    static_pitch_rot.rotate_scalar(-camera_distance, 0, camera_height, px, py,
                                   pz);

    double tcx, tcy, tcz;
    static_yaw_rot.rotate_scalar(px, py, pz, tcx, tcy, tcz);

    // Orbital pivot = plane position + screenshot-composer offset.
    // pivot_offset_* zero = legacy "orbit around plane". Non-zero
    // shifts both camera target tcp_* and look-at target in lockstep,
    // so left-drag yaw/pitch orbit around the panned-to world point.
    double pivot_x = pos.x + pivot_offset_x;
    double pivot_y = pos.y + pivot_offset_y;
    double pivot_z = pos.z + pivot_offset_z;

    double tcp_x = pivot_x + tcx;
    double tcp_y = pivot_y + tcy;
    double tcp_z = pivot_z + tcz;

    camera_pos.x =
        camera_pos.x * (1.0 - camera_smoothing) + tcp_x * camera_smoothing;
    camera_pos.y =
        camera_pos.y * (1.0 - camera_smoothing) + tcp_y * camera_smoothing;
    camera_pos.z =
        camera_pos.z * (1.0 - camera_smoothing) + tcp_z * camera_smoothing;

    double fx = pivot_x - camera_pos.x, fy = pivot_y - camera_pos.y,
           fz = pivot_z - camera_pos.z;
    double flen = sqrt(fx * fx + fy * fy + fz * fz);
    if (flen > 1e-9) {
      double inv_flen = 1.0 / flen;
      fx *= inv_flen;
      fy *= inv_flen;
      fz *= inv_flen;
    }

    double lx = -fy, ly = fx, lz = 0;
    double llen = sqrt(lx * lx + ly * ly + lz * lz);

    // MUST use final_camera_yaw (= camera_yaw + mouse_yaw_offset
    // + camera_pole_yaw_offset), NOT raw camera_yaw. Fix #5/#6 absorb
    // pole-transit flips by jumping camera_yaw and compensating into
    // camera_pole_yaw_offset; using camera_yaw alone here makes the
    // look-at fallback "left" vector flip/roll across rebases (visible
    // as camera roll in the near-vertical pendulum-blend regime).
    double ideal_lx = -sin(final_camera_yaw);
    double ideal_ly = cos(final_camera_yaw);

    if (llen > 1e-9) {
      double inv_llen = 1.0 / llen;
      lx *= inv_llen;
      ly *= inv_llen;
      lz *= inv_llen;
    } else {
      lx = ideal_lx;
      ly = ideal_ly;
      lz = 0;
    }

    // (Fix #8) Snap look-at L to same hemisphere as PREVIOUS frame's L.
    // Using prev_L (not ideal_L) locks hemisphere from history so the
    // snap can't toggle once committed. First-frame init (0,1) matches
    // ideal_L for fcy=0. Camera may end rolled 180° in unusual
    // high-pitch poses but stays continuous.
    //
    // ATTEMPTED SOFT-SNAP (REVERTED): LPF'ing a snap_factor + rotation
    // around F by π × factor. Geometrically broken — intermediate
    // factor values produce sustained visible camera roll through the
    // LPF ramp. Binary flip is correct because Fix #8b pendulum blend
    // hides single-frame L discontinuities at small llen.
    // See feedback_camera_orientation_post_smoothing.md.
    bool _snap_fired = false;  // diagnostic: did Fix #8 negate L this frame?
    if (lx * camera_prev_lx + ly * camera_prev_ly < 0.0) {
      lx = -lx;
      ly = -ly;
      _snap_fired = true;
    }

    // Since F is normalized, llen represents the horizontal extent of the
    // Look-At vector (1.0 = level, 0.0 = vertical). Blend to the ideal left
    // vector as it approaches vertical to suppress the Look-At pendulum
    // singularity.
    if (llen < 0.25) {
      double blend = llen * 4.0;
      blend = blend * blend; // Smooth exponential curve

      // (Fix #8b) Blend toward camera_prev_l* (not ideal_l*). History-
      // based snap above guarantees L is in same hemisphere as prev_L,
      // so blend stays monotonic. Earlier ideal_l* version could pass
      // through zero when history committed to a snap inconsistent
      // with current fcy intent, causing arbitrary L flips.
      lx = lx * blend + camera_prev_lx * (1.0 - blend);
      ly = ly * blend + camera_prev_ly * (1.0 - blend);

      double re_len = sqrt(lx * lx + ly * ly);
      if (re_len > 1e-9) {
        double inv_relen = 1.0 / re_len;
        lx *= inv_relen;
        ly *= inv_relen;
      } else {
        // Degenerate even after history blend — fall back to ideal_L
        // (only used at game start before prev_L has populated, or in
        // truly pathological geometry).
        lx = ideal_lx;
        ly = ideal_ly;
      }
    }

    double ux = fy * lz - fz * ly, uy = fz * lx - fx * lz,
           uz = fx * ly - fy * lx;

    // Normalize U to ensure matrix scale is exactly 1.0 (prevents visual
    // zooming)
    double ulen = sqrt(ux * ux + uy * uy + uz * uz);
    if (ulen > 1e-9) {
      double inv_ulen = 1.0 / ulen;
      ux *= inv_ulen;
      uy *= inv_ulen;
      uz *= inv_ulen;
    }

    // Re-derive L from U and F to guarantee perfect orthogonality
    lx = uy * fz - uz * fy;
    ly = uz * fx - ux * fz;
    lz = ux * fy - uy * fx;

    // Save post-orthogonalization L (xy only — snap operates in xy
    // plane) for next frame's Fix #8 hemisphere reference. MUST be
    // AFTER orthog so Fix #9 accumulates correctly — see
    // feedback_camera_prev_l_rotation_placement.md.
    camera_prev_lx = lx;
    camera_prev_ly = ly;

    // (Fix #9 v7) Stuck-state detector + smooth roll recovery via
    // independent 3D drift vector camera_recovery_l*. v6's in-place
    // rotation of L/U/prev_L was wiped every frame by the prev_L save
    // (snap fires → L=wrong → save → wiped); v7 keeps drift in separate
    // state so it accumulates across frames.
    //
    // Architecture: enter on snap-streak > 30 + llen > 0.5; snapshot L
    // into recovery_l*; each frame rotate around F toward target_L
    // (natural post-recovery L); override matrix L with drift; sync
    // prev_L. Exit when |angle to target| < 0.05 rad.
    // Rate 1.5 rad/sec → π recovery in ~2.1s.
    if (_snap_fired) {
      camera_snap_streak++;
    } else {
      camera_snap_streak = 0;
    }

    if (!camera_in_recovery && camera_snap_streak > 30 && llen > 0.5) {
      // Enter recovery: snapshot current post-orthog L as drift starting point.
      camera_in_recovery = true;
      camera_recovery_lx = lx;
      camera_recovery_ly = ly;
      camera_recovery_lz = lz;
    }

    if (camera_in_recovery) {
      if (llen <= 0.4) {
        // Drifted into pendulum singularity — abort recovery, will
        // re-enter when geometry stabilizes.
        camera_in_recovery = false;
      } else {
        // (Fix #9 v7.1) Re-orthogonalize recovery vector against
        // current F. Recovery vector was perp to PREVIOUS frame's F;
        // plane has moved, so current F differs and recovery_l now has
        // small parallel-to-F component. Without stripping: simplified
        // Rodrigues below gets multiplied by cos θ each frame
        // (numerical decay), AND matrix [F|L|U] becomes non-orthogonal
        // → visible camera-detach artifact.
        double f_dot_r = fx * camera_recovery_lx
                       + fy * camera_recovery_ly
                       + fz * camera_recovery_lz;
        camera_recovery_lx -= fx * f_dot_r;
        camera_recovery_ly -= fy * f_dot_r;
        camera_recovery_lz -= fz * f_dot_r;
        double r_pre_len2 = camera_recovery_lx * camera_recovery_lx
                          + camera_recovery_ly * camera_recovery_ly
                          + camera_recovery_lz * camera_recovery_lz;
        if (r_pre_len2 < 1e-12) {
          // Recovery vector collinear with F — degenerate, abort.
          camera_in_recovery = false;
        } else {
          double inv_pre = 1.0 / sqrt(r_pre_len2);
          camera_recovery_lx *= inv_pre;
          camera_recovery_ly *= inv_pre;
          camera_recovery_lz *= inv_pre;

          // Target the NATURAL post-recovery L = (-fy, fx, 0)/|horiz|.
          // This is what replaces recovery_L on rec=1→0 handoff (L is
          // built from F directly), so aiming at it makes the handoff
          // continuous. Earlier ideal_L target diverged from natural_L
          // by atan2(fy,fx) - fcy in banked turns, causing ~38° camera
          // roll step at recovery exit. Fall back to projected ideal_L
          // only when F is nearly vertical (natural_L degenerate).
          double horiz_sq_t = fx * fx + fy * fy;
          double tlx, tly, tlz;
          if (horiz_sq_t > 1.0e-4) {
            double inv_horiz_t = 1.0 / sqrt(horiz_sq_t);
            tlx = -fy * inv_horiz_t;
            tly =  fx * inv_horiz_t;
            tlz = 0.0;
          } else {
            double f_dot_ideal = fx * ideal_lx + fy * ideal_ly;
            tlx = ideal_lx - fx * f_dot_ideal;
            tly = ideal_ly - fy * f_dot_ideal;
            tlz = -fz * f_dot_ideal;
          }
          double tlen2 = tlx * tlx + tly * tly + tlz * tlz;
          if (tlen2 > 1e-12) {
            double inv_tlen = 1.0 / sqrt(tlen2);
            tlx *= inv_tlen;
            tly *= inv_tlen;
            tlz *= inv_tlen;

            // Signed angle from (now-orthogonal) recovery_l* to
            // target_L around F.
            double rx = camera_recovery_lx;
            double ry = camera_recovery_ly;
            double rz = camera_recovery_lz;
            double cross_x = ry * tlz - rz * tly;
            double cross_y = rz * tlx - rx * tlz;
            double cross_z = rx * tly - ry * tlx;
            double sin_theta = cross_x * fx + cross_y * fy + cross_z * fz;
            double cos_theta = rx * tlx + ry * tly + rz * tlz;
            double theta = atan2(sin_theta, cos_theta);

            if ((theta < 0.05) && (theta > -0.05)) {
              // Recovery complete — snap to target and exit.
              camera_recovery_lx = tlx;
              camera_recovery_ly = tly;
              camera_recovery_lz = tlz;
              camera_in_recovery = false;
            } else {
              double max_step = 1.5 * DT;  // 1.5 rad/sec recovery rate
              double step;
              if (theta > max_step) step = max_step;
              else if (theta < -max_step) step = -max_step;
              else step = theta;

              // Rodrigues rotation around F. Now valid because we
              // re-orthogonalized R against F above.
              double cs = cos(step), sn = sin(step);
              double new_rx = rx * cs + (fy * rz - fz * ry) * sn;
              double new_ry = ry * cs + (fz * rx - fx * rz) * sn;
              double new_rz = rz * cs + (fx * ry - fy * rx) * sn;
              double rlen2 = new_rx * new_rx + new_ry * new_ry + new_rz * new_rz;
              if (rlen2 > 1e-12) {
                double inv_rlen = 1.0 / sqrt(rlen2);
                new_rx *= inv_rlen;
                new_ry *= inv_rlen;
                new_rz *= inv_rlen;
              }
              camera_recovery_lx = new_rx;
              camera_recovery_ly = new_ry;
              camera_recovery_lz = new_rz;
            }

            // Override matrix L with the drift vector so the camera
            // visibly rolls. Recompute U = F × L. Since L is now
            // guaranteed perpendicular to F, the matrix [F | L | U]
            // is orthonormal.
            lx = camera_recovery_lx;
            ly = camera_recovery_ly;
            lz = camera_recovery_lz;
            ux = fy * lz - fz * ly;
            uy = fz * lx - fx * lz;
            uz = fx * ly - fy * lx;
            double ulen2 = ux * ux + uy * uy + uz * uz;
            if (ulen2 > 1e-12) {
              double inv_ulen = 1.0 / sqrt(ulen2);
              ux *= inv_ulen;
              uy *= inv_ulen;
              uz *= inv_ulen;
            }

            // Sync camera_prev_l* to the drift so next frame's snap
            // check uses the rotated value.
            camera_prev_lx = lx;
            camera_prev_ly = ly;
          } else {
            // target_L degenerate (F nearly vertical) — abort recovery.
            camera_in_recovery = false;
          }
        }
      }
    }

    double m00 = fx, m01 = lx, m02 = ux, m10 = fy, m11 = ly, m12 = uy, m20 = fz,
           m21 = lz, m22 = uz;
    double mtr = m00 + m11 + m22;
    int _qbranch = 0;  // diagnostic: which matrix-to-quat branch fired
    if (mtr > 0) {
      double S = sqrt(mtr + 1.0) * 2;
      double inv_S = 1.0 / S;
      camera_orientation.w = 0.25 * S;
      camera_orientation.x = (m21 - m12) * inv_S;
      camera_orientation.y = (m02 - m20) * inv_S;
      camera_orientation.z = (m10 - m01) * inv_S;
      _qbranch = 1;
    } else if ((m00 > m11) && (m00 > m22)) {
      double S = sqrt(1.0 + m00 - m11 - m22) * 2;
      double inv_S = 1.0 / S;
      camera_orientation.w = (m21 - m12) * inv_S;
      camera_orientation.x = 0.25 * S;
      camera_orientation.y = (m10 + m01) * inv_S;
      camera_orientation.z = (m20 + m02) * inv_S;
      _qbranch = 2;
    } else if (m11 > m22) {
      double S = sqrt(1.0 + m11 - m00 - m22) * 2;
      double inv_S = 1.0 / S;
      camera_orientation.w = (m02 - m20) * inv_S;
      camera_orientation.x = (m10 + m01) * inv_S;
      camera_orientation.y = 0.25 * S;
      camera_orientation.z = (m21 + m12) * inv_S;
      _qbranch = 3;
    } else {
      double S = sqrt(1.0 + m22 - m00 - m11) * 2;
      double inv_S = 1.0 / S;
      camera_orientation.w = (m10 - m01) * inv_S;
      camera_orientation.x = (m20 + m02) * inv_S;
      camera_orientation.y = (m21 + m12) * inv_S;
      camera_orientation.z = 0.25 * S;
      _qbranch = 4;
    }

    // Normalize the final quaternion to mathematically eliminate any FOV
    // scaling/zooming
    camera_orientation.normalize();

    // ---- Screenshot pan: fold pending screen-delta into pivot + camera ----
    // R=-L screen-right, U screen-up. drag right shifts pivot +R,
    // drag down shifts -U. Pan scale depth-aware (camera_distance).
    // Update BOTH pivot_offset_* AND camera_pos by the same delta so
    // next frame's smoothing is a no-op on the pan (both at new loc).
    // See project_screenshot_pan_composer_2026_05_07.md.
    if ((screenshot_pan_dx_pending != 0.0)
     || (screenshot_pan_dy_pending != 0.0)) {
      double pan_scale = camera_distance * 0.0015;
      double sx = screenshot_pan_dx_pending * pan_scale;
      double sy = screenshot_pan_dy_pending * pan_scale;
      double dpx = -lx * sx - ux * sy;
      double dpy = -ly * sx - uy * sy;
      double dpz = -lz * sx - uz * sy;
      pivot_offset_x += dpx;
      pivot_offset_y += dpy;
      pivot_offset_z += dpz;
      camera_pos.x += dpx;
      camera_pos.y += dpy;
      camera_pos.z += dpz;
    }
  }


	
}