mixin class PlaneRenderLogic {

  void setup_colors() {
    if (character == "dustman") {
      col_primary = 0xFF9AB4E3;
      col_secondary = 0xFF6A84C0;
    } else if (character == "dustgirl") {
      col_primary = 0xFFA05755;
      col_secondary = 0xFF7F4544;
    } else if (character == "dustworth") {
      col_primary = 0xFFAAC27C;
      col_secondary = 0xFF839A53;
    } else if (character == "dustkid") {
      col_primary = 0xFFC49AE5;
      col_secondary = 0xFFA06AC2;
    } else {
      col_primary = 0xFFEECC00;
      col_secondary = 0xFFCCAA00;
    }
  }

  void correct_coords(float x, float y, float &out out_x, float &out out_y) {
    out_x = (x - cached_hud_offset) * cached_hud_scale;
    out_y = y * cached_hud_scale;
  }

  void draw_line_hud_corrected(uint layer, uint sub_layer, float x1, float y1,
                               float x2, float y2, float width, uint colour) {
    float cx1 = (x1 - cached_hud_offset) * cached_hud_scale;
    float cy1 = y1 * cached_hud_scale;
    float cx2 = (x2 - cached_hud_offset) * cached_hud_scale;
    float cy2 = y2 * cached_hud_scale;
    g.draw_line_hud(layer, sub_layer, cx1, cy1, cx2, cy2,
                    width * cached_hud_scale, colour);
  }

  void draw(float sub_frame) {
    render_frame_id++;

    float screen_w = g.hud_screen_width(false);
    float screen_h = g.hud_screen_height(false);
    float aspect = (screen_h > 0) ? (screen_w / screen_h) : (16.0 / 9.0);

    cached_screen_w = screen_w;
    cached_screen_h = screen_h;
    cached_hud_scale = screen_h / 900.0f;
    cached_hud_offset = (screen_w - 1600.0f * cached_hud_scale) * 0.5f;

    current_h_fov = (450.0 * aspect) * 0.00125 + 0.15;
    current_v_fov = 450.0 * 0.00125 + 0.15;
    current_h_bound_mult = sqrt(current_h_fov * current_h_fov + 1.0);
    current_v_bound_mult = sqrt(current_v_fov * current_v_fov + 1.0);

    lerp_in_place(prev_pos, pos, sub_frame, interp_pos);
    slerp_in_place(prev_orientation, orientation, sub_frame,
                   interp_orientation);
    lerp_in_place(prev_camera_pos, camera_pos, sub_frame, interp_camera_pos);
    slerp_in_place(prev_camera_orientation, camera_orientation, sub_frame,
                   interp_camera_orientation);

    double dr_ail_L =
        prev_aileron_L * (1.0 - sub_frame) + aileron_L * sub_frame;
    double dr_ail_R =
        prev_aileron_R * (1.0 - sub_frame) + aileron_R * sub_frame;
    double dr_elev = prev_elevator * (1.0 - sub_frame) + elevator * sub_frame;
    double dr_rud = prev_rudder * (1.0 - sub_frame) + rudder * sub_frame;
    double dr_flap =
        prev_flap_extension * (1.0 - sub_frame) + flap_extension * sub_frame;

    g.draw_quad_hud(0, 0, false, -1000, -1000, 1000, -1000, 1000, 1000, -1000,
                    1000, fog_bg_color, fog_bg_color, fog_bg_color,
                    fog_bg_color);

    active_faces = 0;
    interp_camera_orientation.get_basis(
        cam_fwd_vec.x, cam_fwd_vec.y, cam_fwd_vec.z, cam_left_vec.x,
        cam_left_vec.y, cam_left_vec.z, cam_up_vec.x, cam_up_vec.y,
        cam_up_vec.z);

    // Cache cam·basis dot products — reused by draw_world / submit_* paths.
    cam_dot_fwd = interp_camera_pos.x * cam_fwd_vec.x +
                  interp_camera_pos.y * cam_fwd_vec.y +
                  interp_camera_pos.z * cam_fwd_vec.z;
    cam_dot_left = interp_camera_pos.x * cam_left_vec.x +
                   interp_camera_pos.y * cam_left_vec.y +
                   interp_camera_pos.z * cam_left_vec.z;
    cam_dot_up = interp_camera_pos.x * cam_up_vec.x +
                 interp_camera_pos.y * cam_up_vec.y +
                 interp_camera_pos.z * cam_up_vec.z;

    // Unit quaternion inverse = transpose of basis matrix; relabel
    // get_basis columns into R^T (skips Quaternion::inverse()).
    double ofx, ofy, ofz, orx, ory, orz, oux, ouy, ouz;
    interp_orientation.get_basis(ofx, ofy, ofz, orx, ory, orz, oux, ouy, ouz);
    double i_fx = ofx, i_fy = orx, i_fz = oux;
    double i_rx = ofy, i_ry = ory, i_rz = ouy;
    double i_ux = ofz, i_uy = orz, i_uz = ouz;

    double diff_x = interp_camera_pos.x - interp_pos.x;
    double diff_y = interp_camera_pos.y - interp_pos.y;
    double diff_z = interp_camera_pos.z - interp_pos.z;

    plane_local_cam.x = diff_x * i_fx + diff_y * i_rx + diff_z * i_ux;
    plane_local_cam.y = diff_x * i_fy + diff_y * i_ry + diff_z * i_uy;
    plane_local_cam.z = diff_x * i_fz + diff_y * i_rz + diff_z * i_uz;

    plane_local_sun.x = sun_dir.x * i_fx + sun_dir.y * i_rx + sun_dir.z * i_ux;
    plane_local_sun.y = sun_dir.x * i_fy + sun_dir.y * i_ry + sun_dir.z * i_uy;
    plane_local_sun.z = sun_dir.x * i_fz + sun_dir.y * i_rz + sun_dir.z * i_uz;

    plane_local_F.x =
        cam_fwd_vec.x * i_fx + cam_fwd_vec.y * i_rx + cam_fwd_vec.z * i_ux;
    plane_local_F.y =
        cam_fwd_vec.x * i_fy + cam_fwd_vec.y * i_ry + cam_fwd_vec.z * i_uy;
    plane_local_F.z =
        cam_fwd_vec.x * i_fz + cam_fwd_vec.y * i_rz + cam_fwd_vec.z * i_uz;

    plane_local_L.x =
        cam_left_vec.x * i_fx + cam_left_vec.y * i_rx + cam_left_vec.z * i_ux;
    plane_local_L.y =
        cam_left_vec.x * i_fy + cam_left_vec.y * i_ry + cam_left_vec.z * i_uy;
    plane_local_L.z =
        cam_left_vec.x * i_fz + cam_left_vec.y * i_rz + cam_left_vec.z * i_uz;

    plane_local_U.x =
        cam_up_vec.x * i_fx + cam_up_vec.y * i_rx + cam_up_vec.z * i_ux;
    plane_local_U.y =
        cam_up_vec.x * i_fy + cam_up_vec.y * i_ry + cam_up_vec.z * i_uy;
    plane_local_U.z =
        cam_up_vec.x * i_fz + cam_up_vec.y * i_rz + cam_up_vec.z * i_uz;

    // plane_cam_off = -(diff projected onto cam basis).
    plane_cam_off_x = -(diff_x * cam_fwd_vec.x + diff_y * cam_fwd_vec.y +
                        diff_z * cam_fwd_vec.z);
    plane_cam_off_y = -(diff_x * cam_left_vec.x + diff_y * cam_left_vec.y +
                        diff_z * cam_left_vec.z);
    plane_cam_off_z = -(diff_x * cam_up_vec.x + diff_y * cam_up_vec.y +
                        diff_z * cam_up_vec.z);

    draw_world(interp_camera_pos, interp_camera_orientation);
    // Shadow runs after terrain, before plane. Z_BIAS ordering:
    // terrain<shadow<plane (small +z_bias above coplanar terrain).
    draw_plane_shadow();
    draw_plane(dr_ail_L, dr_ail_R, dr_elev, dr_rud, dr_flap);
    queue_wheel_trails(@wheel_trail_L, interp_camera_pos);
    queue_wheel_trails(@wheel_trail_R, interp_camera_pos);
    queue_wheel_trails(@wheel_trail_T, interp_camera_pos);
    queue_wheel_trails(@wingtip_trail_L, interp_camera_pos);
    queue_wheel_trails(@wingtip_trail_R, interp_camera_pos);
    render_projectiles(interp_camera_pos);
    render_particles(interp_camera_pos);
    render_smokes(interp_camera_pos);
    render_floating_prisms(interp_camera_pos);
    render_prism_fragments(interp_camera_pos);
    // Wind streamers (fx_level >= 3). Submit BEFORE radix flush so wind
    // quads sort with rest of world face queue. z_bias 200 sits under
    // shadow (290), above terrain (0).
    if (fx_level >= 3)
      render_wind_streams(interp_camera_pos);

    int faces_n = active_faces;
    if (faces_n > 0) {
      // PACK LAYOUT INVARIANT: rq_sort_packed[i] = (sort_key << 16) |
      // (face_idx | is_quad<<15). In-place sort safe (overwritten
      // next frame). DO NOT swap to AS sortAsc() — see
      // feedback_as_int64_sort_quirk.md / SORT_KEY_SCALE.
      radix_sort_faces(rq_sort_packed, sort_scratch_a, sort_scratch_b,
                       sort_counts, faces_n);
      for (int i = 0; i < faces_n; i++) {
        int64 pk = rq_sort_packed[i];
        int si = int(pk & 0x7FFF);
        // is_quad lives in bit 15 of the face-idx field.
        if ((pk & 0x8000) != 0) {
          draw_clipped_face(si);
        } else {
          draw_clipped_triangle(si);
        }
      }
    }

    render_fx(interp_camera_orientation, interp_camera_pos);
    float indicator_size = 50.0;
    float padding = 30.0;
    float native_right_x = 800.0;
    float native_bottom_y = 450.0;
    float att_cx = native_right_x - indicator_size - padding;
    float att_cy = native_bottom_y - indicator_size - padding;
    draw_attitude_indicator(interp_orientation, att_cx, att_cy, indicator_size);

    // Engine dial — watch face with stacked hands (red RPM, white
    // airspeed). Left of attitude indicator, baseline shared.
    float dial_size = 64.0;
    float dial_gap  = 50.0;
    float dial_cy   = att_cy;
    float dial_cx   = att_cx - indicator_size - dial_gap - dial_size;
    draw_engine_dial(dial_cx, dial_cy, dial_size);

    // Prism-destroyed counter (5x2 hex grid). Anchor = BOTTOM-RIGHT —
    // adding columns extends LEFTWARD so the bottom-right pip stays
    // nailed regardless of cell count.
    float prism_hud_anchor_x = att_cx + 57.0;
    float prism_hud_anchor_y = att_cy - indicator_size - 40.0;
    draw_prisms_destroyed_hud(prism_hud_anchor_x, prism_hud_anchor_y);

    // Controls-overlay HUD — fades in after idle, dismisses on first
    // input. No-op when alpha == 0 (early-returns inside). See
    // Plane_HUD.cpp.
    draw_controls_hud();
  }

  void draw_world(const Vec3 &in cam_pos,
                  const Quaternion &in cam_orientation) {
    double cpx = cam_pos.x, cpy = cam_pos.y, cpz = cam_pos.z;

    // Hoist basis + cam_dot_* (already computed in draw()) to locals.
    double cam_fwd_x = cam_fwd_vec.x, cam_fwd_y = cam_fwd_vec.y, cam_fwd_z = cam_fwd_vec.z;
    double cam_left_x = cam_left_vec.x, cam_left_y = cam_left_vec.y, cam_left_z = cam_left_vec.z;
    double cam_up_x = cam_up_vec.x, cam_up_y = cam_up_vec.y, cam_up_z = cam_up_vec.z;

    double cam_dot_f = cam_dot_fwd;
    double cam_dot_l = cam_dot_left;
    double cam_dot_u = cam_dot_up;

    double h_fov = current_h_fov;
    double v_fov = current_v_fov;
    double h_bound_mult = current_h_bound_mult;
    double v_bound_mult = current_v_bound_mult;

    // Hoist frame-invariant fog constants. fog_r/g/b MUST be int (not
    // uint) — (local_fog_* - cr) subtraction would wrap when tri.col_r
    // exceeds fog_r in uint arithmetic.
    int local_fog_r = fog_r, local_fog_g = fog_g, local_fog_b = fog_b;
    double local_fog_start_sq = fog_start_sq;
    double local_fog_end_sq = fog_end_sq;
    double local_inv_fog_sq_diff = inv_fog_sq_diff;

    double nx_l = h_fov * cam_fwd_x + cam_left_x,
           ny_l = h_fov * cam_fwd_y + cam_left_y,
           nz_l = h_fov * cam_fwd_z + cam_left_z;
    double nx_r = h_fov * cam_fwd_x - cam_left_x,
           ny_r = h_fov * cam_fwd_y - cam_left_y,
           nz_r = h_fov * cam_fwd_z - cam_left_z;
    double nx_b = v_fov * cam_fwd_x + cam_up_x,
           ny_b = v_fov * cam_fwd_y + cam_up_y,
           nz_b = v_fov * cam_fwd_z + cam_up_z;
    double nx_t = v_fov * cam_fwd_x - cam_up_x,
           ny_t = v_fov * cam_fwd_y - cam_up_y,
           nz_t = v_fov * cam_fwd_z - cam_up_z;

    // Inline abs() as a ternary — VM abs() is a function dispatch.
    double af_x = cam_fwd_x < 0 ? -cam_fwd_x : cam_fwd_x;
    double af_y = cam_fwd_y < 0 ? -cam_fwd_y : cam_fwd_y;
    double af_z = cam_fwd_z < 0 ? -cam_fwd_z : cam_fwd_z;
    double al_x = nx_l < 0 ? -nx_l : nx_l;
    double al_y = ny_l < 0 ? -ny_l : ny_l;
    double al_z = nz_l < 0 ? -nz_l : nz_l;
    double ar_x = nx_r < 0 ? -nx_r : nx_r;
    double ar_y = ny_r < 0 ? -ny_r : ny_r;
    double ar_z = nz_r < 0 ? -nz_r : nz_r;
    double ab_x = nx_b < 0 ? -nx_b : nx_b;
    double ab_y = ny_b < 0 ? -ny_b : ny_b;
    double ab_z = nz_b < 0 ? -nz_b : nz_b;
    double at_x = nx_t < 0 ? -nx_t : nx_t;
    double at_y = ny_t < 0 ? -ny_t : ny_t;
    double at_z = nz_t < 0 ? -nz_t : nz_t;

    // Iterate ready_chunks (generated + non-empty subset). See
    // project_codebase_audit_2026_05_05.md.
    array<Chunk @> @rdy_chunks = @chunk_manager.ready_chunks;
    uint num_chunks = rdy_chunks.length();
    for (uint c_idx = 0; c_idx < num_chunks; c_idx++) {
      Chunk @c = rdy_chunks[c_idx];

      // Hoist the chunk's AABB bounds — fields are read multiple times below.
      double cmin_x = c.min_x, cmax_x = c.max_x;
      double cmin_y = c.min_y, cmax_y = c.max_y;
      double cmin_z = c.min_z, cmax_z = c.max_z;
      double ccx_ = c.aabb_cx, ccy_ = c.aabb_cy, ccz_ = c.aabb_cz;

      double dx_aabb = 0.0;
      if (cpx < cmin_x) dx_aabb = cmin_x - cpx;
      else if (cpx > cmax_x) dx_aabb = cpx - cmax_x;
      double dy_aabb = 0.0;
      if (cpy < cmin_y) dy_aabb = cmin_y - cpy;
      else if (cpy > cmax_y) dy_aabb = cpy - cmax_y;
      double dz_aabb = 0.0;
      if (cpz < cmin_z) dz_aabb = cmin_z - cpz;
      else if (cpz > cmax_z) dz_aabb = cpz - cmax_z;

      // INVARIANT: >= so fog_t == 1.0 is caught here; downstream fog
      // else-branches assume fog_t strictly in (0, 1).
      double nd_sq = dx_aabb * dx_aabb + dy_aabb * dy_aabb + dz_aabb * dz_aabb;
      if (nd_sq >= local_fog_end_sq) {
        continue;
      }

      // Per-chunk fog: if farthest corner is inside fog_start, no tri
      // can be fogged — skip per-tri cull/blend.
      double fdx_far = cpx < ccx_ ? (cmax_x - cpx) : (cpx - cmin_x);
      double fdy_far = cpy < ccy_ ? (cmax_y - cpy) : (cpy - cmin_y);
      double fdz_far = cpz < ccz_ ? (cmax_z - cpz) : (cpz - cmin_z);
      double far_sq = fdx_far * fdx_far + fdy_far * fdy_far + fdz_far * fdz_far;
      bool chunk_no_fog = (far_sq <= local_fog_start_sq);

      // Sort-dist regime: 0=all far (cheap), 1=all near (expensive),
      // 2=straddle per-tri.
      int sort_regime = (nd_sq > 1000000.0) ? 0
                      : (far_sq <= 1000000.0) ? 1
                      : 2;

      double hx = c.aabb_hx, hy = c.aabb_hy, hz = c.aabb_hz;

      double tcx = ccx_ - cpx;
      double tcy = ccy_ - cpy;
      double tcz = ccz_ - cpz;

      // Fused frustum reject / fully-inside: compute (center,radius) per
      // plane once; reject on (c+r<0), clear fully_inside on (c-r<0).
      double cf = tcx * cam_fwd_x + tcy * cam_fwd_y + tcz * cam_fwd_z;
      double rf = hx  * af_x     + hy  * af_y     + hz  * af_z;
      if (cf + rf < 0.0) {
        continue;
      }
      bool fully_inside = (cf - rf >= 0.0);

      double cl_ = tcx * nx_l + tcy * ny_l + tcz * nz_l;
      double rl_ = hx  * al_x + hy  * al_y + hz  * al_z;
      if (cl_ + rl_ < 0.0) {
        continue;
      }
      if (fully_inside && cl_ - rl_ < 0.0) fully_inside = false;

      double cr_ = tcx * nx_r + tcy * ny_r + tcz * nz_r;
      double rr_ = hx  * ar_x + hy  * ar_y + hz  * ar_z;
      if (cr_ + rr_ < 0.0) {
        continue;
      }
      if (fully_inside && cr_ - rr_ < 0.0) fully_inside = false;

      double cb_ = tcx * nx_b + tcy * ny_b + tcz * nz_b;
      double rb_ = hx  * ab_x + hy  * ab_y + hz  * ab_z;
      if (cb_ + rb_ < 0.0) {
        continue;
      }
      if (fully_inside && cb_ - rb_ < 0.0) fully_inside = false;

      double ct_ = tcx * nx_t + tcy * ny_t + tcz * nz_t;
      double rt_ = hx  * at_x + hy  * at_y + hz  * at_z;
      if (ct_ + rt_ < 0.0) {
        continue;
      }
      if (fully_inside && ct_ - rt_ < 0.0) fully_inside = false;

      uint num_tris = uint(c.active_triangles);
      array<Triangle @> @chunk_tris = @c.triangles;

      // Loop unswitching: fully_inside vs intersect × chunk_no_fog vs mixed.
      if (fully_inside) {
        if (chunk_no_fog) {
          // FAST: no tri can be fogged — skip per-tri fog cull + blend.
          int local_af = active_faces;
          for (uint i = 0; i < num_tris; i++) {
            if (local_af >= MAX_FACES) { c_idx = num_chunks; break; }

            Triangle @tri = chunk_tris[i];

            double tri_cx = tri.c_x, tri_cy = tri.c_y, tri_cz = tri.c_z;
            double fdx = tri_cx - cpx, fdy = tri_cy - cpy, fdz = tri_cz - cpz;

            // Backface cull before dist_sq (no fog_end cull on this path).
            double tri_nx = tri.nx, tri_ny = tri.ny, tri_nz = tri.nz;
            if (fdx * tri_nx + fdy * tri_ny + fdz * tri_nz >= 0.0) continue;

            double p1x = tri.p1x, p1y = tri.p1y, p1z = tri.p1z;
            double p2x = tri.p2x, p2y = tri.p2y, p2z = tri.p2z;
            double p3x = tri.p3x, p3y = tri.p3y, p3z = tri.p3z;

            double tx1 = p1x * cam_fwd_x + p1y * cam_fwd_y + p1z * cam_fwd_z - cam_dot_f;
            double tx2 = p2x * cam_fwd_x + p2y * cam_fwd_y + p2z * cam_fwd_z - cam_dot_f;
            double tx3 = p3x * cam_fwd_x + p3y * cam_fwd_y + p3z * cam_fwd_z - cam_dot_f;

            double ty1 = p1x * cam_left_x + p1y * cam_left_y + p1z * cam_left_z - cam_dot_l;
            double ty2 = p2x * cam_left_x + p2y * cam_left_y + p2z * cam_left_z - cam_dot_l;
            double ty3 = p3x * cam_left_x + p3y * cam_left_y + p3z * cam_left_z - cam_dot_l;
            double tz1 = p1x * cam_up_x + p1y * cam_up_y + p1z * cam_up_z - cam_dot_u;
            double tz2 = p2x * cam_up_x + p2y * cam_up_y + p2z * cam_up_z - cam_dot_u;
            double tz3 = p3x * cam_up_x + p3y * cam_up_y + p3z * cam_up_z - cam_dot_u;

            uint final_colour = tri.color;

            // Regimes 0/1 skip dist_sq; cheap branch reuses tx's
            // ((tx1+tx2+tx3)/3 == centroid·fwd).
            double sort_dist;
            if (sort_regime == 0) {
              sort_dist = (tx1 + tx2 + tx3) * 0.3333333333333333;
            } else if (sort_regime == 1) {
              double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
              double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
              double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
              double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
              double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
              sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
            } else {
              // Mixed regime: per-tri compare.
              double dist_sq = fdx * fdx + fdy * fdy + fdz * fdz;
              if (dist_sq > 1000000.0) {
                sort_dist = (tx1 + tx2 + tx3) * 0.3333333333333333;
              } else {
                double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
                double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
                double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
                double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
              }
            }

            int wb = local_af << 4;
            rq_data[wb] = tx1;     rq_data[wb + 1] = ty1;   rq_data[wb + 2] = tz1;
            rq_data[wb + 3] = tx2;   rq_data[wb + 4] = ty2;   rq_data[wb + 5] = tz2;
            rq_data[wb + 6] = tx3;   rq_data[wb + 7] = ty3;   rq_data[wb + 8] = tz3;
            rq_colour[local_af] = final_colour;
            rq_sort_packed[local_af] = (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(local_af);
            local_af++;
          }
          active_faces = local_af;
        } else {
          // MIXED/FULL-FOG path. Pair-batched: leader stamps pair_p4*
          // + split_kind so 4 verts cover both tris (12 cam dots vs 18).
          // Per-tri: fog_end cull, backface, fog_t blend, color, sort.
          int local_af = active_faces;
          for (uint i = 0; i < num_tris; i += 2) {
            // +2 cap: a pair can emit up to 2 faces in one iteration.
            if (local_af + 2 > MAX_FACES) { c_idx = num_chunks; break; }

            Triangle @triA = chunk_tris[i];
            Triangle @triB = chunk_tris[i + 1];

            double fdAx = triA.c_x - cpx, fdAy = triA.c_y - cpy, fdAz = triA.c_z - cpz;
            double fdBx = triB.c_x - cpx, fdBy = triB.c_y - cpy, fdBz = triB.c_z - cpz;
            double dist_sq_A = fdAx * fdAx + fdAy * fdAy + fdAz * fdAz;
            double dist_sq_B = fdBx * fdBx + fdBy * fdBy + fdBz * fdBz;

            // dead = fog_end OR back-face culled; defer normal load
            // when fog already killed the tri.
            bool a_dead = (dist_sq_A >= local_fog_end_sq);
            bool b_dead = (dist_sq_B >= local_fog_end_sq);
            if (!a_dead) {
              double triA_nx = triA.nx, triA_ny = triA.ny, triA_nz = triA.nz;
              if (fdAx * triA_nx + fdAy * triA_ny + fdAz * triA_nz >= 0.0) a_dead = true;
            }
            if (!b_dead) {
              double triB_nx = triB.nx, triB_ny = triB.ny, triB_nz = triB.nz;
              if (fdBx * triB_nx + fdBy * triB_ny + fdBz * triB_nz >= 0.0) b_dead = true;
            }

            if (a_dead && b_dead) continue;

            // 4 unique verts: triA p1/p2/p3 + leader's pair_p4*.
            double p1x = triA.p1x, p1y = triA.p1y, p1z = triA.p1z;
            double p2x = triA.p2x, p2y = triA.p2y, p2z = triA.p2z;
            double p3x = triA.p3x, p3y = triA.p3y, p3z = triA.p3z;
            double p4x = triA.pair_p4x, p4y = triA.pair_p4y, p4z = triA.pair_p4z;

            double tx1 = p1x * cam_fwd_x + p1y * cam_fwd_y + p1z * cam_fwd_z - cam_dot_f;
            double tx2 = p2x * cam_fwd_x + p2y * cam_fwd_y + p2z * cam_fwd_z - cam_dot_f;
            double tx3 = p3x * cam_fwd_x + p3y * cam_fwd_y + p3z * cam_fwd_z - cam_dot_f;
            double tx4 = p4x * cam_fwd_x + p4y * cam_fwd_y + p4z * cam_fwd_z - cam_dot_f;

            double ty1 = p1x * cam_left_x + p1y * cam_left_y + p1z * cam_left_z - cam_dot_l;
            double ty2 = p2x * cam_left_x + p2y * cam_left_y + p2z * cam_left_z - cam_dot_l;
            double ty3 = p3x * cam_left_x + p3y * cam_left_y + p3z * cam_left_z - cam_dot_l;
            double ty4 = p4x * cam_left_x + p4y * cam_left_y + p4z * cam_left_z - cam_dot_l;

            double tz1 = p1x * cam_up_x + p1y * cam_up_y + p1z * cam_up_z - cam_dot_u;
            double tz2 = p2x * cam_up_x + p2y * cam_up_y + p2z * cam_up_z - cam_dot_u;
            double tz3 = p3x * cam_up_x + p3y * cam_up_y + p3z * cam_up_z - cam_dot_u;
            double tz4 = p4x * cam_up_x + p4y * cam_up_y + p4z * cam_up_z - cam_dot_u;

            int split_kind = triA.pair_split_kind;

            // --- render A (leader: always uses p1/p2/p3) ---
            if (!a_dead) {
              uint t_col_A = triA.color;
              double fog_t_A = (dist_sq_A - local_fog_start_sq) * local_inv_fog_sq_diff;
              uint final_colour_A;
              if (fog_t_A <= 0.0) {
                final_colour_A = t_col_A;
              } else {
                // INVARIANT: fog_t in (0, 1) — fog_end culled above.
                int cr = int(triA.col_r), cg = int(triA.col_g), cb = int(triA.col_b);
                int f_r = int(cr + (local_fog_r - cr) * fog_t_A);
                int f_g = int(cg + (local_fog_g - cg) * fog_t_A);
                int f_b = int(cb + (local_fog_b - cb) * fog_t_A);
                final_colour_A = (0xFF000000) | (uint(f_r) << 16) | (uint(f_g) << 8) | uint(f_b);
              }

              double sort_dist_A;
              if (sort_regime == 0) {
                sort_dist_A = (tx1 + tx2 + tx3) * 0.3333333333333333;
              } else if (sort_regime == 1) {
                double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
                double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
                double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
                double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                sort_dist_A = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
              } else {
                if (dist_sq_A > 1000000.0) {
                  sort_dist_A = (tx1 + tx2 + tx3) * 0.3333333333333333;
                } else {
                  double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
                  double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
                  double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
                  double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                  double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                  sort_dist_A = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
                }
              }

              int wbA = local_af << 4;
              rq_data[wbA]     = tx1;   rq_data[wbA + 1] = ty1;   rq_data[wbA + 2] = tz1;
              rq_data[wbA + 3] = tx2;   rq_data[wbA + 4] = ty2;   rq_data[wbA + 5] = tz2;
              rq_data[wbA + 6] = tx3;   rq_data[wbA + 7] = ty3;   rq_data[wbA + 8] = tz3;
              rq_colour[local_af] = final_colour_A;
              rq_sort_packed[local_af] = (int64(int(sort_dist_A * SORT_KEY_SCALE)) << 16) | int64(local_af);
              local_af++;
            }

            // --- render B (follower: picks 3 of {p1,p2,p3,p4} via split_kind) ---
            //   short (0): B = (v1, v3, v4) = (p1, p3, p4) -> reuse (tx1,tx3,tx4)
            //   long  (1): B = (v2, v3, v4) = (p2, p4, p3) -> reuse (tx2,tx4,tx3)
            if (!b_dead) {
              double btx1, bty1, btz1;
              double btx2, bty2, btz2;
              double btx3, bty3, btz3;
              if (split_kind == 0) {
                btx1 = tx1; bty1 = ty1; btz1 = tz1;
                btx2 = tx3; bty2 = ty3; btz2 = tz3;
                btx3 = tx4; bty3 = ty4; btz3 = tz4;
              } else {
                btx1 = tx2; bty1 = ty2; btz1 = tz2;
                btx2 = tx4; bty2 = ty4; btz2 = tz4;
                btx3 = tx3; bty3 = ty3; btz3 = tz3;
              }

              uint t_col_B = triB.color;
              double fog_t_B = (dist_sq_B - local_fog_start_sq) * local_inv_fog_sq_diff;
              uint final_colour_B;
              if (fog_t_B <= 0.0) {
                final_colour_B = t_col_B;
              } else {
                int cr = int(triB.col_r), cg = int(triB.col_g), cb = int(triB.col_b);
                int f_r = int(cr + (local_fog_r - cr) * fog_t_B);
                int f_g = int(cg + (local_fog_g - cg) * fog_t_B);
                int f_b = int(cb + (local_fog_b - cb) * fog_t_B);
                final_colour_B = (0xFF000000) | (uint(f_r) << 16) | (uint(f_g) << 8) | uint(f_b);
              }

              double sort_dist_B;
              if (sort_regime == 0) {
                sort_dist_B = (btx1 + btx2 + btx3) * 0.3333333333333333;
              } else if (sort_regime == 1) {
                double c_tx1 = btx1 < 0.1 ? 0.1 : btx1;
                double c_tx2 = btx2 < 0.1 ? 0.1 : btx2;
                double c_tx3 = btx3 < 0.1 ? 0.1 : btx3;
                double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                sort_dist_B = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
              } else {
                if (dist_sq_B > 1000000.0) {
                  sort_dist_B = (btx1 + btx2 + btx3) * 0.3333333333333333;
                } else {
                  double c_tx1 = btx1 < 0.1 ? 0.1 : btx1;
                  double c_tx2 = btx2 < 0.1 ? 0.1 : btx2;
                  double c_tx3 = btx3 < 0.1 ? 0.1 : btx3;
                  double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                  double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                  sort_dist_B = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
                }
              }

              int wbB = local_af << 4;
              rq_data[wbB]     = btx1;  rq_data[wbB + 1] = bty1;  rq_data[wbB + 2] = btz1;
              rq_data[wbB + 3] = btx2;  rq_data[wbB + 4] = bty2;  rq_data[wbB + 5] = btz2;
              rq_data[wbB + 6] = btx3;  rq_data[wbB + 7] = bty3;  rq_data[wbB + 8] = btz3;
              rq_colour[local_af] = final_colour_B;
              rq_sort_packed[local_af] = (int64(int(sort_dist_B * SORT_KEY_SCALE)) << 16) | int64(local_af);
              local_af++;
            }
          }
          active_faces = local_af;
        }
      } else {
        // Slow path: chunk intersects frustum boundaries.
        if (chunk_no_fog) {
          // FAST: no tri can be fogged — drop per-tri fog_end cull/blend.
          int local_af = active_faces;
          for (uint i = 0; i < num_tris; i++) {
            if (local_af >= MAX_FACES) { c_idx = num_chunks; break; }

            Triangle @tri = chunk_tris[i];
            double tri_cx = tri.c_x, tri_cy = tri.c_y, tri_cz = tri.c_z;
            double tri_nx = tri.nx, tri_ny = tri.ny, tri_nz = tri.nz;
            double fdx = tri_cx - cpx, fdy = tri_cy - cpy, fdz = tri_cz - cpz;

            // Defer dist_sq until after all culls.
            if (fdx * tri_nx + fdy * tri_ny + fdz * tri_nz >= 0.0) continue;

            double tx_c = fdx * cam_fwd_x + fdy * cam_fwd_y + fdz * cam_fwd_z;
            double tri_br = tri.bound_radius;
            if (tx_c + tri_br < 0.1) continue;

            // Two-sided bound folded into `ty > bound || ty < -bound` form.
            double ty_c = fdx * cam_left_x + fdy * cam_left_y + fdz * cam_left_z;
            double h_abs_bound = tx_c * h_fov + tri_br * h_bound_mult;
            if (ty_c > h_abs_bound || ty_c < -h_abs_bound) continue;

            double tz_c = fdx * cam_up_x + fdy * cam_up_y + fdz * cam_up_z;
            double v_abs_bound = tx_c * v_fov + tri_br * v_bound_mult;
            if (tz_c > v_abs_bound || tz_c < -v_abs_bound) continue;

            double p1x = tri.p1x, p1y = tri.p1y, p1z = tri.p1z;
            double p2x = tri.p2x, p2y = tri.p2y, p2z = tri.p2z;
            double p3x = tri.p3x, p3y = tri.p3y, p3z = tri.p3z;

            double tx1 = p1x * cam_fwd_x + p1y * cam_fwd_y + p1z * cam_fwd_z - cam_dot_f;
            double tx2 = p2x * cam_fwd_x + p2y * cam_fwd_y + p2z * cam_fwd_z - cam_dot_f;
            double tx3 = p3x * cam_fwd_x + p3y * cam_fwd_y + p3z * cam_fwd_z - cam_dot_f;
            if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1) continue;

            double ty1 = p1x * cam_left_x + p1y * cam_left_y + p1z * cam_left_z - cam_dot_l;
            double ty2 = p2x * cam_left_x + p2y * cam_left_y + p2z * cam_left_z - cam_dot_l;
            double ty3 = p3x * cam_left_x + p3y * cam_left_y + p3z * cam_left_z - cam_dot_l;

            double h_m1 = tx1 < 0.1 ? 100000.0 : tx1 * h_fov;
            double h_m2 = tx2 < 0.1 ? 100000.0 : tx2 * h_fov;
            double h_m3 = tx3 < 0.1 ? 100000.0 : tx3 * h_fov;
            if (ty1 > h_m1 && ty2 > h_m2 && ty3 > h_m3) continue;
            if (ty1 < -h_m1 && ty2 < -h_m2 && ty3 < -h_m3) continue;

            double tz1 = p1x * cam_up_x + p1y * cam_up_y + p1z * cam_up_z - cam_dot_u;
            double tz2 = p2x * cam_up_x + p2y * cam_up_y + p2z * cam_up_z - cam_dot_u;
            double tz3 = p3x * cam_up_x + p3y * cam_up_y + p3z * cam_up_z - cam_dot_u;

            double v_m1 = tx1 < 0.1 ? 100000.0 : tx1 * v_fov;
            double v_m2 = tx2 < 0.1 ? 100000.0 : tx2 * v_fov;
            double v_m3 = tx3 < 0.1 ? 100000.0 : tx3 * v_fov;
            if (tz1 > v_m1 && tz2 > v_m2 && tz3 > v_m3) continue;
            if (tz1 < -v_m1 && tz2 < -v_m2 && tz3 < -v_m3) continue;

            uint final_colour = tri.color;

            // tx_c == centroid·fwd, already computed for frustum cull.
            double sort_dist;
            if (sort_regime == 0) {
              sort_dist = tx_c;
            } else if (sort_regime == 1) {
              double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
              double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
              double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
              double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
              double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
              sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
            } else {
              double dist_sq = fdx * fdx + fdy * fdy + fdz * fdz;
              if (dist_sq > 1000000.0) {
                sort_dist = tx_c;
              } else {
                double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
                double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
                double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
                double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
              }
            }

            int wb = local_af << 4;
            rq_data[wb] = tx1;     rq_data[wb + 1] = ty1;   rq_data[wb + 2] = tz1;
            rq_data[wb + 3] = tx2;   rq_data[wb + 4] = ty2;   rq_data[wb + 5] = tz2;
            rq_data[wb + 6] = tx3;   rq_data[wb + 7] = ty3;   rq_data[wb + 8] = tz3;
            rq_colour[local_af] = final_colour;
            rq_sort_packed[local_af] = (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(local_af);
            local_af++;
          }
          active_faces = local_af;
        } else {
          // MIXED / FULL-FOG PATH: per-tri fog branching.
          int local_af = active_faces;
          for (uint i = 0; i < num_tris; i++) {
            if (local_af >= MAX_FACES) { c_idx = num_chunks; break; }

            Triangle @tri = chunk_tris[i];
            double tri_cx = tri.c_x, tri_cy = tri.c_y, tri_cz = tri.c_z;
            double tri_nx = tri.nx, tri_ny = tri.ny, tri_nz = tri.nz;
            double fdx = tri_cx - cpx, fdy = tri_cy - cpy, fdz = tri_cz - cpz;

            double dist_sq = fdx * fdx + fdy * fdy + fdz * fdz;
            // INVARIANT: >= so fog_t == 1.0 is caught here.
            if (dist_sq >= local_fog_end_sq) continue;
            if (fdx * tri_nx + fdy * tri_ny + fdz * tri_nz >= 0.0) continue;

            double tx_c = fdx * cam_fwd_x + fdy * cam_fwd_y + fdz * cam_fwd_z;
            double tri_br = tri.bound_radius;
            if (tx_c + tri_br < 0.1) continue;

            // Two-sided bound folded into `ty > bound || ty < -bound` form.
            double ty_c = fdx * cam_left_x + fdy * cam_left_y + fdz * cam_left_z;
            double h_abs_bound = tx_c * h_fov + tri_br * h_bound_mult;
            if (ty_c > h_abs_bound || ty_c < -h_abs_bound) continue;

            double tz_c = fdx * cam_up_x + fdy * cam_up_y + fdz * cam_up_z;
            double v_abs_bound = tx_c * v_fov + tri_br * v_bound_mult;
            if (tz_c > v_abs_bound || tz_c < -v_abs_bound) continue;

            double p1x = tri.p1x, p1y = tri.p1y, p1z = tri.p1z;
            double p2x = tri.p2x, p2y = tri.p2y, p2z = tri.p2z;
            double p3x = tri.p3x, p3y = tri.p3y, p3z = tri.p3z;

            double tx1 = p1x * cam_fwd_x + p1y * cam_fwd_y + p1z * cam_fwd_z - cam_dot_f;
            double tx2 = p2x * cam_fwd_x + p2y * cam_fwd_y + p2z * cam_fwd_z - cam_dot_f;
            double tx3 = p3x * cam_fwd_x + p3y * cam_fwd_y + p3z * cam_fwd_z - cam_dot_f;
            if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1) continue;

            double ty1 = p1x * cam_left_x + p1y * cam_left_y + p1z * cam_left_z - cam_dot_l;
            double ty2 = p2x * cam_left_x + p2y * cam_left_y + p2z * cam_left_z - cam_dot_l;
            double ty3 = p3x * cam_left_x + p3y * cam_left_y + p3z * cam_left_z - cam_dot_l;

            double h_m1 = tx1 < 0.1 ? 100000.0 : tx1 * h_fov;
            double h_m2 = tx2 < 0.1 ? 100000.0 : tx2 * h_fov;
            double h_m3 = tx3 < 0.1 ? 100000.0 : tx3 * h_fov;
            if (ty1 > h_m1 && ty2 > h_m2 && ty3 > h_m3) continue;
            if (ty1 < -h_m1 && ty2 < -h_m2 && ty3 < -h_m3) continue;

            double tz1 = p1x * cam_up_x + p1y * cam_up_y + p1z * cam_up_z - cam_dot_u;
            double tz2 = p2x * cam_up_x + p2y * cam_up_y + p2z * cam_up_z - cam_dot_u;
            double tz3 = p3x * cam_up_x + p3y * cam_up_y + p3z * cam_up_z - cam_dot_u;

            double v_m1 = tx1 < 0.1 ? 100000.0 : tx1 * v_fov;
            double v_m2 = tx2 < 0.1 ? 100000.0 : tx2 * v_fov;
            double v_m3 = tx3 < 0.1 ? 100000.0 : tx3 * v_fov;
            if (tz1 > v_m1 && tz2 > v_m2 && tz3 > v_m3) continue;
            if (tz1 < -v_m1 && tz2 < -v_m2 && tz3 < -v_m3) continue;

            uint t_col = tri.color;
            double fog_t = (dist_sq - local_fog_start_sq) * local_inv_fog_sq_diff;
            uint final_colour;
            if (fog_t <= 0.0) {
              final_colour = t_col;
            } else {
              // INVARIANT: fog_t in (0,1). int cast prevents uint
              // underflow when tri.col_r > fog_r.
              int cr = int(tri.col_r), cg = int(tri.col_g), cb = int(tri.col_b);
              int f_r = int(cr + (local_fog_r - cr) * fog_t);
              int f_g = int(cg + (local_fog_g - cg) * fog_t);
              int f_b = int(cb + (local_fog_b - cb) * fog_t);
              final_colour = (0xFF000000) | (uint(f_r) << 16) | (uint(f_g) << 8) | uint(f_b);
            }

            // dist_sq already computed for fog_t (reused in mixed regime).
            double sort_dist;
            if (sort_regime == 0) {
              sort_dist = tx_c;
            } else if (sort_regime == 1) {
              double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
              double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
              double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
              double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
              double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
              sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
            } else {
              if (dist_sq > 1000000.0) {
                sort_dist = tx_c;
              } else {
                double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
                double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
                double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
                double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
                double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
                sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
              }
            }

            int wb = local_af << 4;
            rq_data[wb] = tx1;     rq_data[wb + 1] = ty1;   rq_data[wb + 2] = tz1;
            rq_data[wb + 3] = tx2;   rq_data[wb + 4] = ty2;   rq_data[wb + 5] = tz2;
            rq_data[wb + 6] = tx3;   rq_data[wb + 7] = ty3;   rq_data[wb + 8] = tz3;
            rq_colour[local_af] = final_colour;
            rq_sort_packed[local_af] = (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(local_af);
            local_af++;
          }
          active_faces = local_af;
        }
      }

    }

    // ---- Phase 2: STL static-mesh render pass ----
    // Solo tris, stride 1. Per-instance world-AABB frustum/fog reject
    // before per-tri walk. Per-tri pipeline mirrors the chunk mixed-fog
    // stride-1 path. STL tris carry pair_leader=false but it's not read
    // on this path — solo emit is unconditional.
    {
      array<StlInstance @> @stl_list = @stl_instances;
      uint num_inst = stl_list.length();
      int local_af = active_faces;

      for (uint si = 0; si < num_inst; si++) {
        if (local_af >= MAX_FACES) break;

        StlInstance @inst = stl_list[si];
        if (inst is null || !inst.baked) continue;

        // Instance world-AABB pre-reject — fog distance + 5-plane frustum
        // (mirrors chunk block above).
        double imin_x = inst.world_min_x, imax_x = inst.world_max_x;
        double imin_y = inst.world_min_y, imax_y = inst.world_max_y;
        double imin_z = inst.world_min_z, imax_z = inst.world_max_z;

        double dx_aabb = 0.0;
        if (cpx < imin_x) dx_aabb = imin_x - cpx;
        else if (cpx > imax_x) dx_aabb = cpx - imax_x;
        double dy_aabb = 0.0;
        if (cpy < imin_y) dy_aabb = imin_y - cpy;
        else if (cpy > imax_y) dy_aabb = cpy - imax_y;
        double dz_aabb = 0.0;
        if (cpz < imin_z) dz_aabb = imin_z - cpz;
        else if (cpz > imax_z) dz_aabb = cpz - imax_z;
        double inst_nd_sq = dx_aabb * dx_aabb + dy_aabb * dy_aabb +
                            dz_aabb * dz_aabb;
        if (inst_nd_sq >= local_fog_end_sq) continue;

        double iccx = (imin_x + imax_x) * 0.5;
        double iccy = (imin_y + imax_y) * 0.5;
        double iccz = (imin_z + imax_z) * 0.5;
        double ihx = imax_x - iccx;
        double ihy = imax_y - iccy;
        double ihz = imax_z - iccz;
        double tcx_i = iccx - cpx;
        double tcy_i = iccy - cpy;
        double tcz_i = iccz - cpz;

        double cf_i = tcx_i * cam_fwd_x + tcy_i * cam_fwd_y + tcz_i * cam_fwd_z;
        double rf_i = ihx  * af_x     + ihy  * af_y     + ihz  * af_z;
        if (cf_i + rf_i < 0.0) continue;

        double cl_i = tcx_i * nx_l + tcy_i * ny_l + tcz_i * nz_l;
        double rl_i = ihx  * al_x + ihy  * al_y + ihz  * al_z;
        if (cl_i + rl_i < 0.0) continue;

        double cr_i = tcx_i * nx_r + tcy_i * ny_r + tcz_i * nz_r;
        double rr_i = ihx  * ar_x + ihy  * ar_y + ihz  * ar_z;
        if (cr_i + rr_i < 0.0) continue;

        double cb_i = tcx_i * nx_b + tcy_i * ny_b + tcz_i * nz_b;
        double rb_i = ihx  * ab_x + ihy  * ab_y + ihz  * ab_z;
        if (cb_i + rb_i < 0.0) continue;

        double ct_i = tcx_i * nx_t + tcy_i * ny_t + tcz_i * nz_t;
        double rt_i = ihx  * at_x + ihy  * at_y + ihz  * at_z;
        if (ct_i + rt_i < 0.0) continue;

        // Per-tri walk mirrors chunk mixed-fog stride-1.
        array<Triangle @> @stl_tris = @inst.world_tris;
        uint num_stl = uint(stl_tris.length());

        // Z-BIAS per-instance via inst.z_bias (default 315 — Dustman's
        // feet are coplanar with runway-top). Floating instances like
        // apples override to ~290. See project_plane_z_bias_drop_2026_05_02.
        double stl_z_bias = inst.z_bias;

        for (uint i = 0; i < num_stl; i++) {
          if (local_af >= MAX_FACES) break;

          Triangle @tri = stl_tris[i];
          double tri_cx = tri.c_x, tri_cy = tri.c_y, tri_cz = tri.c_z;
          double tri_nx = tri.nx, tri_ny = tri.ny, tri_nz = tri.nz;
          double fdx = tri_cx - cpx, fdy = tri_cy - cpy, fdz = tri_cz - cpz;

          double dist_sq = fdx * fdx + fdy * fdy + fdz * fdz;
          if (dist_sq >= local_fog_end_sq) continue;
          if (fdx * tri_nx + fdy * tri_ny + fdz * tri_nz >= 0.0) continue;

          double tx_c = fdx * cam_fwd_x + fdy * cam_fwd_y + fdz * cam_fwd_z;
          double tri_br = tri.bound_radius;
          if (tx_c + tri_br < 0.1) continue;

          double ty_c = fdx * cam_left_x + fdy * cam_left_y + fdz * cam_left_z;
          double h_abs_bound = tx_c * h_fov + tri_br * h_bound_mult;
          if (ty_c > h_abs_bound || ty_c < -h_abs_bound) continue;

          double tz_c = fdx * cam_up_x + fdy * cam_up_y + fdz * cam_up_z;
          double v_abs_bound = tx_c * v_fov + tri_br * v_bound_mult;
          if (tz_c > v_abs_bound || tz_c < -v_abs_bound) continue;

          double p1x = tri.p1x, p1y = tri.p1y, p1z = tri.p1z;
          double p2x = tri.p2x, p2y = tri.p2y, p2z = tri.p2z;
          double p3x = tri.p3x, p3y = tri.p3y, p3z = tri.p3z;

          double tx1 = p1x * cam_fwd_x + p1y * cam_fwd_y + p1z * cam_fwd_z - cam_dot_f;
          double tx2 = p2x * cam_fwd_x + p2y * cam_fwd_y + p2z * cam_fwd_z - cam_dot_f;
          double tx3 = p3x * cam_fwd_x + p3y * cam_fwd_y + p3z * cam_fwd_z - cam_dot_f;
          if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1) continue;

          double ty1 = p1x * cam_left_x + p1y * cam_left_y + p1z * cam_left_z - cam_dot_l;
          double ty2 = p2x * cam_left_x + p2y * cam_left_y + p2z * cam_left_z - cam_dot_l;
          double ty3 = p3x * cam_left_x + p3y * cam_left_y + p3z * cam_left_z - cam_dot_l;

          double h_m1 = tx1 < 0.1 ? 100000.0 : tx1 * h_fov;
          double h_m2 = tx2 < 0.1 ? 100000.0 : tx2 * h_fov;
          double h_m3 = tx3 < 0.1 ? 100000.0 : tx3 * h_fov;
          if (ty1 > h_m1 && ty2 > h_m2 && ty3 > h_m3) continue;
          if (ty1 < -h_m1 && ty2 < -h_m2 && ty3 < -h_m3) continue;

          double tz1 = p1x * cam_up_x + p1y * cam_up_y + p1z * cam_up_z - cam_dot_u;
          double tz2 = p2x * cam_up_x + p2y * cam_up_y + p2z * cam_up_z - cam_dot_u;
          double tz3 = p3x * cam_up_x + p3y * cam_up_y + p3z * cam_up_z - cam_dot_u;

          double v_m1 = tx1 < 0.1 ? 100000.0 : tx1 * v_fov;
          double v_m2 = tx2 < 0.1 ? 100000.0 : tx2 * v_fov;
          double v_m3 = tx3 < 0.1 ? 100000.0 : tx3 * v_fov;
          if (tz1 > v_m1 && tz2 > v_m2 && tz3 > v_m3) continue;
          if (tz1 < -v_m1 && tz2 < -v_m2 && tz3 < -v_m3) continue;

          // Fog blend preserves alpha byte from tri.color (STL tris carry
          // 0xAA pearly-glass alpha; chunk path forces 0xFF) so Dustman
          // stays translucent through fog instead of becoming silhouette.
          uint t_col = tri.color;
          double fog_t = (dist_sq - local_fog_start_sq) * local_inv_fog_sq_diff;
          uint final_colour;
          if (fog_t <= 0.0) {
            final_colour = t_col;
          } else {
            // INVARIANT: fog_t in (0,1) — fog_end culled above.
            int cr = int(tri.col_r), cg = int(tri.col_g), cb = int(tri.col_b);
            int f_r = int(cr + (local_fog_r - cr) * fog_t);
            int f_g = int(cg + (local_fog_g - cg) * fog_t);
            int f_b = int(cb + (local_fog_b - cb) * fog_t);
            final_colour = (t_col & 0xFF000000) | (uint(f_r) << 16) | (uint(f_g) << 8) | uint(f_b);
          }

          // Sort dist (mixed regime — STL can be near or far).
          double sort_dist;
          if (dist_sq > 1000000.0) {
            sort_dist = tx_c;
          } else {
            double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
            double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
            double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
            double max_tx = c_tx1 > c_tx2 ? (c_tx1 > c_tx3 ? c_tx1 : c_tx3) : (c_tx2 > c_tx3 ? c_tx2 : c_tx3);
            double min_tx = c_tx1 < c_tx2 ? (c_tx1 < c_tx3 ? c_tx1 : c_tx3) : (c_tx2 < c_tx3 ? c_tx2 : c_tx3);
            sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.16666666666666666 + min_tx * 0.3 + max_tx * 0.2;
          }

          int wb = local_af << 4;
          rq_data[wb]     = tx1; rq_data[wb + 1] = ty1; rq_data[wb + 2] = tz1;
          rq_data[wb + 3] = tx2; rq_data[wb + 4] = ty2; rq_data[wb + 5] = tz2;
          rq_data[wb + 6] = tx3; rq_data[wb + 7] = ty3; rq_data[wb + 8] = tz3;
          rq_colour[local_af] = final_colour;
          rq_sort_packed[local_af] =
              (int64(int((sort_dist - stl_z_bias) * SORT_KEY_SCALE)) << 16) | int64(local_af);
          local_af++;
        }
      }
      active_faces = local_af;
    }
  }

  void submit_world_box_rotated(double px, double py, double pz, double sx,
                                double sy, double sz, uint colour,
                                const Quaternion &in local_rot,
                                const Vec3 &in cam_pos, double z_bias) {
    double dx = sx * 0.5, dy = sy * 0.5, dz = sz * 0.5;
    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    local_rot.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double vx_x = dx * fx, vx_y = dx * fy, vx_z = dx * fz;
    double vy_x = dy * rx, vy_y = dy * ry, vy_z = dy * rz;
    double vz_x = dz * ux, vz_y = dz * uy, vz_z = dz * uz;

    box_p001.set(px - vx_x - vy_x + vz_x, py - vx_y - vy_y + vz_y,
                 pz - vx_z - vy_z + vz_z);
    box_p101.set(px + vx_x - vy_x + vz_x, py + vx_y - vy_y + vz_y,
                 pz + vx_z - vy_z + vz_z);
    box_p111.set(px + vx_x + vy_x + vz_x, py + vx_y + vy_y + vz_y,
                 pz + vx_z + vy_z + vz_z);
    box_p011.set(px - vx_x + vy_x + vz_x, py - vx_y + vy_y + vz_y,
                 pz - vx_z + vy_z + vz_z);
    box_p010.set(px - vx_x + vy_x - vz_x, py - vx_y + vy_y - vz_y,
                 pz - vx_z + vy_z - vz_z);
    box_p110.set(px + vx_x + vy_x - vz_x, py + vx_y + vy_y - vz_y,
                 pz + vx_z + vy_z - vz_z);
    box_p100.set(px + vx_x - vy_x - vz_x, py + vx_y - vy_y - vz_y,
                 pz + vx_z - vy_z - vz_z);
    box_p000.set(px - vx_x - vy_x - vz_x, py - vx_y - vy_y - vz_y,
                 pz - vx_z - vy_z - vz_z);

    // Pre-project the 8 shared corners once, then emit all 6 faces.
    submit_world_box_from_corners(colour, z_bias);
  }

  void submit_world_quad(const Vec3 &in p1, const Vec3 &in p2,
                         const Vec3 &in p3, const Vec3 &in p4, uint base_colour,
                         const Vec3 &in cam_pos, double z_bias) {
    if (active_faces >= MAX_FACES) return;

    // Hoist Vec3 components and camera basis into scalar locals.
    double p1x = p1.x, p1y = p1.y, p1z = p1.z;
    double p2x = p2.x, p2y = p2.y, p2z = p2.z;
    double p3x = p3.x, p3y = p3.y, p3z = p3.z;
    double p4x = p4.x, p4y = p4.y, p4z = p4.z;

    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;

    double tx1 = p1x * cfx + p1y * cfy + p1z * cfz - cam_dot_fwd;
    double tx2 = p2x * cfx + p2y * cfy + p2z * cfz - cam_dot_fwd;
    double tx3 = p3x * cfx + p3y * cfy + p3z * cfz - cam_dot_fwd;
    double tx4 = p4x * cfx + p4y * cfy + p4z * cfz - cam_dot_fwd;

    if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1 && tx4 < 0.1) return;

    double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
    double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
    double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
    double c_tx4 = tx4 < 0.1 ? 0.1 : tx4;
    double sort_dist = (c_tx1 + c_tx2 + c_tx3 + c_tx4) * 0.25 - z_bias;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = tx1;
    rq_data[b + 1]  = p1x * clx + p1y * cly + p1z * clz - cam_dot_left;
    rq_data[b + 2]  = p1x * cux + p1y * cuy + p1z * cuz - cam_dot_up;

    rq_data[b + 3]  = tx2;
    rq_data[b + 4]  = p2x * clx + p2y * cly + p2z * clz - cam_dot_left;
    rq_data[b + 5]  = p2x * cux + p2y * cuy + p2z * cuz - cam_dot_up;

    rq_data[b + 6]  = tx3;
    rq_data[b + 7]  = p3x * clx + p3y * cly + p3z * clz - cam_dot_left;
    rq_data[b + 8]  = p3x * cux + p3y * cuy + p3z * cuz - cam_dot_up;

    rq_data[b + 9]  = tx4;
    rq_data[b + 10] = p4x * clx + p4y * cly + p4z * clz - cam_dot_left;
    rq_data[b + 11] = p4x * cux + p4y * cuy + p4z * cuz - cam_dot_up;

    rq_colour[af] = base_colour;
    // PACK LAYOUT INVARIANT: 24-bit sort key in bits 16..39, face idx +
    // is_quad (bit 15) in bits 0..15. Safe ONLY because radix_sort_faces
    // (in math_core.cpp) bit-extracts the key directly. DO NOT swap to AS
    // built-in sortAsc() without relayering — see math_core.cpp's
    // SORT_KEY_SCALE comment for the AS int64-sort-low-32-only quirk
    // (also feedback_as_int64_sort_quirk.md). Same invariant applies to
    // every rq_sort_packed[] write in this file.
    rq_sort_packed[af] =
        (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(af | 0x8000);
    active_faces++;
  }



  void submit_quad(const Vec3 &in p1, const Vec3 &in p2, const Vec3 &in p3,
                   const Vec3 &in p4, uint base_colour) {
    if (active_faces >= MAX_FACES) return;

    // Hoist Vec3 components and plane-local basis/cam/sun/cam_off into scalar
    // locals (each was re-read 4x in the writeout).
    double p1x = p1.x, p1y = p1.y, p1z = p1.z;
    double p2x = p2.x, p2y = p2.y, p2z = p2.z;
    double p3x = p3.x, p3y = p3.y, p3z = p3.z;
    double p4x = p4.x, p4y = p4.y, p4z = p4.z;

    double pFx = plane_local_F.x, pFy = plane_local_F.y, pFz = plane_local_F.z;
    double pLx = plane_local_L.x, pLy = plane_local_L.y, pLz = plane_local_L.z;
    double pUx = plane_local_U.x, pUy = plane_local_U.y, pUz = plane_local_U.z;
    double ox = plane_cam_off_x, oy = plane_cam_off_y, oz = plane_cam_off_z;
    double pcx = plane_local_cam.x, pcy = plane_local_cam.y, pcz = plane_local_cam.z;
    double psx = plane_local_sun.x, psy = plane_local_sun.y, psz = plane_local_sun.z;

    double fc_x = (p1x + p2x + p3x + p4x) * 0.25;
    double fc_y = (p1y + p2y + p3y + p4y) * 0.25;
    double fc_z = (p1z + p2z + p3z + p4z) * 0.25;

    double cur_dir_x = fc_x - pcx;
    double cur_dir_y = fc_y - pcy;
    double cur_dir_z = fc_z - pcz;

    double dist_sq = cur_dir_x * cur_dir_x + cur_dir_y * cur_dir_y + cur_dir_z * cur_dir_z;
    double fog_t = (dist_sq - fog_start_sq) * inv_fog_sq_diff;
    if (fog_t >= 1.0) return;

    double v1x = p2x - p1x, v1y = p2y - p1y, v1z = p2z - p1z;
    double v2x = p3x - p1x, v2y = p3y - p1y, v2z = p3z - p1z;
    double nx = v1y * v2z - v1z * v2y, ny = v1z * v2x - v1x * v2z, nz = v1x * v2y - v1y * v2x;

    if (nx * cur_dir_x + ny * cur_dir_y + nz * cur_dir_z > 0) return;

    double nlen = sqrt(nx * nx + ny * ny + nz * nz);
    if (nlen > 1e-9) {
      double inv_nlen = 1.0 / nlen;
      nx *= inv_nlen; ny *= inv_nlen; nz *= inv_nlen;
    } else {
      nx = 0; ny = 0; nz = 0;
    }

    double light_intensity = nx * psx + ny * psy + nz * psz;
    if (light_intensity < 0.15) light_intensity = 0.15;

    // Fused multiply_color + lerp_color (fog_t >= 1 rejected by caller).
    // Lit channels truncated to uint BEFORE fog lerp; bit-identical
    // to multiply_color()->lerp_color() chain.
    uint lit_r_i = uint(double((base_colour >> 16) & 0xFF) * light_intensity);
    uint lit_g_i = uint(double((base_colour >>  8) & 0xFF) * light_intensity);
    uint lit_b_i = uint(double( base_colour        & 0xFF) * light_intensity);
    uint final_colour;
    if (fog_t <= 0.0) {
      final_colour = (base_colour & 0xFF000000) | (lit_r_i << 16) | (lit_g_i << 8) | lit_b_i;
    } else {
      int la = int((base_colour >> 24) & 0xFF);
      int lr = int(lit_r_i), lg = int(lit_g_i), lb = int(lit_b_i);
      int fa = int((fog_bg_color >> 24) & 0xFF);
      int fr = int((fog_bg_color >> 16) & 0xFF);
      int fg = int((fog_bg_color >>  8) & 0xFF);
      int fb = int( fog_bg_color        & 0xFF);
      final_colour = (uint(la + (fa - la) * fog_t) << 24)
                   | (uint(lr + (fr - lr) * fog_t) << 16)
                   | (uint(lg + (fg - lg) * fog_t) << 8)
                   |  uint(lb + (fb - lb) * fog_t);
    }

    double planar_depth = cur_dir_x * pFx + cur_dir_y * pFy + cur_dir_z * pFz;

    // Z-BIAS INVARIANT: terrain (0) < shadow (290) < plane (300). Radix
    // is ascending over inverted 24-bit field; z_bias SUBTRACTED from tx
    // so bigger bias draws on top. Plane > shadow (10u margin) keeps
    // shadow from overpainting plane bottom on landed-coplanar. See
    // Plane_Shadow.cpp Z_BIAS comment for corner-clip trade-off.
    double z_bias = 300.0;

    int af = active_faces;
    int b  = af << 4;

    rq_data[b]      = p1x * pFx + p1y * pFy + p1z * pFz + ox;
    rq_data[b + 1]  = p1x * pLx + p1y * pLy + p1z * pLz + oy;
    rq_data[b + 2]  = p1x * pUx + p1y * pUy + p1z * pUz + oz;
    rq_data[b + 3]  = p2x * pFx + p2y * pFy + p2z * pFz + ox;
    rq_data[b + 4]  = p2x * pLx + p2y * pLy + p2z * pLz + oy;
    rq_data[b + 5]  = p2x * pUx + p2y * pUy + p2z * pUz + oz;
    rq_data[b + 6]  = p3x * pFx + p3y * pFy + p3z * pFz + ox;
    rq_data[b + 7]  = p3x * pLx + p3y * pLy + p3z * pLz + oy;
    rq_data[b + 8]  = p3x * pUx + p3y * pUy + p3z * pUz + oz;
    rq_data[b + 9]  = p4x * pFx + p4y * pFy + p4z * pFz + ox;
    rq_data[b + 10] = p4x * pLx + p4y * pLy + p4z * pLz + oy;
    rq_data[b + 11] = p4x * pUx + p4y * pUy + p4z * pUz + oz;
    rq_colour[af] = final_colour;
    // is_quad bit 15 — see PACK LAYOUT INVARIANT in submit_world_quad.
    rq_sort_packed[af] = (int64(int((planar_depth - z_bias) * SORT_KEY_SCALE)) << 16) | int64(af | 0x8000);
    active_faces++;
  }


  // World quad with 4 corners pre-projected to cam-space (tx=fwd, ty=left,
  // tz=up). Same output as submit_world_quad minus the projection work.
  void emit_projected_world_quad(double tx1, double ty1, double tz1, double tx2,
                                 double ty2, double tz2, double tx3, double ty3,
                                 double tz3, double tx4, double ty4, double tz4,
                                 uint base_colour, double z_bias) {
    if (active_faces >= MAX_FACES)
      return;
    if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1 && tx4 < 0.1)
      return;

    double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
    double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
    double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
    double c_tx4 = tx4 < 0.1 ? 0.1 : tx4;
    double sort_dist = (c_tx1 + c_tx2 + c_tx3 + c_tx4) * 0.25 - z_bias;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = tx1;
    rq_data[b + 1]  = ty1;
    rq_data[b + 2]  = tz1;
    rq_data[b + 3]  = tx2;
    rq_data[b + 4]  = ty2;
    rq_data[b + 5]  = tz2;
    rq_data[b + 6]  = tx3;
    rq_data[b + 7]  = ty3;
    rq_data[b + 8]  = tz3;
    rq_data[b + 9]  = tx4;
    rq_data[b + 10] = ty4;
    rq_data[b + 11] = tz4;
    rq_colour[af] = base_colour;
    // is_quad bit 15 — see PACK LAYOUT INVARIANT in submit_world_quad.
    rq_sort_packed[af] =
        (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(af | 0x8000);
    active_faces++;
  }

  // 6 face-quads of a world-space box (corners in box_p000..p111). Each
  // of the 8 shared corners projected once (24 dots) instead of 72.
  void submit_world_box_from_corners(uint colour, double z_bias) {
    double fvx = cam_fwd_vec.x, fvy = cam_fwd_vec.y, fvz = cam_fwd_vec.z;
    double lvx = cam_left_vec.x, lvy = cam_left_vec.y, lvz = cam_left_vec.z;
    double uvx = cam_up_vec.x, uvy = cam_up_vec.y, uvz = cam_up_vec.z;
    double cdf = cam_dot_fwd, cdl = cam_dot_left, cdu = cam_dot_up;

    double tx000 = box_p000.x * fvx + box_p000.y * fvy + box_p000.z * fvz - cdf;
    double ty000 = box_p000.x * lvx + box_p000.y * lvy + box_p000.z * lvz - cdl;
    double tz000 = box_p000.x * uvx + box_p000.y * uvy + box_p000.z * uvz - cdu;

    double tx001 = box_p001.x * fvx + box_p001.y * fvy + box_p001.z * fvz - cdf;
    double ty001 = box_p001.x * lvx + box_p001.y * lvy + box_p001.z * lvz - cdl;
    double tz001 = box_p001.x * uvx + box_p001.y * uvy + box_p001.z * uvz - cdu;

    double tx010 = box_p010.x * fvx + box_p010.y * fvy + box_p010.z * fvz - cdf;
    double ty010 = box_p010.x * lvx + box_p010.y * lvy + box_p010.z * lvz - cdl;
    double tz010 = box_p010.x * uvx + box_p010.y * uvy + box_p010.z * uvz - cdu;

    double tx011 = box_p011.x * fvx + box_p011.y * fvy + box_p011.z * fvz - cdf;
    double ty011 = box_p011.x * lvx + box_p011.y * lvy + box_p011.z * lvz - cdl;
    double tz011 = box_p011.x * uvx + box_p011.y * uvy + box_p011.z * uvz - cdu;

    double tx100 = box_p100.x * fvx + box_p100.y * fvy + box_p100.z * fvz - cdf;
    double ty100 = box_p100.x * lvx + box_p100.y * lvy + box_p100.z * lvz - cdl;
    double tz100 = box_p100.x * uvx + box_p100.y * uvy + box_p100.z * uvz - cdu;

    double tx101 = box_p101.x * fvx + box_p101.y * fvy + box_p101.z * fvz - cdf;
    double ty101 = box_p101.x * lvx + box_p101.y * lvy + box_p101.z * lvz - cdl;
    double tz101 = box_p101.x * uvx + box_p101.y * uvy + box_p101.z * uvz - cdu;

    double tx110 = box_p110.x * fvx + box_p110.y * fvy + box_p110.z * fvz - cdf;
    double ty110 = box_p110.x * lvx + box_p110.y * lvy + box_p110.z * lvz - cdl;
    double tz110 = box_p110.x * uvx + box_p110.y * uvy + box_p110.z * uvz - cdu;

    double tx111 = box_p111.x * fvx + box_p111.y * fvy + box_p111.z * fvz - cdf;
    double ty111 = box_p111.x * lvx + box_p111.y * lvy + box_p111.z * lvz - cdl;
    double tz111 = box_p111.x * uvx + box_p111.y * uvy + box_p111.z * uvz - cdu;

    // Same 6-face winding as the original submit_world_quad calls.
    emit_projected_world_quad(tx001, ty001, tz001, tx101, ty101, tz101, tx111,
                              ty111, tz111, tx011, ty011, tz011, colour,
                              z_bias);
    emit_projected_world_quad(tx010, ty010, tz010, tx110, ty110, tz110, tx100,
                              ty100, tz100, tx000, ty000, tz000, colour,
                              z_bias);
    emit_projected_world_quad(tx110, ty110, tz110, tx010, ty010, tz010, tx011,
                              ty011, tz011, tx111, ty111, tz111, colour,
                              z_bias);
    emit_projected_world_quad(tx000, ty000, tz000, tx100, ty100, tz100, tx101,
                              ty101, tz101, tx001, ty001, tz001, colour,
                              z_bias);
    emit_projected_world_quad(tx100, ty100, tz100, tx110, ty110, tz110, tx111,
                              ty111, tz111, tx101, ty101, tz101, colour,
                              z_bias);
    emit_projected_world_quad(tx010, ty010, tz010, tx000, ty000, tz000, tx001,
                              ty001, tz001, tx011, ty011, tz011, colour,
                              z_bias);
  }



  void submit_world_triangle(const Vec3 &in p1, const Vec3 &in p2,
                             const Vec3 &in p3, uint base_colour,
                             const Vec3 &in cam_pos, double z_bias) {
    if (active_faces >= MAX_FACES)
      return;

    // Hoist cam basis + cam_dot + Vec3 components into scalar locals.
    double fwx = cam_fwd_vec.x,  fwy = cam_fwd_vec.y,  fwz = cam_fwd_vec.z;
    double lfx = cam_left_vec.x, lfy = cam_left_vec.y, lfz = cam_left_vec.z;
    double upx = cam_up_vec.x,   upy = cam_up_vec.y,   upz = cam_up_vec.z;
    double cdf = cam_dot_fwd, cdl = cam_dot_left, cdu = cam_dot_up;
    double p1x = p1.x, p1y = p1.y, p1z = p1.z;
    double p2x = p2.x, p2y = p2.y, p2z = p2.z;
    double p3x = p3.x, p3y = p3.y, p3z = p3.z;

    double tx1 = p1x * fwx + p1y * fwy + p1z * fwz - cdf;
    double tx2 = p2x * fwx + p2y * fwy + p2z * fwz - cdf;
    double tx3 = p3x * fwx + p3y * fwy + p3z * fwz - cdf;

    if (tx1 < 0.1 && tx2 < 0.1 && tx3 < 0.1)
      return;

    double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
    double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
    double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
    double sort_dist = (c_tx1 + c_tx2 + c_tx3) * 0.3333333333 - z_bias;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = tx1;
    rq_data[b + 1]  = p1x * lfx + p1y * lfy + p1z * lfz - cdl;
    rq_data[b + 2]  = p1x * upx + p1y * upy + p1z * upz - cdu;

    rq_data[b + 3]  = tx2;
    rq_data[b + 4]  = p2x * lfx + p2y * lfy + p2z * lfz - cdl;
    rq_data[b + 5]  = p2x * upx + p2y * upy + p2z * upz - cdu;

    rq_data[b + 6]  = tx3;
    rq_data[b + 7]  = p3x * lfx + p3y * lfy + p3z * lfz - cdl;
    rq_data[b + 8]  = p3x * upx + p3y * upy + p3z * upz - cdu;

    // Triangle — is_quad bit unset; slots 9..11 untouched (unread).
    rq_colour[af] = base_colour;
    rq_sort_packed[af] =
        (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(af);
    active_faces++;
  }


  void submit_double_quad(const Vec3 &in p1, const Vec3 &in p2,
                          const Vec3 &in p3, const Vec3 &in p4,
                          uint base_colour) {
    this.submit_quad(p1, p2, p3, p4, base_colour);
    this.submit_quad(p4, p3, p2, p1, base_colour);
  }

  // Scalar variant — used by submit_box_plane_local_from_corners to
  // skip 72 VM member dispatches.
  void emit_plane_local_quad_scalar(double p1x, double p1y, double p1z,
                                    double p2x, double p2y, double p2z,
                                    double p3x, double p3y, double p3z,
                                    double p4x, double p4y, double p4z,
                                    double tx1, double ty1, double tz1,
                                    double tx2, double ty2, double tz2,
                                    double tx3, double ty3, double tz3,
                                    double tx4, double ty4, double tz4,
                                    uint base_colour) {
    if (active_faces >= MAX_FACES)
      return;

    double pcx = plane_local_cam.x, pcy = plane_local_cam.y, pcz = plane_local_cam.z;
    double psx = plane_local_sun.x, psy = plane_local_sun.y, psz = plane_local_sun.z;
    double pFx = plane_local_F.x,   pFy = plane_local_F.y,   pFz = plane_local_F.z;

    double fc_x = (p1x + p2x + p3x + p4x) * 0.25;
    double fc_y = (p1y + p2y + p3y + p4y) * 0.25;
    double fc_z = (p1z + p2z + p3z + p4z) * 0.25;

    double cur_dir_x = fc_x - pcx;
    double cur_dir_y = fc_y - pcy;
    double cur_dir_z = fc_z - pcz;

    double dist_sq =
        cur_dir_x * cur_dir_x + cur_dir_y * cur_dir_y + cur_dir_z * cur_dir_z;
    double fog_t = (dist_sq - fog_start_sq) * inv_fog_sq_diff;
    if (fog_t >= 1.0)
      return;

    double v1x = p2x - p1x, v1y = p2y - p1y, v1z = p2z - p1z;
    double v2x = p3x - p1x, v2y = p3y - p1y, v2z = p3z - p1z;
    double nx = v1y * v2z - v1z * v2y, ny = v1z * v2x - v1x * v2z,
           nz = v1x * v2y - v1y * v2x;

    if (nx * cur_dir_x + ny * cur_dir_y + nz * cur_dir_z > 0)
      return;

    double nlen = sqrt(nx * nx + ny * ny + nz * nz);
    if (nlen > 1e-9) {
      double inv_nlen = 1.0 / nlen;
      nx *= inv_nlen;
      ny *= inv_nlen;
      nz *= inv_nlen;
    } else {
      nx = 0;
      ny = 0;
      nz = 0;
    }

    double light_intensity = nx * psx + ny * psy + nz * psz;
    if (light_intensity < 0.15)
      light_intensity = 0.15;

    // Fused multiply_color + lerp_color — see submit_quad for the
    // bit-identical-to-chain note.
    uint lit_r_i = uint(double((base_colour >> 16) & 0xFF) * light_intensity);
    uint lit_g_i = uint(double((base_colour >>  8) & 0xFF) * light_intensity);
    uint lit_b_i = uint(double( base_colour        & 0xFF) * light_intensity);
    uint final_colour;
    if (fog_t <= 0.0) {
      final_colour = (base_colour & 0xFF000000) | (lit_r_i << 16) | (lit_g_i << 8) | lit_b_i;
    } else {
      int la = int((base_colour >> 24) & 0xFF);
      int lr = int(lit_r_i), lg = int(lit_g_i), lb = int(lit_b_i);
      int fa = int((fog_bg_color >> 24) & 0xFF);
      int fr = int((fog_bg_color >> 16) & 0xFF);
      int fg = int((fog_bg_color >>  8) & 0xFF);
      int fb = int( fog_bg_color        & 0xFF);
      final_colour = (uint(la + (fa - la) * fog_t) << 24)
                   | (uint(lr + (fr - lr) * fog_t) << 16)
                   | (uint(lg + (fg - lg) * fog_t) << 8)
                   |  uint(lb + (fb - lb) * fog_t);
    }

    double planar_depth = cur_dir_x * pFx + cur_dir_y * pFy + cur_dir_z * pFz;
    // Z-BIAS INVARIANT: see submit_quad.
    double z_bias = 300.0;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = tx1;
    rq_data[b + 1]  = ty1;
    rq_data[b + 2]  = tz1;
    rq_data[b + 3]  = tx2;
    rq_data[b + 4]  = ty2;
    rq_data[b + 5]  = tz2;
    rq_data[b + 6]  = tx3;
    rq_data[b + 7]  = ty3;
    rq_data[b + 8]  = tz3;
    rq_data[b + 9]  = tx4;
    rq_data[b + 10] = ty4;
    rq_data[b + 11] = tz4;
    rq_colour[af] = final_colour;
    // is_quad bit 15 — see PACK LAYOUT INVARIANT in submit_world_quad.
    rq_sort_packed[af] =
        (int64(int((planar_depth - z_bias) * SORT_KEY_SCALE)) << 16) |
        int64(af | 0x8000);
    active_faces++;
  }

  // 6 face-quads of a plane-local box (corners in box_p000..p111). Each
  // of 8 shared corners projected once (24 dots) instead of 72; per-face
  // normal/fog/lighting still runs per face.
  void submit_box_plane_local_from_corners(uint colour) {
    double Fx = plane_local_F.x, Fy = plane_local_F.y, Fz = plane_local_F.z;
    double Lx = plane_local_L.x, Ly = plane_local_L.y, Lz = plane_local_L.z;
    double Ux = plane_local_U.x, Uy = plane_local_U.y, Uz = plane_local_U.z;
    double ox = plane_cam_off_x, oy = plane_cam_off_y, oz = plane_cam_off_z;

    // Hoist all 24 box corner scalars — each Vec3 field dispatched once.
    double c000x = box_p000.x, c000y = box_p000.y, c000z = box_p000.z;
    double c001x = box_p001.x, c001y = box_p001.y, c001z = box_p001.z;
    double c010x = box_p010.x, c010y = box_p010.y, c010z = box_p010.z;
    double c011x = box_p011.x, c011y = box_p011.y, c011z = box_p011.z;
    double c100x = box_p100.x, c100y = box_p100.y, c100z = box_p100.z;
    double c101x = box_p101.x, c101y = box_p101.y, c101z = box_p101.z;
    double c110x = box_p110.x, c110y = box_p110.y, c110z = box_p110.z;
    double c111x = box_p111.x, c111y = box_p111.y, c111z = box_p111.z;

    double tx000 = c000x * Fx + c000y * Fy + c000z * Fz + ox;
    double ty000 = c000x * Lx + c000y * Ly + c000z * Lz + oy;
    double tz000 = c000x * Ux + c000y * Uy + c000z * Uz + oz;

    double tx001 = c001x * Fx + c001y * Fy + c001z * Fz + ox;
    double ty001 = c001x * Lx + c001y * Ly + c001z * Lz + oy;
    double tz001 = c001x * Ux + c001y * Uy + c001z * Uz + oz;

    double tx010 = c010x * Fx + c010y * Fy + c010z * Fz + ox;
    double ty010 = c010x * Lx + c010y * Ly + c010z * Lz + oy;
    double tz010 = c010x * Ux + c010y * Uy + c010z * Uz + oz;

    double tx011 = c011x * Fx + c011y * Fy + c011z * Fz + ox;
    double ty011 = c011x * Lx + c011y * Ly + c011z * Lz + oy;
    double tz011 = c011x * Ux + c011y * Uy + c011z * Uz + oz;

    double tx100 = c100x * Fx + c100y * Fy + c100z * Fz + ox;
    double ty100 = c100x * Lx + c100y * Ly + c100z * Lz + oy;
    double tz100 = c100x * Ux + c100y * Uy + c100z * Uz + oz;

    double tx101 = c101x * Fx + c101y * Fy + c101z * Fz + ox;
    double ty101 = c101x * Lx + c101y * Ly + c101z * Lz + oy;
    double tz101 = c101x * Ux + c101y * Uy + c101z * Uz + oz;

    double tx110 = c110x * Fx + c110y * Fy + c110z * Fz + ox;
    double ty110 = c110x * Lx + c110y * Ly + c110z * Lz + oy;
    double tz110 = c110x * Ux + c110y * Uy + c110z * Uz + oz;

    double tx111 = c111x * Fx + c111y * Fy + c111z * Fz + ox;
    double ty111 = c111x * Lx + c111y * Ly + c111z * Lz + oy;
    double tz111 = c111x * Ux + c111y * Uy + c111z * Uz + oz;

    // Preserve the original 6-face winding — cross-product normal in
    // emit_plane_local_quad_scalar depends on the p1,p2,p3 ordering.
    emit_plane_local_quad_scalar(
        c001x, c001y, c001z, c101x, c101y, c101z, c111x, c111y, c111z, c011x,
        c011y, c011z, tx001, ty001, tz001, tx101, ty101, tz101, tx111, ty111,
        tz111, tx011, ty011, tz011, colour);
    emit_plane_local_quad_scalar(
        c010x, c010y, c010z, c110x, c110y, c110z, c100x, c100y, c100z, c000x,
        c000y, c000z, tx010, ty010, tz010, tx110, ty110, tz110, tx100, ty100,
        tz100, tx000, ty000, tz000, colour);
    emit_plane_local_quad_scalar(
        c110x, c110y, c110z, c010x, c010y, c010z, c011x, c011y, c011z, c111x,
        c111y, c111z, tx110, ty110, tz110, tx010, ty010, tz010, tx011, ty011,
        tz011, tx111, ty111, tz111, colour);
    emit_plane_local_quad_scalar(
        c000x, c000y, c000z, c100x, c100y, c100z, c101x, c101y, c101z, c001x,
        c001y, c001z, tx000, ty000, tz000, tx100, ty100, tz100, tx101, ty101,
        tz101, tx001, ty001, tz001, colour);
    emit_plane_local_quad_scalar(
        c100x, c100y, c100z, c110x, c110y, c110z, c111x, c111y, c111z, c101x,
        c101y, c101z, tx100, ty100, tz100, tx110, ty110, tz110, tx111, ty111,
        tz111, tx101, ty101, tz101, colour);
    emit_plane_local_quad_scalar(
        c010x, c010y, c010z, c000x, c000y, c000z, c001x, c001y, c001z, c011x,
        c011y, c011z, tx010, ty010, tz010, tx000, ty000, tz000, tx001, ty001,
        tz001, tx011, ty011, tz011, colour);
  }

  void submit_quad_custom_light_directed(const Vec3 &in p1, const Vec3 &in p2,
                                         const Vec3 &in p3, const Vec3 &in p4,
                                         uint base_colour,
                                         double light_intensity) {
    if (active_faces >= MAX_FACES) return;

    // Hoist Vec3 components and plane-local basis (each used 4x below).
    double p1x = p1.x, p1y = p1.y, p1z = p1.z;
    double p2x = p2.x, p2y = p2.y, p2z = p2.z;
    double p3x = p3.x, p3y = p3.y, p3z = p3.z;
    double p4x = p4.x, p4y = p4.y, p4z = p4.z;

    double pFx = plane_local_F.x, pFy = plane_local_F.y, pFz = plane_local_F.z;
    double pLx = plane_local_L.x, pLy = plane_local_L.y, pLz = plane_local_L.z;
    double pUx = plane_local_U.x, pUy = plane_local_U.y, pUz = plane_local_U.z;

    double fc_x = (p1x + p2x + p3x + p4x) * 0.25;
    double fc_y = (p1y + p2y + p3y + p4y) * 0.25;
    double fc_z = (p1z + p2z + p3z + p4z) * 0.25;
    double cur_dir_x = fc_x - plane_local_cam.x,
           cur_dir_y = fc_y - plane_local_cam.y,
           cur_dir_z = fc_z - plane_local_cam.z;

    double dist_sq =
        cur_dir_x * cur_dir_x + cur_dir_y * cur_dir_y + cur_dir_z * cur_dir_z;
    double fog_t = (dist_sq - fog_start_sq) * inv_fog_sq_diff;
    if (fog_t >= 1.0) return;

    double v1x = p2x - p1x, v1y = p2y - p1y, v1z = p2z - p1z;
    double v2x = p3x - p1x, v2y = p3y - p1y, v2z = p3z - p1z;
    double nx = v1y * v2z - v1z * v2y, ny = v1z * v2x - v1x * v2z,
           nz = v1x * v2y - v1y * v2x;
    if (nx * cur_dir_x + ny * cur_dir_y + nz * cur_dir_z > 0) return;

    if (light_intensity < 0.15) light_intensity = 0.15;

    // Fused multiply_color + lerp_color — see submit_quad.
    uint lit_r_i = uint(double((base_colour >> 16) & 0xFF) * light_intensity);
    uint lit_g_i = uint(double((base_colour >>  8) & 0xFF) * light_intensity);
    uint lit_b_i = uint(double( base_colour        & 0xFF) * light_intensity);
    uint final_colour;
    if (fog_t <= 0.0) {
      final_colour = (base_colour & 0xFF000000) | (lit_r_i << 16) | (lit_g_i << 8) | lit_b_i;
    } else {
      int la = int((base_colour >> 24) & 0xFF);
      int lr = int(lit_r_i), lg = int(lit_g_i), lb = int(lit_b_i);
      int fa = int((fog_bg_color >> 24) & 0xFF);
      int fr = int((fog_bg_color >> 16) & 0xFF);
      int fg = int((fog_bg_color >>  8) & 0xFF);
      int fb = int( fog_bg_color        & 0xFF);
      final_colour = (uint(la + (fa - la) * fog_t) << 24)
                   | (uint(lr + (fr - lr) * fog_t) << 16)
                   | (uint(lg + (fg - lg) * fog_t) << 8)
                   |  uint(lb + (fb - lb) * fog_t);
    }

    double planar_depth = cur_dir_x * pFx + cur_dir_y * pFy + cur_dir_z * pFz;
    // Z-BIAS INVARIANT: see submit_quad.
    double z_bias = 300.0;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = p1x * pFx + p1y * pFy + p1z * pFz + plane_cam_off_x;
    rq_data[b + 1]  = p1x * pLx + p1y * pLy + p1z * pLz + plane_cam_off_y;
    rq_data[b + 2]  = p1x * pUx + p1y * pUy + p1z * pUz + plane_cam_off_z;
    rq_data[b + 3]  = p2x * pFx + p2y * pFy + p2z * pFz + plane_cam_off_x;
    rq_data[b + 4]  = p2x * pLx + p2y * pLy + p2z * pLz + plane_cam_off_y;
    rq_data[b + 5]  = p2x * pUx + p2y * pUy + p2z * pUz + plane_cam_off_z;
    rq_data[b + 6]  = p3x * pFx + p3y * pFy + p3z * pFz + plane_cam_off_x;
    rq_data[b + 7]  = p3x * pLx + p3y * pLy + p3z * pLz + plane_cam_off_y;
    rq_data[b + 8]  = p3x * pUx + p3y * pUy + p3z * pUz + plane_cam_off_z;
    rq_data[b + 9]  = p4x * pFx + p4y * pFy + p4z * pFz + plane_cam_off_x;
    rq_data[b + 10] = p4x * pLx + p4y * pLy + p4z * pLz + plane_cam_off_y;
    rq_data[b + 11] = p4x * pUx + p4y * pUy + p4z * pUz + plane_cam_off_z;
    rq_colour[af] = final_colour;
    // is_quad bit 15 — see PACK LAYOUT INVARIANT in submit_world_quad.
    rq_sort_packed[af] =
        (int64(int((planar_depth - z_bias) * SORT_KEY_SCALE)) << 16) |
        int64(af | 0x8000);
    active_faces++;
  }

  void submit_wing_quad_custom_light(const Vec3 &in p1, const Vec3 &in p2,
                                     const Vec3 &in p3, const Vec3 &in p4,
                                     uint colour, double light_intensity,
                                     bool is_right_wing) {
    if (is_right_wing) {
      this.submit_quad_custom_light_directed(p1, p2, p3, p4, colour,
                                             light_intensity);
    } else {
      this.submit_quad_custom_light_directed(p4, p3, p2, p1, colour,
                                             light_intensity);
    }
  }

  void submit_box(double px, double py, double pz, double sx, double sy,
                  double sz, uint colour) {
    double dx = sx * 0.5, dy = sy * 0.5, dz = sz * 0.5;
    box_p001.set(px - dx, py - dy, pz + dz);
    box_p101.set(px + dx, py - dy, pz + dz);
    box_p111.set(px + dx, py + dy, pz + dz);
    box_p011.set(px - dx, py + dy, pz + dz);
    box_p010.set(px - dx, py + dy, pz - dz);
    box_p110.set(px + dx, py + dy, pz - dz);
    box_p100.set(px + dx, py - dy, pz - dz);
    box_p000.set(px - dx, py - dy, pz - dz);
    submit_box_plane_local_from_corners(colour);
  }

  void submit_box_rotated(double px, double py, double pz, double sx, double sy,
                          double sz, uint colour,
                          const Quaternion &in local_rot) {
    double dx = sx * 0.5, dy = sy * 0.5, dz = sz * 0.5;
    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    local_rot.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double vx_x = dx * fx, vx_y = dx * fy, vx_z = dx * fz;
    double vy_x = dy * rx, vy_y = dy * ry, vy_z = dy * rz;
    double vz_x = dz * ux, vz_y = dz * uy, vz_z = dz * uz;

    box_p001.set(px - vx_x - vy_x + vz_x, py - vx_y - vy_y + vz_y,
                 pz - vx_z - vy_z + vz_z);
    box_p101.set(px + vx_x - vy_x + vz_x, py + vx_y - vy_y + vz_y,
                 pz + vx_z - vy_z + vz_z);
    box_p111.set(px + vx_x + vy_x + vz_x, py + vx_y + vy_y + vz_y,
                 pz + vx_z + vy_z + vz_z);
    box_p011.set(px - vx_x + vy_x + vz_x, py - vx_y + vy_y + vz_y,
                 pz - vx_z + vy_z + vz_z);
    box_p010.set(px - vx_x + vy_x - vz_x, py - vx_y + vy_y - vz_y,
                 pz - vx_z + vy_z - vz_z);
    box_p110.set(px + vx_x + vy_x - vz_x, py + vx_y + vy_y - vz_y,
                 pz + vx_z + vy_z - vz_z);
    box_p100.set(px + vx_x - vy_x - vz_x, py + vx_y - vy_y - vz_y,
                 pz + vx_z - vy_z - vz_z);
    box_p000.set(px - vx_x - vy_x - vz_x, py - vx_y - vy_y - vz_y,
                 pz - vx_z - vy_z - vz_z);
    submit_box_plane_local_from_corners(colour);
  }

  void submit_hinged_box(double hx, double hy, double hz, double ox, double oy,
                         double oz, double sx, double sy, double sz,
                         uint colour, const Quaternion &in local_rot) {
    double dx = sx * 0.5, dy = sy * 0.5, dz = sz * 0.5;
    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    local_rot.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double cx = ox * fx + oy * rx + oz * ux;
    double cy = ox * fy + oy * ry + oz * uy;
    double cz = ox * fz + oy * rz + oz * uz;

    double vx_x = dx * fx, vx_y = dx * fy, vx_z = dx * fz;
    double vy_x = dy * rx, vy_y = dy * ry, vy_z = dy * rz;
    double vz_x = dz * ux, vz_y = dz * uy, vz_z = dz * uz;

    double cx_hx = cx + hx, cy_hy = cy + hy, cz_hz = cz + hz;

    box_p001.set(cx_hx - vx_x - vy_x + vz_x, cy_hy - vx_y - vy_y + vz_y,
                 cz_hz - vx_z - vy_z + vz_z);
    box_p101.set(cx_hx + vx_x - vy_x + vz_x, cy_hy + vx_y - vy_y + vz_y,
                 cz_hz + vx_z - vy_z + vz_z);
    box_p111.set(cx_hx + vx_x + vy_x + vz_x, cy_hy + vx_y + vy_y + vz_y,
                 cz_hz + vx_z + vy_z + vz_z);
    box_p011.set(cx_hx - vx_x + vy_x + vz_x, cy_hy - vx_y + vy_y + vz_y,
                 cz_hz - vx_z + vy_z + vz_z);
    box_p010.set(cx_hx - vx_x + vy_x - vz_x, cy_hy - vx_y + vy_y - vz_y,
                 cz_hz - vx_z + vy_z - vz_z);
    box_p110.set(cx_hx + vx_x + vy_x - vz_x, cy_hy + vx_y + vy_y - vz_y,
                 cz_hz + vx_z + vy_z - vz_z);
    box_p100.set(cx_hx + vx_x - vy_x - vz_x, cy_hy + vx_y - vy_y - vz_y,
                 cz_hz + vx_z - vy_z - vz_z);
    box_p000.set(cx_hx - vx_x - vy_x - vz_x, cy_hy - vx_y - vy_y - vz_y,
                 cz_hz - vx_z - vy_z - vz_z);
    submit_box_plane_local_from_corners(colour);
  }

  void submit_tapered_segment(double x_back, double x_front, double w_back,
                              double h_back, double z_offset_back,
                              double w_front, double h_front,
                              double z_offset_front, double y_offset,
                              uint colour) {
    box_p001.set(x_back, y_offset - w_back * 0.5, z_offset_back + h_back * 0.5);
    box_p101.set(x_front, y_offset - w_front * 0.5,
                 z_offset_front + h_front * 0.5);
    box_p111.set(x_front, y_offset + w_front * 0.5,
                 z_offset_front + h_front * 0.5);
    box_p011.set(x_back, y_offset + w_back * 0.5, z_offset_back + h_back * 0.5);
    box_p010.set(x_back, y_offset + w_back * 0.5, z_offset_back - h_back * 0.5);
    box_p110.set(x_front, y_offset + w_front * 0.5,
                 z_offset_front - h_front * 0.5);
    box_p100.set(x_front, y_offset - w_front * 0.5,
                 z_offset_front - h_front * 0.5);
    box_p000.set(x_back, y_offset - w_back * 0.5, z_offset_back - h_back * 0.5);

    // Irregular hexahedron — same 8-corner / 6-face topology as the box.
    submit_box_plane_local_from_corners(colour);
  }

  // No-top variant of submit_tapered_segment — emits 5 of 6 hexahedron
  // faces (omits the +z top). Used by fuselage cabin (seg-3 + seg-2a) so
  // roof has opening matching canopy footprint; canopy's own bottom seals
  // the opening, shoulder quads close the rest. Eliminates canopy-back/
  // fuselage-top coplanar conflict and canopy-front penetration.
  void submit_tapered_segment_no_top(double x_back, double x_front,
                                     double w_back, double h_back,
                                     double z_offset_back, double w_front,
                                     double h_front, double z_offset_front,
                                     double y_offset, uint colour) {
    double hw_b = w_back * 0.5, hh_b = h_back * 0.5;
    double hw_f = w_front * 0.5, hh_f = h_front * 0.5;
    double y_neg_b = y_offset - hw_b, y_pos_b = y_offset + hw_b;
    double y_neg_f = y_offset - hw_f, y_pos_f = y_offset + hw_f;
    double z_top_b = z_offset_back + hh_b, z_bot_b = z_offset_back - hh_b;
    double z_top_f = z_offset_front + hh_f, z_bot_f = z_offset_front - hh_f;

    double c000x = x_back,  c000y = y_neg_b, c000z = z_bot_b;
    double c001x = x_back,  c001y = y_neg_b, c001z = z_top_b;
    double c010x = x_back,  c010y = y_pos_b, c010z = z_bot_b;
    double c011x = x_back,  c011y = y_pos_b, c011z = z_top_b;
    double c100x = x_front, c100y = y_neg_f, c100z = z_bot_f;
    double c101x = x_front, c101y = y_neg_f, c101z = z_top_f;
    double c110x = x_front, c110y = y_pos_f, c110z = z_bot_f;
    double c111x = x_front, c111y = y_pos_f, c111z = z_top_f;

    double Fx = plane_local_F.x, Fy = plane_local_F.y, Fz = plane_local_F.z;
    double Lx = plane_local_L.x, Ly = plane_local_L.y, Lz = plane_local_L.z;
    double Ux = plane_local_U.x, Uy = plane_local_U.y, Uz = plane_local_U.z;
    double ox = plane_cam_off_x, oy = plane_cam_off_y, oz = plane_cam_off_z;

    double tx000 = c000x * Fx + c000y * Fy + c000z * Fz + ox;
    double ty000 = c000x * Lx + c000y * Ly + c000z * Lz + oy;
    double tz000 = c000x * Ux + c000y * Uy + c000z * Uz + oz;
    double tx001 = c001x * Fx + c001y * Fy + c001z * Fz + ox;
    double ty001 = c001x * Lx + c001y * Ly + c001z * Lz + oy;
    double tz001 = c001x * Ux + c001y * Uy + c001z * Uz + oz;
    double tx010 = c010x * Fx + c010y * Fy + c010z * Fz + ox;
    double ty010 = c010x * Lx + c010y * Ly + c010z * Lz + oy;
    double tz010 = c010x * Ux + c010y * Uy + c010z * Uz + oz;
    double tx011 = c011x * Fx + c011y * Fy + c011z * Fz + ox;
    double ty011 = c011x * Lx + c011y * Ly + c011z * Lz + oy;
    double tz011 = c011x * Ux + c011y * Uy + c011z * Uz + oz;
    double tx100 = c100x * Fx + c100y * Fy + c100z * Fz + ox;
    double ty100 = c100x * Lx + c100y * Ly + c100z * Lz + oy;
    double tz100 = c100x * Ux + c100y * Uy + c100z * Uz + oz;
    double tx101 = c101x * Fx + c101y * Fy + c101z * Fz + ox;
    double ty101 = c101x * Lx + c101y * Ly + c101z * Lz + oy;
    double tz101 = c101x * Ux + c101y * Uy + c101z * Uz + oz;
    double tx110 = c110x * Fx + c110y * Fy + c110z * Fz + ox;
    double ty110 = c110x * Lx + c110y * Ly + c110z * Lz + oy;
    double tz110 = c110x * Ux + c110y * Uy + c110z * Uz + oz;
    double tx111 = c111x * Fx + c111y * Fy + c111z * Fz + ox;
    double ty111 = c111x * Lx + c111y * Ly + c111z * Lz + oy;
    double tz111 = c111x * Ux + c111y * Uy + c111z * Uz + oz;

    // Faces 2-6: bottom (-z), right (+y), left (-y), front (+x), back (-x).
    // +z top face OMITTED — caller supplies shoulder/frame quads.
    emit_plane_local_quad_scalar(
        c010x, c010y, c010z, c110x, c110y, c110z, c100x, c100y, c100z, c000x,
        c000y, c000z, tx010, ty010, tz010, tx110, ty110, tz110, tx100, ty100,
        tz100, tx000, ty000, tz000, colour);
    emit_plane_local_quad_scalar(
        c110x, c110y, c110z, c010x, c010y, c010z, c011x, c011y, c011z, c111x,
        c111y, c111z, tx110, ty110, tz110, tx010, ty010, tz010, tx011, ty011,
        tz011, tx111, ty111, tz111, colour);
    emit_plane_local_quad_scalar(
        c000x, c000y, c000z, c100x, c100y, c100z, c101x, c101y, c101z, c001x,
        c001y, c001z, tx000, ty000, tz000, tx100, ty100, tz100, tx101, ty101,
        tz101, tx001, ty001, tz001, colour);
    emit_plane_local_quad_scalar(
        c100x, c100y, c100z, c110x, c110y, c110z, c111x, c111y, c111z, c101x,
        c101y, c101z, tx100, ty100, tz100, tx110, ty110, tz110, tx111, ty111,
        tz111, tx101, ty101, tz101, colour);
    emit_plane_local_quad_scalar(
        c010x, c010y, c010z, c000x, c000y, c000z, c001x, c001y, c001z, c011x,
        c011y, c011z, tx010, ty010, tz010, tx000, ty000, tz000, tx001, ty001,
        tz001, tx011, ty011, tz011, colour);
  }

  // Single plane-local quad with auto-computed lighting. Used for
  // fuselage roof shoulder/frame quads outside canopy footprint.
  void submit_plane_local_quad_scalar(double p1x, double p1y, double p1z,
                                      double p2x, double p2y, double p2z,
                                      double p3x, double p3y, double p3z,
                                      double p4x, double p4y, double p4z,
                                      uint colour) {
    double Fx = plane_local_F.x, Fy = plane_local_F.y, Fz = plane_local_F.z;
    double Lx = plane_local_L.x, Ly = plane_local_L.y, Lz = plane_local_L.z;
    double Ux = plane_local_U.x, Uy = plane_local_U.y, Uz = plane_local_U.z;
    double ox = plane_cam_off_x, oy = plane_cam_off_y, oz = plane_cam_off_z;
    double tx1 = p1x * Fx + p1y * Fy + p1z * Fz + ox;
    double ty1 = p1x * Lx + p1y * Ly + p1z * Lz + oy;
    double tz1 = p1x * Ux + p1y * Uy + p1z * Uz + oz;
    double tx2 = p2x * Fx + p2y * Fy + p2z * Fz + ox;
    double ty2 = p2x * Lx + p2y * Ly + p2z * Lz + oy;
    double tz2 = p2x * Ux + p2y * Uy + p2z * Uz + oz;
    double tx3 = p3x * Fx + p3y * Fy + p3z * Fz + ox;
    double ty3 = p3x * Lx + p3y * Ly + p3z * Lz + oy;
    double tz3 = p3x * Ux + p3y * Uy + p3z * Uz + oz;
    double tx4 = p4x * Fx + p4y * Fy + p4z * Fz + ox;
    double ty4 = p4x * Lx + p4y * Ly + p4z * Lz + oy;
    double tz4 = p4x * Ux + p4y * Uy + p4z * Uz + oz;
    emit_plane_local_quad_scalar(p1x, p1y, p1z, p2x, p2y, p2z, p3x, p3y, p3z,
                                 p4x, p4y, p4z, tx1, ty1, tz1, tx2, ty2, tz2,
                                 tx3, ty3, tz3, tx4, ty4, tz4, colour);
  }

  void draw_wing_half(double x_root, double x_tip, double y_start, double y_end,
                      double chord_start, double chord_end, double thick_start,
                      double thick_end, double control_angle, bool is_hinged) {
    uint color_top = col_primary, color_bot = col_secondary,
         color_te = multiply_color(col_secondary, 0.8);
    get_airfoil_profile(x_root, y_start, chord_start, thick_start,
                        @temp_airfoil_p1);
    get_airfoil_profile(x_tip, y_end, chord_end, thick_end, @temp_airfoil_p2);
    array<Vec3> @p1 = @temp_airfoil_p1;
    array<Vec3> @p2 = @temp_airfoil_p2;
    bool is_rw = (y_end > 0);

    // Hoist airfoil-profile array accesses into Vec3 handles — one
    // bounds-checked dispatch per index instead of scattered re-reads.
    Vec3 @v1_0 = p1[0];
    Vec3 @v1_2 = p1[2];
    Vec3 @v1_3 = p1[3];
    Vec3 @v1_4 = p1[4];
    Vec3 @v1_5 = p1[5];
    Vec3 @v1_6 = p1[6];
    Vec3 @v2_0 = p2[0];
    Vec3 @v2_2 = p2[2];
    Vec3 @v2_3 = p2[3];
    Vec3 @v2_4 = p2[4];
    Vec3 @v2_5 = p2[5];
    Vec3 @v2_6 = p2[6];

    // Hoist plane_local_sun once.
    double psx = plane_local_sun.x, psy = plane_local_sun.y,
           psz = plane_local_sun.z;

    double light_top = (psz > 0.15 ? psz : 0.15);
    double light_bot = (-psz > 0.15 ? -psz : 0.15);
    double light_te = (-psx > 0.15 ? -psx : 0.15);

    this.submit_wing_quad_custom_light(v1_0, v2_0, v2_2, v1_2, color_top,
                                       light_top, is_rw);
    this.submit_wing_quad_custom_light(v1_2, v2_2, v2_3, v1_3, color_top,
                                       light_top, is_rw);
    this.submit_wing_quad_custom_light(v1_0, v1_6, v2_6, v2_0, color_bot,
                                       light_bot, is_rw);
    this.submit_wing_quad_custom_light(v1_6, v1_5, v2_5, v2_6, color_bot,
                                       light_bot, is_rw);

    if (is_hinged) {
      double angle = -control_angle * 1.2;
      // Hoist Vec3 components — each dispatched once, not twice.
      double v1_3x = v1_3.x, v1_3y = v1_3.y, v1_3z = v1_3.z;
      double v1_6x = v1_6.x, v1_6y = v1_6.y, v1_6z = v1_6.z;
      double v2_3x = v2_3.x, v2_3y = v2_3.y, v2_3z = v2_3.z;
      double v2_6x = v2_6.x, v2_6y = v2_6.y, v2_6z = v2_6.z;
      double h1x = (v1_3x + v1_6x) * 0.5, h1y = (v1_3y + v1_6y) * 0.5,
             h1z = (v1_3z + v1_6z) * 0.5;
      double h2x = (v2_3x + v2_6x) * 0.5, h2y = (v2_3y + v2_6y) * 0.5,
             h2z = (v2_3z + v2_6z) * 0.5;

      box_p001.set(h2x - h1x, h2y - h1y, h2z - h1z);
      box_p001.normalize_in_place();
      box_p101.set(h1x, h1y, h1z);
      box_p111.set(h2x, h2y, h2z);

      // Cache sin/cos of half-angle (2 trig calls instead of 4).
      double half_angle = angle * 0.5;
      double c_ha = cos(half_angle), s_ha = sin(half_angle);
      q_rot_1.w = c_ha;
      q_rot_1.x = box_p001.x * s_ha;
      q_rot_1.y = box_p001.y * s_ha;
      q_rot_1.z = box_p001.z * s_ha;

      rotate_point_around_hinge(v1_3, box_p101, q_rot_1, temp_a1_3);
      rotate_point_around_hinge(v1_4, box_p101, q_rot_1, temp_a1_4);
      rotate_point_around_hinge(v1_5, box_p101, q_rot_1, temp_a1_5);
      rotate_point_around_hinge(v1_6, box_p101, q_rot_1, temp_a1_6);
      rotate_point_around_hinge(v2_3, box_p111, q_rot_1, temp_a2_3);
      rotate_point_around_hinge(v2_4, box_p111, q_rot_1, temp_a2_4);
      rotate_point_around_hinge(v2_5, box_p111, q_rot_1, temp_a2_5);
      rotate_point_around_hinge(v2_6, box_p111, q_rot_1, temp_a2_6);

      double ax, ay, az;
      q_rot_1.rotate_scalar(0, 0, 1, ax, ay, az);
      double lt = ax * psx + ay * psy + az * psz;
      double light_ail_top = (lt > 0.15 ? lt : 0.15);
      q_rot_1.rotate_scalar(0, 0, -1, ax, ay, az);
      double lb = ax * psx + ay * psy + az * psz;
      double light_ail_bot = (lb > 0.15 ? lb : 0.15);
      q_rot_1.rotate_scalar(-1, 0, 0, ax, ay, az);
      double lte = ax * psx + ay * psy + az * psz;
      double light_ail_te = (lte > 0.15 ? lte : 0.15);

      this.submit_wing_quad_custom_light(temp_a1_3, temp_a2_3, temp_a2_4,
                                         temp_a1_4, col_primary, light_ail_top,
                                         is_rw);
      this.submit_wing_quad_custom_light(temp_a1_6, temp_a1_5, temp_a2_5,
                                         temp_a2_6, col_secondary,
                                         light_ail_bot, is_rw);
      this.submit_wing_quad_custom_light(temp_a1_4, temp_a2_4, temp_a2_5,
                                         temp_a1_5, color_te, light_ail_te,
                                         is_rw);
      this.submit_wing_quad_custom_light(temp_a1_6, temp_a2_6, temp_a2_3,
                                         temp_a1_3, col_primary, light_ail_top,
                                         is_rw);
      this.submit_wing_quad_custom_light(v1_3, v2_3, v2_6, v1_6, color_te,
                                         light_te, is_rw);

      double e_ny = (y_end > 0) ? 1.0 : -1.0;
      double le_val = e_ny * psy;
      double le_ival = -e_ny * psy;
      double l_e = (le_val > 0.15 ? le_val : 0.15);
      double l_e_i = (le_ival > 0.15 ? le_ival : 0.15);
      this.submit_wing_quad_custom_light(temp_a1_6, temp_a1_3, temp_a1_4,
                                         temp_a1_5, col_primary, l_e_i, is_rw);
      this.submit_wing_quad_custom_light(temp_a2_6, temp_a2_5, temp_a2_4,
                                         temp_a2_3, col_primary, l_e, is_rw);
    } else {
      this.submit_wing_quad_custom_light(v1_3, v2_3, v2_4, v1_4, color_top,
                                         light_top, is_rw);
      this.submit_wing_quad_custom_light(v1_6, v1_5, v2_5, v2_6, color_bot,
                                         light_bot, is_rw);
      this.submit_wing_quad_custom_light(v1_4, v2_4, v2_5, v1_5, color_te,
                                         light_te, is_rw);
    }

    double e_noy = (y_end > 0 ? 1.0 : -1.0);
    double le2 = e_noy * psy;
    double l_e = (le2 > 0.15 ? le2 : 0.15);
    this.submit_wing_quad_custom_light(v2_0, v2_6, v2_2, v2_2, color_top,
                                       l_e, is_rw);
    if (!is_hinged) {
      this.submit_wing_quad_custom_light(v2_2, v2_6, v2_4, v2_3, color_top,
                                         l_e, is_rw);
    } else {
      this.submit_wing_quad_custom_light(v2_2, v2_6, v2_3, v2_3, color_top,
                                         l_e, is_rw);
    }
  }


  void draw_plane(double ail_L, double ail_R, double elev, double rud,
                  double flap) {
    uint f_b = 0xFFEEEEEE, f_t = col_primary, c_c = 0xFF111111,
         g_c = 0xFF4488CC;

    submit_tapered_segment(60.0, 75.0, 16.0, 18.0, -2.0, 10.0, 10.0, -2.0, 0.0,
                           c_c);
    // CANOPY-CUTOUT: seg-2 split at x=30 (canopy front bottom ends here).
    // seg-2a (x=[20,30]) emitted no-top; seg-2b (x=[30,60]) keeps full
    // hexahedron. Split params at x=30 (linear interp x=20→60):
    //   t=0.25 → w=19, h=21, z_off=-0.5  (top z=+10, y=±9.5).
    submit_tapered_segment(30.0, 60.0, 19.0, 21.0, -0.5, 16.0, 18.0, -2.0, 0.0,
                           f_b);
    submit_tapered_segment_no_top(20.0, 30.0, 20.0, 22.0, 0.0, 19.0, 21.0,
                                  -0.5, 0.0, f_b);
    // CANOPY-CUTOUT: seg-3 (x=[-10,20]) is cabin section under canopy.
    // No-top variant — shoulder/frame quads below close the roof outside
    // canopy footprint at the original z=+11 profile.
    submit_tapered_segment_no_top(-10.0, 20.0, 20.0, 22.0, 0.0, 20.0, 22.0,
                                  0.0, 0.0, f_t);
    submit_tapered_segment(-40.0, -10.0, 12.0, 14.0, 0.0, 20.0, 22.0, 0.0, 0.0,
                           f_b);
    submit_tapered_segment(75.0, 80.0, 10.0, 10.0, -2.0, 1.0, 1.0, -2.0, 0.0,
                           f_t);

    // Roof frame around canopy footprint. Outer edges follow original
    // fuselage top profile (z=+11 over seg-3, tapering z=11→10 over
    // seg-2a). Inner edges trace canopy y(x) outline: y=-7 at x=-10, -8
    // at x=10, -7.5 at x=20, -7 at x=30 (mirrored on +y). The 1u-deep
    // gap at x=[10,30] is externally occluded by fuselage + canopy side
    // faces, so trough walls aren't needed.
    //
    // Seg-3 left shoulder (x=[-10,10], canopy back, flat z=+11):
    submit_plane_local_quad_scalar(-10.0, -10.0, 11.0,
                                    10.0, -10.0, 11.0,
                                    10.0,  -8.0, 11.0,
                                   -10.0,  -7.0, 11.0, f_t);
    // Seg-3 left shoulder (x=[10,20], canopy front portion in seg-3):
    submit_plane_local_quad_scalar( 10.0, -10.0, 11.0,
                                    20.0, -10.0, 11.0,
                                    20.0,  -7.5, 11.0,
                                    10.0,  -8.0, 11.0, f_t);
    // Seg-3 right shoulder (x=[-10,10], mirror):
    submit_plane_local_quad_scalar(-10.0,   7.0, 11.0,
                                    10.0,   8.0, 11.0,
                                    10.0,  10.0, 11.0,
                                   -10.0,  10.0, 11.0, f_t);
    // Seg-3 right shoulder (x=[10,20], mirror):
    submit_plane_local_quad_scalar( 10.0,   8.0, 11.0,
                                    20.0,   7.5, 11.0,
                                    20.0,  10.0, 11.0,
                                    10.0,  10.0, 11.0, f_t);
    // Seg-2a left shoulder (x=[20,30], outer y=-10→-9.5 z=11→10,
    // inner y=-7.5→-7 z=11→10) — planar tilted quad:
    submit_plane_local_quad_scalar( 20.0, -10.0, 11.0,
                                    30.0,  -9.5, 10.0,
                                    30.0,  -7.0, 10.0,
                                    20.0,  -7.5, 11.0, f_b);
    // Seg-2a right shoulder (mirror):
    submit_plane_local_quad_scalar( 20.0,   7.5, 11.0,
                                    30.0,   7.0, 10.0,
                                    30.0,   9.5, 10.0,
                                    20.0,  10.0, 11.0, f_b);
    // Cache sin/cos of half-angle (2 trig calls instead of 4).
    {
      double ha = prop_angle * 0.5;
      q_rot_1.w = cos(ha);
      q_rot_1.x = sin(ha);
      q_rot_1.y = 0;
      q_rot_1.z = 0;
    }
    submit_box_rotated(77, 0, -2, 2, 65, 4, 0xFF111111, q_rot_1);
    submit_box_rotated(77, 0, -2, 2, 4, 65, 0xFF111111, q_rot_1);
    // Canopy. Roof has matching cutout (see CANOPY-CUTOUT above): seg-3
    // + seg-2a emit no-top, shoulder quads close the roof outside the
    // canopy y(x) outline. Canopy's own bottom seals the cabin opening
    // along its perimeter — no fuselage face is coplanar/penetrated.
    submit_tapered_segment(-10.0, 10.0, 14.0, 4.0, 13.0, 16.0, 5.0, 13.5, 0.0,
                           g_c);
    submit_tapered_segment(10.0, 30.0, 16.0, 5.0, 13.5, 14.0, 2.0, 10.0, 0.0,
                           g_c);

    double flap_L = flap * 0.8, flap_R = -flap * 0.8;

    draw_wing_half(15.0, 15.0, -10.0, -35.0, 32.0, 25.6, 12.0, 9.6, flap_L,
                   true);
    draw_wing_half(15.0, 15.0, -35.0, -90.0, 25.6, 20.0, 9.6, 8.0, ail_L, true);
    draw_wing_half(15.0, 15.0, 10.0, 35.0, 32.0, 25.6, 12.0, 9.6, flap_R, true);
    draw_wing_half(15.0, 15.0, 35.0, 90.0, 25.6, 20.0, 9.6, 8.0, ail_R, true);

    submit_box(-40, 0, 8, 16, 4, 25, f_b);
    submit_box(-40, 0, 4, 16, 45, 2, f_t);
    {
      double ha = -elev * 0.5;
      q_rot_2.w = cos(ha);
      q_rot_2.x = 0;
      q_rot_2.y = sin(ha);
      q_rot_2.z = 0;
    }
    submit_hinged_box(-48.0, 0, 4, -6.0, 0, 0, 12, 45, 2, 0xFFDDDDDD, q_rot_2);
    {
      double ha = rud * 0.5;
      q_rot_3.w = cos(ha);
      q_rot_3.x = 0;
      q_rot_3.y = 0;
      q_rot_3.z = sin(ha);
    }
    submit_hinged_box(-48.0, 0, 12, -6.0, 0, 0, 12, 3, 25, 0xFFDDDDDD, q_rot_3);

    double pant_z_L = -25.0 + vis_comp_L;
    double wheel_z_L = -28.0 + vis_comp_L;

    double a_lx = 20, a_ly = -7.73, a_lz = -6.35;
    double b_lx = 20, b_ly = -18.27, b_lz = pant_z_L - 0.65;
    double m_lx = (a_lx + b_lx) * 0.5, m_ly = (a_ly + b_ly) * 0.5,
           m_lz = (a_lz + b_lz) * 0.5;
    double ldx = a_lx - b_lx, ldy = a_ly - b_ly, ldz = a_lz - b_lz;
    double L_len = sqrt(ldx * ldx + ldy * ldy + ldz * ldz);
    double L_ang = -atan2(ldy, ldz);
    {
      double ha = L_ang * 0.5;
      q_rot_1.w = cos(ha);
      q_rot_1.x = sin(ha);
      q_rot_1.y = 0;
      q_rot_1.z = 0;
    }

    submit_box_rotated(m_lx, m_ly, m_lz, 4, 2, L_len, f_b, q_rot_1);
    submit_tapered_segment(15.0, 25.0, 6.0, 8.0, pant_z_L, 4.0, 4.0, pant_z_L,
                           -18.0, f_t);
    submit_box(20, -18, pant_z_L, 14, 6, 8, f_t);
    submit_box(20, -18, wheel_z_L, 12, 4, 12, 0xFF111111);

    double pant_z_R = -25.0 + vis_comp_R;
    double wheel_z_R = -28.0 + vis_comp_R;

    double a_rx = 20, a_ry = 7.73, a_rz = -6.35;
    double b_rx = 20, b_ry = 18.27, b_rz = pant_z_R - 0.65;
    double m_rx = (a_rx + b_rx) * 0.5, m_ry = (a_ry + b_ry) * 0.5,
           m_rz = (a_rz + b_rz) * 0.5;
    double rdx = a_rx - b_rx, rdy = a_ry - b_ry, rdz = a_rz - b_rz;
    double R_len = sqrt(rdx * rdx + rdy * rdy + rdz * rdz);
    double R_ang = -atan2(rdy, rdz);
    {
      double ha = R_ang * 0.5;
      q_rot_1.w = cos(ha);
      q_rot_1.x = sin(ha);
      q_rot_1.y = 0;
      q_rot_1.z = 0;
    }

    submit_box_rotated(m_rx, m_ry, m_rz, 4, 2, R_len, f_b, q_rot_1);
    submit_tapered_segment(15.0, 25.0, 6.0, 8.0, pant_z_R, 4.0, 4.0, pant_z_R,
                           18.0, f_t);
    submit_box(20, 18, pant_z_R, 14, 6, 8, f_t);
    submit_box(20, 18, wheel_z_R, 12, 4, 12, 0xFF111111);

    submit_box(-42, 0, -10, 2, 2, 12, 0xFF555555);
    double wheel_z_T = -16.0 + vis_comp_T;
    {
      double ha = -rud * 0.5;
      q_rot_1.w = cos(ha);
      q_rot_1.x = 0;
      q_rot_1.y = 0;
      q_rot_1.z = sin(ha);
    }
    submit_box_rotated(-42, 0, wheel_z_T, 6, 3, 6, 0xFF111111, q_rot_1);
    double strut_len_T = abs(-10.0 - wheel_z_T);
    if (strut_len_T > 0)
      submit_box(-42, 0, -10.0 - strut_len_T * 0.5, 1.5, 1.5, strut_len_T,
                 0xFF555555);
  }

  void draw_clipped_triangle(int si) {
    int b = si << 4;
    double p1x = rq_data[b],     p1y = rq_data[b + 1], p1z = rq_data[b + 2];
    double p2x = rq_data[b + 3], p2y = rq_data[b + 4], p2z = rq_data[b + 5];
    double p3x = rq_data[b + 6], p3y = rq_data[b + 7], p3z = rq_data[b + 8];
    uint colour = rq_colour[si];

    // Hoist camera_fov — fast path divides by it 3x, slow path up to 4x.
    double fov = camera_fov;

    if (p1x >= 0.1 && p2x >= 0.1 && p3x >= 0.1) {
      double inv_p1x = fov / p1x;
      double inv_p2x = fov / p2x;
      double inv_p3x = fov / p3x;

      // The 4th (degenerate) quad vertex reuses vertex-3's screen coords;
      // cache once instead of computing twice inside draw_quad_hud args.
      float sx1f = float(-p1y * inv_p1x), sy1f = float(-p1z * inv_p1x);
      float sx2f = float(-p2y * inv_p2x), sy2f = float(-p2z * inv_p2x);
      float sx3f = float(-p3y * inv_p3x), sy3f = float(-p3z * inv_p3x);

      // Direct call, bypassing draw_triangle_hud wrapper.
      g.draw_quad_hud(0, 0, false,
                      sx1f, sy1f, sx2f, sy2f, sx3f, sy3f, sx3f, sy3f,
                      colour, colour, colour, colour);
      return;
    }

    // SLOW PATH: at least one vertex behind near plane. Use scalar locals
    // (cx0..cx3) instead of class-member arrays — clip output is at most 4
    // verts. Per-vertex projection folded into emit (no separate pass).
    double cx0 = 0, cy0 = 0, cz0 = 0;
    double cx1 = 0, cy1 = 0, cz1 = 0;
    double cx2 = 0, cy2 = 0, cz2 = 0;
    double cx3 = 0, cy3 = 0, cz3 = 0;
    int cc = 0;

    // Edge p1 -> p2 — cc starts at 0
    { bool a_in = p1x >= 0.1, b_in = p2x >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - p1x) / (p2x - p1x);
        double nx_ = 0.1, ny_ = p1y + t * (p2y - p1y), nz_ = p1z + t * (p2z - p1z);
        cx0 = nx_; cy0 = ny_; cz0 = nz_;
        cc = 1;
      }
      if (b_in) {
        if (cc == 0) { cx0 = p2x; cy0 = p2y; cz0 = p2z; cc = 1; }
        else         { cx1 = p2x; cy1 = p2y; cz1 = p2z; cc = 2; }
      }
    }
    // Edge p2 -> p3 — cc in {0,1,2}
    { bool a_in = p2x >= 0.1, b_in = p3x >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - p2x) / (p3x - p2x);
        double nx_ = 0.1, ny_ = p2y + t * (p3y - p2y), nz_ = p2z + t * (p3z - p2z);
        if      (cc == 0) { cx0 = nx_; cy0 = ny_; cz0 = nz_; cc = 1; }
        else if (cc == 1) { cx1 = nx_; cy1 = ny_; cz1 = nz_; cc = 2; }
        else              { cx2 = nx_; cy2 = ny_; cz2 = nz_; cc = 3; }
      }
      if (b_in) {
        if      (cc == 0) { cx0 = p3x; cy0 = p3y; cz0 = p3z; cc = 1; }
        else if (cc == 1) { cx1 = p3x; cy1 = p3y; cz1 = p3z; cc = 2; }
        else              { cx2 = p3x; cy2 = p3y; cz2 = p3z; cc = 3; }
      }
    }
    // Edge p3 -> p1 — cc in {0,1,2,3}
    { bool a_in = p3x >= 0.1, b_in = p1x >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - p3x) / (p1x - p3x);
        double nx_ = 0.1, ny_ = p3y + t * (p1y - p3y), nz_ = p3z + t * (p1z - p3z);
        if      (cc == 0) { cx0 = nx_; cy0 = ny_; cz0 = nz_; cc = 1; }
        else if (cc == 1) { cx1 = nx_; cy1 = ny_; cz1 = nz_; cc = 2; }
        else if (cc == 2) { cx2 = nx_; cy2 = ny_; cz2 = nz_; cc = 3; }
        else              { cx3 = nx_; cy3 = ny_; cz3 = nz_; cc = 4; }
      }
      if (b_in) {
        if      (cc == 0) { cx0 = p1x; cy0 = p1y; cz0 = p1z; cc = 1; }
        else if (cc == 1) { cx1 = p1x; cy1 = p1y; cz1 = p1z; cc = 2; }
        else if (cc == 2) { cx2 = p1x; cy2 = p1y; cz2 = p1z; cc = 3; }
        else              { cx3 = p1x; cy3 = p1y; cz3 = p1z; cc = 4; }
      }
    }

    if (cc < 3) return;

    // Project directly into float locals; y-flip folded into the projection.
    double s0 = fov / cx0; float sx0 = float(-cy0 * s0), sy0 = float(-cz0 * s0);
    double s1 = fov / cx1; float sx1 = float(-cy1 * s1), sy1 = float(-cz1 * s1);
    double s2 = fov / cx2; float sx2 = float(-cy2 * s2), sy2 = float(-cz2 * s2);

    // First triangle of the fan (degenerate quad).
    g.draw_quad_hud(0, 0, false, sx0, sy0, sx1, sy1, sx2, sy2, sx2, sy2,
                    colour, colour, colour, colour);

    if (cc == 4) {
      double s3 = fov / cx3;
      float sx3 = float(-cy3 * s3), sy3 = float(-cz3 * s3);
      g.draw_quad_hud(0, 0, false, sx0, sy0, sx2, sy2, sx3, sy3, sx3, sy3,
                      colour, colour, colour, colour);
    }
  }

  void draw_clipped_face(int si) {
    int b = si << 4;
    double p1x = rq_data[b],      p1y = rq_data[b + 1],  p1z = rq_data[b + 2];
    double p2x = rq_data[b + 3],  p2y = rq_data[b + 4],  p2z = rq_data[b + 5];
    double p3x = rq_data[b + 6],  p3y = rq_data[b + 7],  p3z = rq_data[b + 8];
    double p4x = rq_data[b + 9],  p4y = rq_data[b + 10], p4z = rq_data[b + 11];
    uint colour = rq_colour[si];
    // Hoist camera_fov to a scalar local.
    double fov = camera_fov;

    if (p1x >= 0.1 && p2x >= 0.1 && p3x >= 0.1 && p4x >= 0.1) {
      double s1 = fov / p1x, s2 = fov / p2x;
      double s3 = fov / p3x, s4 = fov / p4x;
      // y-flip folded into the projection.
      float sx1 = float(-p1y * s1), nsy1 = float(-p1z * s1);
      float sx2 = float(-p2y * s2), nsy2 = float(-p2z * s2);
      float sx3 = float(-p3y * s3), nsy3 = float(-p3z * s3);
      float sx4 = float(-p4y * s4), nsy4 = float(-p4z * s4);
      // Single quad call — convex planar quads need no split. Halves engine-
      // boundary crossings on the hot path.
      g.draw_quad_hud(0, 0, false, sx1, nsy1, sx2, nsy2, sx3, nsy3, sx4, nsy4,
                      colour, colour, colour, colour);
      return;
    }

    // Slow path: unrolled 4-edge clip with scalar locals (cx0..cx4 etc.) in
    // place of member clip arrays — output can have 0..5 vertices.
    double vx0 = p1x, vy0 = p1y, vz0 = p1z;
    double vx1 = p2x, vy1 = p2y, vz1 = p2z;
    double vx2 = p3x, vy2 = p3y, vz2 = p3z;
    double vx3 = p4x, vy3 = p4y, vz3 = p4z;

    double cx0 = 0, cy0 = 0, cz0 = 0;
    double cx1 = 0, cy1 = 0, cz1 = 0;
    double cx2 = 0, cy2 = 0, cz2 = 0;
    double cx3 = 0, cy3 = 0, cz3 = 0;
    double cx4 = 0, cy4 = 0, cz4 = 0;
    int cc = 0;

    // 0->1
    { bool a_in = vx0 >= 0.1, b_in = vx1 >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - vx0) / (vx1 - vx0);
        double nx = 0.1, ny = vy0 + t*(vy1-vy0), nz = vz0 + t*(vz1-vz0);
        if      (cc == 0) { cx0 = nx; cy0 = ny; cz0 = nz; }
        else if (cc == 1) { cx1 = nx; cy1 = ny; cz1 = nz; }
        else if (cc == 2) { cx2 = nx; cy2 = ny; cz2 = nz; }
        else if (cc == 3) { cx3 = nx; cy3 = ny; cz3 = nz; }
        else              { cx4 = nx; cy4 = ny; cz4 = nz; }
        cc++;
      }
      if (b_in) {
        if      (cc == 0) { cx0 = vx1; cy0 = vy1; cz0 = vz1; }
        else if (cc == 1) { cx1 = vx1; cy1 = vy1; cz1 = vz1; }
        else if (cc == 2) { cx2 = vx1; cy2 = vy1; cz2 = vz1; }
        else if (cc == 3) { cx3 = vx1; cy3 = vy1; cz3 = vz1; }
        else              { cx4 = vx1; cy4 = vy1; cz4 = vz1; }
        cc++;
      }
    }
    // 1->2
    { bool a_in = vx1 >= 0.1, b_in = vx2 >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - vx1) / (vx2 - vx1);
        double nx = 0.1, ny = vy1 + t*(vy2-vy1), nz = vz1 + t*(vz2-vz1);
        if      (cc == 0) { cx0 = nx; cy0 = ny; cz0 = nz; }
        else if (cc == 1) { cx1 = nx; cy1 = ny; cz1 = nz; }
        else if (cc == 2) { cx2 = nx; cy2 = ny; cz2 = nz; }
        else if (cc == 3) { cx3 = nx; cy3 = ny; cz3 = nz; }
        else              { cx4 = nx; cy4 = ny; cz4 = nz; }
        cc++;
      }
      if (b_in) {
        if      (cc == 0) { cx0 = vx2; cy0 = vy2; cz0 = vz2; }
        else if (cc == 1) { cx1 = vx2; cy1 = vy2; cz1 = vz2; }
        else if (cc == 2) { cx2 = vx2; cy2 = vy2; cz2 = vz2; }
        else if (cc == 3) { cx3 = vx2; cy3 = vy2; cz3 = vz2; }
        else              { cx4 = vx2; cy4 = vy2; cz4 = vz2; }
        cc++;
      }
    }
    // 2->3
    { bool a_in = vx2 >= 0.1, b_in = vx3 >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - vx2) / (vx3 - vx2);
        double nx = 0.1, ny = vy2 + t*(vy3-vy2), nz = vz2 + t*(vz3-vz2);
        if      (cc == 0) { cx0 = nx; cy0 = ny; cz0 = nz; }
        else if (cc == 1) { cx1 = nx; cy1 = ny; cz1 = nz; }
        else if (cc == 2) { cx2 = nx; cy2 = ny; cz2 = nz; }
        else if (cc == 3) { cx3 = nx; cy3 = ny; cz3 = nz; }
        else              { cx4 = nx; cy4 = ny; cz4 = nz; }
        cc++;
      }
      if (b_in) {
        if      (cc == 0) { cx0 = vx3; cy0 = vy3; cz0 = vz3; }
        else if (cc == 1) { cx1 = vx3; cy1 = vy3; cz1 = vz3; }
        else if (cc == 2) { cx2 = vx3; cy2 = vy3; cz2 = vz3; }
        else if (cc == 3) { cx3 = vx3; cy3 = vy3; cz3 = vz3; }
        else              { cx4 = vx3; cy4 = vy3; cz4 = vz3; }
        cc++;
      }
    }
    // 3->0
    { bool a_in = vx3 >= 0.1, b_in = vx0 >= 0.1;
      if (a_in != b_in) {
        double t = (0.1 - vx3) / (vx0 - vx3);
        double nx = 0.1, ny = vy3 + t*(vy0-vy3), nz = vz3 + t*(vz0-vz3);
        if      (cc == 0) { cx0 = nx; cy0 = ny; cz0 = nz; }
        else if (cc == 1) { cx1 = nx; cy1 = ny; cz1 = nz; }
        else if (cc == 2) { cx2 = nx; cy2 = ny; cz2 = nz; }
        else if (cc == 3) { cx3 = nx; cy3 = ny; cz3 = nz; }
        else              { cx4 = nx; cy4 = ny; cz4 = nz; }
        cc++;
      }
      if (b_in) {
        if      (cc == 0) { cx0 = vx0; cy0 = vy0; cz0 = vz0; }
        else if (cc == 1) { cx1 = vx0; cy1 = vy0; cz1 = vz0; }
        else if (cc == 2) { cx2 = vx0; cy2 = vy0; cz2 = vz0; }
        else if (cc == 3) { cx3 = vx0; cy3 = vy0; cz3 = vz0; }
        else              { cx4 = vx0; cy4 = vy0; cz4 = vz0; }
        cc++;
      }
    }

    if (cc < 3) return;

    // Inline projection (only the verts each fan triangle needs); y-flip
    // already folded in. Statically unrolled fan loop.
    double s0 = fov / cx0, s1 = fov / cx1, s2 = fov / cx2;
    float sx0 = float(-cy0 * s0), sy0 = float(-cz0 * s0);
    float sx1 = float(-cy1 * s1), sy1 = float(-cz1 * s1);
    float sx2 = float(-cy2 * s2), sy2 = float(-cz2 * s2);

    g.draw_quad_hud(0, 0, false, sx0, sy0, sx1, sy1, sx2, sy2, sx2, sy2, colour, colour, colour, colour);
    if (cc >= 4) {
      double s3 = fov / cx3;
      float sx3 = float(-cy3 * s3), sy3 = float(-cz3 * s3);
      g.draw_quad_hud(0, 0, false, sx0, sy0, sx2, sy2, sx3, sy3, sx3, sy3, colour, colour, colour, colour);
      if (cc == 5) {
        double s4 = fov / cx4;
        float sx4 = float(-cy4 * s4), sy4 = float(-cz4 * s4);
        g.draw_quad_hud(0, 0, false, sx0, sy0, sx3, sy3, sx4, sy4, sx4, sy4, colour, colour, colour, colour);
      }
    }
  }
  
  void draw_attitude_indicator(const Quaternion &in orientation, float cx,
                               float cy, float size) {
    double fwd_x, fwd_y, fwd_z, right_x, right_y, right_z, up_x, up_y, up_z;
    orientation.get_basis(fwd_x, fwd_y, fwd_z, right_x, right_y, right_z, up_x,
                          up_y, up_z);
    double p_val = fwd_z < -1.0 ? -1.0 : (fwd_z > 1.0 ? 1.0 : fwd_z);
    double pitch = asin(p_val);
    double roll = atan2(right_z, up_z);
    float cos_r = float(cos(-roll));
    float sin_r = float(sin(-roll));

    double inv_pi_4 = 4.0 / PI;
    double rad_per_10_deg = PI / 18.0;

    // Horizon arc: half-width on circular arc through (w=1.5*size, y=0)
    // and (w=0.9*size, y=±size). Off-center circle, horizontal tangent
    // at y=0. Derived from W_MAX=1.5, W_MIN=0.9.
    const float HORIZON_W_MIN = 0.9f;
    const float HORIZON_W_C   = 0.36667f;
    const float HORIZON_W_R2  = 1.28444f;

    // Pitch-ladder fade: ease alpha 1→0 over last 30% to the perimeter.
    const float LADDER_FADE_START = 0.7f;

    for (int p = -9; p <= 9; p++) {
      double p_angle = p * rad_per_10_deg;
      double diff = pitch - p_angle;
      float p_offset = float(diff * inv_pi_4) * size;
      float ladder_alpha = 1.0f;
      bool clamped_horizon = false;

      if (abs(p_offset) > size) {
        if (p == 0) {
          p_offset = (p_offset > 0) ? size : -size;
          clamped_horizon = true;
        } else {
          continue;
        }
      } else if (p != 0) {
        float t = abs(p_offset) / size;
        if (t > LADDER_FADE_START) {
          float u = (t - LADDER_FADE_START) / (1.0f - LADDER_FADE_START);
          ladder_alpha = 1.0f - u;
        }
      }

      float w;
      if (p == 0) {
        if (clamped_horizon) {
          w = HORIZON_W_MIN * size;
        } else {
          float ny = p_offset / size;
          w = (HORIZON_W_C + sqrt(HORIZON_W_R2 - ny * ny)) * size;
        }
      } else {
        w = (p % 3 == 0) ? size * 0.7f : size * 0.4f;
      }

      float lx = cx - w, rx = cx + w, py = cy + p_offset;
      float rlx = cx + (lx - cx) * cos_r - (py - cy) * sin_r,
            rly = cy + (lx - cx) * sin_r + (py - cy) * cos_r;
      float rrx = cx + (rx - cx) * cos_r - (py - cy) * sin_r,
            rry = cy + (rx - cx) * sin_r + (py - cy) * cos_r;

      uint line_col =
          (p > 0) ? 0x7788CCFF : ((p < 0) ? 0x77CC8844 : 0x77FFFFFF);
      // Apply ladder fade to non-horizon marks (alpha byte only).
      if (p != 0 && ladder_alpha < 1.0f) {
        uint base_a = (line_col >> 24) & 0xFF;
        uint scaled_a = uint(float(base_a) * ladder_alpha + 0.5f);
        line_col = (line_col & 0x00FFFFFF) | (scaled_a << 24);
      }
      float thickness = (p == 0) ? 3.0f : 2.0f;
      float clip_bound = size * 2.0f;

      if (rly > cy - clip_bound && rly < cy + clip_bound &&
          rry > cy - clip_bound && rry < cy + clip_bound) {
        this.draw_line_hud_corrected(10, 2, rlx, rly, rrx, rry, thickness,
                                     line_col);
        if (p != 0) {
          float tick_len = 6.0, tdir = (p > 0) ? -1.0f : 1.0f;
          float tlx = rlx + tick_len * sin_r * tdir,
                tly = rly - tick_len * cos_r * tdir;
          float trx = rrx + tick_len * sin_r * tdir,
                try_ = rry - tick_len * cos_r * tdir;
          this.draw_line_hud_corrected(10, 2, rlx, rly, tlx, tly, 2, line_col);
          this.draw_line_hud_corrected(10, 2, rrx, rry, trx, try_, 2, line_col);
        }
      }
    }

    uint symbol_col = 0x77FFFF00;
    this.draw_line_hud_corrected(10, 4, cx - 18, cy, cx - 7, cy, 3, symbol_col);
    this.draw_line_hud_corrected(10, 4, cx + 7, cy, cx + 18, cy, 3, symbol_col);
    this.draw_line_hud_corrected(10, 4, cx, cy - 4, cx, cy + 4, 3, symbol_col);
    this.draw_line_hud_corrected(10, 4, cx - 7, cy, cx, cy + 4, 3, symbol_col);
    this.draw_line_hud_corrected(10, 4, cx + 7, cy, cx, cy + 4, 3, symbol_col);
  }

  // 5x2 hexagon grid HUD tracking prisms destroyed (cap 10).
  // (anchor_x, anchor_y) = BOTTOM-RIGHT of rightmost cell's bbox;
  // grid extends LEFTWARD/UPWARD so bottom-right pip stays fixed.
  // Pointy-top hex, prism-orange palette (matches FloatingPrism RGB
  // with lower HUD alpha). Empty cells render NOTHING. Fill order
  // bottom-right → bottom-left → top-right → top-left.
  void draw_prisms_destroyed_hud(float anchor_x, float anchor_y) {
    int destroyed = prisms_destroyed;
    if (destroyed > 10) destroyed = 10;
    if (destroyed <= 0) return; // empty grid renders nothing.
    int cols = 5;
    int rows = 2;

    // Pointy-top hex: r = vertex-to-center; half_w = r·cos(30°).
    float r = 9.0f;
    float half_w = r * 0.86602540378f;
    float half_h = r * 0.5f;
    float cell_pitch_x = half_w * 2.0f + 4.0f;
    float cell_pitch_y = r * 2.0f + 3.0f;

    // Anchor = bottom-right of grid; extend leftward/upward.
    float grid_w = cell_pitch_x * float(cols) - 4.0f;
    float grid_h = cell_pitch_y * float(rows) - 3.0f;
    float grid_left = anchor_x - grid_w;
    float grid_top  = anchor_y - grid_h;

    // Translucent prism palette (RGB matches FloatingPrism, softer alpha).
    uint fill_col_static = 0x80ED711D;
    uint edge_col_static = 0x99FC9D2B;
    float thick_static = 1.5f;

    // Canonical vertex offsets — shared, per-pip rotation applied
    // below. Order CW from top: 0 top, 1 UR, 2 LR, 3 bot, 4 LL, 5 UL.
    float ox0 =      0.0f, oy0 = -r;
    float ox1 =  half_w,   oy1 = -half_h;
    float ox2 =  half_w,   oy2 =  half_h;
    float ox3 =      0.0f, oy3 =  r;
    float ox4 = -half_w,   oy4 =  half_h;
    float ox5 = -half_w,   oy5 = -half_h;

    // Landing animation. TRACE: 4 perimeter tracers (1.5 edges each)
    // ride to opposing-diagonal midpoints while centre fan inflates
    // 0→r. FLASH: fill alpha + colour bloom, easing back over 6 frames.
    int TRACE_FRAMES = 18;
    int FLASH_FRAMES = 6;
    int ANIM_TOTAL_FRAMES = TRACE_FRAMES + FLASH_FRAMES;
    float TIP_LEN_U = 3.0f;

    // Chunky 8-bit rotation: each pip snaps 20°/60 frames. snap_offset
    // desyncs schedule; rot_step stays 0 across trace+flash so tracers
    // always meet at canonical edge midpoints.
    int   ROT_PERIOD_FRAMES = 60;
    int   ROT_TOTAL_STEPS = 18;
    float ROT_STEP_RAD = 20.0f * PI / 180.0f;

    // Rising-edge detect: stamp newly-revealed slots with current
    // render_frame_id so the anim starts on first paint. Cap at 10.
    if (destroyed > prism_pip_last_destroyed_seen) {
      int seed_lo = prism_pip_last_destroyed_seen;
      int seed_hi = destroyed;
      if (seed_hi > 10) seed_hi = 10;
      for (int s = seed_lo; s < seed_hi; s++) {
        prism_pip_spawn_frame[s] = int(render_frame_id);
      }
      prism_pip_last_destroyed_seen = destroyed;
    }

    // Fill order: idx 0 lands at bottom-right; sweep right-to-left across
    // the bottom row first, then right-to-left across the top row.
    for (int idx = 0; idx < destroyed; idx++) {
      int row = (rows - 1) - (idx / cols);   // 0 → bottom, 1 → top
      int col = (cols - 1) - (idx % cols);   // 0 → rightmost
      float hx = grid_left + half_w + float(col) * cell_pitch_x;
      float hy = grid_top  + r      + float(row) * cell_pitch_y;

      // Resolve anim phase. spawn_frame == -1 = safety (render static).
      // t_anim = frames since pip landed.
      int spawn_frame = prism_pip_spawn_frame[idx];
      int t_anim = (spawn_frame < 0) ? ANIM_TOTAL_FRAMES
                                     : int(render_frame_id) - spawn_frame;
      bool in_trace = (t_anim >= 0 && t_anim < TRACE_FRAMES);
      bool in_flash = (!in_trace && t_anim >= TRACE_FRAMES &&
                       t_anim < ANIM_TOTAL_FRAMES);

      // Per-pip rotation: snap_offset desyncs pips; rot_step=0 until
      // first scheduled snap. CCW (HUD y-down → negate rot_rad).
      int rot_step = 0;
      if (spawn_frame >= 0) {
        int frames_since_spawn = int(render_frame_id) - spawn_frame;
        int snap_offset = (spawn_frame * 7 + idx * 11) % ROT_PERIOD_FRAMES;
        if (snap_offset < 0) snap_offset += ROT_PERIOD_FRAMES;
        if (frames_since_spawn > snap_offset) {
          rot_step = (frames_since_spawn - snap_offset) / ROT_PERIOD_FRAMES;
        }
      }
      rot_step = rot_step % ROT_TOTAL_STEPS;
      float rot_rad = -float(rot_step) * ROT_STEP_RAD;
      float rc = float(cos(rot_rad));
      float rs = float(sin(rot_rad));

      // Apply rotation around (hx,hy) to canonical offsets.
      float vx0 = hx + ox0 * rc - oy0 * rs, vy0 = hy + ox0 * rs + oy0 * rc;
      float vx1 = hx + ox1 * rc - oy1 * rs, vy1 = hy + ox1 * rs + oy1 * rc;
      float vx2 = hx + ox2 * rc - oy2 * rs, vy2 = hy + ox2 * rs + oy2 * rc;
      float vx3 = hx + ox3 * rc - oy3 * rs, vy3 = hy + ox3 * rs + oy3 * rc;
      float vx4 = hx + ox4 * rc - oy4 * rs, vy4 = hy + ox4 * rs + oy4 * rc;
      float vx5 = hx + ox5 * rc - oy5 * rs, vy5 = hy + ox5 * rs + oy5 * rc;

      // Phase-resolved fill/outline. Trace phase doesn't render the
      // static outline (tracers do); flash blooms fill briefly.
      uint fill_col = fill_col_static;
      uint edge_col = edge_col_static;
      float thick = thick_static;
      if (in_flash) {
        // f_flash 1.0 at entry → 0.0 at end of FLASH_FRAMES.
        float f_flash = 1.0f - float(t_anim - TRACE_FRAMES) /
                                float(FLASH_FRAMES);
        // Subtle bloom: alpha 0x80→0x9C, RGB shifts to lighter peach.
        fill_col = lerp_color(fill_col_static, 0x9CF89035, f_flash);
      }

      if (in_trace) {
        // Ease-out quadratic across TRACE_FRAMES.
        float p_lin = float(t_anim) / float(TRACE_FRAMES - 1);
        if (p_lin > 1.0f) p_lin = 1.0f;
        float inv = 1.0f - p_lin;
        float p = 1.0f - inv * inv;

        // Centre fan: 6 triangles, outer verts pulled to centre by
        // (1-p). p==0 collapses to a point; p==1 is full hex.
        float wx0 = hx + (vx0 - hx) * p, wy0 = hy + (vy0 - hy) * p;
        float wx1 = hx + (vx1 - hx) * p, wy1 = hy + (vy1 - hy) * p;
        float wx2 = hx + (vx2 - hx) * p, wy2 = hy + (vy2 - hy) * p;
        float wx3 = hx + (vx3 - hx) * p, wy3 = hy + (vy3 - hy) * p;
        float wx4 = hx + (vx4 - hx) * p, wy4 = hy + (vy4 - hy) * p;
        float wx5 = hx + (vx5 - hx) * p, wy5 = hy + (vy5 - hy) * p;
        g.draw_quad_hud(10, 4, false, hx, hy, wx0, wy0, wx1, wy1, wx1, wy1,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);
        g.draw_quad_hud(10, 4, false, hx, hy, wx1, wy1, wx2, wy2, wx2, wy2,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);
        g.draw_quad_hud(10, 4, false, hx, hy, wx2, wy2, wx3, wy3, wx3, wy3,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);
        g.draw_quad_hud(10, 4, false, hx, hy, wx3, wy3, wx4, wy4, wx4, wy4,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);
        g.draw_quad_hud(10, 4, false, hx, hy, wx4, wy4, wx5, wy5, wx5, wy5,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);
        g.draw_quad_hud(10, 4, false, hx, hy, wx5, wy5, wx0, wy0, wx0, wy0,
                        fill_col_static, fill_col_static,
                        fill_col_static, fill_col_static);

        // Four perimeter tracers (1.5 edges each). vx1↔vx4 diagonal
        // pair: A&D meet at midpoint(vx2,vx3); B&C meet at midpoint
        // (vx0,vx5). Together cover all 6 edges once.
        float et = p * 1.5f;
        // Tracer A: vx1 CW (vx1 → vx2 → midpoint(vx2,vx3)).
        draw_prism_pip_tracer(vx1, vy1, vx2, vy2, vx3, vy3, et,
                              thick_static, TIP_LEN_U, edge_col_static);
        // Tracer B: vx1 CCW (vx1 → vx0 → midpoint(vx0,vx5)).
        draw_prism_pip_tracer(vx1, vy1, vx0, vy0, vx5, vy5, et,
                              thick_static, TIP_LEN_U, edge_col_static);
        // Tracer C: vx4 CW (vx4 → vx5 → midpoint(vx5,vx0)).
        draw_prism_pip_tracer(vx4, vy4, vx5, vy5, vx0, vy0, et,
                              thick_static, TIP_LEN_U, edge_col_static);
        // Tracer D: vx4 CCW (vx4 → vx3 → midpoint(vx3,vx2)).
        draw_prism_pip_tracer(vx4, vy4, vx3, vy3, vx2, vy2, et,
                              thick_static, TIP_LEN_U, edge_col_static);
        continue;
      }

      // Fill via 6 degenerate-quad triangles fanning from the center —
      // same idiom as draw_clipped_triangle's fast path. Hex is convex
      // so no clipping needed; HUD-space, near-plane is irrelevant.
      g.draw_quad_hud(10, 4, false, hx, hy, vx0, vy0, vx1, vy1, vx1, vy1,
                      fill_col, fill_col, fill_col, fill_col);
      g.draw_quad_hud(10, 4, false, hx, hy, vx1, vy1, vx2, vy2, vx2, vy2,
                      fill_col, fill_col, fill_col, fill_col);
      g.draw_quad_hud(10, 4, false, hx, hy, vx2, vy2, vx3, vy3, vx3, vy3,
                      fill_col, fill_col, fill_col, fill_col);
      g.draw_quad_hud(10, 4, false, hx, hy, vx3, vy3, vx4, vy4, vx4, vy4,
                      fill_col, fill_col, fill_col, fill_col);
      g.draw_quad_hud(10, 4, false, hx, hy, vx4, vy4, vx5, vy5, vx5, vy5,
                      fill_col, fill_col, fill_col, fill_col);
      g.draw_quad_hud(10, 4, false, hx, hy, vx5, vy5, vx0, vy0, vx0, vy0,
                      fill_col, fill_col, fill_col, fill_col);

      // Wireframe outline matching in-world icosahedron edge colour.
      this.draw_line_hud_corrected(10, 5, vx0, vy0, vx1, vy1, thick, edge_col);
      this.draw_line_hud_corrected(10, 5, vx1, vy1, vx2, vy2, thick, edge_col);
      this.draw_line_hud_corrected(10, 5, vx2, vy2, vx3, vy3, thick, edge_col);
      this.draw_line_hud_corrected(10, 5, vx3, vy3, vx4, vy4, thick, edge_col);
      this.draw_line_hud_corrected(10, 5, vx4, vy4, vx5, vy5, thick, edge_col);
      this.draw_line_hud_corrected(10, 5, vx5, vy5, vx0, vy0, thick, edge_col);
    }
  }

  // Helper for prism HUD landing anim. One perimeter tracer riding
  // start → mid → halfway-to-end (total 1.5 edges). edges_traveled <=
  // 1.0 → first edge; (1.0,1.5] → second edge by (et-1.0) ∈ [0,0.5].
  // Trail in trail_col; leading tip_len_u in pale amber (0xFFFFD89A).
  // Tip clamped to available trail length.
  void draw_prism_pip_tracer(float sx, float sy, float mx, float my,
                             float ex, float ey, float edges_traveled,
                             float thick, float tip_len_u, uint trail_col) {
    if (edges_traveled <= 0.0f) return;
    uint tip_col = 0xFFFFD89A;

    // seg_a = active-edge start; head = moving leading point. Any
    // completed earlier edge is rendered in full so trail stays
    // continuous across the corner turn.
    float seg_a_x, seg_a_y, head_x, head_y;
    if (edges_traveled <= 1.0f) {
      seg_a_x = sx; seg_a_y = sy;
      head_x = sx + (mx - sx) * edges_traveled;
      head_y = sy + (my - sy) * edges_traveled;
    } else {
      // First edge fully drawn — render once, shift active to 2nd edge.
      this.draw_line_hud_corrected(10, 5, sx, sy, mx, my, thick, trail_col);
      float remaining = edges_traveled - 1.0f; // ∈ (0, 0.5]
      seg_a_x = mx; seg_a_y = my;
      head_x = mx + (ex - mx) * remaining;
      head_y = my + (ey - my) * remaining;
    }

    // White tip backs off tip_len_u from head; trail fills the rest.
    // If segment shorter than tip_len_u, whole thing is white.
    float dx = head_x - seg_a_x;
    float dy = head_y - seg_a_y;
    float seg_len = float(sqrt(dx * dx + dy * dy));
    if (seg_len <= tip_len_u) {
      this.draw_line_hud_corrected(10, 5, seg_a_x, seg_a_y, head_x, head_y,
                                   thick, tip_col);
      return;
    }
    float back_t = (seg_len - tip_len_u) / seg_len;
    float back_x = seg_a_x + dx * back_t;
    float back_y = seg_a_y + dy * back_t;
    this.draw_line_hud_corrected(10, 5, seg_a_x, seg_a_y, back_x, back_y,
                                 thick, trail_col);
    this.draw_line_hud_corrected(10, 5, back_x, back_y, head_x, head_y,
                                 thick, tip_col);
  }

  // -- Engine-dial cluster ---------------------------------------------
  // Watch-face idiom: 21 ticks across 300° CW arc (240°=rest,
  // -60°=max-redline), tapered watch hand, white pivot cap. Layer 10,
  // sub-layers 2 (face) / 4-5 (hands) / 6 (pivot).
  // INVARIANT: draw_quad_hud takes NATIVE HUD coords (engine handles
  // letterbox); DO NOT pre-correct — that doubles the scale.
  // Active arc: 240°→-30° normal (ticks 0..18), -30°→-60° redline
  // (ticks 18..20, character-primary tint).
  void draw_dial_face(float cx, float cy, float size) {
    // Redline ticks tinted with character primary RGB.
    uint primary_rgb   = col_primary & 0x00FFFFFF;
    uint redline_major = 0x88000000 | primary_rgb;
    uint redline_minor = 0x77000000 | primary_rgb;

    // 21 ticks at 15° from 240° to -60° CW. Majors every 60° (i%4==0).
    // Redline at i >= 18.
    for (int i = 0; i <= 20; i++) {
      double tick_deg = 240.0 - double(i) * 15.0;
      double ta = tick_deg * PI / 180.0;
      bool major   = ((i % 4) == 0);
      bool redline = (i >= 18);

      float r_outer = size;
      float r_inner = size - (major ? 12.0f : 7.0f);
      float thickness = major ? 2.0f : 1.0f;

      uint col;
      if      (redline) col = major ? redline_major : redline_minor;
      else if (major)   col = 0x88FFFFFF;
      else              col = 0x55FFFFFF;

      float ca = float(cos(ta));
      float sa = float(sin(ta));
      float x0 = cx + r_inner * ca;
      float y0 = cy - r_inner * sa;
      float x1 = cx + r_outer * ca;
      float y1 = cy - r_outer * sa;
      this.draw_line_hud_corrected(10, 2, x0, y0, x1, y1, thickness, col);
    }
  }

  // Tapered watch hand — kite quad pivoted at (cx,cy). hand_angle is
  // CCW from +x; sin flipped for y-down render.
  void draw_dial_hand(float cx, float cy, float size, double hand_angle,
                      uint hand_col, uint sub_layer,
                      float tip_frac, float mid_w, float tail_len) {
    float ha_c = float(cos(hand_angle));
    float ha_s = float(sin(hand_angle));
    // forward dir (screen y-down): ( cosθ, -sinθ )
    // perp    dir (screen y-down): (-sinθ, -cosθ )    (fwd · perp = 0)
    float fwd_x =  ha_c, fwd_y = -ha_s;
    float prp_x = -ha_s, prp_y = -ha_c;

    float mid_len = size * 0.20f;
    float tip_len = size * tip_frac;

    // V0 tail (-tail_len, 0); V1 mid-left (mid_len, +mid_w);
    // V2 tip (tip_len, 0); V3 mid-right (mid_len, -mid_w).
    float tail_x = cx - tail_len * fwd_x;
    float tail_y = cy - tail_len * fwd_y;
    float mlx = cx + mid_len * fwd_x + mid_w * prp_x;
    float mly = cy + mid_len * fwd_y + mid_w * prp_y;
    float tip_x = cx + tip_len * fwd_x;
    float tip_y = cy + tip_len * fwd_y;
    float mrx = cx + mid_len * fwd_x - mid_w * prp_x;
    float mry = cy + mid_len * fwd_y - mid_w * prp_y;

    g.draw_quad_hud(10, sub_layer, false,
                    tail_x, tail_y, mlx, mly, tip_x, tip_y, mrx, mry,
                    hand_col, hand_col, hand_col, hand_col);
  }

  // Pivot cap — tiny diamond at dial centre, top sub_layer.
  void draw_dial_pivot(float cx, float cy) {
    uint pivot_col = 0x88EEEEEE;
    g.draw_quad_hud(10, 6, false,
                    cx,        cy - 3.0f,
                    cx + 3.0f, cy,
                    cx,        cy + 3.0f,
                    cx - 3.0f, cy,
                    pivot_col, pivot_col, pivot_col, pivot_col);
  }

  // Engine dial — two stacked hands sharing one face:
  //   white airspeed (sub_layer 4) drawn first;
  //   red RPM (sub_layer 5) on top, pulses orange overdriving;
  //   pivot cap (sub_layer 6) caps both bases.
  // Both sweep 240° rest → -30° max → -60° redline so positions
  // are spatially comparable (red ahead = accelerating, etc).
  void draw_engine_dial(float cx, float cy, float size) {
    // === Shared geometry =============================================
    const double a_rest = 240.0 * PI / 180.0;
    const double a_max  = -30.0 * PI / 180.0;
    const double a_over = -60.0 * PI / 180.0;
    uint now_us = get_time_us();

    // === RPM hand: spring on (engine_thrust + dash overdrive) =======
    double thrust_norm = (max_thrust > 0.0)
                             ? (engine_thrust / max_thrust)
                             : 0.0;
    if (thrust_norm < 0.0) thrust_norm = 0.0;
    if (thrust_norm > 1.0) thrust_norm = 1.0;

    // Mirror Plane_Physics boost_factor curve so dial tracks actual
    // engine boost ramp, not just the dash flag.
    double overdrive = 0.0;
    if (dash_timer > 0.0) {
      double elapsed = dash_duration - dash_timer;
      double bf;
      if (elapsed < 0.4)         bf = 1.0 + (elapsed * 2.5);
      else if (dash_timer < 0.8) bf = 1.0 + (dash_timer * 1.25);
      else                       bf = 2.0;
      overdrive = bf - 1.0;
      if (overdrive < 0.0) overdrive = 0.0;
      if (overdrive > 1.0) overdrive = 1.0;
    }
    double target_rpm = thrust_norm + overdrive;

    double dt_rpm = 1.0 / 60.0;
    if (rpm_last_us != 0) {
      double measured = double(now_us - rpm_last_us) * 1.0e-6;
      if (measured > 0.0 && measured < 0.1) dt_rpm = measured;
      else if (measured >= 0.1)             dt_rpm = 0.1;
    }
    rpm_last_us = now_us;

    // k=60, c=12 → ω_n ≈ 7.75 rad/s, ζ ≈ 0.77 (mild underdamp,
    // ~3% overshoot). Semi-implicit Euler.
    {
      const double k = 60.0;
      const double c = 12.0;
      double accel = (target_rpm - rpm_displayed) * k - rpm_velocity * c;
      rpm_velocity  += accel * dt_rpm;
      rpm_displayed += rpm_velocity * dt_rpm;
    }
    if (rpm_displayed < -0.05) {
      rpm_displayed = -0.05;
      if (rpm_velocity < 0.0) rpm_velocity = 0.0;
    }
    if (rpm_displayed > 2.05) {
      rpm_displayed = 2.05;
      if (rpm_velocity > 0.0) rpm_velocity = 0.0;
    }

    double r_clamped = rpm_displayed;
    if (r_clamped < 0.0) r_clamped = 0.0;
    if (r_clamped > 2.0) r_clamped = 2.0;
    double rpm_angle;
    if (r_clamped <= 1.0)
      rpm_angle = a_rest + r_clamped * (a_max - a_rest);
    else
      rpm_angle = a_max + (r_clamped - 1.0) * (a_over - a_max);

    // RPM hand uses character primary; reach into redline ticks
    // signals past-max state.
    uint rpm_col = col_primary;

    // === Airspeed hand: first-order lag on |vel| ====================
    // 0..max_normal = white arc; max_normal..max_dial = redline band.
    const double airspeed_max_normal = 1500.0;
    const double airspeed_max_dial   = 1800.0;

    double speed =
        sqrt(vel.x * vel.x + vel.y * vel.y + vel.z * vel.z);
    double speed_norm = speed / airspeed_max_normal;
    double max_norm = airspeed_max_dial / airspeed_max_normal; // 1.2
    if (speed_norm < 0.0)      speed_norm = 0.0;
    if (speed_norm > max_norm) speed_norm = max_norm;

    double dt_as = 1.0 / 60.0;
    if (airspeed_last_us != 0) {
      double measured = double(now_us - airspeed_last_us) * 1.0e-6;
      if (measured > 0.0 && measured < 0.1) dt_as = measured;
      else if (measured >= 0.1)             dt_as = 0.1;
    }
    airspeed_last_us = now_us;

    // alpha = 1 - exp(-rate*dt) linear approx (rate=10 → ~100ms tau);
    // avoids depending on exp() in AS.
    double alpha = 10.0 * dt_as;
    if (alpha > 1.0) alpha = 1.0;
    airspeed_displayed += (speed_norm - airspeed_displayed) * alpha;

    double s_clamped = airspeed_displayed;
    if (s_clamped < 0.0)      s_clamped = 0.0;
    if (s_clamped > max_norm) s_clamped = max_norm;
    double as_angle;
    if (s_clamped <= 1.0)
      as_angle = a_rest + s_clamped * (a_max - a_rest);
    else
      // Map the 1.0..max_norm band linearly across the redline arc.
      as_angle =
          a_max + (s_clamped - 1.0) / (max_norm - 1.0) * (a_over - a_max);

    // Soft cool-white airspeed hand, matched alpha to RPM.
    uint as_col = 0x88EEEEF8;

    // Draw stack: face → airspeed (shorter/thinner) → RPM (longer
    // /thicker, lead hand) → pivot.
    draw_dial_face(cx, cy, size);
    draw_dial_hand(cx, cy, size, as_angle,  as_col,  4, 0.74f, 2.8f, 6.0f);
    draw_dial_hand(cx, cy, size, rpm_angle, rpm_col, 5, 0.88f, 3.5f, 9.0f);
    draw_dial_pivot(cx, cy);
  }

}