// main.cpp
#include "math_core.cpp"
#include "vfx_entities.cpp"
#include "terrain_engine.cpp"
#include "stl_assets.cpp"
#include "PlaneController.cpp"

// ---- Embedded assets ----
// dm.txt is an ASCII STL of the Dustman model (~541 facets). apple.txt is
// an ASCII STL of an apple (~416 facets, unit-scale ~1u model). Both
// loaded at PlaneController::init via get_embed_value(...). See project plan.
const string EMBED_dm_stl = "dm.txt";
const string EMBED_apple  = "apple.txt";

// ---- Font glyph PNGs (embed_src/font/*.png) ----
// Glyph set for controls-overlay HUD (Plane_HUD.cpp). Covers a-w (except
// q/x/z) + / + : + leftover 1/2/3.
//
// To add chars: declare EMBED_spr_font_<key> here, mirror with
// msg.set_string in build_sprites, add branch in Plane_HUD.cpp::hud_glyph_name.
// All three must move together — missing any one leaves the glyph un-rendered.
//
// Embed key   = "spr_font_<glyph>" (lib/embed_utils.cpp)
// Sprite name = "font_<glyph>"     (build_sprites)
// Sprite-set  = "script"
const string EMBED_spr_font_1 = "font/1.png";
const string EMBED_spr_font_2 = "font/2.png";
const string EMBED_spr_font_3 = "font/3.png";
const string EMBED_spr_font_a = "font/a.png";
const string EMBED_spr_font_b = "font/b.png";
const string EMBED_spr_font_c = "font/c.png";
const string EMBED_spr_font_d = "font/d.png";
const string EMBED_spr_font_e = "font/e.png";
const string EMBED_spr_font_f = "font/f.png";
const string EMBED_spr_font_g = "font/g.png";
const string EMBED_spr_font_h = "font/h.png";
const string EMBED_spr_font_i = "font/i.png";
const string EMBED_spr_font_j = "font/j.png";
const string EMBED_spr_font_k = "font/k.png";
const string EMBED_spr_font_l = "font/l.png";
const string EMBED_spr_font_m = "font/m.png";
const string EMBED_spr_font_n = "font/n.png";
const string EMBED_spr_font_o = "font/o.png";
const string EMBED_spr_font_p = "font/p.png";
const string EMBED_spr_font_r = "font/r.png";
const string EMBED_spr_font_s = "font/s.png";
const string EMBED_spr_font_t = "font/t.png";
const string EMBED_spr_font_u = "font/u.png";
const string EMBED_spr_font_v = "font/v.png";
const string EMBED_spr_font_w = "font/w.png";
const string EMBED_spr_font_y = "font/y.png";
// q, x, z deliberately omitted — unused by control lines.
// Symbols. NB: filename scheme varies — `:` is u003a.png but `/` is
// hex_0x2f.png. Sprite names stay uniform so hud_glyph_name lookups
// don't need to know.
const string EMBED_spr_font_u002f = "font/hex_0x2f.png"; // /
const string EMBED_spr_font_u003a = "font/u003a.png";   // :

class script {
  // ---- Shadow tuning constants ----
  // Read each frame by PlaneController::draw_plane_shadow via cached
  // `script@ sc`. Master on/off driven by engine's Script FX Level
  // (levels 0/1 off, 2/3 on); for per-level tuning branch on
  // g.get_script_fx_level() rather than re-exposing to UI.
  //
  // Fade window — oblique sun-direction distance from plane to nearest
  // catcher. Linear ramp; end_dist must be > start_dist.
  float shadow_fade_start_dist = 800.0f;
  float shadow_fade_end_dist   = 1000.0f;

  // Adaptive grid LOD: cells per silhouette edge near vs far. Coalescer
  // merges 2x2 to a single quad, so 1x1 is pure perf at range.
  float shadow_lod_far_dist = 800.0f;
  uint  shadow_grid_near    = 2;
  uint  shadow_grid_far     = 1;

  // ---- Floating-prism spawn controls ----
  // Read by ChunkManager::process_queue.
  //
  // prism_per_super_cell: max chunks per 3x3x3 super-cell that become
  //   spawn candidates (top-K by hash). 0=off, max 27. ~15% candidate
  //   rate at 4 (downstream gates may still reject).
  // prism_spawn_seed: per-chunk spawn hash seed. Same seed+runway =
  //   identical layout.
  [text] uint prism_per_super_cell = 4;
  [text] uint prism_spawn_seed = 80;

  // ---- Floating-prism placement tuning ----
  // Read by ChunkManager::resolve_pending_prisms. Defaults mirror the
  // file-scope constants in terrain_engine.cpp.
  //
  // pr_dist_min:  Gate 4 min distance between two prisms.
  // pr_terr_min:  min spawn offset along source-tri normal.
  // pr_terr_max:  max spawn offset along source-tri normal.
  // pr_tri_clear: Gate 3 sphere radius around spawn_pos with no terrain.
  // pr_dens_tol:  Gate 2 k-of-N tolerance (0=strict, 1=default).
  [text] float pr_dist_min  = 2000.0f;
  [text] float pr_terr_min  = 1000.0f;
  [text] float pr_terr_max  = 2400.0f;
  [text] float pr_tri_clear =  280.0f;
  [text] uint  pr_dens_tol  = 1;

  // ---- Apple → Dustforce-entity wiring ----
  // Each script apple (spawn_apple_at in init) pairs with one Dustforce
  // apple entity in the level. On collection we synth a hitbox at entity
  // world pos so the replay system records the apple as "found" (tetris.as
  // pattern). Editor maps by index: apple_1 ↔ first spawn, etc.
  [entity] uint apple_1;
  [entity] uint apple_2;
  [entity] uint apple_3;

  script() {}

  // Register custom sprites loaded from EMBED_spr_font_* PNGs above.
  // Available via `sprites@.add_sprite_set("script")`. Consumed by
  // PlaneHudLogic::init_controls_hud.
  //
  // Three places to keep in lockstep when adding chars: EMBED line above,
  // set_string line here, branch in Plane_HUD.cpp::hud_glyph_name.
  void build_sprites(message @msg) {
    msg.set_string("font_1", "spr_font_1");
    msg.set_string("font_2", "spr_font_2");
    msg.set_string("font_3", "spr_font_3");
    msg.set_string("font_a", "spr_font_a");
    msg.set_string("font_b", "spr_font_b");
    msg.set_string("font_c", "spr_font_c");
    msg.set_string("font_d", "spr_font_d");
    msg.set_string("font_e", "spr_font_e");
    msg.set_string("font_f", "spr_font_f");
    msg.set_string("font_g", "spr_font_g");
    msg.set_string("font_h", "spr_font_h");
    msg.set_string("font_i", "spr_font_i");
    msg.set_string("font_j", "spr_font_j");
    msg.set_string("font_k", "spr_font_k");
    msg.set_string("font_l", "spr_font_l");
    msg.set_string("font_m", "spr_font_m");
    msg.set_string("font_n", "spr_font_n");
    msg.set_string("font_o", "spr_font_o");
    msg.set_string("font_p", "spr_font_p");
    msg.set_string("font_r", "spr_font_r");
    msg.set_string("font_s", "spr_font_s");
    msg.set_string("font_t", "spr_font_t");
    msg.set_string("font_u", "spr_font_u");
    msg.set_string("font_v", "spr_font_v");
    msg.set_string("font_w", "spr_font_w");
    msg.set_string("font_y", "spr_font_y");
    msg.set_string("font_u002f", "spr_font_u002f");
    msg.set_string("font_u003a", "spr_font_u003a");
  }

  void spawn_player(message @msg) {
    PlaneController @plane = PlaneController();
    plane.character = msg.get_string("character");
    scriptenemy @ent = create_scriptenemy(plane);
    ent.x(msg.get_float("x"));
    ent.y(msg.get_float("y"));
    msg.set_entity("player", @ent.as_entity());
  }
};