class TrailPoint {
  Vec3 pos;
  float life;
  bool connected;
  // Emission-time speed factor (0 at min, 1 at vortex_thresh). Dash
  // trail renderer lerps colored thickness + white stripe visibility
  // per-point. Wheel trails ignore (default).
  float speed_scale;
  TrailPoint() {
    connected = true;
    speed_scale = 1.0f;
  }
  TrailPoint(Vec3 p, float l, bool c = true) {
    pos = p;
    life = l;
    connected = c;
    speed_scale = 1.0f;
  }
}

class Smoke {
  Vec3 pos;
  Vec3 vel;
  float life;
  float max_life;
  float inv_max_life;
  float base_size;
  // Per-axis size mults (defaults 1.0 = cubic). Non-uniform values give
  // flattened "sheet" puffs in the smoke's local frame.
  float size_x;
  float size_y;
  float size_z;
  // Alpha mult on top of the 180-cap fade. <1.0 = airier puffs.
  float alpha_mul;
  uint color;
  Quaternion rot;
  double rot_vel_x, rot_vel_y, rot_vel_z;
  Smoke() {
    size_x = 1.0f;
    size_y = 1.0f;
    size_z = 1.0f;
    alpha_mul = 1.0f;
  }
}

class Particle {
  Vec3 pos;
  Vec3 vel;
  float life;
  uint color;
  // Default off (existing spawners unaffected). Wing-impact sparks set
  // both true for thin straight-line motion-blur streaks.
  bool no_gravity;
  bool streak;
  Particle() {
    no_gravity = false;
    streak = false;
  }
  Particle(Vec3 p, Vec3 v, float l, uint c) {
    pos = p;
    vel = v;
    life = l;
    color = c;
    no_gravity = false;
    streak = false;
  }
}

class Projectile {
  Vec3 pos;
  Vec3 vel;
  float life;
  uint color;
  Projectile() {}
  Projectile(Vec3 p, Vec3 v, float l, uint c) {
    pos = p;
    vel = v;
    life = l;
    color = c;
  }
}

class FloatingPrism {
  Vec3 pos;
  float life;
  float size;
  uint color;
  FloatingPrism() {}
  FloatingPrism(Vec3 p, float s, uint c) {
    pos = p;
    size = s;
    color = c;
    life = 0;
  }
}

// Wind streamer — atmospheric ribbon meandering along global wind vector.
// Sparse, white, low-opacity world-space ribbon under fx_level >= 3. Owns
// internal point chain (OLDEST→NEWEST) + stream-level lifecycle envelope.
//
// INVARIANT: points/point_life parallel arrays, length-equal at all times.
// Render skips segment 0 (i starts at 1) so spawn pos never phantom-edges
// to head.
class WindStream {
  array<Vec3> points;        // chain — head appended each emit_interval
  array<float> point_life;   // (0..1]; uniform decay; dead front trimmed
  Vec3 head;                 // continuous integrator state; next emit pos

  // Stream-level lifecycle. envelope_alpha ramps in on age<=fade_in_t,
  // plateau, ramps out on age >= max_age - fade_out_t. Freed when
  // age >= max_age AND chain empty.
  float age;
  float max_age;
  float fade_in_t;
  float fade_out_t;

  // Per-stream motion snapshot — frozen at spawn. Global wind drift only
  // affects NEW spawns; active streams keep their born heading.
  //   wind_dir   — unit world-frame direction (global ± per-stream jitter)
  //   speed_mult — multiplier on global wind_strength_cur (~0.85 calm,
  //                ~1.7 fast-straight)
  Vec3 wind_dir;
  double speed_mult;

  // Meander state. perp_a/b snapshot at spawn (perpendicular to wind_dir).
  // Two perp axes × independent phase/freq → irregular helix-ish path.
  // Archetype drives amp+freq (CALM tiny, TURBULENT loud high-freq).
  Vec3 perp_a;
  Vec3 perp_b;
  double phase_a;
  double phase_b;
  double freq_a;
  double freq_b;
  double meander_amp;

  // Emit timer counts down to 0; at 0 we append head to chain and reset.
  float emit_timer;

  // Cached sin(phase_a/b) from previous step — lets delta-meander integrator
  // do 2 sin()/stream/frame instead of 4 (cached_sin + sin(new), store new).
  double sin_phase_a;
  double sin_phase_b;

  // Stream-level bound sphere recomputed at end of update_wind_streams over
  // surviving points. render_wind_streams uses it for fog + behind-cam +
  // frustum-cone cull at stream granularity. Stale until chain >= 1 point;
  // render's `pn < 2 continue` fires before the bound test.
  Vec3 bound_c;
  double bound_r;

  WindStream() {}
}

class PrismFragment {
  Vec3 pos;
  Vec3 vel;
  Quaternion rot;
  Vec3 spin_axis;
  double spin_speed;
  float life;
  uint color;
  Vec3 p1, p2, p3, p4;
  PrismFragment() {}
  PrismFragment(Vec3 p, Vec3 v, Vec3 sa, double ss, float l, uint c, Vec3 v1,
                Vec3 v2, Vec3 v3, Vec3 v4) {
    pos = p;
    vel = v;
    rot.w = 1;
    rot.x = 0;
    rot.y = 0;
    rot.z = 0;
    spin_axis = sa;
    spin_speed = ss;
    life = l;
    color = c;
    p1 = v1;
    p2 = v2;
    p3 = v3;
    p4 = v4;
  }
}
