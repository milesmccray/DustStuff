#include "Plane_Render.cpp"
#include "Plane_Shadow.cpp"
#include "Plane_Physics.cpp"
#include "Plane_VFX.cpp"
#include "Plane_HUD.cpp"

// -- Plane Controller Class --
class PlaneController : enemy_base, PlaneRenderLogic, PlaneShadowLogic, PlanePhysicsLogic, PlaneVFXLogic, PlaneHudLogic {
  scene @g;
  scriptenemy @self;
  // Level's script instance — set in init(). Lets shadow/physics read
  // [text] user-tunables from main.cpp's class script. null only
  // pre-init; guarded at every read.
  script @sc;

  ChunkManager chunk_manager;
  uint frame_id = 0;
  uint render_frame_id = 0;

  string character = "dustman";
  uint col_primary = 0xFF9AB4E3;
  uint col_secondary = 0xFF6A84C0;

  Vec3 pos, prev_pos, vel, angular_velocity;
  Quaternion orientation, prev_orientation;

  double mass = 600.0;
  Vec3 inertia;
  double gravity = 980.0;

  double engine_thrust = 0.0;
  double max_thrust = 650000.0;
  double prop_angle = 0.0;

  // RPM dial HUD smoothing: second-order spring on normalized thrust
  // (engine_thrust/max_thrust + dash overdrive). Driven from wall-clock
  // (frame-rate independent), mildly underdamped for tach-like overshoot.
  double rpm_displayed = 0.0;
  double rpm_velocity  = 0.0;
  uint   rpm_last_us   = 0;

  // Airspeed dial smoothing: first-order lag (~100ms) on |vel|. vel
  // already integrates smoothly so lag just masks per-frame jitter.
  // Units: 1.0 = airspeed_max_normal, >1.0 = Vne band.
  double airspeed_displayed = 0.0;
  uint   airspeed_last_us   = 0;

  double linear_air_damping = 0.05;
  Vec3 angular_air_damping(4.0, 4.0, 4.0);

  double aileron_L = 0.0, prev_aileron_L = 0.0;
  double aileron_R = 0.0, prev_aileron_R = 0.0;
  double elevator = 0.0, prev_elevator = 0.0;
  double rudder = 0.0, prev_rudder = 0.0;

  double flap_extension = 0.0, prev_flap_extension = 0.0;
  double brake_timer = 0.0;
  bool prev_taunt = false;
  bool prev_jump = false;
  // Taunt+held-jump must not cancel air-brake; player must re-press jump.
  // Cleared as soon as jump is observed released.
  bool jump_brake_cancel_locked = false;

  // Smoothed yaw [-1,+1]: snap-to-base on press, ramp to full while
  // held, damp on release, snap-opposite on reversal. (rudder-staging
  // block in update loop.)
  double yaw_input = 0.0;
  // Roll/pitch use same staging as yaw.
  double roll_input = 0.0;
  double pitch_input = 0.0;

  // Reversal boost (roll/yaw): scales 0→1 when input opposes current
  // body-frame angular velocity. Bounded multiplier on torque.
  double roll_reversal_boost = 0.0;
  double yaw_reversal_boost = 0.0;

  // Long-hold roll authority [0..1]. Accumulates while x_intent held
  // past saturation; drains faster on release/reversal. Multiplies roll
  // torque + aileron by (1 + charge * gain). (roll-hold block in loop.)
  double roll_hold_charge = 0.0;

  double dash_timer = 0.0;
  bool prev_dash = false;
  double dash_duration = 3.0;

  // -- Wingtip vortex bursts (trail jaggedness) --
  // Rare, short-lived perpendicular perturbations that jag the dash trail.
  double vortex_timer = 0.0;    // seconds remaining in the current burst
  double vortex_cooldown = 0.0; // seconds until the next burst may trigger
  double vortex_phase = 0.0;    // rotating phase angle (radians)

  // -- Visual suspension and trails --
  double vis_comp_L = 0.0, vis_comp_R = 0.0, vis_comp_T = 0.0;
  bool was_touch_L = false, was_touch_R = false, was_touch_T = false;
  bool was_dash = false;
  // Per-frame wingtip-impact tracking. Set in apply_point_collision
  // on spark-eligible hit; reset at step() start. update_trails reads
  // these for wingtip trail point drops + `connected` gating.
  bool wing_touch_L_frame = false, wing_touch_R_frame = false;
  bool was_wing_touch_L = false, was_wing_touch_R = false;

  double cam_dot_fwd = 0;
  double cam_dot_left = 0;
  double cam_dot_up = 0;
  double inv_mass;
  Vec3 inv_inertia;

  float cached_screen_w = 0.0f;
  float cached_screen_h = 0.0f;
  float cached_hud_scale = 1.0f;  // h / 900
  float cached_hud_offset = 0.0f; // (w - 1600 * scale) * 0.5

  array<TrailPoint @> trail_L;
  array<TrailPoint @> trail_R;
  array<TrailPoint @> wheel_trail_L;
  array<TrailPoint @> wheel_trail_R;
  array<TrailPoint @> wheel_trail_T;
  array<TrailPoint @> wingtip_trail_L;
  array<TrailPoint @> wingtip_trail_R;
  array<Particle @> particles;
  uint max_trail_points = 60;

  array<TrailPoint @> trail_pool;
  array<Particle @> particle_pool;
  array<Projectile @> projectiles;
  array<Projectile @> projectile_pool;
  array<FloatingPrism @> floating_prisms;
  array<FloatingPrism @> prism_pool;

  // === Wind streamers (fx_level >= 3) ========================================
  // Sparse atmospheric ribbons. ~2/sec spawn in a sphere around the camera
  // (biased upwind). Both update + render paths in Plane_VFX.cpp gated on
  // fx_level >= 3 at call site.
  array<WindStream @> wind_streams;
  array<WindStream @> wind_stream_pool;
  // Free-running radian phases; sin() yields -1..+1 drift.
  double wind_drift_phase_yaw = 0.0;
  double wind_drift_phase_pit = 0.0;
  double wind_strength_phase  = 0.0;
  // Cached current wind — recomputed once per step() before integrator,
  // shared by spawn + integrator.
  Vec3 wind_vec_cur;
  double wind_strength_cur = 0.0;

  // STL static-mesh assets: parsed once at init, referenced by every
  // StlInstance. stl_instances aggregates all placements in the world;
  // render/physics walks iterate it once and don't care which asset
  // each instance is sourced from.
  StlAsset stl_dustman;
  StlAsset stl_apple;
  array<StlInstance @> stl_instances;

  // Collectible apples — sphere-collision pickups placed in the world.
  // Each Apple owns a paired StlInstance for its visual; on collect we
  // swap-pop from BOTH this array and stl_instances (see step()'s
  // apple loop in Plane_Physics.cpp).
  array<Apple @> apples;
  array<Apple @> apple_pool;

  FloatingPrism @get_prism() {
    uint n = prism_pool.length();
    if (n > 0) {
      FloatingPrism @p = prism_pool[n - 1];
      prism_pool.removeLast();
      return p;
    }
    return FloatingPrism();
  }
  void free_prism(FloatingPrism @p) { prism_pool.insertLast(p); }

  // Wind-stream pool: caller must reset all stream fields — see
  // spawn_wind_stream in Plane_VFX.cpp.
  WindStream @get_wind_stream() {
    uint n = wind_stream_pool.length();
    if (n > 0) {
      WindStream @w = wind_stream_pool[n - 1];
      wind_stream_pool.removeLast();
      return w;
    }
    return WindStream();
  }
  void free_wind_stream(WindStream @w) {
    // Clear chain — value-typed arrays, resize(0) cheap.
    w.points.resize(0);
    w.point_life.resize(0);
    wind_stream_pool.insertLast(w);
  }

  Apple @get_apple() {
    uint n = apple_pool.length();
    if (n > 0) {
      Apple @a = apple_pool[n - 1];
      apple_pool.removeLast();
      a.collected = false;
      a.collect_t = 0.0f;
      a.base_scale = 0.0;
      a.base_tz = 0.0;
      @a.inst = null;
      a.entity_id = 0;
      return a;
    }
    return Apple();
  }
  void free_apple(Apple @a) {
    @a.inst = null;
    apple_pool.insertLast(a);
  }

  // Spawn collectible apple at (x,y,z). Builds StlInstance, pairs with
  // Apple entity, inserts both. entity_id binds to Dustforce apple for
  // replay credit (0 = unwired). Init-time only — stl_apple must be loaded.
  void spawn_apple_at(double x, double y, double z, uint entity_id, float radius = 80.0f) {
    StlInstance @inst = StlInstance();
    inst.set_asset(@stl_apple);
    double a_scale = 300.0;
    inst.set_color(0xF0994C58);   // muted apple-red, ~94% opacity
    inst.stem_col = 0xF01F1C26;   // dark plum stem
    inst.shade_min = 0.6;
    // Apples float — never coplanar with terrain, so lower 290 z_bias
    // narrows the false-front artifact zone.
    inst.z_bias = 290.0;
    inst.axis_tilt_rad = double(PI) / 2.0;     // y-up model -> z-up world
    inst.axis_lean_rad = -double(PI) / 4.0;    // stem leans -X
    inst.spin_axis_x = 0.3;
    inst.spin_axis_y = 0.5;
    inst.spin_axis_z = 0.8;
    inst.spin_rate = 0.5;
    // Four-light rig — coverage across all octants.
    inst.key_light_x = -0.5;
    inst.key_light_y = 0.4;
    inst.key_light_z = 1.0;
    inst.key_light_intensity = 0.6;
    inst.under_light_x = 0.0;
    inst.under_light_y = -0.5;
    inst.under_light_z = -1.0;
    inst.under_light_intensity = 0.5;
    inst.rim_light_x = -0.5;
    inst.rim_light_y = -0.4;
    inst.rim_light_z = -0.5;
    inst.rim_light_intensity = 0.55;
    inst.set_transform(x, y, z, a_scale, 0.0);
    inst.bake_world_transform();
    stl_instances.insertLast(inst);

    Apple @a = get_apple();
    a.pos.set(x, y, z);
    a.size = radius;
    a.collected = false;
    @a.inst = @inst;
    a.entity_id = entity_id;
    apples.insertLast(a);
  }

  // Synthesize a player-owned hitbox at the paired Dustforce apple entity
  // so replay records it as "found". Owner MUST be @self.as_controllable()
  // (custom-character scriptenemy — controller_controllable(0) doesn't
  // exist for us). Guards: entity_id==0/entity_by_id null/self null skip.
  void hitTheApple(uint entity_id) {
    if (entity_id == 0) return;
    if (self is null) return;
    entity@ ent = entity_by_id(entity_id);
    if (ent is null) return;
    hitbox@ h = create_hitbox(@self.as_controllable(), 0,
                              ent.x(), ent.y(), -5, 5, -5, 5);
    g.add_entity(h.as_entity(), false);
  }

  array<PrismFragment @> prism_fragments;
  array<PrismFragment @> fragment_pool;

  double gun_cooldown = 0.0;
  bool prev_right_down = false;
  array<Smoke @> smokes;
  array<Smoke @> smoke_pool;

  Smoke @get_smoke() {
    uint n = smoke_pool.length();
    if (n > 0) {
      Smoke @s = smoke_pool[n - 1];
      smoke_pool.removeLast();
      // Reset shape/alpha — pool reuse skips ctor, and non-setting
      // spawners (projectile impact, contrails) need cubic full-alpha.
      s.size_x = 1.0f;
      s.size_y = 1.0f;
      s.size_z = 1.0f;
      s.alpha_mul = 1.0f;
      return s;
    }
    return Smoke();
  }

  void free_smoke(Smoke @s) { smoke_pool.insertLast(s); }
  Projectile @get_projectile() {
    uint n = projectile_pool.length();
    if (n > 0) {
      Projectile @p = projectile_pool[n - 1];
      projectile_pool.removeLast();
      return p;
    }
    return Projectile();
  }
  void free_projectile(Projectile @p) { projectile_pool.insertLast(p); }

  PrismFragment @get_prism_fragment() {
    uint n = fragment_pool.length();
    if (n > 0) {
      PrismFragment @f = fragment_pool[n - 1];
      fragment_pool.removeLast();
      return f;
    }
    return PrismFragment();
  }
  void free_prism_fragment(PrismFragment @f) { fragment_pool.insertLast(f); }

  void spawn_shatter_fragment(const Vec3 &in p1, const Vec3 &in p2,
                              const Vec3 &in p3, const Vec3 &in p4,
                              const Vec3 &in prism_pos, uint color,
                              const Vec3 &in impact_pos,
                              const Vec3 &in impact_vel) {

    double c_x = (p1.x + p2.x + p3.x + p4.x) * 0.25;
    double c_y = (p1.y + p2.y + p3.y + p4.y) * 0.25;
    double c_z = (p1.z + p2.z + p3.z + p4.z) * 0.25;

    PrismFragment @f = get_prism_fragment();
    f.p1.set(p1.x - c_x, p1.y - c_y, p1.z - c_z);
    f.p2.set(p2.x - c_x, p2.y - c_y, p2.z - c_z);
    f.p3.set(p3.x - c_x, p3.y - c_y, p3.z - c_z);
    f.p4.set(p4.x - c_x, p4.y - c_y, p4.z - c_z);

    double dx = c_x - prism_pos.x, dy = c_y - prism_pos.y,
           dz = c_z - prism_pos.z;
    double dlen = sqrt(dx * dx + dy * dy + dz * dz);
    if (dlen > 1e-4) {
      double inv_dlen = 1.0 / dlen;
      dx *= inv_dlen;
      dy *= inv_dlen;
      dz *= inv_dlen;
    } else {
      dx = 0;
      dy = 0;
      dz = 1;
    }

    double cx_imp = c_x - impact_pos.x, cy_imp = c_y - impact_pos.y,
           cz_imp = c_z - impact_pos.z;
    double dist_to_impact =
        sqrt(cx_imp * cx_imp + cy_imp * cy_imp + cz_imp * cz_imp);
    double impact_weight = 1.0 / (1.0 + dist_to_impact * 0.05);

    double base_spd = 100.0 + fast_hash(uint(c_x)) * 100.0;
    double vx = dx * base_spd, vy = dy * base_spd, vz = dz * base_spd;

    double impact_spd = impact_vel.magnitude();
    if (impact_spd > 1e-4) {
      double inv_spd = 1.0 / impact_spd;
      double transfer = impact_spd * 0.4 * impact_weight;
      vx += (impact_vel.x * inv_spd) * transfer;
      vy += (impact_vel.y * inv_spd) * transfer;
      vz += (impact_vel.z * inv_spd) * transfer;

      if (dist_to_impact > 1e-4) {
        double inv_f = 1.0 / dist_to_impact;
        double blowout = 500.0 * impact_weight;
        vx += (cx_imp * inv_f) * blowout;
        vy += (cy_imp * inv_f) * blowout;
        vz += (cz_imp * inv_f) * blowout;
      }
    }

    double sax = fast_hash(uint(c_x)) * 100.0 - 50.0;
    double say = fast_hash(uint(c_y)) * 100.0 - 50.0;
    double saz = fast_hash(uint(c_z)) * 100.0 - 50.0;
    double slen = sqrt(sax * sax + say * say + saz * saz);
    if (slen > 1e-9) {
      double inv_slen = 1.0 / slen;
      sax *= inv_slen;
      say *= inv_slen;
      saz *= inv_slen;
    }

    double spin_speed =
        2.0 + fast_hash(uint(c_x + c_y)) * 5.0 + impact_weight * 10.0;
    uint hash_seed = uint(abs(vx * 123.0) + abs(vy * 456.0) + abs(vz * 789.0));
    double travel_rate = 0.5 + fast_hash(hash_seed) * 1.5;
    double spin_rate = 0.2 + fast_hash(hash_seed + 1337) * 2.5;

    f.pos.set(c_x, c_y, c_z);
    f.vel.set(vx * travel_rate, vy * travel_rate, vz * travel_rate);
    f.rot.w = 1;
    f.rot.x = 0;
    f.rot.y = 0;
    f.rot.z = 0;
    f.spin_axis.set(sax, say, saz);
    f.spin_speed = spin_speed * spin_rate;
    f.life = 1.0;
    // Override alpha to 0xD9 (~85%) — shatter shards run brighter than the
    // intact prism's 0xAA face alpha so they read against the kept body
    // during the brief overlap window. Edges inherit alpha via renderer.
    f.color = (color & 0x00FFFFFF) | 0xBF000000;

    prism_fragments.insertLast(f);
  }

  void spawn_shatter_fragments_for_face(const Vec3 &in v1, const Vec3 &in v2,
                                        const Vec3 &in v3,
                                        const Vec3 &in prism_pos, uint color,
                                        const Vec3 &in impact_pos,
                                        const Vec3 &in impact_vel) {
    Vec3 m12((v1.x + v2.x) * 0.5, (v1.y + v2.y) * 0.5, (v1.z + v2.z) * 0.5);
    Vec3 m23((v2.x + v3.x) * 0.5, (v2.y + v3.y) * 0.5, (v2.z + v3.z) * 0.5);
    Vec3 m31((v3.x + v1.x) * 0.5, (v3.y + v1.y) * 0.5, (v3.z + v1.z) * 0.5);
    Vec3 c((v1.x + v2.x + v3.x) * 0.333333333333,
           (v1.y + v2.y + v3.y) * 0.333333333333,
           (v1.z + v2.z + v3.z) * 0.333333333333);

    Vec3 d1(v2.x - v1.x, v2.y - v1.y, v2.z - v1.z);
    Vec3 d2(v3.x - v1.x, v3.y - v1.y, v3.z - v1.z);
    Vec3 n(d1.y * d2.z - d1.z * d2.y, d1.z * d2.x - d1.x * d2.z,
           d1.x * d2.y - d1.y * d2.x);
    n.normalize_in_place();

    double off1 = fast_hash(uint(c.x)) * 20.0 - 10.0;
    double off2 = fast_hash(uint(c.y)) * 20.0 - 10.0;

    c.x += n.x * off1;
    c.y += n.y * off1;
    c.z += n.z * off1;
    m12.x += n.x * off2;
    m12.y += n.y * off2;
    m12.z += n.z * off2;
    m23.x += n.x * off2;
    m23.y += n.y * off2;
    m23.z += n.z * off2;
    m31.x += n.x * off2;
    m31.y += n.y * off2;
    m31.z += n.z * off2;

    spawn_shatter_fragment(v1, m12, c, m31, prism_pos, color, impact_pos,
                           impact_vel);
    spawn_shatter_fragment(v2, m23, c, m12, prism_pos, color, impact_pos,
                           impact_vel);
    spawn_shatter_fragment(v3, m31, c, m23, prism_pos, color, impact_pos,
                           impact_vel);
  }

  void shatter_prism(FloatingPrism @p, const Vec3 &in impact_pos,
                     const Vec3 &in impact_vel) {
    double phi = 1.6180339887 * p.size;
    double one = 1.0 * p.size;

    double a = p.life * 1.5;
    double ha = p.life * 0.75;
    double sha = sin(ha);
    q_rot_1.w = cos(ha);
    q_rot_1.x = sha * 0.3;
    q_rot_1.y = sha * 0.5;
    q_rot_1.z = sha * 0.8;
    q_rot_1.normalize();

    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    q_rot_1.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double o_rx = one * rx, o_ry = one * ry, o_rz = one * rz;
    double p_ux = phi * ux, p_uy = phi * uy, p_uz = phi * uz;

    double o_fx = one * fx, o_fy = one * fy, o_fz = one * fz;
    double p_rx = phi * rx, p_ry = phi * ry, p_rz = phi * rz;

    double p_fx = phi * fx, p_fy = phi * fy, p_fz = phi * fz;
    double o_ux = one * ux, o_uy = one * uy, o_uz = one * uz;

    array<Vec3> @v = @temp_prism_v;
    double px = 0, py = 0, pz = 0;

    v[0].set(px + o_rx + p_ux, py + o_ry + p_uy, pz + o_rz + p_uz);
    v[1].set(px - o_rx + p_ux, py - o_ry + p_uy, pz - o_rz + p_uz);
    v[2].set(px + o_rx - p_ux, py + o_ry - p_uy, pz + o_rz - p_uz);
    v[3].set(px - o_rx - p_ux, py - o_ry - p_uy, pz - o_rz - p_uz);

    v[4].set(px + o_fx + p_rx, py + o_fy + p_ry, pz + o_fz + p_rz);
    v[5].set(px - o_fx + p_rx, py - o_fy + p_ry, pz - o_fz + p_rz);
    v[6].set(px + o_fx - p_rx, py + o_fy - p_ry, pz + o_fz - p_rz);
    v[7].set(px - o_fx - p_rx, py - o_fy - p_ry, pz - o_fz - p_rz);

    v[8].set(px + p_fx + o_ux, py + p_fy + o_uy, pz + p_fz + o_uz);
    v[9].set(px - p_fx + o_ux, py - p_fy + o_uy, pz - p_fz + o_uz);
    v[10].set(px + p_fx - o_ux, py + p_fy - o_uy, pz + p_fz - o_uz);
    v[11].set(px - p_fx - o_ux, py - p_fy - o_uy, pz - p_fz - o_uz);

    for (int k = 0; k < 12; k++) {
      v[k].x += p.pos.x;
      v[k].y += p.pos.y;
      v[k].z += p.pos.z;
    }

    spawn_shatter_fragments_for_face(v[0], v[1], v[8], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[0], v[8], v[4], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[0], v[4], v[5], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[0], v[5], v[9], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[0], v[9], v[1], p.pos, p.color,
                                     impact_pos, impact_vel);

    spawn_shatter_fragments_for_face(v[3], v[11], v[7], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[3], v[7], v[6], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[3], v[6], v[10], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[3], v[10], v[2], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[3], v[2], v[11], p.pos, p.color,
                                     impact_pos, impact_vel);

    spawn_shatter_fragments_for_face(v[1], v[8], v[6], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[8], v[4], v[10], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[4], v[5], v[2], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[5], v[9], v[11], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[9], v[1], v[7], p.pos, p.color,
                                     impact_pos, impact_vel);

    spawn_shatter_fragments_for_face(v[10], v[6], v[8], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[2], v[10], v[4], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[11], v[2], v[5], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[7], v[11], v[9], p.pos, p.color,
                                     impact_pos, impact_vel);
    spawn_shatter_fragments_for_face(v[6], v[7], v[1], p.pos, p.color,
                                     impact_pos, impact_vel);
  }

  Vec3 temp_q1, temp_q2, temp_q3, temp_q4;
  Vec3 temp_a1_3, temp_a1_4, temp_a1_5, temp_a1_6;
  Vec3 temp_a2_3, temp_a2_4, temp_a2_5, temp_a2_6;
  Vec3 box_p001, box_p101, box_p111, box_p011, box_p010, box_p110, box_p100,
      box_p000;
  Vec3 contact_L, contact_R, contact_T;
  Vec3 wing_contact_L, wing_contact_R;
  Quaternion q_rot_1, q_rot_2, q_rot_3;
  Vec3 interp_pos;
  Quaternion interp_orientation;
  Vec3 interp_camera_pos;
  Quaternion interp_camera_orientation;

  TrailPoint @get_trail_point() {
    uint n = trail_pool.length();
    if (n > 0) {
      TrailPoint @tp = trail_pool[n - 1];
      trail_pool.removeLast();
      return tp;
    }
    return TrailPoint();
  }
  void free_trail_point(TrailPoint @tp) { trail_pool.insertLast(tp); }

  Particle @get_particle() {
    uint n = particle_pool.length();
    if (n > 0) {
      Particle @p = particle_pool[n - 1];
      particle_pool.removeLast();
      // Reset optional flags so a recycled particle doesn't inherit the
      // previous user's no_gravity / streak settings.
      p.no_gravity = false;
      p.streak = false;
      return p;
    }
    return Particle();
  }
  void free_particle(Particle @p) { particle_pool.insertLast(p); }

  array<Vec3> temp_airfoil_p1(8);
  array<Vec3> temp_airfoil_p2(8);

  // --- Shadow system scratch (reused each frame, never reallocated) ----
  // One silhouette's grid vertices at a time (max 6x3=18; 64 capacity).
  // shadow_vx/vy/vz = world landing; shadow_tx/ty/tz = cached cam-space
  // projection (shared across adjacent quads). Validity encoded as
  // shadow_hit_plane_key[r] != 0 (nonzero on hit, 0 on miss).
  array<double> shadow_vx(64);
  array<double> shadow_vy(64);
  array<double> shadow_vz(64);
  array<double> shadow_tx(64);
  array<double> shadow_ty(64);
  array<double> shadow_tz(64);
  // Per-vertex landing plane key (run-coalesce key for emit loop).
  // Plane-eq key (NOT triangle id): voxel ground has many coplanar tris;
  // merge needs same-plane semantics. Encoding: nx/ny/nz quantized to
  // 1/1024 (int16), d to 1/16 (int16), packed as
  // [nx_q<<48 | ny_q<<32 | nz_q<<16 | d_q]. Sentinel 0 = no hit.
  array<int64>  shadow_hit_plane_key(64);

  // ---- Ray-bundle batched raymarch scratch ----
  // Consumed by shadow_raymarch_batch. All 64-cap (max silhouette grid).
  // PER-RAY INPUT: bwx/y/z NOT MUTATED — Phase 0 writes lifted origin
  // to lwx/y/z; bwx/y/z stay original for post-batch pcache append.
  // PER-RAY OUTPUT: lx/ly/lz; Phase 3 writes hit_plane_key.
  array<double> shadow_batch_wx(64);
  array<double> shadow_batch_wy(64);
  array<double> shadow_batch_wz(64);
  // Lifted ray origin (= bwx - dx*L). See feedback_shadow_batch_wx_lift_overwrite.md.
  array<double> shadow_batch_lwx(64);
  array<double> shadow_batch_lwy(64);
  array<double> shadow_batch_lwz(64);
  array<double> shadow_batch_lx(64);
  array<double> shadow_batch_ly(64);
  array<double> shadow_batch_lz(64);
  // Hit encoded as bwsf[r] >= 0 (lockstep invariant: Phase 0 inits -1,
  // Phase 1+2 hits set it).
  array<double> shadow_batch_best_t(64);
  array<int>    shadow_batch_winner_sf_idx(64);
  array<int>    shadow_batch_winner_ci(64);
  // Sparse active ray list. Phase 0 appends non-cached rays; Phase 1
  // + reduction iterate it (no per-ray !bactive gate). Phase 2 uses
  // swap-and-pop.
  array<int>    shadow_batch_active_list(64);
  // Published after raymarch returns; used by flush's pcache Pass-B.
  int           shadow_batch_active_count = 0;
  // Per-chunk per-bucket live ray scatter. Bucket b at [b*64, b*64 + count).
  array<int>    shadow_batch_bucket_live(16 * 64);
  array<int>    shadow_batch_bucket_live_count(16);
  // Flattened per-bucket parallel scratch (eliminates double-indirection
  // in stage-1). _bt written back on cam-vis hits so intra-bucket
  // best_t tightening is preserved.
  array<double> shadow_batch_bucket_live_wx(16 * 64);
  array<double> shadow_batch_bucket_live_wy(16 * 64);
  array<double> shadow_batch_bucket_live_wz(16 * 64);
  array<double> shadow_batch_bucket_live_bt(16 * 64);
  // Per-ray (u,v) sun-perpendicular projection scattered alongside
  // wx/wy/wz/bt so 2D pre-reject doesn't need bk_live[slot]→r chase.
  array<double> shadow_batch_bucket_live_u(16 * 64);
  array<double> shadow_batch_bucket_live_v(16 * 64);
  // Per-ray (u,v) — computed once per raymarch after ORIGIN_LIFT.
  array<double> shadow_batch_perp_u(64);
  array<double> shadow_batch_perp_v(64);
  // Per-ray ray·dir hoist; per-chunk along_t = chunk_dot_dir - ray_dot_dir[r].
  array<double> shadow_batch_ray_dot_dir(64);

  // Plane-body angular screen-space bounds (cached per draw_plane_shadow).
  // Two-AABB decomp of CROSS shape (single AABB false-rejects off-cross
  // quadrants). Part 0 = wings, Part 1 = fus+vtail. Reject iff inside
  // at least one sub-AABB. Excludes gears/tw/prop (near-ground).
  array<double> plane_part_ty_min = {0.0, 0.0};
  array<double> plane_part_ty_max = {0.0, 0.0};
  array<double> plane_part_tz_min = {0.0, 0.0};
  array<double> plane_part_tz_max = {0.0, 0.0};
  array<bool>   plane_part_valid  = {false, false};

  // Static plane-local body extents. Part 0 = wings, Part 1 = fus+vtail.
  // TREAT AS CONSTANTS: never written outside this declaration (AS
  // forbids `const` on class properties — convention only).
  array<double> shadow_part_x_min = { -1.0, -45.0 };
  array<double> shadow_part_x_max = { 31.0,  75.0 };
  array<double> shadow_part_y_min = { -95.0, -12.0 };
  array<double> shadow_part_y_max = {  95.0,  12.0 };
  array<double> shadow_part_z_min = {  -3.0, -12.0 };
  array<double> shadow_part_z_max = {   7.0,  25.0 };

  // Active-piece routing. Drives piece_slot in raymarch_batch (indexes
  // shadow_last_hit_sf_idx per-piece ray cache). NOT telemetry.
  //   0=wL 1=wR 2=fus 3=hstab+el 4=pL 5=pR 6=tw 7=prop.
  int  shadow_active_piece_idx = 0;

  // Cross-call raymarch→project_silhouette scratch.
  //   rm_void_reason: 0=cam-vis nearest, 1=no sun-front, 2=cam-invis
  //     only (void), 3=fallback to deeper cam-vis past nearer cam-invis.
  //   rm_hit_plane_key: packed plane eq of winner; 0 = no hit.
  int    rm_void_reason   = 0;
  int64  rm_hit_plane_key = 0;

  // Oblique probe hit normal (multi-anchor cam-invis input).
  // Populated by shadow_distance_along_sun on hit; left zero on miss.
  // CONTRACT: callers must gate on "probe returned < MAX_T".
  double shadow_oblique_normal_x = 0.0;
  double shadow_oblique_normal_y = 0.0;
  double shadow_oblique_normal_z = 0.0;

  // 4-anchor batched probe scratch. Inputs and outputs at [0..3];
  // capacity 8 = future headroom. bt sentinel on miss = MAX_T+1.
  array<double> shadow_probe_anchor_x(8);
  array<double> shadow_probe_anchor_y(8);
  array<double> shadow_probe_anchor_z(8);
  array<double> shadow_probe_out_t(8);
  array<double> shadow_probe_out_nx(8);
  array<double> shadow_probe_out_ny(8);
  array<double> shadow_probe_out_nz(8);
  array<bool>   shadow_probe_out_hit(8);

  // Per-anchor cam-invis flags (Lever F2). 0..3 = wingR/wingL/nose/tail.
  // True = back-facing cam (cf > 0). False = cam-vis OR probe missed
  // (assume cam-vis to avoid false-skip).
  array<bool>   shadow_anchor_cam_invis(4);
  // Per-piece skip flags, 0..7 = WL/WR/FS/PR/LP/RP/TW/PD. FS always
  // false — fuselage silhouette spans nose↔tail (single anchor too coarse).
  array<bool>   shadow_piece_skip(8);

  // Shadow perf: frame-local candidate chunks + ray-distance cap.
  // Both filters only REJECT; landings are bit-identical.
  int            shadow_candidate_count = 0;
  double         shadow_max_ray_dist    = 1.0e30;
  // Adaptive cap via decaying max of recent winner_t. Dynamic cap can
  // only TIGHTEN, so per-piece-reach chunk-cache bloat
  // (project_shadow_reach_floor_landed) cannot recur via this lever.
  // Decay 0.985/frame ≈ 46-frame half-life.
  double         shadow_winner_t_max_history = 0.0;
  double         shadow_winner_t_frame_max   = 0.0;
  // Cached chunk_size half-extent (cross-object dispatch hoist).
  double         shadow_half_cs         = 0.0;

  // Silhouette-emit context (frame-constant pos+basis+colour+z_bias).
  // Set once in draw_plane_shadow; consumed by emit chain (replaces
  // 14-arg forwarding through 5 nested calls).
  double         shadow_ctx_px          = 0.0;
  double         shadow_ctx_py          = 0.0;
  double         shadow_ctx_pz          = 0.0;
  double         shadow_ctx_ofx         = 0.0;
  double         shadow_ctx_ofy         = 0.0;
  double         shadow_ctx_ofz         = 0.0;
  double         shadow_ctx_orx         = 0.0;
  double         shadow_ctx_ory         = 0.0;
  double         shadow_ctx_orz         = 0.0;
  double         shadow_ctx_oux         = 0.0;
  double         shadow_ctx_ouy         = 0.0;
  double         shadow_ctx_ouz         = 0.0;
  uint           shadow_ctx_colour      = 0;
  double         shadow_ctx_z_bias      = 0.0;

  // Cached fuselage 2D AABB. Fast-path on @FPU==@shadow_hull_out_fus_pu
  // (AS pointer-equiv); fuselage is the F-polygon for ~9/10 calls/frame.
  double         shadow_ctx_fus_min_u   = 0.0;
  double         shadow_ctx_fus_max_u   = 0.0;
  double         shadow_ctx_fus_min_v   = 0.0;
  double         shadow_ctx_fus_max_v   = 0.0;

  // Per-chunk tight-AABB half-diag (precomputed). Tight-AABB matches
  // filter's center to bound tris warped past nominal 1200³ cell.
  array<double> shadow_cand_half_diag;
  // Per-chunk tight-AABB midpoint (cached at populate; read by piece-
  // bundle filter to avoid 6-read recompute per chunk × 8 pieces).
  array<double> shadow_cand_tcx;
  array<double> shadow_cand_tcy;
  array<double> shadow_cand_tcz;

  // Sun-direction-derived populate-time caches (sun_stable invalidates
  // on rotation). chunk_dot_dir = tight_mid · -sun_dir;
  // c_t_near/far_* = pre-mul'd tight AABB slab; pc_t_near/far_* =
  // pre-mul'd position-AABB (nominal cell) slab.
  array<double> shadow_cand_chunk_dot_dir;
  array<double> shadow_cand_c_t_near_x;
  array<double> shadow_cand_c_t_far_x;
  array<double> shadow_cand_c_t_near_y;
  array<double> shadow_cand_c_t_far_y;
  array<double> shadow_cand_c_t_near_z;
  array<double> shadow_cand_c_t_far_z;
  array<double> shadow_cand_pc_t_near_x;
  array<double> shadow_cand_pc_t_far_x;
  array<double> shadow_cand_pc_t_near_y;
  array<double> shadow_cand_pc_t_far_y;
  array<double> shadow_cand_pc_t_near_z;
  array<double> shadow_cand_pc_t_far_z;
  // Per-chunk "no-warp" flag (1 = tight AABB == nominal cell on all 3
  // axes). When true, pos-AABB rescue can never succeed; gating skips
  // ~12 ops per outcome-0 ray on flat-terrain chunks.
  array<int> shadow_cand_no_warp;

  // 1D along-sun extent (|sx|·hx + |sy|·hy + |sz|·hz) ≤ 3D half_diag
  // by Cauchy-Schwarz; ~10-30% tighter for sun_z≈0.84. Used by tight
  // pre-reject + break-gate tail-max.
  array<double> shadow_cand_along_sun_extent;
  array<double> shadow_cand_max_along_sun_extent_tail;

  // ---- Pre-filtered sun-front triangle handles per chunk ----
  // Flat concatenation across candidate chunks; sf_start[ci]/_count[ci]
  // give [start, start+count). Invalidated on rebuild + sun rotation.
  // ---- Rebuild PRE-PASS scratches (exact-once resize) ----
  // Walked once to size sf_* arrays via sum of active_triangles.
  // Capacity rides max(populated_chunks.length); they don't shrink, so
  // the back is left dirty intentionally — only [0, shadow_kept_count)
  // is read. Consumers fetch via `@pop_all[shadow_kept_chunk_ci[k]]`.
  array<int>        shadow_kept_chunk_ci;
  array<int>        shadow_kept_chunk_tri_count;
  int               shadow_kept_count = 0;

  array<int>        shadow_cand_sf_start;
  array<int>        shadow_cand_sf_count;
  // Parallel flat arrays for STAGE-1 tri fields (nx/ny/nz/pd). Defers
  // any Triangle@ field access until stage 2b.
  array<double>     shadow_cand_sf_nx;
  array<double>     shadow_cand_sf_ny;
  array<double>     shadow_cand_sf_nz;
  array<double>     shadow_cand_sf_pd;
  // Parallel flat arrays for STAGE-2a tri AABB fields.
  array<double>     shadow_cand_sf_min_x;
  array<double>     shadow_cand_sf_max_x;
  array<double>     shadow_cand_sf_min_y;
  array<double>     shadow_cand_sf_max_y;
  array<double>     shadow_cand_sf_min_z;
  array<double>     shadow_cand_sf_max_z;
  // Stage-1 per-tri SUN-CONSTANT scalars (rays parallel to -sun_dir).
  //   sf_denom[i] = -n_dot_sun (strictly < -1e-9 by sun-front filter)
  //   sf_inv_denom[i] = 1/denom (mul replaces s1 survivor divide)
  array<double>     shadow_cand_sf_denom;
  array<double>     shadow_cand_sf_inv_denom;
  // Stage-2a Lever S sphere pre-reject. sf_max_corner_sq = bound_radius².
  // CORRECTNESS: bound_radius = max(|vertex - centroid|), so the sphere
  // STRICTLY CONTAINS the triangle → no false reject.
  array<double>     shadow_cand_sf_cx;
  array<double>     shadow_cand_sf_cy;
  array<double>     shadow_cand_sf_cz;
  array<double>     shadow_cand_sf_max_corner_sq;
  // Lever UV: pre-projected (u,v) of triangle centroid in sun-perp basis.
  // Inner ray loop's FIRST check (before Stage 1). With (u,v,sun_dir)
  // orthonormal and rays parallel to -sun_dir, min d_3D² = du² + dv²
  // is a strict lower bound on hit-point distance ⇒ zero false negatives.
  array<double>     shadow_cand_sf_cu;
  array<double>     shadow_cand_sf_cv;
  // Stage-2b BARYCENTRIC fields (flattened from Triangle@). Stage 2b is
  // 100% array-lookup; indexed lockstep by sf_idx ∈ [0, sf_total).
  array<double>     shadow_cand_sf_invD;
  array<double>     shadow_cand_sf_p1x;
  array<double>     shadow_cand_sf_p1y;
  array<double>     shadow_cand_sf_p1z;
  array<double>     shadow_cand_sf_v0x;
  array<double>     shadow_cand_sf_v0y;
  array<double>     shadow_cand_sf_v0z;
  array<double>     shadow_cand_sf_v1x;
  array<double>     shadow_cand_sf_v1y;
  array<double>     shadow_cand_sf_v1z;
  array<double>     shadow_cand_sf_d00;
  array<double>     shadow_cand_sf_d01;
  array<double>     shadow_cand_sf_d11;
  // Per-tri pre-quantized plane key (16-bit pack of tnx/tny/tnz/plane_d).
  // Phase 3 reads one int64 per hit-ray. Lazy-populated.
  array<int64>      shadow_cand_sf_packed_key;
  // Bucket grid 4×4 = 16 buckets/chunk. 2×2 LOST on average.
  // TREAT AS CONSTANTS: AS forbids `const` on class properties.
  int SHADOW_BUCKET_DIM         = 4;
  int SHADOW_BUCKETS_PER_CHUNK  = 16;  // SHADOW_BUCKET_DIM²

  // 2D bucket grid in sun-perpendicular plane (4×4 in (u,v) ⊥ -sun_dir).
  // Basis built from smallest-|sun_dir| cross-axis seed (protects against
  // degenerate cross when -sun_dir is axis-aligned). Straddling tris are
  // duplicated; no candidate missed.
  array<double>     shadow_cand_bucket_origin_u;
  array<double>     shadow_cand_bucket_origin_v;
  array<double>     shadow_cand_bucket_inv_size_u;
  array<double>     shadow_cand_bucket_inv_size_v;
  // Per-(chunk × bucket) tri-index ranges. meta_idx = ci * 16 + (bv*4 + bu).
  array<int>        shadow_cand_bucket_tri_start;
  array<int>        shadow_cand_bucket_tri_count;
  // Flat sf-index storage (concat per-chunk per-bucket sub-arrays).
  array<int>        shadow_cand_bucket_tri_idx;
  int               shadow_cand_bucket_tri_idx_count = 0;
  int               shadow_cand_bucket_tri_idx_reserve_hint = 1024;
  // 2-pass bucket-build scratch.
  array<int>        shadow_bucket_build_count(16);
  array<int>        shadow_bucket_build_cursor(16);
  // Touched-buckets list (inner tri loop walks these, not all 16).
  array<int>        shadow_batch_touched_buckets(16);

  // Sun-perpendicular orthonormal axes (recomputed each rebuild).
  double shadow_sun_perp_u_x = 1.0;
  double shadow_sun_perp_u_y = 0.0;
  double shadow_sun_perp_u_z = 0.0;
  double shadow_sun_perp_v_x = 0.0;
  double shadow_sun_perp_v_y = 1.0;
  double shadow_sun_perp_v_z = 0.0;
  // Reverse mapping: sf_idx → chunk_ci.
  // DEFENSIVE: fast path (Lever 1) MUST check that the cached winning
  // tri's chunk is in the current piece's Phase C filter. Without this
  // check, cache accepts an excluded chunk → geometrically-valid but
  // "wrong pose" hit (shadow-disappearing bug on canyon descent).
  array<int>        shadow_cand_sf_chunk_ci;
  // TRIED AND REVERTED: within-chunk sort key + insertion sort — rebuild
  // 8-12ms exceeded marginal tB-cull win.

  // Chunk-level along-sun sort scratch (front-to-sun order so tB-reject
  // fires early). Pack/decode at the sort site.
  array<int64>      shadow_cand_sort_packed;

  // Bucket-bounds Pass-1→Pass-2 cache. Layout: [i*4 + 0..3] =
  // bu_lo, bu_hi, bv_lo, bv_hi (i = chunk-relative tri index).
  array<int>        shadow_cand_scratch_bucket_bounds(1024);
  double            shadow_cand_sun_anchor_x = 1e30;  // force rebuild on first call
  double            shadow_cand_sun_anchor_y = 1e30;
  double            shadow_cand_sun_anchor_z = 1e30;

  // Frame-level camera scalar cache (refreshed at draw_plane_shadow entry).
  double            shadow_cfx = 0.0, shadow_cfy = 0.0, shadow_cfz = 0.0;
  double            shadow_clx = 0.0, shadow_cly = 0.0, shadow_clz = 0.0;
  double            shadow_cux = 0.0, shadow_cuy = 0.0, shadow_cuz = 0.0;
  double            shadow_cdf = 0.0, shadow_cdl = 0.0, shadow_cdu = 0.0;

  // (-sun_dir) inverse cache for fade-probe slab tests. sun_dir constant
  // within a frame; exact == on doubles is fine (no FP between caller
  // and probe entry).
  double            shadow_inv_neg_sun_dir_x = 0.0;
  double            shadow_inv_neg_sun_dir_y = 0.0;
  double            shadow_inv_neg_sun_dir_z = 0.0;
  double            shadow_inv_neg_sun_anchor_x = 1e30;
  double            shadow_inv_neg_sun_anchor_y = 1e30;
  double            shadow_inv_neg_sun_anchor_z = 1e30;

  // TRIED AND REVERTED: within-chunk tri sort — net-negative
  // (1.0-1.5ms/rebuild, tB-reject rate unchanged).

  // Populated sf_* count after most recent rebuild. NOT trimmed at tail.
  // DEFENSIVE: [0, sf_total) is fresh; [sf_total, capacity) holds stale
  // payload from prior frame and is NEVER read by any consumer.
  int shadow_cand_sf_total = 0;

  // Ray coherency cache. Per-ray sf-index of last frame's winner; fast
  // path seeds best_t before main loop. SAFE (full tri test still runs).
  // DEFENSIVE: default int init is 0 = first valid sf_idx. Rebuild branch
  // MUST fill -1 before any raymarch reads.
  int SHADOW_LH_SLOTS_PER_PIECE = 256;
  array<int> shadow_last_hit_sf_idx(8 * SHADOW_LH_SLOTS_PER_PIECE);

  // Per-piece ray-coherency cursor (ring buffer, modulo 256). Wrap
  // recycles OLDEST hits instead of clobbering newest.
  int shadow_piece_ray_cursor = 0;

  // Intra-piece vertex cache (~128 results). Adjacent sub-quads share
  // verts; pre-batch scan pre-fills internals + marks cached so Phase
  // 0/1/2 skip and Phase 3 reads bbt/blx etc. Bit-exact (wx,wy,wz) match.
  int SHADOW_PCACHE_CAP = 128;
  array<double> shadow_pcache_wx(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_wy(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_wz(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_bbt(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_blx(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_bly(SHADOW_PCACHE_CAP);
  array<double> shadow_pcache_blz(SHADOW_PCACHE_CAP);
  array<int>    shadow_pcache_bwsf(SHADOW_PCACHE_CAP);
  int shadow_pcache_count = 0;
  // pcache spatial hash. Open-addressed 256 (50% load), insert-only.
  // Hash insert DEFERRED to Pass B so within-call duplicate verts each
  // get raymarched. Wraparound guard in shadow_pcache_reset.
  int SHADOW_PCACHE_HASH_SIZE = 256;     // power of 2; 0xFF mask
  int SHADOW_PCACHE_HASH_GEN_RESET = 0x40000000;  // 2^30
  array<int> shadow_pcache_hash_idx(SHADOW_PCACHE_HASH_SIZE);
  array<int> shadow_pcache_hash_gen(SHADOW_PCACHE_HASH_SIZE);
  int shadow_pcache_hash_gen_cur = 0;

  // In-queue dedup hash. 128 slots, open addressing + linear probe.
  // Key int(wx)^int(wy)^int(wz) with FNV-style primes; collisions
  // disambiguated by double compare; probe ends at first stale-gen.
  int SHADOW_BATCH_Q_HASH_SIZE = 128;          // power of 2; 0x7F mask
  int SHADOW_BATCH_Q_HASH_GEN_RESET = 0x40000000;  // 2^30
  array<int> shadow_batch_q_hash_idx(SHADOW_BATCH_Q_HASH_SIZE);
  array<int> shadow_batch_q_hash_gen(SHADOW_BATCH_Q_HASH_SIZE);
  int shadow_batch_q_hash_gen_cur = 0;
  // Per-batch "from cache" flag (Phase 0/1 skip cached; Phase 3 reads
  // pre-filled bhit/blx/bbt/bwsf).
  array<bool> shadow_batch_cached(64);
  // In-queue alias map: alias_to[r] = src idx (within super-batch);
  // -1 = unique. Aliased rays marked cached; flush copies src outputs
  // before quad emit reads them.
  array<int> shadow_batch_alias_to(64);
  // Sparse alias list (flush iterates [0..count) only).
  array<int> shadow_batch_alias_list(64);
  int        shadow_batch_alias_count = 0;

  // Deferred-emit super-batching: project_silhouette queues rays +
  // per-quad emit specs; flush dispatches one batched raymarch + emit
  // replay. Queue 64, spec 32; auto-flush triggers on overflow.
  int  shadow_batch_queue_size = 0;
  int  shadow_q_count          = 0;
  array<int>    shadow_q_idx_base(32);
  array<int>    shadow_q_nu(32);
  array<int>    shadow_q_nv(32);
  array<double> shadow_q_max_edge_sq_tight(32);
  array<uint>   shadow_q_colour(32);
  array<double> shadow_q_z_bias(32);
  int SHADOW_Q_CAPACITY = 32;

  // Super-batching escape hatch. FALSE = per-call dispatch (one quad
  // per batch). Kept as debug switch / clean revert path.
  bool SHADOW_USE_SUPER_BATCH = true;

  // Per-bucket Z-bounds for tri-level Z-cull. dz<0 (sun_dir.z>=0.1)
  // makes ray Z monotonic; bucket bounds short-circuit tris before
  // reading plane equations. Init to (+INF,-INF) per chunk middle pass.
  array<double> shadow_batch_bk_z_min(16);
  array<double> shadow_batch_bk_z_max(16);

  // Phase C per-piece ray-bundle chunk pre-filter. Cylindrical bundle
  // along (-sun_dir); chunks perpendicular-far from bundle unreachable.
  //   shadow_piece_ci_list  = indices into shadow_cand_*
  //   shadow_piece_ci_count = -1 (no filter, fall back to identity_ci_list)
  //                           or 0..N. Conservative — rejected chunks
  //                           could not be hit by any ray.
  array<int> shadow_piece_ci_list;
  int        shadow_piece_ci_count = -1;
  // Per-piece reach cache (raymarch's per-batch reach precompute hoisted
  // from per-call to per-piece). _valid=false → fall back to per-call.
  double shadow_piece_reach_top    = 0.0;
  bool   shadow_piece_reach_valid  = false;
  // Per-piece chunk membership mask. ci "in" iff mask[ci] == mask_gen.
  // DEFENSIVE: fast path uses this O(1) check that cached tri's chunk
  // is reachable by the current piece. Gen-counter avoids per-piece
  // zero-fill (~3440 writes/frame); wraparound guard in setter.
  array<int> shadow_piece_chunk_mask;
  int        shadow_piece_mask_gen = 0;
  // Fallback identity mapping (0..n-1) for uniform chunk-loop dispatch.
  array<int> shadow_identity_ci_list;

  // TRIED AND REVERTED: per-piece filter cache across stable frames —
  // cache invalidated ~every frame at ~16u/frame velocity; net neutral.
  // Widening risked boundary misclassification.

  // Cross-piece bundle-filter share. When piece N's bundle is within
  // threshold of N-1, adopt N-1's filter. Worst-case is a looser kept
  // set, no correctness risk. Invalidated at frame start.
  bool   shadow_piece_share_valid       = false;
  double shadow_piece_share_cx          = 0.0;
  double shadow_piece_share_cy          = 0.0;
  double shadow_piece_share_cz          = 0.0;
  double shadow_piece_share_radius      = 0.0;
  int    shadow_piece_share_n_kept      = 0;
  double shadow_piece_share_reach_top   = 0.0;
  bool   shadow_piece_share_reach_valid = false;

  // Piece bundle world-space body-corner scratch. Max=20 (fuselage); 32 cap.
  array<double> shadow_bundle_wx(32);
  array<double> shadow_bundle_wy(32);
  array<double> shadow_bundle_wz(32);

  // Polygon-clipping / ear-clipping scratch.
  // Concurrent-liveness map:
  //   cx_*      sequential, shared.
  //   clipA_*   top-level clip; live across ear loop.
  //   clipB_*   nested T\F2 inside two_convex; clipA still live → separate.
  //   ear_outer outer P1 ear loop (two_convex).
  //   ear_inner nested earclip inside emit_tri_clipped_against_F2.
  //   tri_*     3-vert T scratch.
  // CONTRACT: every consumer uses indexed writes against pre-sized
  // backing (no insertLast/resize-down — keeps storage stable, no GC).
  array<int>    shadow_cx_w_edge(16);
  array<int>    shadow_cx_f_edge(16);
  array<double> shadow_cx_t_w(16);
  // F-edge delta scratch (hoists dfu/dfv out of W×F crossings inner loop).
  array<double> shadow_cx_f_du(32);
  array<double> shadow_cx_f_dv(32);
  array<double> shadow_clipA_PU(32);
  array<double> shadow_clipA_PV(32);
  array<double> shadow_clipA_HX(32);
  array<double> shadow_clipA_HY(32);
  array<double> shadow_clipA_HZ(32);
  array<double> shadow_clipB_PU(32);
  array<double> shadow_clipB_PV(32);
  array<double> shadow_clipB_HX(32);
  array<double> shadow_clipB_HY(32);
  array<double> shadow_clipB_HZ(32);
  array<int>    shadow_ear_outer_next(32);
  array<int>    shadow_ear_outer_prev(32);
  array<int>    shadow_ear_inner_next(32);
  array<int>    shadow_ear_inner_prev(32);
  // Reflex-vertex indices (sync'd with reflex_mask in earclip). Inner
  // ear-test walks these instead of full ring; O(reflex_count).
  array<int>    shadow_ear_inner_reflex(32);
  array<double> shadow_tri_PU(3);
  array<double> shadow_tri_PV(3);
  array<double> shadow_tri_HX(3);
  array<double> shadow_tri_HY(3);
  array<double> shadow_tri_HZ(3);

  // W hull receivers (shared by hull_minus_convex + two_convex; never
  // nested). Max W = HULL_CACHE_MAX_V = 20; cap 32.
  array<double> shadow_W_PU(32);
  array<double> shadow_W_PV(32);
  array<double> shadow_W_HX(32);
  array<double> shadow_W_HY(32);
  array<double> shadow_W_HZ(32);

  // ccmc out-flag: TRUE when 0 crossings + W not inside F (disjoint /
  // F⊂W). Lets two_convex route to single hull_minus_convex(W, F2).
  bool shadow_ccmc_was_disjoint = false;

  // compute_silhouette_hull_2d3d inner scratch (NEVER nested, one set;
  // sized for fuselage N=20).
  array<double> shadow_hull_scratch_PU(32);
  array<double> shadow_hull_scratch_PV(32);
  array<int>    shadow_hull_scratch_idx(32);
  array<int>    shadow_hull_scratch_H(64);

  // Hull output per emit piece. CONTRACT: callers bound by hull_count,
  // NOT .length (tail can be stale). Pieces: fus(2), wL(0), wR(1),
  // el(3). Pants/tw/prop clip against these.
  array<double> shadow_hull_out_fus_pu(32);
  array<double> shadow_hull_out_fus_pv(32);
  array<double> shadow_hull_out_fus_hx(32);
  array<double> shadow_hull_out_fus_hy(32);
  array<double> shadow_hull_out_fus_hz(32);
  array<double> shadow_hull_out_wL_pu(32);
  array<double> shadow_hull_out_wL_pv(32);
  array<double> shadow_hull_out_wL_hx(32);
  array<double> shadow_hull_out_wL_hy(32);
  array<double> shadow_hull_out_wL_hz(32);
  array<double> shadow_hull_out_wR_pu(32);
  array<double> shadow_hull_out_wR_pv(32);
  array<double> shadow_hull_out_wR_hx(32);
  array<double> shadow_hull_out_wR_hy(32);
  array<double> shadow_hull_out_wR_hz(32);
  array<double> shadow_hull_out_el_pu(32);
  array<double> shadow_hull_out_el_pv(32);
  array<double> shadow_hull_out_el_hx(32);
  array<double> shadow_hull_out_el_hy(32);
  array<double> shadow_hull_out_el_hz(32);

  // Plane-local body-hull corners (hoisted from inline initializers
  // to avoid GC-tracked allocs/sec). Static init once; pL/pR/tw bz
  // overwritten in place; prop blade scratch per blade.
  //
  // Fuselage body: 20 cross-section corners (FULLY STATIC).
  array<double> shadow_hull_fus_bx = {
    -40.0, -40.0, -40.0, -40.0,
    -10.0, -10.0, -10.0, -10.0,
     20.0,  20.0,  20.0,  20.0,
     60.0,  60.0,  60.0,  60.0,
     75.0,  75.0,  75.0,  75.0
  };
  array<double> shadow_hull_fus_by = {
     -6.0,   6.0,   6.0,  -6.0,
    -10.0,  10.0,  10.0, -10.0,
    -10.0,  10.0,  10.0, -10.0,
     -8.0,   8.0,   8.0,  -8.0,
     -5.0,   5.0,   5.0,  -5.0
  };
  array<double> shadow_hull_fus_bz = {
     -7.0,  -7.0,   7.0,   7.0,
    -11.0, -11.0,  11.0,  11.0,
    -11.0, -11.0,  11.0,  11.0,
    -11.0, -11.0,   7.0,   7.0,
     -7.0,  -7.0,   3.0,   3.0
  };

  // Left / right wings: 8 corners each — FULLY STATIC.
  array<double> shadow_hull_wL_bx = {
    31.0, -1.0,  5.0, 25.0,
    31.0, -1.0,  5.0, 25.0
  };
  array<double> shadow_hull_wL_by = {
    -10.0, -10.0, -90.0, -90.0,
    -10.0, -10.0, -90.0, -90.0
  };
  array<double> shadow_hull_wL_bz = {
      0.0,   0.0,   0.0,   0.0,
      4.0,   4.0,   4.0,   4.0
  };
  array<double> shadow_hull_wR_bx = {
    31.0, -1.0,  5.0, 25.0,
    31.0, -1.0,  5.0, 25.0
  };
  array<double> shadow_hull_wR_by = {
     10.0,  10.0,  90.0,  90.0,
     10.0,  10.0,  90.0,  90.0
  };
  array<double> shadow_hull_wR_bz = {
      0.0,   0.0,   0.0,   0.0,
      4.0,   4.0,   4.0,   4.0
  };

  // Horizontal stabilizer + elevator: 8 corners — FULLY STATIC.
  array<double> shadow_hull_el_bx = {
    -60.0, -60.0, -60.0, -60.0,
    -32.0, -32.0, -32.0, -32.0
  };
  array<double> shadow_hull_el_by = {
    -22.5,  22.5,  22.5, -22.5,
    -22.5,  22.5,  22.5, -22.5
  };
  array<double> shadow_hull_el_bz = {
      3.0,   3.0,   5.0,   5.0,
      3.0,   3.0,   5.0,   5.0
  };

  // Landing-gear pants and tail wheel: 8 corners each.
  //   bx/by are FULLY STATIC; bz is SEMI-STATIC — written in
  //   draw_plane_shadow each frame since pant_z_L/R and wheel_z_T
  //   depend on vis_comp_L/R/T (suspension compression).
  //   The array itself is pre-sized once here so the per-frame write
  //   is just 8 indexed assignments (no alloc).
  array<double> shadow_hull_pL_bx = {
     13.0,  13.0,  13.0,  13.0,
     27.0,  27.0,  27.0,  27.0
  };
  array<double> shadow_hull_pL_by = {
    -21.0, -15.0, -15.0, -21.0,
    -21.0, -15.0, -15.0, -21.0
  };
  array<double> shadow_hull_pL_bz(8);
  array<double> shadow_hull_pR_bx = {
     13.0,  13.0,  13.0,  13.0,
     27.0,  27.0,  27.0,  27.0
  };
  array<double> shadow_hull_pR_by = {
     15.0,  21.0,  21.0,  15.0,
     15.0,  21.0,  21.0,  15.0
  };
  array<double> shadow_hull_pR_bz(8);
  array<double> shadow_hull_tw_bx = {
    -45.0, -45.0, -45.0, -45.0,
    -39.0, -39.0, -39.0, -39.0
  };
  array<double> shadow_hull_tw_by = {
     -1.5,   1.5,   1.5,  -1.5,
     -1.5,   1.5,   1.5,  -1.5
  };
  array<double> shadow_hull_tw_bz(8);

  // Prop-blade scratch. Each blade is 4 corners at x=77 rotating
  // around +x with prop_angle + i*2pi/3 for i in {0,1,2}. The bx
  // array is fully static (all four equal prop_cx=77); by/bz are
  // overwritten inside the per-blade loop in draw_plane_shadow.
  array<double> shadow_hull_blade_bx = { 77.0, 77.0, 77.0, 77.0 };
  array<double> shadow_hull_blade_by(4);
  array<double> shadow_hull_blade_bz(4);

  // Prop-disc envelope (Phase C piece-bundle seed). The prop blades
  // sweep a disc of radius 34.5 centered at plane-local (77, 0, -2).
  // These 4 corners bound every blade position; used to set the piece
  // bundle ONCE for the whole prop (all 3 blades share piece idx 7).
  // Constants only — no per-frame writes.
  array<double> shadow_hull_prop_env_bx = {  77.0,  77.0,  77.0,  77.0 };
  array<double> shadow_hull_prop_env_by = { -34.5,  34.5,  34.5, -34.5 };
  array<double> shadow_hull_prop_env_bz = { -36.5, -36.5,  32.5,  32.5 };

  // ---- Candidate-cache reuse across frames ----
  // Bucket search_radius to nearest 100u + anchor cache to plane pos;
  // rebuild only when movement > CAND_MOVE_THRESHOLD or bucket changes.
  // Filter radius = bucketed + CAND_MARGIN.
  // CORRECTNESS: cache can only OVER-include — per-ray slab tests still
  // reject too-far chunks.
  double shadow_cand_anchor_x    = 0.0;
  double shadow_cand_anchor_y    = 0.0;
  double shadow_cand_anchor_z    = 0.0;
  double shadow_cand_radius_last = -1.0;  // sentinel: force rebuild on first use

  // ---- Silhouette hull cache ----
  // 7 slots (pieces 0..6) for compute_silhouette_hull_2d3d output.
  // Fingerprint = (plane_local_sun.{x,y,z}, aux). Piece 7 (prop) rotates → bypassed.
  //
  // DEFENSIVE: MAX_V=20 sized for fuselage worst-case (20 corners).
  // Smaller MAX_V produced silent cache-corruption — see comment in
  // compute_silhouette_hull_2d3d_cached.
  //
  // CONTRACT: caller must set_shadow_hull_cache_key(piece_idx, aux)
  // before compute_silhouette_hull_2d3d_cached; piece_idx=-1 bypasses.
  array<double> shadow_hull_cache_sx    = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  array<double> shadow_hull_cache_sy    = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  array<double> shadow_hull_cache_sz    = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  array<double> shadow_hull_cache_aux   = {0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
  array<int>    shadow_hull_cache_count = {0, 0, 0, 0, 0, 0, 0};
  array<bool>   shadow_hull_cache_valid = {false, false, false, false, false, false, false};
  array<double> shadow_hull_cache_pu(140);
  array<double> shadow_hull_cache_pv(140);
  array<double> shadow_hull_cache_hx(140);
  array<double> shadow_hull_cache_hy(140);
  array<double> shadow_hull_cache_hz(140);
  // Caller-set cache key. compute_silhouette_hull_2d3d_cached reads
  // these on entry. piece_idx == -1 disables caching for that call.
  int    shadow_cache_piece_idx = -1;
  double shadow_cache_aux       = 0.0;

  Vec3 camera_pos, prev_camera_pos;
  Quaternion camera_orientation, prev_camera_orientation;
  Quaternion static_pitch_rot, static_yaw_rot;

  double camera_yaw = 0.0;
  double camera_pitch = 0.0;
  double camera_lock_timer = 0.0;
  double camera_lock_blend = 0.0;
  // Smoothed gimbal-proximity factor (0=clear, 1=in singularity).
  // Asymmetric LPF (fast in, slow out): single-frame crossings activate
  // the dead zone; exit fades gradually instead of snapping back.
  double camera_gimbal_factor = 0.0;
  // Filtered camera_yaw angular velocity. Filtering the RATE (not just
  // position) keeps motion continuous across gimbal transitions —
  // accelerates/decelerates through dead-zone boundaries instead of
  // slamming to zero.
  double camera_yaw_rate = 0.0;
  // Catch-up gain latch. True while gf>0.7 (level-triggered re-assert
  // every frame in the dead zone), cleared when caught up (|dr|<0.2 +
  // gf<0.2) OR on a target_use_pf falling edge (singular crossing, see
  // camera_prev_target_use_pf). Gates catchup_gain in update_camera().
  // Per-step magnitude is bounded by the Fix #3 effective_du cap, not by
  // the latch state.
  bool camera_gimbal_armed    = false;
  // target_use_pf state from previous step. Used to detect singular
  // crossings (true→false transitions) — when atan2 loses its anchor and
  // the next recovery may put target_yaw on a totally different branch.
  bool camera_prev_target_use_pf = false;
  // Master kill-switch for catchup_gain (A/B toggle).
  bool camera_catchup_enabled = true;
  // Pole-transit yaw rebase delta accumulator. Singular crossings or
  // in-pole rebases shift camera_yaw to absorb representation flips; the
  // equal-and-opposite delta lives here so final_camera_yaw stays
  // visually continuous. CRITICAL: MUST NOT fold into mouse_yaw_offset
  // (return-to-center spring would decay compensation at ~5 rad/s and
  // reproduce the exact 180° swivel the rebase prevents). Persists
  // across transits; no spring.
  double camera_pole_yaw_offset = 0.0;
  // Persistent L hemisphere reference. Used instead of ideal_L so the
  // snap toggle locks by history (dot-with-ideal_L crosses zero in some
  // maneuvers, producing 90°+ roll discontinuity).
  double camera_prev_lx = 0.0;
  double camera_prev_ly = 1.0;

  // Consecutive snap-frame counter. When exceeds unstick threshold AND
  // outside pendulum zone, force-reset prev_L to ideal_L. Slow-drift
  // alternatives all failed because post-orthog L save every frame
  // wipes the rotation.
  int camera_snap_streak = 0;

  // Smooth roll recovery state. On stuck-state detection, recovery_l*
  // gradually rotates around F toward target_L; while in_recovery, L is
  // OVERRIDDEN — bypasses the snap+save loop. Visible effect is a smooth
  // barrel roll instead of a discrete flip.
  bool camera_in_recovery = false;
  double camera_recovery_lx = 0.0;
  double camera_recovery_ly = 1.0;
  double camera_recovery_lz = 0.0;

  double camera_distance = 500.0, camera_height = 200.0;
  double camera_fov = 800.0, camera_smoothing = 0.08;

  int last_mouse_st = 0;
  float last_mouse_x = 0;
  float last_mouse_y = 0;
  double mouse_yaw_offset = 0.0;
  double mouse_pitch_offset = 0.0;

  // Screenshot-thumbnail composer (rotation lock + orbital pivot offset).
  // Left-drag rotates orbit (spring decays on release). Middle-press
  // EDGE latches rotation_locked + folds screen-pixel deltas into
  // pivot_offset_* (world-space) at end of update_camera using current
  // (L,U). camera_pos moves in lockstep so smoothing doesn't drag back.
  // pivot_offset added into BOTH tcp_* AND look-at — subsequent left-
  // drag rotates around panned point. Double-left-click resets all.
  float last_mid_mouse_x = 0;
  float last_mid_mouse_y = 0;
  double pivot_offset_x = 0.0;
  double pivot_offset_y = 0.0;
  double pivot_offset_z = 0.0;
  // Latched on middle-press edge; held until double-left-click reset.
  // Suppresses mouse_yaw/pitch return-to-center spring.
  bool rotation_locked = false;
  // Seconds since last left-press edge (double-click threshold 0.4s).
  double left_press_age = 99.0;
  // This-frame middle-drag pixel delta — read at end of update_camera.
  float screenshot_pan_dx_pending = 0.0;
  float screenshot_pan_dy_pending = 0.0;

  Vec3 sun_dir = Vec3(0.5, 0.4, 1.0).normalize();
  uint fog_bg_color = 0xFF5895D8;
  int fog_r = 0, fog_g = 0, fog_b = 0;
  double fog_start = 1000.0;
  double fog_end = 4500.0;
  double fog_start_sq = 1000.0 * 1000.0;
  double fog_end_sq = 4500.0 * 4500.0;
  double inv_fog_sq_diff = 1.0 / (4500.0 * 4500.0 - 1000.0 * 1000.0);

  // Engine "Script FX Level" cached at init(). 0=Off, 1=Low, 2=Medium,
  // 3=High. Drives shadow gate + level-0 perf tier (fog horizon, load
  // sphere). Immutable post-init — engine UX requires level reload.
  int fx_level = 3;

  float current_h_fov = 0.0;
  float current_v_fov = 0.0;
  float current_h_bound_mult = 0.0;
  float current_v_bound_mult = 0.0;

  array<double> cpc_wpts_x;
  array<double> cpc_wpts_y;
  array<double> cpc_wpts_z;
  // Previous-frame body-point positions for the swept prism-collision
  // tunneling test (see check_prism_collision).
  array<double> cpc_prev_wpts_x;
  array<double> cpc_prev_wpts_y;
  array<double> cpc_prev_wpts_z;
  array<bool> cpc_in_range;
  // Contact point from most recent check_prism_collision(); step() reads
  // it to spawn impact smoke at the exact body-point location.
  double last_prism_hit_x = 0.0;
  double last_prism_hit_y = 0.0;
  double last_prism_hit_z = 0.0;

  // Running count of prisms the plane has destroyed this session. Bumped
  // at every shatter_prism() site (plane impact + projectile hit); consumed
  // by the HUD's 5x2 hex-grid counter (capped visually at 10) and the
  // level-end trigger below.
  int prisms_destroyed = 0;
  // Per-pip anim state for draw_prisms_destroyed_hud. Renderer detects
  // rising-edge and stamps spawn frame. spawn_frame=-1 = no anim queued.
  array<int> prism_pip_spawn_frame(10, -1);
  int prism_pip_last_destroyed_seen = 0;
  // Latch so end_level fires once per session.
  bool level_end_triggered = false;

  // Ends the level once HUD grid (10 prisms) is filled. Uses self.x()/y()
  // as the respawn anchor, matching Dustmod sample level convention.
  void maybe_end_level_on_prisms_complete() {
    if (!level_end_triggered && prisms_destroyed >= 10) {
      level_end_triggered = true;
      g.end_level(self.x(), self.y());
    }
  }
  array<double> cpc_pts_lx = {0.0, 60.0, 20.0, 20.0, -40.0, -40.0};
  array<double> cpc_pts_ly = {0.0, 0.0, -75.0, 75.0, 0.0, 0.0};
  array<double> cpc_pts_lz = {0.0, 0.0, 5.0, 5.0, -25.0, -5.0};
  array<double> cpc_pts_r = {20.0, 10.0, 5.0, 5.0, 5.0, 5.0};

  array<Triangle @> active_physics_triangles;
  int active_physics_count = 0;
  array<Triangle @>
      physics_grid(16384); // Flat array (64 cells * 256 max tris per cell)
  array<int> physics_grid_count(64);
  array<uint> physics_grid_gen(64);
  uint physics_grid_current_gen = 0;
  double physics_grid_min_x = 0, physics_grid_min_y = 0, physics_grid_min_z = 0;
  uint current_query_id = 0;

  // PACK LAYOUT INVARIANT: stride 16 doubles per face, `b = af << 4`.
  //   0..2 p1x/y/z, 3..5 p2x/y/z, 6..8 p3x/y/z, 9..11 p4x/y/z,
  //   12 is_quad (0/1), 13..15 padding (stride power-of-two for shift).
  array<double> rq_data;
  // Colour stays uint (AS double→uint for ARGB high-bit is impl-defined).
  // PACK LAYOUT INVARIANT (sort_packed):
  //   (int32(sort_dist * SORT_KEY_SCALE) << 16) | (face_idx | is_quad<<15)
  // bits 0..14 = write-order index (MAX_FACES=8000 < 2^15), bit 15 = is_quad.
  // Painter sort recovers via `pk & 0x7FFF` / `(pk & 0x8000) != 0`.
  array<uint>  rq_colour;
  array<int64> rq_sort_packed;

  int active_faces = 0;
  // Radix sort scratch: two int64 ping-pong buffers (MAX_FACES) +
  // 256-bin count table. Hoisted to members for stable storage.
  array<int64> sort_scratch_a;
  array<int64> sort_scratch_b;
  array<int>   sort_counts(256);

  array<Triangle> temp_prism_tris(20);
  array<Vec3> temp_prism_v(12);
  // Reusable corner buffer for camera-facing edge quads.
  array<Vec3> temp_edge_v(4);
  // Icosahedron 30 unique-edge index pairs (60 ints) for draw_icosahedron
  // wireframe pass. Layout: 5 top spokes around v[0], 5 top pentagon, 5
  // bottom spokes around v[3], 5 bottom pentagon, 10 equator connections.
  array<int> prism_edge_idx = {
    0, 1,  0, 8,  0, 4,  0, 5,  0, 9,
    1, 8,  8, 4,  4, 5,  5, 9,  9, 1,
    3,11,  3, 7,  3, 6,  3,10,  3, 2,
   11, 7,  7, 6,  6,10, 10, 2,  2,11,
    1, 7,  1, 6,  8, 6,  8,10,  4,10,
    4, 2,  5, 2,  5,11,  9,11,  9, 7
  };

  Vec3 cam_fwd_vec;
  Vec3 cam_left_vec;
  Vec3 cam_up_vec;

  Vec3 plane_local_cam;
  Vec3 plane_local_sun;
  Vec3 plane_local_F, plane_local_L, plane_local_U;
  double plane_cam_off_x = 0, plane_cam_off_y = 0, plane_cam_off_z = 0;

  // ---- Controls-overlay HUD (PlaneHudLogic) ----
  // Project convention: mixin classes hold methods only; all member state
  // lives on PlaneController. font_spr is lazily populated in
  // init_controls_hud(); update/draw run every frame from step()/draw().
  sprites @font_spr = null;
  float controls_hud_alpha     = 0.0f;
  float controls_hud_idle_time = 0.0f;
  // Once HUD dismissed (first input while alpha > 0), latches true so
  // HUD never reappears. Brief inputs sustain fade-out instead of
  // nicking alpha and re-rising.
  bool controls_hud_dismissed = false;
  // Previous-frame input snapshot for edge detection. Mouse buttons read
  // via g.mouse_state(0) bits 0x4 (left), 0x1/0x2/0x8 (right), 0x10 (mid).
  int  prev_hud_x_intent   = 0;
  int  prev_hud_y_intent   = 0;
  bool prev_hud_jump       = false;
  bool prev_hud_dash       = false;
  bool prev_hud_taunt_btn  = false;
  bool prev_hud_light      = false;
  bool prev_hud_heavy      = false;
  bool prev_hud_left_click   = false;
  bool prev_hud_right_click  = false;
  bool prev_hud_middle_click = false;

  PlaneController() {
    @g = get_scene();
    inertia.set(mass * 4500.0, mass * 3000.0, mass * 8000.0);
    inv_mass = 1.0 / mass;
    inv_inertia.set(1.0 / inertia.x, 1.0 / inertia.y, 1.0 / inertia.z);
  }

  void init(script @s, scriptenemy @self) {
    @ this.self = self;
    @ this.sc = s;
    self.auto_physics(false);
    setup_colors();

    // Load Dustman + apple assets and bake one instance each.
    stl_dustman.load_from_embed("dm_stl");      // base-block filter ON (default)
    stl_apple.load_from_embed("apple", false);   // base-block filter OFF — apple verts aren't unit-scale
    // Tag stem faces ONCE on shared apple asset. Heuristic: face is stem
    // iff (maxR<=R_T AND cy>=Y_LO) AND any of:
    //   (A) cy>=Y_HI → upper stem above body
    //   (B) face normal OUTWARD → outward-dimple stem
    //   (C) face normal HORIZONTAL → inverted-winding cyl
    // (C) handles mesh's inconsistent stem-cyl winding; winding-agnostic.
    stl_apple.tag_stem_y_up();
    {
      StlInstance @inst = StlInstance();
      inst.set_asset(@stl_dustman);
      // -X end of runway behind the plane/camera. Runway x=[-1600, 2400];
      // Dustman at x=-1300 with 300u clearance to runway's -X edge.
      // (tx, ty, tz) = WORLD CENTROID (bake pivots rotations around it).
      // Feet on runway (z=0): tz = (max_z-min_z)/2*scale. yaw=+PI/2 puts
      // side profile facing cockpit when you look back.
      double dm_scale = 300.0;
      double dm_tz = (stl_dustman.model_max_z - stl_dustman.model_min_z) * 0.5 * dm_scale;
      double dm_yaw = double(PI) / 2.0;
      // Four-light rig (world-space directions).
      inst.key_light_x = -0.5;
      inst.key_light_y = 0.4;
      inst.key_light_z = 1.0;
      inst.key_light_intensity = 0.2;
      inst.under_light_x = 0.0;
      inst.under_light_y = -0.5;
      inst.under_light_z = -1.0;
      inst.under_light_intensity = 0.15;
      inst.rim_light_x = -0.5;
      inst.rim_light_y = -0.4;
      inst.rim_light_z = -0.5;
      inst.rim_light_intensity = 0.2;
      inst.set_transform(-1300.0, 200.0, dm_tz, dm_scale, dm_yaw);
      inst.bake_world_transform();
      stl_instances.insertLast(inst);
    }
    // Apple distribution. Each spawn pairs by index with one of the
    // [entity] apple_N fields on class script (main.cpp). On collection
    // physics calls hitTheApple(ap.entity_id); entity_id==0 skipped.
    spawn_apple_at( 7476.58,  -2800.28, -14397.1, sc.apple_1);
    spawn_apple_at(-12012.5,  -7896.18,  13980.4, sc.apple_2);
    spawn_apple_at( 8873.8,  -12112.7,   -6005.75, sc.apple_3);

    // NEW: Pre-warm all pools to eliminate runtime Garbage Collection
    for (int i = 0; i < 30; i++)
      prism_pool.insertLast(FloatingPrism());
    // Apples are sparse — 16 covers expected level distribution with headroom.
    for (int i = 0; i < 16; i++)
      apple_pool.insertLast(Apple());
    for (int i = 0; i < 250; i++)
      particle_pool.insertLast(Particle());
    for (int i = 0; i < 150; i++)
      trail_pool.insertLast(TrailPoint());
    for (int i = 0; i < 80; i++)
      smoke_pool.insertLast(Smoke());
    for (int i = 0; i < 150; i++)
      fragment_pool.insertLast(PrismFragment());
    for (int i = 0; i < 30; i++)
      projectile_pool.insertLast(Projectile());
    // Wind streamers: cap WIND_MAX_STREAMS=12. Pool 16 covers cap +
    // headroom for in-flight expiries at sustained spawn rate.
    for (int i = 0; i < 16; i++)
      wind_stream_pool.insertLast(WindStream());
    for (int i = 0; i < 60; i++)
      chunk_manager.chunk_pool.insertLast(Chunk());

    // Pre-generate 16 runway chunks before first step() (process_queue
    // 2/frame budget would otherwise show ~5-10 frames of pop-in).
    chunk_manager.preload_runway();

    // Preload world within ~3600u sphere (radius=3 ≈ 113 chunks → ~50-70
    // mesh-gens) + sync resolve prism candidates. Eliminates takeoff
    // pop-in within fog_end=4500u.
    {
      uint ppc_init = (sc !is null) ? sc.prism_per_super_cell : uint(4);
      uint pss_init = (sc !is null) ? sc.prism_spawn_seed     : uint(70);
      // Placement tuning knobs (main.cpp [text] fields).
      double pr_dm_i = (sc !is null) ? double(sc.pr_dist_min)  : 2000.0;
      double pr_tn_i = (sc !is null) ? double(sc.pr_terr_min)  : 1000.0;
      double pr_tx_i = (sc !is null) ? double(sc.pr_terr_max)  : 2400.0;
      double pr_tc_i = (sc !is null) ? double(sc.pr_tri_clear) :  280.0;
      uint   pr_dt_i = (sc !is null) ? sc.pr_dens_tol          : uint(1);
      chunk_manager.preload_world(3, ppc_init, pss_init,
                                  floating_prisms, prism_pool,
                                  pr_dm_i, pr_tn_i, pr_tx_i,
                                  pr_tc_i, pr_dt_i);
    }

    fog_r = (fog_bg_color >> 16) & 0xFF;
    fog_g = (fog_bg_color >> 8) & 0xFF;
    fog_b = fog_bg_color & 0xFF;

    // Cache engine FX level. Off (0) trims fog horizon; pairs with the
    // 1-chunk-smaller load sphere in step() for FPS on low-end. Levels
    // 1/2/3 use shipped 4500u horizon.
    fx_level = (g !is null) ? g.get_script_fx_level() : 3;
    if (fx_level <= 0) {
      fog_end         = 4000.0;
      fog_end_sq      = fog_end * fog_end;
      inv_fog_sq_diff = 1.0 / (fog_end_sq - fog_start_sq);
    }

    // Safe initial spawn parameters for the generated runway
    pos.set(double(self.x()), 200.0, 150.0);
    prev_pos = pos;
    orientation.w = 1;
    prev_orientation = orientation;

    camera_yaw = 0.0;
    camera_pitch = 0.0;
    camera_gimbal_factor = 0.0;
    camera_yaw_rate = 0.0;
    camera_gimbal_armed = false;
    camera_prev_target_use_pf = false;
    camera_pole_yaw_offset = 0.0;
    // Init prev_L from ideal_L of initial fcy. DEFENSIVE: without this,
    // default (0,1) mismatches actual orientation at frame 1 (mouse_yaw
    // _offset=-0.8 → fcy≈-0.8); Fix #8 would lock wrong hemisphere →
    // permanent 180° roll for the session.
    double _init_fcy = camera_yaw + mouse_yaw_offset + camera_pole_yaw_offset;
    camera_prev_lx = -sin(_init_fcy);
    camera_prev_ly = cos(_init_fcy);

    // Fix #9 v7 recovery state
    camera_in_recovery = false;
    camera_recovery_lx = camera_prev_lx;
    camera_recovery_ly = camera_prev_ly;
    camera_recovery_lz = 0.0;
    camera_snap_streak = 0;

    // Start the camera above and to the right, looking diagonally down-left
    mouse_yaw_offset = -0.8;
    mouse_pitch_offset = -0.6;

    // Temporarily force 100% smoothing to snap the camera instantly to the
    // target offset
    double old_smoothing = camera_smoothing;
    camera_smoothing = 1.0;
    update_camera();
    camera_smoothing = old_smoothing;

    // Now lock in the prev variables so it doesn't try to interpolate from
    // 0,0,0
    prev_camera_pos = camera_pos;
    prev_camera_orientation = camera_orientation;

    rq_data.resize(MAX_FACES * 16);
    rq_colour.resize(MAX_FACES);
    rq_sort_packed.resize(MAX_FACES);
    sort_scratch_a.resize(MAX_FACES);
    sort_scratch_b.resize(MAX_FACES);

    cpc_wpts_x.resize(6);
    cpc_wpts_y.resize(6);
    cpc_wpts_z.resize(6);
    cpc_prev_wpts_x.resize(6);
    cpc_prev_wpts_y.resize(6);
    cpc_prev_wpts_z.resize(6);
    cpc_in_range.resize(6);

    temp_prism_tris.resize(20);
    temp_prism_v.resize(12);
    temp_edge_v.resize(4);

    // Controls-overlay HUD — load font sprite-set "script" once. Idle
    // tracking + fade lives in step()/draw() (PlaneHudLogic).
    init_controls_hud();
  }

  void setup_colors() {
    if (character == "dustman") {
      col_primary = 0xFF9AB4E3;
      col_secondary = 0xFF6A84C0;
    } else if (character == "dustgirl") {
      col_primary = 0xFFA05755;
      col_secondary = 0xFF7F4544;
    } else if (character == "dustworth") {
      col_primary = 0xFFAAC27C;
      col_secondary = 0xFF839A53;
    } else if (character == "dustkid") {
      col_primary = 0xFFC49AE5;
      col_secondary = 0xFFA06AC2;
    } else {
      col_primary = 0xFFEECC00;
      col_secondary = 0xFFCCAA00;
    }
  }
};