// Plane_HUD.cpp — Controls-overlay HUD (idle fade-in font sprite text).
//
// Composes into PlaneController as a mixin. Owns:
//   - font_spr  : sprites@ holding the build_sprites-registered font
//                 glyphs (sprite-set "script"; names "font_<glyph>" —
//                 1/2/3, a-w + y, '/', ':' — see main.cpp::build_sprites).
//   - controls_hud_alpha     : current display alpha [0..HUD_MAX_ALPHA].
//   - controls_hud_idle_time : seconds since last detected input.
//
// Trigger: 3 seconds of zero input → fade in to alpha=HUD_MAX_ALPHA
// (=0.7) over ~0.6s. ANY input — pre-show or post-show — latches
// `controls_hud_dismissed` and fades to 0 over ~0.5s. Once dismissed,
// the HUD never re-shows for the rest of the level (so e.g. holding
// dash from spawn locks it off, even if the player then idles).
//
// Wiring (PlaneController.cpp):
//   * init_controls_hud() called from PlaneController::init() AFTER `g`/`sc`
//     are wired but it doesn't depend on them — sprite-set load only.
//   * step_controls_hud() called once per frame from PlanePhysicsLogic::step()
//     to accumulate idle time and observe inputs on `self`.
//   * draw_controls_hud() called from PlaneRenderLogic::draw() inside the
//     HUD section (after instruments, before the perf log block).
//
// Coords: HUD logical area is 1600x900 centered at (0,0). Top-left
// corner = (-800,-450), bottom-right = (+800,+450). Instrument cluster
// (attitude indicator, engine dial, prism pips) anchors bottom-RIGHT
// around (att_cx≈720, att_cy≈370). Controls panel anchors bottom-LEFT:
// 8 lines stacked at HUD_LINE_HEIGHT=24u spacing, bottom line at y=380,
// top line at y=380 - 7*24 = 212. Left column (labels) starts at
// x=-780; right column (action names) at x=-540 — same x for every
// row so the action names form a tidy vertical stack.

// Tunables — file-scope const (feedback_as_no_const_class_props.md: AS
// rejects `const` on class properties, mixin holds methods only).
//
// Idle threshold + fade rates. Rates are 1/seconds. MAX_ALPHA caps
// steady-state opacity at 70% so HUD reads as a soft hint, not a
// primary layer competing with the instrument cluster.
const float HUD_IDLE_THRESHOLD_S = 2.0f;
const float HUD_FADE_IN_RATE     = 1.0f / 0.6f;
const float HUD_FADE_OUT_RATE    = 1.0f / 0.7f;
const float HUD_MAX_ALPHA        = 0.7f;

// Glyph render. Native font size 12 (~12px tall PNGs). SCALE=1.0 →
// ~12 logical-HUD-units tall. ADVANCE = center-to-center spacing
// between adjacent glyphs. LINE_HEIGHT = center-to-center vertical
// spacing (24 = ~12 glyph + ~12 gap, ~1 glyph-height of breathing).
//
// Per-glyph advance overrides for non-uniform widths, tuned by eye:
// 'i' narrowest, '/' narrow-but-wider-than-i, space at half-width
// (blank slot reads too gappy at full), 'm' and 'w' wider than baseline.
// Add more branches in hud_glyph_advance() if other glyphs develop similar symptoms.
const float HUD_GLYPH_SCALE         = 1.0f;
const float HUD_GLYPH_ADVANCE       = 18.0f;
const float HUD_GLYPH_ADVANCE_I     =  7.0f;
const float HUD_GLYPH_ADVANCE_SLASH = 12.0f;
const float HUD_GLYPH_ADVANCE_SPACE =  9.0f;
const float HUD_GLYPH_ADVANCE_M     = 22.0f;
const float HUD_GLYPH_ADVANCE_W     = 23.0f;
const float HUD_LINE_HEIGHT         = 24.0f;

// White tint baseline. Alpha byte OR'd in at draw time from
// controls_hud_alpha. NB: MULTIPLY tint — keep font PNGs
// white-on-transparent for a pure white render.
const uint  HUD_TEXT_RGB         = 0x00FFFFFF;

mixin class PlaneHudLogic {

  void init_controls_hud() {
    @font_spr = create_sprites();
    // Standard sprite-set name for build_sprites-registered sprites.
    font_spr.add_sprite_set("script");
  }

  // Returns true if any controllable input is currently being applied.
  // Conservative — held-state OR edge-detect on each of the 7 standard
  // intent channels + left/right/middle mouse buttons means we don't
  // miss single-frame taps. Mouse-button decode mirrors the camera-
  // drag path in PlanePhysicsLogic::step() (bit 0x4 = left, bits
  // 0x1/0x2/0x8 = right, bit 0x10 = middle/scroll-wheel).
  bool controls_hud_input_active() {
    if (self is null) return false;
    int xi = self.x_intent();
    int yi = self.y_intent();
    bool jump  = self.jump_intent()  > 0;
    bool dash  = self.dash_intent()  > 0;
    bool taunt = self.taunt_intent() > 0;
    bool light = self.light_intent() > 0;
    bool heavy = self.heavy_intent() > 0;

    int mst = (g !is null) ? g.mouse_state(0) : 0;
    bool left_click   = (mst & 0x4) != 0;
    bool right_click  = (mst & 0x1) != 0 || (mst & 0x2) != 0 || (mst & 0x8) != 0;
    bool middle_click = (mst & 0x10) != 0;

    bool any_held =
        xi != 0 || yi != 0 ||
        jump || dash || taunt || light || heavy ||
        left_click || right_click || middle_click;

    bool any_change =
        xi != prev_hud_x_intent ||
        yi != prev_hud_y_intent ||
        jump         != prev_hud_jump         ||
        dash         != prev_hud_dash         ||
        taunt        != prev_hud_taunt_btn    ||
        light        != prev_hud_light        ||
        heavy        != prev_hud_heavy        ||
        left_click   != prev_hud_left_click   ||
        right_click  != prev_hud_right_click  ||
        middle_click != prev_hud_middle_click;

    prev_hud_x_intent   = xi;
    prev_hud_y_intent   = yi;
    prev_hud_jump       = jump;
    prev_hud_dash       = dash;
    prev_hud_taunt_btn  = taunt;
    prev_hud_light      = light;
    prev_hud_heavy      = heavy;
    prev_hud_left_click   = left_click;
    prev_hud_right_click  = right_click;
    prev_hud_middle_click = middle_click;

    return any_held || any_change;
  }

  // Per-frame state advance. Called from PlanePhysicsLogic::step().
  // States: WAITING → FADING_IN/VISIBLE → DISMISSING → DONE (terminal).
  //
  // Dismissal latches on the FIRST input observed regardless of alpha
  // (includes pre-show inputs — held dash from spawn locks HUD off).
  // Once latched, fade-out continues every frame regardless of input
  // state, so brief taps still fully dismiss.
  void step_controls_hud() {
    // Already dismissed: monotone fade-out to 0, then hold there.
    // Skip input polling entirely — it can't do anything anymore.
    if (controls_hud_dismissed) {
      if (controls_hud_alpha > 0.0f) {
        controls_hud_alpha -= HUD_FADE_OUT_RATE * DT;
        if (controls_hud_alpha < 0.0f) controls_hud_alpha = 0.0f;
      }
      return;
    }

    bool active = controls_hud_input_active();
    if (active) {
      // Any input — pre-show or post-show — latches permanent
      // dismissal. The fade-out subtraction is a no-op while alpha=0
      // (clamps below) so pre-show input just locks the HUD off.
      controls_hud_dismissed = true;
      controls_hud_alpha -= HUD_FADE_OUT_RATE * DT;
      if (controls_hud_alpha < 0.0f) controls_hud_alpha = 0.0f;
    } else {
      controls_hud_idle_time += DT;
      if (controls_hud_idle_time >= HUD_IDLE_THRESHOLD_S) {
        controls_hud_alpha += HUD_FADE_IN_RATE * DT;
        if (controls_hud_alpha > HUD_MAX_ALPHA) controls_hud_alpha = HUD_MAX_ALPHA;
      }
    }
  }

  // Map a single character (uint code point — string[i] returns uint
  // in AS) to its registered sprite name. Returns "" for chars without
  // a glyph; caller still advances cursor so layout stays stable.
  //
  // Embedded glyphs: 1, 2, 3 (digits leftover from test123); a-w + y
  // (lowercase letters minus q/x/z which the 8 control lines don't
  // need); '/' and ':'. Uppercase A-Z folds to lowercase first since
  // the font has only lowercase glyphs.
  string hud_glyph_name(uint ch) {
    // Fold uppercase to lowercase.
    if (ch >= 0x41 && ch <= 0x5A) ch += 0x20;

    // Digits 1-3 (only digits embedded — extend if ever needed).
    if (ch >= 0x31 && ch <= 0x33) {
      string s = " "; s[0] = ch;
      return "font_" + s;
    }

    // Lowercase a-z minus q (0x71), x (0x78), z (0x7A).
    if (ch >= 0x61 && ch <= 0x7A) {
      if (ch == 0x71 || ch == 0x78 || ch == 0x7A) return "";
      string s = " "; s[0] = ch;
      return "font_" + s;
    }

    // Symbols.
    if (ch == 0x2F) return "font_u002f"; // /
    if (ch == 0x3A) return "font_u003a"; // :

    return "";
  }

  // Returns the cursor advance to apply AFTER rendering character `ch`.
  // Per-glyph because the font is non-uniform: 'i' and '/' render
  // narrower than the default 18u (would leave a gap), 'm'/'w' render
  // wider (would overlap the next glyph), and space gets ~half width
  // so word breaks don't read as huge gaps. Everything else uses the
  // default.
  float hud_glyph_advance(uint ch) {
    if (ch >= 0x41 && ch <= 0x5A) ch += 0x20; // fold uppercase
    if (ch == 0x69) return HUD_GLYPH_ADVANCE_I;     // 'i'
    if (ch == 0x6D) return HUD_GLYPH_ADVANCE_M;     // 'm'
    if (ch == 0x77) return HUD_GLYPH_ADVANCE_W;     // 'w'
    if (ch == 0x2F) return HUD_GLYPH_ADVANCE_SLASH; // '/'
    if (ch == 0x20) return HUD_GLYPH_ADVANCE_SPACE; // ' '
    return HUD_GLYPH_ADVANCE;
  }

  // Total advance width of `text` from first glyph center to last
  // glyph center. Sum of per-glyph advances for chars [0..n-2] — the
  // last glyph's trailing advance doesn't affect end-of-text.
  float hud_text_width(string text) {
    float w = 0.0f;
    int n = int(text.length());
    for (int i = 0; i < n - 1; i++) {
      w += hud_glyph_advance(text[i]);
    }
    return w;
  }

  // Internal: walk `text` left-to-right placing glyph sprites along a
  // per-glyph cursor. start_x is the CENTER of the first glyph (matches
  // engine sprite-position convention). Each glyph advances the cursor
  // by hud_glyph_advance(ch), so narrow chars like 'i' don't leave a
  // gap. Layer 22 / sub_layer 22 keeps the text above instruments.
  void draw_controls_hud_glyphs(string text, float start_x, float cy) {
    if (font_spr is null) return;
    if (controls_hud_alpha <= 0.0f) return;

    int n = int(text.length());
    if (n <= 0) return;

    // Pack alpha (0..255) into the high byte of an ARGB white.
    uint a8 = uint(controls_hud_alpha * 255.0f);
    if (a8 > 255) a8 = 255;
    uint colour = (a8 << 24) | HUD_TEXT_RGB;

    float cursor_x = start_x;
    for (int i = 0; i < n; i++) {
      uint ch = text[i];
      string glyph = hud_glyph_name(ch);
      if (glyph != "") {
        font_spr.draw_hud(
            22, 22,
            glyph, 0, 1,
            cursor_x, cy,
            0.0f,
            HUD_GLYPH_SCALE, HUD_GLYPH_SCALE,
            colour);
      }
      cursor_x += hud_glyph_advance(ch);
    }
  }

  // Center `text` horizontally on cx.
  void draw_controls_hud_text(string text, float cx, float cy) {
    int n = int(text.length());
    if (n <= 0) return;
    float total_w = hud_text_width(text);
    draw_controls_hud_glyphs(text, cx - total_w * 0.5f, cy);
  }

  // Left-align `text` so the first glyph's center sits at left_x.
  void draw_controls_hud_text_left(string text, float left_x, float cy) {
    draw_controls_hud_glyphs(text, left_x, cy);
  }

  // Top-level draw entry called from PlaneRenderLogic::draw().
  // Two-column control reference card. 8 rows top-down. Both columns
  // left-aligned (right_col_x same for every row → tidy vertical stack
  // regardless of label length). Bottom row at bottom_y; rows stack
  // upward at HUD_LINE_HEIGHT spacing. right_col_x sits clear of the
  // longest left label ("LIGHT/HEAVY:", ~193u + trailing ':').
  void draw_controls_hud() {
    if (controls_hud_alpha <= 0.0f) return;

    float bottom_y    = 380.0f;
    float left_col_x  = -780.0f;
    float right_col_x = -558.0f;

    // 8 rows in display order (top → bottom). Parallel arrays.
    // Strings written in caps to preserve user intent — hud_glyph_name
    // folds A-Z to a-z transparently.
    array<string> labels = {
      "JUMP:",
      "TAUNT:",
      "UP/DOWN:",
      "RIGHT/LEFT:",
      "LIGHT/HEAVY:",
      "DASH:",
      "RIGHT CLICK:",
      "LEFT CLICK:"
    };
    array<string> values = {
      "THROTTLE",
      "BRAKE",
      "ELEVATOR",
      "AILERON",
      "RUDDER",
      "BOOST",
      "FIRE",
      "CAMERA"
    };

    // Top-line y is 7 line-heights above the bottom-most line.
    float top_y = bottom_y - 7.0f * HUD_LINE_HEIGHT;
    for (int i = 0; i < 8; i++) {
      float y = top_y + float(i) * HUD_LINE_HEIGHT;
      draw_controls_hud_text_left(labels[i], left_col_x, y);
      draw_controls_hud_text_left(values[i], right_col_x, y);
    }
  }
};
