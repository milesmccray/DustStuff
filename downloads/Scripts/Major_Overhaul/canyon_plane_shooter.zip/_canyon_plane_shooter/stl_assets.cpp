// stl_assets.cpp
// Static mesh assets loaded from embedded ASCII STL files. STL tris are
// SOLO (live in StlInstance, not Chunk), keeping the leader/follower
// pair-stride render path in Plane_Render.cpp (i+=2) intact.
//
// TRAP: do NOT add StlInstance world_tris to Chunk.triangles via
// add_triangle. The render's i+=2 stride would mis-pair them with
// neighboring terrain tris and corrupt rendering. Render/physics
// pick up STL via dedicated stride-1 walks added in Phase 2/4.

// Pre-normalized sun direction (matches ChunkManager default 0.5,0.4,1.0).
// Hoisted file-scope so per-bake setup skips a sqrt + 1 div + 4 muls.
// WARNING: keep in sync if terrain sun moves — STL tris must match
// add_triangle shading for the fog path that reads col_r/col_g/col_b.
//   raw |(0.5,0.4,1.0)| = sqrt(1.41); inv = 1/sqrt(1.41).
const double STL_SUN_DX = 0.42093029889538335;  // 0.5 / sqrt(1.41)
const double STL_SUN_DY = 0.33674423911630668;  // 0.4 / sqrt(1.41)
const double STL_SUN_DZ = 0.84186059779076670;  // 1.0 / sqrt(1.41)

// StlAsset: immutable model-space geometry shared across StlInstances.
// verts is flat: tri_idx * 9 + (0..8) = p1xyz, p2xyz, p3xyz. STL
// "facet normal" lines are discarded — Triangle.set() recomputes from
// edge cross-product, which every consumer reads.
class StlAsset {
  array<double> verts;
  int tri_count = 0;

  // Model-space AABB.
  double model_min_x = 0.0, model_max_x = 0.0;
  double model_min_y = 0.0, model_max_y = 0.0;
  double model_min_z = 0.0, model_max_z = 0.0;
  bool loaded = false;

  // Optional per-face classification populated by a tagger pass (e.g.
  // tag_stem_y_up). 0 = body, 1 = stem/alt. Length 0 or tri_count.
  // Bake reads as flat uint8 lookup for branch-free color swap.
  array<uint8> face_class;
  bool has_face_classes = false;

  // Cached model-space per-tri data populated by bake_extras (auto-called
  // at end of load_from_embed). Lets bake_world_transform skip per-tri
  // cross-product+sqrt for normal and 9-sq-dist+sqrt for bound_radius —
  // both rotation/scale-invariant under uniform-scale + rotation.
  //   normals[t*3..+2] — unit model-space normal; world = R * model_n.
  //   bound_radii[t]   — model-space tight sphere radius about centroid;
  //                      world = scale * bound_radii[t].
  array<double> normals;
  array<double> bound_radii;
  bool extras_baked = false;

  // Model-AABB centroid — rotation pivot for bake. Populated by
  // bake_extras alongside normals/bound_radii. Pre-folded so bake skips
  // 6 member dispatches + 3 muls + 3 adds per call.
  double model_centroid_x = 0.0;
  double model_centroid_y = 0.0;
  double model_centroid_z = 0.0;

  StlAsset() {}

  // filter_base_block: true for dm.txt (skips the ImageToStl.com
  // exporter pedestal — facets with all 3 verts on |x|=1∧|y|=1
  // columns). Leave false for non-unit-scale models (apple.txt etc.)
  // — the test would otherwise drop nothing or drop everything.
  void load_from_embed(string embed_name, bool filter_base_block = true) {
    if (!has_embed_value(embed_name)) {
      puts("StlAsset[" + embed_name + "]: embed not found");
      return;
    }
    string data = get_embed_value(embed_name);
    array<string> @lines = data.split("\n");
    uint nL = lines.length();

    // First pass: count facets for exact alloc (no insertLast churn).
    int n_tri = 0;
    for (uint i = 0; i < nL; i++) {
      if (lines[i].findFirst("facet normal") >= 0) n_tri++;
    }
    if (n_tri == 0) {
      puts("StlAsset[" + embed_name + "]: zero facets parsed");
      return;
    }
    verts.resize(n_tri * 9);

    // Second pass: state machine. "facet normal" → 3 "vertex" lines →
    // "endfacet". Defensive: skip and resync on malformed input.
    // Base-block filter: pedestal facets (all 3 verts on |x|=1∧|y|=1
    // columns) don't bump t_idx, so the next valid facet overwrites
    // the slots. AABB accumulation deferred to endfacet so block-vert
    // extremes don't pollute it.
    int t_idx = 0;
    int v_in_tri = 0;
    bool in_facet = false;
    bool first_v = true;
    bool facet_is_block = true; // assume; cleared by any non-corner vert
    int blocks_skipped = 0;

    for (uint i = 0; i < nL; i++) {
      string ln = lines[i];

      if (ln.findFirst("facet normal") >= 0) {
        in_facet = true;
        v_in_tri = 0;
        // When filter is off, facet never flips to block; skip branch never fires.
        facet_is_block = filter_base_block;
        continue;
      }
      if (!in_facet) continue;
      if (ln.findFirst("endfacet") >= 0) {
        in_facet = false;
        if (v_in_tri == 3) {
          if (facet_is_block) {
            blocks_skipped++;
            // Discard: slots get overwritten by next tri.
          } else {
            // Keep: AABB-accumulate the just-written 3 verts.
            int base = t_idx * 9;
            for (int j = 0; j < 3; j++) {
              double xj = verts[base + j * 3];
              double yj = verts[base + j * 3 + 1];
              double zj = verts[base + j * 3 + 2];
              if (first_v) {
                model_min_x = model_max_x = xj;
                model_min_y = model_max_y = yj;
                model_min_z = model_max_z = zj;
                first_v = false;
              } else {
                if (xj < model_min_x) model_min_x = xj;
                else if (xj > model_max_x) model_max_x = xj;
                if (yj < model_min_y) model_min_y = yj;
                else if (yj > model_max_y) model_max_y = yj;
                if (zj < model_min_z) model_min_z = zj;
                else if (zj > model_max_z) model_max_z = zj;
              }
            }
            t_idx++;
          }
        }
        continue;
      }

      int vpos = ln.findFirst("vertex");
      if (vpos < 0) continue;
      if (v_in_tri >= 3) continue; // defensive: skip extra verts

      // Tokenize 3 floats after "vertex". Defensive on whitespace
      // runs and Windows CRLF (parseFloat ignores trailing garbage).
      string after = ln.substr(uint(vpos + 6));
      array<string> @toks = after.split(" ");
      double vx = 0.0, vy = 0.0, vz = 0.0;
      int got = 0;
      for (uint k = 0; k < toks.length(); k++) {
        if (toks[k].length() == 0) continue;
        if (got == 0) vx = parseFloat(toks[k]);
        else if (got == 1) vy = parseFloat(toks[k]);
        else if (got == 2) {
          vz = parseFloat(toks[k]);
          got++;
          break;
        }
        got++;
      }

      // Block-corner test: |x|<0.999 OR |y|<0.999 → not block.
      double ax_v = vx < 0 ? -vx : vx;
      double ay_v = vy < 0 ? -vy : vy;
      if (ax_v < 0.999 || ay_v < 0.999) facet_is_block = false;

      int slot = t_idx * 9 + v_in_tri * 3;
      verts[slot] = vx;
      verts[slot + 1] = vy;
      verts[slot + 2] = vz;

      v_in_tri++;
    }

    tri_count = t_idx;
    loaded = (tri_count > 0);

    // Shrink to actual count if any block facets were skipped.
    if (int(verts.length()) > tri_count * 9) verts.resize(tri_count * 9);

    // Populate model-space normal + bound-radius cache for bake reuse.
    bake_extras();
  }

  // Compute model-space per-tri unit normals + bounding-sphere radii.
  // Mirrors Triangle.set() math so bakes can skip recomputation per
  // frame on spinning instances. Idempotent (extras_baked guard).
  void bake_extras() {
    if (extras_baked || tri_count == 0) return;
    normals.resize(tri_count * 3);
    bound_radii.resize(tri_count);

    // Cache model-AABB centroid — rotation pivot used by bake every
    // frame on spinning instances. Computed here once so bake skips
    // 6 member reads + 3 muls + 3 adds per call.
    model_centroid_x = (model_min_x + model_max_x) * 0.5;
    model_centroid_y = (model_min_y + model_max_y) * 0.5;
    model_centroid_z = (model_min_z + model_max_z) * 0.5;

    for (int t = 0; t < tri_count; t++) {
      int b = t * 9;
      double v1x = verts[b],     v1y = verts[b + 1], v1z = verts[b + 2];
      double v2x = verts[b + 3], v2y = verts[b + 4], v2z = verts[b + 5];
      double v3x = verts[b + 6], v3y = verts[b + 7], v3z = verts[b + 8];

      // Edge cross → unnormalized normal (matches Triangle.set()).
      double e1x = v2x - v1x, e1y = v2y - v1y, e1z = v2z - v1z;
      double e2x = v3x - v1x, e2y = v3y - v1y, e2z = v3z - v1z;
      double cnx = e1y * e2z - e1z * e2y;
      double cny = e1z * e2x - e1x * e2z;
      double cnz = e1x * e2y - e1y * e2x;
      double n_len_sq = cnx * cnx + cny * cny + cnz * cnz;
      int no = t * 3;
      if (n_len_sq > 1.0e-18) {
        double inv = 1.0 / sqrt(n_len_sq);
        normals[no]     = cnx * inv;
        normals[no + 1] = cny * inv;
        normals[no + 2] = cnz * inv;
      } else {
        // Degenerate tri — normal stays (0,0,0). Render back-face-culls.
        normals[no]     = 0.0;
        normals[no + 1] = 0.0;
        normals[no + 2] = 0.0;
      }

      // Tight bounding sphere about the tri centroid.
      double cx = (v1x + v2x + v3x) * (1.0 / 3.0);
      double cy = (v1y + v2y + v3y) * (1.0 / 3.0);
      double cz = (v1z + v2z + v3z) * (1.0 / 3.0);
      double dx1 = v1x - cx, dy1 = v1y - cy, dz1 = v1z - cz;
      double dx2 = v2x - cx, dy2 = v2y - cy, dz2 = v2z - cz;
      double dx3 = v3x - cx, dy3 = v3y - cy, dz3 = v3z - cz;
      double d1 = dx1 * dx1 + dy1 * dy1 + dz1 * dz1;
      double d2 = dx2 * dx2 + dy2 * dy2 + dz2 * dz2;
      double d3 = dx3 * dx3 + dy3 * dy3 + dz3 * dz3;
      double dmax = d1 > d2 ? (d1 > d3 ? d1 : d3) : (d2 > d3 ? d2 : d3);
      bound_radii[t] = sqrt(dmax);
    }
    extras_baked = true;
  }

  // Tag stem faces of a Y-UP organic model (apple, pear). Run ONCE after
  // load_from_embed; face_class[] reused per bake (single uint8 read).
  //
  // 1D thresholds fail (Y catches dimpled shoulder; R catches calyx-pit;
  // conical region can't separate stem-base from pit-wall). Three-rule gate
  // on (maxR<=R_T ∧ cy>=Y_LO) faces:
  //   (A) cy >= Y_HI                              → upper stem
  //   (B) n·r̂ >= N_T (outward-facing dimple)      → outward dimple stem
  //   (C) |n_y|/|n| <= NY_MAX (horizontal normal) → inward-winding stem
  //       (handles inconsistent source-mesh winding — ~8 cyl walls inverted)
  // Pit walls excluded from (C): bowl-interior normals have |n_y|≈0.5;
  // stem cyl walls stay |n_y|<0.10 regardless of winding.
  //
  // (sx, sz) = stem axis = (x,z) centroid of top (1-y_frac_axis) band
  // (apple stem is offset from body-AABB centroid).
  //
  // Defaults select 92/416 faces on shipped apple (56 upper + 28
  // outward-dimple + 8 inverted-winding).
  void tag_stem_y_up(double y_hi_frac = 0.825, double y_lo_frac = 0.60,
                     double r_frac = 0.12, double n_dot_thresh = 0.05,
                     double ny_max = 0.15,
                     double y_frac_axis = 0.85) {
    if (!loaded || tri_count == 0) {
      puts("StlAsset.tag_stem_y_up: asset not loaded, skipping");
      return;
    }

    double y_span = model_max_y - model_min_y;
    double x_span = model_max_x - model_min_x;
    double z_span = model_max_z - model_min_z;
    double body_width = x_span > z_span ? x_span : z_span;
    if (y_span < 1.0e-6 || body_width < 1.0e-6) {
      puts("StlAsset.tag_stem_y_up: degenerate AABB, skipping");
      return;
    }

    // Stem axis = (x,z) centroid of top (1-y_frac_axis) band verts.
    // Falls back to model-AABB centroid if band empty.
    double y_axis_thresh = model_min_y + y_frac_axis * y_span;
    double sx_sum = 0.0, sz_sum = 0.0;
    int    sx_n   = 0;
    int nV = tri_count * 3;
    for (int v = 0; v < nV; v++) {
      int o = v * 3;
      double vy = verts[o + 1];
      if (vy >= y_axis_thresh) {
        sx_sum += verts[o];
        sz_sum += verts[o + 2];
        sx_n++;
      }
    }
    double sx, sz;
    if (sx_n > 0) {
      sx = sx_sum / double(sx_n);
      sz = sz_sum / double(sx_n);
    } else {
      sx = (model_min_x + model_max_x) * 0.5;
      sz = (model_min_z + model_max_z) * 0.5;
    }

    double y_hi = model_min_y + y_hi_frac * y_span;
    double y_lo = model_min_y + y_lo_frac * y_span;
    double r_thresh = r_frac * body_width;
    double r_thresh_sq = r_thresh * r_thresh;  // avoid sqrt in hot loop
    double ny_max_sq = ny_max * ny_max;        // for Rule C squared-form test

    face_class.resize(tri_count);
    int stem_count_upper = 0;
    int stem_count_lower = 0;
    int stem_count_inv   = 0;  // Rule C: inverted-winding cylinder walls
    for (int t = 0; t < tri_count; t++) {
      int b = t * 9;
      double v1x = verts[b],     v1y = verts[b + 1], v1z = verts[b + 2];
      double v2x = verts[b + 3], v2y = verts[b + 4], v2z = verts[b + 5];
      double v3x = verts[b + 6], v3y = verts[b + 7], v3z = verts[b + 8];
      double cy = (v1y + v2y + v3y) * (1.0 / 3.0);

      uint8 cls = 0;

      // Short-circuit: below y_lo can't be stem (~83% body skip).
      if (cy >= y_lo) {
        // Rule R: maxR^2 <= R_T^2 (all 3 verts close to stem axis).
        double dx1 = v1x - sx, dz1 = v1z - sz;
        double dx2 = v2x - sx, dz2 = v2z - sz;
        double dx3 = v3x - sx, dz3 = v3z - sz;
        double r1s = dx1 * dx1 + dz1 * dz1;
        double r2s = dx2 * dx2 + dz2 * dz2;
        double r3s = dx3 * dx3 + dz3 * dz3;
        double rmax_sq = r1s;
        if (r2s > rmax_sq) rmax_sq = r2s;
        if (r3s > rmax_sq) rmax_sq = r3s;

        if (rmax_sq <= r_thresh_sq) {
          if (cy >= y_hi) {
            // Rule A: upper stem — narrow-face above y_hi IS stem.
            cls = 1;
            stem_count_upper++;
          } else {
            // Lower-stem candidate. Two acceptance paths:
            //   Rule B: outward radial (n·r̂ ≥ N_T) — correct winding.
            //   Rule C: horizontal normal (|n_y|/|n| ≤ NY_MAX) —
            //     inward-winding cyl walls. Pit walls excluded (|n_y|≈0.5).
            // Squared-form throughout to avoid sqrt.
            double e1x = v2x - v1x, e1y = v2y - v1y, e1z = v2z - v1z;
            double e2x = v3x - v1x, e2y = v3y - v1y, e2z = v3z - v1z;
            double nx = e1y * e2z - e1z * e2y;
            double ny = e1z * e2x - e1x * e2z;
            double nz = e1x * e2y - e1y * e2x;
            double n_len_sq = nx * nx + ny * ny + nz * nz;

            if (n_len_sq > 1.0e-18) {
              // Rule C first (cheaper — no centroid/radial vec).
              if (ny * ny <= ny_max_sq * n_len_sq) {
                cls = 1;
                stem_count_inv++;
              } else {
                // Rule B — outward-radial test, lazy centroid.
                double cx = (v1x + v2x + v3x) * (1.0 / 3.0);
                double cz = (v1z + v2z + v3z) * (1.0 / 3.0);
                double rdx = cx - sx, rdz = cz - sz;
                double r_horiz_sq = rdx * rdx + rdz * rdz;
                if (r_horiz_sq > 1.0e-18) {
                  double numer = nx * rdx + nz * rdz;
                  if (numer > 0.0) {
                    double thresh_sq = n_dot_thresh * n_dot_thresh *
                                       n_len_sq * r_horiz_sq;
                    if (numer * numer >= thresh_sq) {
                      cls = 1;
                      stem_count_lower++;
                    }
                  }
                }
              }
            }
          }
        }
      }
      face_class[t] = cls;
    }
    has_face_classes = true;
  }
}

// StlInstance: placement of an StlAsset in world space. Owns a
// pre-baked array<Triangle@> walked stride-1 by render and physics.
// Re-bake supported (set_transform → bake_world_transform); world_tris
// capacity preserved across re-bakes (no GC churn).
// NOTE: field name `asset` conflicts with a Dustforce built-in const
// int — use `src_asset`. See feedback_as_asset_reserved_name.md.
class StlInstance {
  StlAsset @src_asset;
  double tx = 0.0, ty = 0.0, tz = 0.0;
  double scale = 1.0;
  double yaw = 0.0;     // rotation about Z (engine up), applied last
  double axis_tilt_rad = 0.0; // rotation about X, before yaw. For y-up
                        // models: +PI/2 maps model +Y onto world +Z.
  double axis_lean_rad = 0.0; // rotation about Y, after tilt, before yaw.
                        // Tilts a stem-up model toward ±X; lets yaw swing
                        // the leaning stem on otherwise axisymmetric models.

  // Base color (a<<24 | RGB). Default pearly white glass = Dustman.
  // Per-tri sun shading multiplies in; alpha passes through.
  uint base_col = 0xAAF4F8FF;

  // Alt color for faces with face_class==1 (e.g. tag_stem_y_up).
  // 0 = disabled (single-color fast path, no array read). Bake gates
  // on has_face_classes && stem_col!=0.
  uint stem_col = 0;

  // Shading floor for sun-back faces. 0.75 = pearly soft (Dustman).
  // ~0.15 = more reactive lighting (apple). Terrain uses 0.15.
  double shade_min = 0.75;

  // Per-frame spin (rad/s) about an oblique axis. 0 = static.
  // When non-zero, step() advances spin_angle and re-bakes. Spin is
  // applied AFTER pitch+yaw so the resting orientation is the rest pose.
  // Default axis = +Z. Auto-normalized at bake time.
  double spin_rate = 0.0;
  double spin_axis_x = 0.0;
  double spin_axis_y = 0.0;
  double spin_axis_z = 1.0;
  double spin_angle = 0.0; // accumulator; advanced each step

  // Key/fill light. Intensity 0 = disabled. Auto-normalized at bake.
  // Contribution sums with sun, clamped to 1.0. Same opt-in pattern
  // for under_light + rim_light below (three-point rig).
  double key_light_x = 1.0;
  double key_light_y = 0.0;
  double key_light_z = 0.0;
  double key_light_intensity = 0.0;

  // Under-light: typically -Z to fill undersides.
  double under_light_x = 0.0;
  double under_light_y = 0.0;
  double under_light_z = -1.0;
  double under_light_intensity = 0.0;

  // Rim light: fills the remaining octant sun+key+under leave dark.
  double rim_light_x = 0.0;
  double rim_light_y = 0.0;
  double rim_light_z = 0.0;
  double rim_light_intensity = 0.0;


  // Painter's-algorithm bias subtracted from per-tri sort_dist in STL
  // render path. Default 315 = Dustman (feet coplanar with runway, see
  // project_plane_z_bias_drop_2026_05_02). Floating instances can use
  // ~290 (plane shadow value) to narrow false-front zone.
  double z_bias = 315.0;

  array<Triangle @> world_tris;

  // World AABB for single-AABB pre-reject in render/physics.
  double world_min_x = 0.0, world_max_x = 0.0;
  double world_min_y = 0.0, world_max_y = 0.0;
  double world_min_z = 0.0, world_max_z = 0.0;
  bool baked = false;

  StlInstance() {}

  void set_asset(StlAsset @a) { @src_asset = @a; }
  void set_color(uint c) { base_col = c; }
  // NOTE: NO setters for `axis_tilt_rad` / `shade_min`. AS auto-creates
  // a virtual property X from any `set_X` method; if a field of the
  // same name exists, internal reads fail "no get accessor". Assign
  // those fields directly from the caller.

  void set_transform(double x, double y, double z, double s, double yaw_rad) {
    tx = x;
    ty = y;
    tz = z;
    scale = s;
    yaw = yaw_rad;
  }

  void bake_world_transform(bool log = false) {
    if (src_asset is null || !src_asset.loaded || src_asset.tri_count == 0) {
      if (log) puts("StlInstance: asset not ready, skipping bake");
      return;
    }

    int nT = src_asset.tri_count;

    // Pre-allocate once; subsequent bakes reuse Triangles (no GC churn).
    if (int(world_tris.length()) < nT) {
      world_tris.reserve(nT);
      while (int(world_tris.length()) < nT) world_tris.insertLast(Triangle());
    }

    double cy_rot = cos(yaw);
    double sy_rot = sin(yaw);
    double cp_rot = cos(axis_tilt_rad);
    double sp_rot = sin(axis_tilt_rad);
    double cl_rot = cos(axis_lean_rad);
    double sl_rot = sin(axis_lean_rad);

    // Spin rotation matrix (Rodrigues axis-angle), identity when
    // spin_angle=0. Axis auto-normalized.
    double sax = spin_axis_x, say = spin_axis_y, saz = spin_axis_z;
    double s_len_sq = sax * sax + say * say + saz * saz;
    if (s_len_sq > 1.0e-9) {
      double s_inv_len = 1.0 / sqrt(s_len_sq);
      sax *= s_inv_len; say *= s_inv_len; saz *= s_inv_len;
    } else {
      sax = 0.0; say = 0.0; saz = 1.0;
    }
    double c_sp = cos(spin_angle);
    double s_sp = sin(spin_angle);
    double t_sp = 1.0 - c_sp;
    double sm00 = t_sp * sax * sax + c_sp;
    double sm01 = t_sp * sax * say - s_sp * saz;
    double sm02 = t_sp * sax * saz + s_sp * say;
    double sm10 = t_sp * sax * say + s_sp * saz;
    double sm11 = t_sp * say * say + c_sp;
    double sm12 = t_sp * say * saz - s_sp * sax;
    double sm20 = t_sp * sax * saz - s_sp * say;
    double sm21 = t_sp * say * saz + s_sp * sax;
    double sm22 = t_sp * saz * saz + c_sp;

    // Sun direction: file-scope STL_SUN_DX/DY/DZ (pre-normalized).
    // Saves 1 sqrt + 1 div + 4 muls per bake (was per-bake normalize).

    // Key light: pre-normalize once; key_on gates per-tri cost.
    bool key_on = (key_light_intensity > 0.0);
    double key_dx = key_light_x, key_dy = key_light_y, key_dz = key_light_z;
    double k_intensity = key_light_intensity;
    if (key_on) {
      double k_len_sq = key_dx * key_dx + key_dy * key_dy + key_dz * key_dz;
      if (k_len_sq > 1.0e-9) {
        double k_inv = 1.0 / sqrt(k_len_sq);
        key_dx *= k_inv; key_dy *= k_inv; key_dz *= k_inv;
      } else {
        key_on = false;
      }
    }

    // Under-light — same opt-in/normalize pattern.
    bool und_on = (under_light_intensity > 0.0);
    double und_dx = under_light_x, und_dy = under_light_y, und_dz = under_light_z;
    double u_intensity = under_light_intensity;
    if (und_on) {
      double u_len_sq = und_dx * und_dx + und_dy * und_dy + und_dz * und_dz;
      if (u_len_sq > 1.0e-9) {
        double u_inv = 1.0 / sqrt(u_len_sq);
        und_dx *= u_inv; und_dy *= u_inv; und_dz *= u_inv;
      } else {
        und_on = false;
      }
    }

    // Rim light — same opt-in/normalize pattern.
    bool rim_on = (rim_light_intensity > 0.0);
    double rim_dx = rim_light_x, rim_dy = rim_light_y, rim_dz = rim_light_z;
    double r_intensity = rim_light_intensity;
    if (rim_on) {
      double r_len_sq = rim_dx * rim_dx + rim_dy * rim_dy + rim_dz * rim_dz;
      if (r_len_sq > 1.0e-9) {
        double r_inv = 1.0 / sqrt(r_len_sq);
        rim_dx *= r_inv; rim_dy *= r_inv; rim_dz *= r_inv;
      } else {
        rim_on = false;
      }
    }

    // Base color — per-tri shading multiplies in, alpha passes through.
    uint inst_base_col = base_col;
    uint base_a = (inst_base_col >> 24) & 0xFF;
    uint base_r = (inst_base_col >> 16) & 0xFF;
    uint base_g = (inst_base_col >> 8) & 0xFF;
    uint base_b = inst_base_col & 0xFF;

    // Alt color (e.g. stem). Inactive → single-color fast path
    // preserved bit-for-bit (no face_class read).
    bool class_routing = (stem_col != 0) && src_asset.has_face_classes &&
                         (int(src_asset.face_class.length()) >= nT);
    uint stem_a = 0, stem_r = 0, stem_g = 0, stem_b = 0;
    if (class_routing) {
      stem_a = (stem_col >> 24) & 0xFF;
      stem_r = (stem_col >> 16) & 0xFF;
      stem_g = (stem_col >> 8) & 0xFF;
      stem_b = stem_col & 0xFF;
    }


    // Model centroid — rotation pivot. tx/ty/tz specify world position of
    // the centroid. Pre-cached on StlAsset by bake_extras; defensive
    // recompute if extras absent.
    double m_cx, m_cy, m_cz;
    if (src_asset.extras_baked) {
      m_cx = src_asset.model_centroid_x;
      m_cy = src_asset.model_centroid_y;
      m_cz = src_asset.model_centroid_z;
    } else {
      m_cx = (src_asset.model_min_x + src_asset.model_max_x) * 0.5;
      m_cy = (src_asset.model_min_y + src_asset.model_max_y) * 0.5;
      m_cz = (src_asset.model_min_z + src_asset.model_max_z) * 0.5;
    }

    array<double> @av = @src_asset.verts;

    // ---- Transform compose ----
    // world_p = M * model_p + T' where
    //   M  = scale * M_spin * R_z(yaw) * R_y(lean) * R_x(pitch)
    //   T' = (tx,ty,tz) - M * centroid
    // Replaces 4-stage per-vert chain (70 muls → 9 muls).
    double r_yx_00 = cl_rot;
    double r_yx_01 = sl_rot * sp_rot;
    double r_yx_02 = sl_rot * cp_rot;
    double r_yx_11 = cp_rot;
    double r_yx_12 = -sp_rot;
    double r_yx_20 = -sl_rot;
    double r_yx_21 = cl_rot * sp_rot;
    double r_yx_22 = cl_rot * cp_rot;

    // R = R_z(yaw) * R_yx
    double r00 = cy_rot * r_yx_00;                          // cy*cl
    double r01 = cy_rot * r_yx_01 - sy_rot * r_yx_11;       // cy*sl*sp - sy*cp
    double r02 = cy_rot * r_yx_02 - sy_rot * r_yx_12;       // cy*sl*cp + sy*sp
    double r10 = sy_rot * r_yx_00;                          // sy*cl
    double r11 = sy_rot * r_yx_01 + cy_rot * r_yx_11;
    double r12 = sy_rot * r_yx_02 + cy_rot * r_yx_12;
    double r20 = r_yx_20;
    double r21 = r_yx_21;
    double r22 = r_yx_22;

    // R_full = M_spin * R (rotation-only). Kept separate from M so the
    // cached model normal stays unit-length — multiplying by full M
    // would scale it and break back-face cull.
    double rf00 = sm00 * r00 + sm01 * r10 + sm02 * r20;
    double rf01 = sm00 * r01 + sm01 * r11 + sm02 * r21;
    double rf02 = sm00 * r02 + sm01 * r12 + sm02 * r22;
    double rf10 = sm10 * r00 + sm11 * r10 + sm12 * r20;
    double rf11 = sm10 * r01 + sm11 * r11 + sm12 * r21;
    double rf12 = sm10 * r02 + sm11 * r12 + sm12 * r22;
    double rf20 = sm20 * r00 + sm21 * r10 + sm22 * r20;
    double rf21 = sm20 * r01 + sm21 * r11 + sm22 * r21;
    double rf22 = sm20 * r02 + sm21 * r12 + sm22 * r22;

    // M = scale * R_full. Verts read M; normals read rf*.
    double m00 = scale * rf00;
    double m01 = scale * rf01;
    double m02 = scale * rf02;
    double m10 = scale * rf10;
    double m11 = scale * rf11;
    double m12 = scale * rf12;
    double m20 = scale * rf20;
    double m21 = scale * rf21;
    double m22 = scale * rf22;

    // T' = T - M * centroid (folds in centroid subtract).
    double tprime_x = tx - (m00 * m_cx + m01 * m_cy + m02 * m_cz);
    double tprime_y = ty - (m10 * m_cx + m11 * m_cy + m12 * m_cz);
    double tprime_z = tz - (m20 * m_cx + m21 * m_cy + m22 * m_cz);

    // Hoist face_class handle (saves member dispatch per tri).
    array<uint8> @fc = null;
    if (class_routing) @fc = @src_asset.face_class;

    // Hoist normal + bound_radius caches. Defensive fallback if asset
    // wasn't extras_baked (load calls bake_extras unconditionally now,
    // but stay robust against direct construction).
    bool have_extras = src_asset.extras_baked &&
                       int(src_asset.normals.length()) >= nT * 3 &&
                       int(src_asset.bound_radii.length()) >= nT;
    array<double> @an  = have_extras ? @src_asset.normals     : null;
    array<double> @abr = have_extras ? @src_asset.bound_radii : null;

    // AABB sentinel init — drops per-tri first_v branch. Real verts
    // bounded ±1e9 so 1e18 sentinels lose first compare.
    world_min_x = 1.0e18; world_min_y = 1.0e18; world_min_z = 1.0e18;
    world_max_x = -1.0e18; world_max_y = -1.0e18; world_max_z = -1.0e18;

    for (int t = 0; t < nT; t++) {
      int base = t * 9;
      double m1x = av[base];
      double m1y = av[base + 1];
      double m1z = av[base + 2];
      double m2x = av[base + 3];
      double m2y = av[base + 4];
      double m2z = av[base + 5];
      double m3x = av[base + 6];
      double m3y = av[base + 7];
      double m3z = av[base + 8];

      // world_p = M * model_p + T'.
      double w1x = m00 * m1x + m01 * m1y + m02 * m1z + tprime_x;
      double w1y = m10 * m1x + m11 * m1y + m12 * m1z + tprime_y;
      double w1z = m20 * m1x + m21 * m1y + m22 * m1z + tprime_z;
      double w2x = m00 * m2x + m01 * m2y + m02 * m2z + tprime_x;
      double w2y = m10 * m2x + m11 * m2y + m12 * m2z + tprime_y;
      double w2z = m20 * m2x + m21 * m2y + m22 * m2z + tprime_z;
      double w3x = m00 * m3x + m01 * m3y + m02 * m3z + tprime_x;
      double w3y = m10 * m3x + m11 * m3y + m12 * m3z + tprime_y;
      double w3z = m20 * m3x + m21 * m3y + m22 * m3z + tprime_z;

      // Source color: base_col, or stem_col if class_routing && fc[t]==1.
      // Off path collapses to base_col (no array read).
      uint src_a = base_a, src_r = base_r, src_g = base_g, src_b = base_b;
      uint src_col = inst_base_col;
      if (class_routing && fc[t] == 1) {
        src_a = stem_a; src_r = stem_r; src_g = stem_g; src_b = stem_b;
        src_col = stem_col;
      }

      // ---- Render-only Triangle setup (replaces world_tris[t].set()) ----
      // STL tris read by Plane_Render only — chunk physics/shadow/VFX iterate
      // Chunk.triangles. Skip d00/d01/d11/invDenom, e12/e23/e31, inv_len_sq*,
      // abs_n*, plane_d (~25 muls + 3 divs + 4 branches). Chunk-physics gate
      // `if (tri.invDenom == 0.0) continue;` safely skips them.
      // Normal: cached unit n_m × R_full = unit world normal.
      // Bound radius: scale * cached model radius (exact under uniform scale).
      Triangle @tri = world_tris[t];
      tri.p1x = w1x; tri.p1y = w1y; tri.p1z = w1z;
      tri.p2x = w2x; tri.p2y = w2y; tri.p2z = w2z;
      tri.p3x = w3x; tri.p3y = w3y; tri.p3z = w3z;

      // World centroid — feeds tri.c_* and the fallback bound_radius.
      double cwx = (w1x + w2x + w3x) * (1.0 / 3.0);
      double cwy = (w1y + w2y + w3y) * (1.0 / 3.0);
      double cwz = (w1z + w2z + w3z) * (1.0 / 3.0);
      tri.c_x = cwx; tri.c_y = cwy; tri.c_z = cwz;

      double tnx, tny, tnz;
      if (have_extras) {
        int n_off = t * 3;
        double nmx = an[n_off];
        double nmy = an[n_off + 1];
        double nmz = an[n_off + 2];
        tnx = rf00 * nmx + rf01 * nmy + rf02 * nmz;
        tny = rf10 * nmx + rf11 * nmy + rf12 * nmz;
        tnz = rf20 * nmx + rf21 * nmy + rf22 * nmz;
        tri.bound_radius = abr[t] * scale;
      } else {
        // Defensive fallback — same math as Triangle.set()/bake_extras.
        double e1x = w2x - w1x, e1y = w2y - w1y, e1z = w2z - w1z;
        double e2x = w3x - w1x, e2y = w3y - w1y, e2z = w3z - w1z;
        double cnx = e1y * e2z - e1z * e2y;
        double cny = e1z * e2x - e1x * e2z;
        double cnz = e1x * e2y - e1y * e2x;
        double n_len_sq = cnx * cnx + cny * cny + cnz * cnz;
        if (n_len_sq > 1.0e-18) {
          double inv = 1.0 / sqrt(n_len_sq);
          tnx = cnx * inv; tny = cny * inv; tnz = cnz * inv;
        } else {
          tnx = 0.0; tny = 0.0; tnz = 0.0;
        }
        double dx1 = w1x - cwx, dy1 = w1y - cwy, dz1 = w1z - cwz;
        double dx2 = w2x - cwx, dy2 = w2y - cwy, dz2 = w2z - cwz;
        double dx3 = w3x - cwx, dy3 = w3y - cwy, dz3 = w3z - cwz;
        double dd1 = dx1 * dx1 + dy1 * dy1 + dz1 * dz1;
        double dd2 = dx2 * dx2 + dy2 * dy2 + dz2 * dz2;
        double dd3 = dx3 * dx3 + dy3 * dy3 + dz3 * dz3;
        double dmax = dd1 > dd2 ? (dd1 > dd3 ? dd1 : dd3) : (dd2 > dd3 ? dd2 : dd3);
        tri.bound_radius = sqrt(dmax);
      }
      tri.nx = tnx; tri.ny = tny; tri.nz = tnz;

      // Per-tri AABB into locals — reused for instance-AABB accum below.
      // tri.min_x/max_x/etc. NOT written: render's STL pass doesn't touch
      // them (chunk-tri infra). Saves 6 member writes per tri.
      double tminx = w1x, tmaxx = w1x;
      if (w2x < tminx) tminx = w2x; else if (w2x > tmaxx) tmaxx = w2x;
      if (w3x < tminx) tminx = w3x; else if (w3x > tmaxx) tmaxx = w3x;
      double tminy = w1y, tmaxy = w1y;
      if (w2y < tminy) tminy = w2y; else if (w2y > tmaxy) tmaxy = w2y;
      if (w3y < tminy) tminy = w3y; else if (w3y > tmaxy) tmaxy = w3y;
      double tminz = w1z, tmaxz = w1z;
      if (w2z < tminz) tminz = w2z; else if (w2z > tmaxz) tmaxz = w2z;
      if (w3z < tminz) tminz = w3z; else if (w3z > tmaxz) tmaxz = w3z;

      // Per-tri sun shading + col_r/g/b split — mirrors add_triangle
      // (REQUIRED: fog blend path reads col_r/g/b directly). Optional
      // key/under/rim light contributions sum in. tnx/tny/tnz are
      // already locals so dot products skip member dispatch.
      // Sun direction is file-scope STL_SUN_DX/DY/DZ (pre-normalized).
      double sun_dot = tnx * STL_SUN_DX + tny * STL_SUN_DY + tnz * STL_SUN_DZ;
      double light_intensity = sun_dot > 0.0 ? sun_dot : 0.0;
      if (key_on) {
        double key_dot = tnx * key_dx + tny * key_dy + tnz * key_dz;
        if (key_dot > 0.0) light_intensity += key_dot * k_intensity;
      }
      if (und_on) {
        double und_dot = tnx * und_dx + tny * und_dy + tnz * und_dz;
        if (und_dot > 0.0) light_intensity += und_dot * u_intensity;
      }
      if (rim_on) {
        double rim_dot = tnx * rim_dx + tny * rim_dy + tnz * rim_dz;
        if (rim_dot > 0.0) light_intensity += rim_dot * r_intensity;
      }
      if (light_intensity < shade_min) light_intensity = shade_min;
      if (light_intensity > 1.0) light_intensity = 1.0;
      uint lit_r = uint(double(src_r) * light_intensity);
      uint lit_g = uint(double(src_g) * light_intensity);
      uint lit_b = uint(double(src_b) * light_intensity);
      tri.color = (src_a << 24) | (lit_r << 16) | (lit_g << 8) | lit_b;
      tri.col_r = lit_r;
      tri.col_g = lit_g;
      tri.col_b = lit_b;

      // AABB accum — sentinels remove first_v branch; reads from locals.
      if (tminx < world_min_x) world_min_x = tminx;
      if (tmaxx > world_max_x) world_max_x = tmaxx;
      if (tminy < world_min_y) world_min_y = tminy;
      if (tmaxy > world_max_y) world_max_y = tmaxy;
      if (tminz < world_min_z) world_min_z = tminz;
      if (tmaxz > world_max_z) world_max_z = tmaxz;
    }

    baked = true;
    if (log) {
      puts("StlInstance: baked " + nT + " tris @ pos(" + tx + "," + ty +
           "," + tz + ") scale=" + scale + " yaw=" + yaw +
           " axis_tilt_rad=" + axis_tilt_rad +
           ", world AABB x=[" + world_min_x + "," + world_max_x +
           "] y=[" + world_min_y + "," + world_max_y + "] z=[" +
           world_min_z + "," + world_max_z + "]");
    }
  }
}

// Apple: collectible pickup. pos/size = collision sphere (FloatingPrism
// role); @inst is the visual. Lives here (not vfx_entities.cpp) because
// StlInstance is declared above and vfx_entities is parsed earlier.
// Lifecycle: collected=false → collision-checked; collected=true →
// collect_t advances (spin/shrink/drift), despawn at COLLECT_DURATION.
// base_scale/base_tz captured at collection moment for stable lerp origin.
class Apple {
  Vec3 pos;
  float size;       // collision sphere radius (world units, ~80u for tight)
  bool collected;   // set true on hit; main loop swap-pops on next iter
  float collect_t;  // seconds since collection (0 until hit)
  double base_scale;// inst.scale captured at collection moment
  double base_tz;   // inst.tz captured at collection moment
  StlInstance @inst;
  // Paired Dustforce apple-entity ID. 0 = unwired (no replay hit
  // synth on collection). Populated at spawn_apple_at.
  uint entity_id;
  Apple() {
    size = 80.0f;
    collected = false;
    collect_t = 0.0f;
    base_scale = 0.0;
    base_tz = 0.0;
    @inst = null;
    entity_id = 0;
  }
  Apple(Vec3 p, float s) {
    pos = p;
    size = s;
    collected = false;
    collect_t = 0.0f;
    base_scale = 0.0;
    base_tz = 0.0;
    @inst = null;
    entity_id = 0;
  }
}
