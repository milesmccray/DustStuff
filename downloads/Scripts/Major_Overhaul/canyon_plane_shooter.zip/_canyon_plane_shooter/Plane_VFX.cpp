// === Wind streamer tuning (fx_level >= 3) ====================================
// Sparse white ribbons sweeping along a global wind vector that drifts over
// time. update_wind_streams() runs from update_trails(); render_wind_streams()
// runs before radix flush in Plane_Render.cpp::draw().

// Wind base direction (world frame). Drift cone applied via sin() of slow
// phases below. Strength in u/sec; oscillates by ±WIND_STRENGTH_OSC.
const double WIND_BASE_X = 1.0;
const double WIND_BASE_Y = 0.0;
const double WIND_BASE_Z = -0.15;          // slight downward bias
const double WIND_BASE_STRENGTH  = 380.0;  // u/sec
const double WIND_STRENGTH_OSC   = 110.0;  // ± amplitude on strength
// Phase advance rates in rad/sec; independent rates avoid lockstep.
const double WIND_DRIFT_RATE_YAW = 0.08;   // ~78s yaw period
const double WIND_DRIFT_RATE_PIT = 0.05;   // ~125s pitch period
const double WIND_DRIFT_RATE_STR = 0.10;   // ~63s strength period
const double WIND_DRIFT_AMP_YAW  = 0.55;   // ±31° drift cone
const double WIND_DRIFT_AMP_PIT  = 0.25;   // ±14° pitch drift

// Spawn sphere centered on camera, shifted upwind so streams drift through
// view as they age. UPWIND_BIAS kept short so faster streams still reach
// near-cam visibility before max_age expires.
const double WIND_SPAWN_RADIUS = 2500.0;
const double WIND_UPWIND_BIAS  = 600.0;

// Altitude gate — suppress spawn once player descends to lower dirt band
// (gz=-20, world Z = -8000), three cells above underwater boundary at gz=-23.
// Already-active streams above threshold age out naturally (max_age 5.5–9s)
// so a fast dive doesn't pop them mid-flight.
const double WIND_MIN_SPAWN_Z  = -8000.0;

// Stream lifecycle. Hard cap prevents runaway during long sessions; spawn
// gated against MAX even when probability fires.
const uint   WIND_MAX_STREAMS = 12;
const float  WIND_SPAWN_PROB_PER_FRAME = 2.5f / 60.0f;  // ~2.5/sec target
const float  WIND_STREAM_AGE_MIN = 5.5f;
const float  WIND_STREAM_AGE_MAX = 9.0f;
const float  WIND_FADE_IN_T  = 0.8f;
const float  WIND_FADE_OUT_T = 2.0f;

// Chain emit + decay. Head snapshotted into chain every EMIT_INTERVAL.
// Points decay uniformly; dead front trimmed. MAX_POINTS caps memory if
// life decay is slow.
const float  WIND_EMIT_INTERVAL = 0.10f;       // 10 emits/sec
const float  WIND_POINT_LIFE_DECAY = 0.28f;    // ~3.6s lifetime
const uint   WIND_MAX_POINTS_PER_STREAM = 50;

// Per-stream archetype CDF on rand()%100 — weighted toward CALM/MODERATE
// (70%) with FAST_STRAIGHT/TURBULENT for variety (30%).
const int WIND_ARCH_CALM_PCT = 40;
const int WIND_ARCH_MOD_PCT  = 70;   // CALM 0..40, MODERATE 40..70
const int WIND_ARCH_FAST_PCT = 90;   // FAST_STRAIGHT 70..90, TURBULENT 90..100

// CALM — gentle drift, low wobble, slightly slower than global.
const double WIND_CALM_AMP_LO   = 5.0;
const double WIND_CALM_AMP_HI   = 20.0;
const double WIND_CALM_FREQ_LO  = 0.4;
const double WIND_CALM_FREQ_HI  = 1.4;
const double WIND_CALM_SPD_LO   = 0.7;
const double WIND_CALM_SPD_HI   = 1.0;
const double WIND_CALM_DIR_JIT  = 0.08;        // ±4.6° from global wind

// MODERATE — mid wobble, near-global speed.
const double WIND_MOD_AMP_LO    = 20.0;
const double WIND_MOD_AMP_HI    = 55.0;
const double WIND_MOD_FREQ_LO   = 1.2;
const double WIND_MOD_FREQ_HI   = 2.5;
const double WIND_MOD_SPD_LO    = 0.9;
const double WIND_MOD_SPD_HI    = 1.2;
const double WIND_MOD_DIR_JIT   = 0.15;        // ±8.6°

// FAST_STRAIGHT — minimal wobble, distinctly faster.
const double WIND_FAST_AMP_LO   = 2.0;
const double WIND_FAST_AMP_HI   = 12.0;
const double WIND_FAST_FREQ_LO  = 0.3;
const double WIND_FAST_FREQ_HI  = 1.0;
const double WIND_FAST_SPD_LO   = 1.4;
const double WIND_FAST_SPD_HI   = 1.7;
const double WIND_FAST_DIR_JIT  = 0.10;        // ±5.7°

// TURBULENT — chaotic high-freq wobble; near-global speed so wobble reads.
const double WIND_TURB_AMP_LO   = 50.0;
const double WIND_TURB_AMP_HI   = 90.0;
const double WIND_TURB_FREQ_LO  = 3.0;
const double WIND_TURB_FREQ_HI  = 6.0;
const double WIND_TURB_SPD_LO   = 0.8;
const double WIND_TURB_SPD_HI   = 1.1;
const double WIND_TURB_DIR_JIT  = 0.25;        // ±14.3°

// Screen-space-equivalent thickness: world width = k * dist_to_cam keeps
// on-screen size constant (~1.1 px) instead of vanishing subpixel past 2000u.
// z_bias 200 sits BELOW shadow z_bias 290, ABOVE terrain 0 — shadows occlude
// wind, wind occludes nothing behind shadow (haze-like, acceptable).
const double WIND_THICKNESS_PER_U = 0.0010;    // world u per u-of-distance
const double WIND_THICKNESS_MIN   = 0.05;      // skip emit below this
// Peak alpha hit only at chain mid; both ends fade via parabolic envelope
// (see render_wind_streams). Peak ~35% at mid, ~18% averaged.
const float  WIND_PEAK_ALPHA      = 90.0f;     // /255 at chain mid-point
const double WIND_Z_BIAS          = 200.0;

mixin class PlaneVFXLogic {

  void update_trails(bool touch_L, bool touch_R, bool touch_T,
                     const Vec3 &in contact_L, const Vec3 &in contact_R,
                     const Vec3 &in contact_T) {
    // Trail gated on forward-velocity (vel · local +X) not |vel|, so
    // sideways dash suppresses emission. Bands: <min none;
    // [min,vortex_thresh) plain; >=vortex_thresh vortices ramp.
    double fwd_x, fwd_y, fwd_z;
    orientation.rotate_scalar(1.0, 0.0, 0.0, fwd_x, fwd_y, fwd_z);
    double v_fwd = vel.x * fwd_x + vel.y * fwd_y + vel.z * fwd_z;

    double min_trail_speed        = 200.0;
    double vortex_threshold_speed = 970.0;
    double vortex_max_speed       = 1300.0;

    if (dash_timer > 0 && v_fwd >= min_trail_speed) {
      // Emission-time speed scale (0 at min → 1 at vortex_thresh)
      // stored per-point so old points keep their emit look.
      float speed_scale = float((v_fwd - min_trail_speed) /
                                (vortex_threshold_speed - min_trail_speed));
      if (speed_scale < 0.0f) speed_scale = 0.0f;
      else if (speed_scale > 1.0f) speed_scale = 1.0f;

      double vort_ly = 0.0, vort_lz = 0.0, vort_ry = 0.0, vort_rz = 0.0;

      if (v_fwd >= vortex_threshold_speed) {
        // Slight ramp above the threshold: hs = 0 at threshold, 1 at max.
        double hs = (v_fwd - vortex_threshold_speed) /
                    (vortex_max_speed - vortex_threshold_speed);
        if (hs < 0.0) hs = 0.0;
        else if (hs > 1.0) hs = 1.0;

        // ~0.7 bursts/s at threshold → ~2.2/s at peak.
        double burst_prob_per_sec = 0.7 + 1.5 * hs;
        double cd_min   = 0.50 - 0.30 * hs; // 0.50 -> 0.20
        double cd_range = 1.20 - 0.80 * hs; // 1.20 -> 0.40

        // Schedule wingtip-vortex bursts gated by random cooldown.
        if (vortex_timer > 0.0) {
          vortex_timer -= DT;
          vortex_phase += DT * 32.0; // spin rate of the curl component
          if (vortex_timer < 0.0) vortex_timer = 0.0;
        } else if (vortex_cooldown > 0.0) {
          vortex_cooldown -= DT;
          if (vortex_cooldown < 0.0) vortex_cooldown = 0.0;
        } else {
          if (double(rand() % 10000) < 10000.0 * burst_prob_per_sec * DT) {
            vortex_timer    = 0.20 + 0.30 * (double(rand() % 1000) * 0.001);
            vortex_cooldown = cd_min + cd_range * (double(rand() % 1000) * 0.001);
            vortex_phase    = double(rand() % 1000) * 0.001 * 6.2831853;
          }
        }
      } else {
        // Below threshold: let in-flight burst finish, don't start new.
        // Cooldown keeps ticking so re-accel doesn't fire immediately.
        if (vortex_timer > 0.0) {
          vortex_timer -= DT;
          vortex_phase += DT * 32.0;
          if (vortex_timer < 0.0) vortex_timer = 0.0;
        }
        if (vortex_cooldown > 0.0) {
          vortex_cooldown -= DT;
          if (vortex_cooldown < 0.0) vortex_cooldown = 0.0;
        }
      }

      // Per-wingtip perp offset; sin/cos curl + jitter; L/R mirror on Y.
      if (vortex_timer > 0.0) {
        // Last 100ms ramp-out so trail rejoins wingtip smoothly.
        double env = vortex_timer < 0.10 ? vortex_timer * 10.0 : 1.0;
        double s  = sin(vortex_phase);
        double co = cos(vortex_phase);
        double amp = 1.0 * env;
        double jy = (double(rand() % 2001) - 1000.0) * 0.001 * env;
        double jz = (double(rand() % 2001) - 1000.0) * 0.001 * env;
        vort_ly =  amp * s  + jy;
        vort_lz =  amp * co + jz;
        vort_ry = -amp * s  - jy; // counter-rotating mirror on Y
        vort_rz =  amp * co + jz;
      }

      double l_rx, l_ry, l_rz, r_rx, r_ry, r_rz;
      orientation.rotate_scalar(15.0, -90.0 + vort_ly, 5.0 + vort_lz,
                                l_rx, l_ry, l_rz);
      orientation.rotate_scalar(15.0,  90.0 + vort_ry, 5.0 + vort_rz,
                                r_rx, r_ry, r_rz);

      // INVARIANT: OLDEST→NEWEST ordering (insertLast). trail[i].
      // connected = "was the previous frame also active".
      TrailPoint @tL = get_trail_point();
      tL.pos.set(pos.x + l_rx, pos.y + l_ry, pos.z + l_rz);
      tL.life = 1.0;
      tL.connected = was_dash;
      tL.speed_scale = speed_scale;
      trail_L.insertLast(tL);
      TrailPoint @tR = get_trail_point();
      tR.pos.set(pos.x + r_rx, pos.y + r_ry, pos.z + r_rz);
      tR.life = 1.0;
      tR.connected = was_dash;
      tR.speed_scale = speed_scale;
      trail_R.insertLast(tR);
      if (rand() % 3 == 0) {
        Particle @pL = get_particle();
        pL.pos.set(pos.x + l_rx, pos.y + l_ry, pos.z + l_rz);
        pL.vel.set(vel.x * 0.1, vel.y * 0.1, vel.z * 0.1);
        pL.life = 0.4;
        pL.color = col_primary;
        particles.insertLast(pL);
        Particle @pR = get_particle();
        pR.pos.set(pos.x + r_rx, pos.y + r_ry, pos.z + r_rz);
        pR.vel.set(vel.x * 0.1, vel.y * 0.1, vel.z * 0.1);
        pR.life = 0.4;
        pR.color = col_primary;
        particles.insertLast(pR);
      }
      was_dash = true;
    } else {
      was_dash = false;
    }

    // Same OLDEST→NEWEST ordering (insertLast) as dash trails above.
    if (touch_L) {
      TrailPoint @t = get_trail_point();
      t.pos = contact_L;
      t.life = 1.0;
      t.connected = was_touch_L;
      wheel_trail_L.insertLast(t);
    }
    if (touch_R) {
      TrailPoint @t = get_trail_point();
      t.pos = contact_R;
      t.life = 1.0;
      t.connected = was_touch_R;
      wheel_trail_R.insertLast(t);
    }
    if (touch_T) {
      TrailPoint @t = get_trail_point();
      t.pos = contact_T;
      t.life = 1.0;
      t.connected = was_touch_T;
      wheel_trail_T.insertLast(t);
    }

    // Wingtip trails — drop TrailPoint per impact-frame; `connected`
    // gated on previous frame so brief lift-offs break the trail.
    if (wing_touch_L_frame) {
      TrailPoint @t = get_trail_point();
      t.pos = wing_contact_L;
      t.life = 1.0;
      t.connected = was_wing_touch_L;
      wingtip_trail_L.insertLast(t);
    }
    if (wing_touch_R_frame) {
      TrailPoint @t = get_trail_point();
      t.pos = wing_contact_R;
      t.life = 1.0;
      t.connected = was_wing_touch_R;
      wingtip_trail_R.insertLast(t);
    }

    was_touch_L = touch_L;
    was_touch_R = touch_R;
    was_touch_T = touch_T;
    was_wing_touch_L = wing_touch_L_frame;
    was_wing_touch_R = wing_touch_R_frame;

    decay_trail(@trail_L);
    decay_trail(@trail_R);
    decay_wheel_trail(@wheel_trail_L);
    decay_wheel_trail(@wheel_trail_R);
    decay_wheel_trail(@wheel_trail_T);
    decay_wheel_trail(@wingtip_trail_L);
    decay_wheel_trail(@wingtip_trail_R);
    update_particles();
    update_projectiles();
    update_smokes();
    // Wind streamers gated under fx_level >= 3. fx_level cached at init()
    // and treated as immutable post-init.
    if (fx_level >= 3)
      update_wind_streams();
  }

  // INVARIANT: OLDEST→NEWEST ordering — uniform decay means dead is
  // contiguous prefix; one linear shift-compact suffices.
  void decay_trail(array<TrailPoint @> @trail) {
    uint max_tp = max_trail_points;
    uint len = trail.length();
    if (len == 0)
      return;

    for (uint i = 0; i < len; i++) {
      trail[i].life -= 1.8 * DT;
    }

    // Count dead front (oldest), then trim survivors to enforce max.
    uint drop = 0;
    while (drop < len && trail[drop].life <= 0) {
      free_trail_point(trail[drop]);
      drop++;
    }
    uint surviving = len - drop;
    if (surviving > max_tp) {
      uint extra = surviving - max_tp;
      for (uint k = 0; k < extra; k++) {
        free_trail_point(trail[drop + k]);
      }
      drop += extra;
    }
    // Single linear shift-compact (skipped if nothing was dropped).
    if (drop > 0) {
      uint new_len = len - drop;
      for (uint k = 0; k < new_len; k++) {
        @trail[k] = @trail[k + drop];
      }
      trail.resize(new_len);
    }
  }

  void decay_wheel_trail(array<TrailPoint @> @trail) {
    uint max_tp = max_trail_points * 2;
    uint len = trail.length();
    if (len == 0)
      return;

    for (uint i = 0; i < len; i++) {
      trail[i].life -= 0.5 * DT;
    }

    uint drop = 0;
    while (drop < len && trail[drop].life <= 0) {
      free_trail_point(trail[drop]);
      drop++;
    }
    uint surviving = len - drop;
    if (surviving > max_tp) {
      uint extra = surviving - max_tp;
      for (uint k = 0; k < extra; k++) {
        free_trail_point(trail[drop + k]);
      }
      drop += extra;
    }
    if (drop > 0) {
      uint new_len = len - drop;
      for (uint k = 0; k < new_len; k++) {
        @trail[k] = @trail[k + drop];
      }
      trail.resize(new_len);
    }
  }

  void update_particles() {
    double fe = fog_end;
    int n = int(particles.length());
    for (int i = n - 1; i >= 0; i--) {
      Particle @p = particles[i];
      double dx = p.pos.x - pos.x;
      double dy = p.pos.y - pos.y;
      double dz = p.pos.z - pos.z;
      if (dx > fe || dx < -fe || dy > fe || dy < -fe || dz > fe || dz < -fe ||
          (dx * dx + dy * dy + dz * dz > fog_end_sq)) {
        free_particle(p);
        @particles[i] = @particles[n - 1];
        particles.removeLast();
        n--;
        continue;
      }
      // Sparks (no_gravity=true) fly straight — gravity arc would
      // read as ember instead of hot shear flash.
      if (!p.no_gravity)
        p.vel.z -= 400.0 * DT; // Gravity
      p.pos.x += p.vel.x * DT;
      p.pos.y += p.vel.y * DT;
      p.pos.z += p.vel.z * DT;
      p.life -= DT;
      if (p.life <= 0) {
        free_particle(p);
        @particles[i] = @particles[n - 1];
        particles.removeLast();
        n--;
      }
    }
  }

  void update_smokes() {
    double fe = fog_end;
    int n = int(smokes.length());
    for (int i = n - 1; i >= 0; i--) {
      Smoke @s = smokes[i];
      double dx = s.pos.x - pos.x;
      double dy = s.pos.y - pos.y;
      double dz = s.pos.z - pos.z;
      if (dx > fe || dx < -fe || dy > fe || dy < -fe || dz > fe || dz < -fe ||
          (dx * dx + dy * dy + dz * dz > fog_end_sq)) {
        free_smoke(s);
        @smokes[i] = @smokes[n - 1];
        smokes.removeLast();
        n--;
        continue;
      }
      s.pos.x += s.vel.x * DT;
      s.pos.y += s.vel.y * DT;
      s.pos.z += s.vel.z * DT;

      s.vel.scale_in_place(1.0 -
                           4.0 * DT); // Decelerate quickly for explosion effect

      double angle =
          sqrt(s.rot_vel_x * s.rot_vel_x + s.rot_vel_y * s.rot_vel_y +
               s.rot_vel_z * s.rot_vel_z) *
          DT;
      if (angle > 1e-4) {
        double ha = angle * 0.5;
        double sa = sin(ha);
        double cha = cos(ha);
        double inv_angle_dt = DT / angle;
        double ax = s.rot_vel_x * inv_angle_dt;
        double ay = s.rot_vel_y * inv_angle_dt;
        double az = s.rot_vel_z * inv_angle_dt;

        // Fast manual quaternion multiplication
        double nw = cha * s.rot.w - (ax * sa) * s.rot.x - (ay * sa) * s.rot.y -
                    (az * sa) * s.rot.z;
        double nx = cha * s.rot.x + (ax * sa) * s.rot.w + (ay * sa) * s.rot.z -
                    (az * sa) * s.rot.y;
        double ny = cha * s.rot.y - (ax * sa) * s.rot.z + (ay * sa) * s.rot.w +
                    (az * sa) * s.rot.x;
        double nz = cha * s.rot.z + (ax * sa) * s.rot.y - (ay * sa) * s.rot.x +
                    (az * sa) * s.rot.w;

        s.rot.w = nw;
        s.rot.x = nx;
        s.rot.y = ny;
        s.rot.z = nz;
        s.rot.normalize();
      }

      s.life -= DT;
      if (s.life <= 0) {
        free_smoke(s);
        @smokes[i] = @smokes[n - 1];
        smokes.removeLast();
        n--;
      }
    }
  }






  void submit_trail_quad(const Vec3 &in p1, const Vec3 &in p2,
                         const Vec3 &in p3, const Vec3 &in p4, uint colour,
                         const Vec3 &in cam_pos) {
    if (active_faces >= MAX_FACES)
      return;

    double fwx = cam_fwd_vec.x,  fwy = cam_fwd_vec.y,  fwz = cam_fwd_vec.z;
    double lfx = cam_left_vec.x, lfy = cam_left_vec.y, lfz = cam_left_vec.z;
    double upx = cam_up_vec.x,   upy = cam_up_vec.y,   upz = cam_up_vec.z;
    double cdf = cam_dot_fwd, cdl = cam_dot_left, cdu = cam_dot_up;
    double p1x = p1.x, p1y = p1.y, p1z = p1.z;
    double p2x = p2.x, p2y = p2.y, p2z = p2.z;
    double p3x = p3.x, p3y = p3.y, p3z = p3.z;
    double p4x = p4.x, p4y = p4.y, p4z = p4.z;

    double tx1 = p1x * fwx + p1y * fwy + p1z * fwz - cdf;
    double tx2 = p2x * fwx + p2y * fwy + p2z * fwz - cdf;
    double tx3 = p3x * fwx + p3y * fwy + p3z * fwz - cdf;
    double tx4 = p4x * fwx + p4y * fwy + p4z * fwz - cdf;

    double c_tx1 = tx1 < 0.1 ? 0.1 : tx1;
    double c_tx2 = tx2 < 0.1 ? 0.1 : tx2;
    double c_tx3 = tx3 < 0.1 ? 0.1 : tx3;
    double c_tx4 = tx4 < 0.1 ? 0.1 : tx4;

    double max_tx12 = c_tx1 > c_tx2 ? c_tx1 : c_tx2;
    double max_tx34 = c_tx3 > c_tx4 ? c_tx3 : c_tx4;
    double max_tx = max_tx12 > max_tx34 ? max_tx12 : max_tx34;

    double centroid_tx = (c_tx1 + c_tx2 + c_tx3 + c_tx4) * 0.25;
    // z_bias 300: compensates terrain min_tx-weighted sort offset.
    double sort_dist = ((centroid_tx * 0.6) + (max_tx * 0.4)) - 300.0;

    int af = active_faces;
    int b  = af << 4;
    rq_data[b]      = tx1;
    rq_data[b + 1]  = p1x * lfx + p1y * lfy + p1z * lfz - cdl;
    rq_data[b + 2]  = p1x * upx + p1y * upy + p1z * upz - cdu;

    rq_data[b + 3]  = tx2;
    rq_data[b + 4]  = p2x * lfx + p2y * lfy + p2z * lfz - cdl;
    rq_data[b + 5]  = p2x * upx + p2y * upy + p2z * upz - cdu;

    rq_data[b + 6]  = tx3;
    rq_data[b + 7]  = p3x * lfx + p3y * lfy + p3z * lfz - cdl;
    rq_data[b + 8]  = p3x * upx + p3y * upy + p3z * upz - cdu;

    rq_data[b + 9]  = tx4;
    rq_data[b + 10] = p4x * lfx + p4y * lfy + p4z * lfz - cdl;
    rq_data[b + 11] = p4x * upx + p4y * upy + p4z * upz - cdu;

    rq_colour[af] = colour;
    rq_sort_packed[af] =
        (int64(int(sort_dist * SORT_KEY_SCALE)) << 16) | int64(af | 0x8000);
    active_faces++;
  }

  void render_smokes(const Vec3 &in cam_pos) {
    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;
    double h_fov = current_h_fov;
    double v_fov = current_v_fov;
    double h_bound_mult = current_h_bound_mult;
    double v_bound_mult = current_v_bound_mult;

    uint s_len = smokes.length();
    for (uint i = 0; i < s_len; i++) {
      Smoke @s = smokes[i];

      double dx = s.pos.x - cam_pos.x;
      double dy = s.pos.y - cam_pos.y;
      double dz = s.pos.z - cam_pos.z;
      double dist_sq = dx * dx + dy * dy + dz * dz;
      if (dist_sq > fog_end_sq)
        continue;

      // Frustum reject on centroid+bound BEFORE building the box.
      double progress = 1.0 - (s.life * s.inv_max_life);
      double size = s.base_size * (1.0 + progress * 2.5);
      // Bound = largest axis; conservative for non-uniform sheets.
      double sxv = size * s.size_x;
      double syv = size * s.size_y;
      double szv = size * s.size_z;
      double max_axis = sxv;
      if (syv > max_axis) max_axis = syv;
      if (szv > max_axis) max_axis = szv;
      double bound = max_axis * 0.866025; // sqrt(3)/2 AABB->sphere overestimate

      double tx = dx * cfx + dy * cfy + dz * cfz;
      if (tx + bound < 0.1)
        continue;

      double ty = dx * clx + dy * cly + dz * clz;
      double h_b = bound * h_bound_mult;
      double tx_h_fov = tx * h_fov;
      if (ty > tx_h_fov + h_b || -ty > tx_h_fov + h_b)
        continue;

      double tz = dx * cux + dy * cuy + dz * cuz;
      double v_b = bound * v_bound_mult;
      double tx_v_fov = tx * v_fov;
      if (tz > tx_v_fov + v_b || -tz > tx_v_fov + v_b)
        continue;

      uint alpha = uint((s.life * s.inv_max_life) * 180.0 * s.alpha_mul);
      if (alpha > 255)
        alpha = 255;
      uint c = (s.color & 0x00FFFFFF) | (alpha << 24);

      submit_world_box_rotated(s.pos.x, s.pos.y, s.pos.z, sxv, syv, szv, c,
                               s.rot, cam_pos, 500.0);
    }
  }

  void draw_crystal_face(const Vec3 &in p1, const Vec3 &in p2,
                         const Vec3 &in p3, uint base_color,
                         const Vec3 &in cam_pos) {
    double dx1 = p2.x - p1.x, dy1 = p2.y - p1.y, dz1 = p2.z - p1.z;
    double dx2 = p3.x - p1.x, dy2 = p3.y - p1.y, dz2 = p3.z - p1.z;
    double nx = dy1 * dz2 - dz1 * dy2, ny = dz1 * dx2 - dx1 * dz2,
           nz = dx1 * dy2 - dy1 * dx2;
    double nlen = sqrt(nx * nx + ny * ny + nz * nz);
    if (nlen > 1e-4) {
      double inv_nlen = 1.0 / nlen;
      nx *= inv_nlen;
      ny *= inv_nlen;
      nz *= inv_nlen;
    }

    double light = nx * sun_dir.x + ny * sun_dir.y + nz * sun_dir.z;
    if (light < 0)
      light = -light;
    if (light < 0.2)
      light = 0.2;
    // Compress 0.2-1.0 sun band to 0.72-1.0 (35% darken cap).
    light = 1.0 - (1.0 - light) * 0.35;

    uint c = multiply_color(base_color, light);

    double cpx = (p1.x + p2.x + p3.x) * 0.3333333333;
    double cpy = (p1.y + p2.y + p3.y) * 0.3333333333;
    double cpz = (p1.z + p2.z + p3.z) * 0.3333333333;
    double fdx = cpx - cam_pos.x, fdy = cpy - cam_pos.y, fdz = cpz - cam_pos.z;
    double dist_sq = fdx * fdx + fdy * fdy + fdz * fdz;
    double fog_t = (dist_sq - fog_start_sq) * inv_fog_sq_diff;
    if (fog_t > 0.0) {
      if (fog_t >= 1.0) {
        c = fog_bg_color;
      } else {
        int c_r = (c >> 16) & 0xFF, c_g = (c >> 8) & 0xFF, c_b = c & 0xFF;
        c_r += int((fog_r - c_r) * fog_t);
        c_g += int((fog_g - c_g) * fog_t);
        c_b += int((fog_b - c_b) * fog_t);
        c = (0xFF000000) | (uint(c_r) << 16) | (uint(c_g) << 8) | uint(c_b);
      }
    }

    uint alpha = (base_color >> 24) & 0xFF;
    c = (c & 0x00FFFFFF) | (alpha << 24);

    submit_world_triangle(p1, p2, p3, c, cam_pos, 0.0);
  }

  // Prism wire-edge as camera-facing quad. Width = edge×(mid-cam)
  // for constant on-screen thickness. Fog mirrors draw_crystal_face;
  // alpha preserved from base_color. z_bias 0.0 = prism/fragment level.
  void draw_prism_edge(const Vec3 &in p1, const Vec3 &in p2, uint base_color,
                       double thickness, const Vec3 &in cam_pos) {
    double ex = p2.x - p1.x, ey = p2.y - p1.y, ez = p2.z - p1.z;
    double cpx = (p1.x + p2.x) * 0.5;
    double cpy = (p1.y + p2.y) * 0.5;
    double cpz = (p1.z + p2.z) * 0.5;
    double mx = cpx - cam_pos.x;
    double my = cpy - cam_pos.y;
    double mz = cpz - cam_pos.z;

    // Width = edge × (mid→cam): perpendicular to both, stays camera-facing.
    double rx = ey * mz - ez * my;
    double ry = ez * mx - ex * mz;
    double rz = ex * my - ey * mx;
    double rlen = sqrt(rx * rx + ry * ry + rz * rz);
    if (rlen < 1e-6)
      return; // edge collinear with view ray (degenerate this frame)
    double inv_r = thickness / rlen;
    rx *= inv_r;
    ry *= inv_r;
    rz *= inv_r;

    // Fog blend mirrors draw_crystal_face; re-stamp alpha after.
    uint c = base_color;
    double dist_sq = mx * mx + my * my + mz * mz;
    double fog_t = (dist_sq - fog_start_sq) * inv_fog_sq_diff;
    if (fog_t > 0.0) {
      if (fog_t >= 1.0) {
        c = fog_bg_color;
      } else {
        int c_r = (c >> 16) & 0xFF, c_g = (c >> 8) & 0xFF, c_b = c & 0xFF;
        c_r += int((fog_r - c_r) * fog_t);
        c_g += int((fog_g - c_g) * fog_t);
        c_b += int((fog_b - c_b) * fog_t);
        c = (0xFF000000) | (uint(c_r) << 16) | (uint(c_g) << 8) | uint(c_b);
      }
    }
    uint alpha = (base_color >> 24) & uint(0xFF);
    c = (c & 0x00FFFFFF) | (alpha << 24);

    Vec3 @q0 = temp_edge_v[0];
    Vec3 @q1 = temp_edge_v[1];
    Vec3 @q2 = temp_edge_v[2];
    Vec3 @q3 = temp_edge_v[3];
    q0.x = p1.x + rx; q0.y = p1.y + ry; q0.z = p1.z + rz;
    q1.x = p1.x - rx; q1.y = p1.y - ry; q1.z = p1.z - rz;
    q2.x = p2.x - rx; q2.y = p2.y - ry; q2.z = p2.z - rz;
    q3.x = p2.x + rx; q3.y = p2.y + ry; q3.z = p2.z + rz;

    submit_world_quad(q0, q1, q2, q3, c, cam_pos, 0.0);
  }

  void draw_icosahedron(const Vec3 &in pos, double size, const Quaternion &in q,
                        uint color, const Vec3 &in cam_pos) {
    double phi = 1.6180339887 * size;
    double one = 1.0 * size;

    double fx, fy, fz, rx, ry, rz, ux, uy, uz;
    q.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);

    double o_rx = one * rx, o_ry = one * ry, o_rz = one * rz;
    double p_ux = phi * ux, p_uy = phi * uy, p_uz = phi * uz;

    double o_fx = one * fx, o_fy = one * fy, o_fz = one * fz;
    double p_rx = phi * rx, p_ry = phi * ry, p_rz = phi * rz;

    double p_fx = phi * fx, p_fy = phi * fy, p_fz = phi * fz;
    double o_ux = one * ux, o_uy = one * uy, o_uz = one * uz;

    array<Vec3> @v = @temp_prism_v;
    double px = pos.x, py = pos.y, pz = pos.z;

    v[0].set(px + o_rx + p_ux, py + o_ry + p_uy, pz + o_rz + p_uz);
    v[1].set(px - o_rx + p_ux, py - o_ry + p_uy, pz - o_rz + p_uz);
    v[2].set(px + o_rx - p_ux, py + o_ry - p_uy, pz + o_rz - p_uz);
    v[3].set(px - o_rx - p_ux, py - o_ry - p_uy, pz - o_rz - p_uz);

    v[4].set(px + o_fx + p_rx, py + o_fy + p_ry, pz + o_fz + p_rz);
    v[5].set(px - o_fx + p_rx, py - o_fy + p_ry, pz - o_fz + p_rz);
    v[6].set(px + o_fx - p_rx, py + o_fy - p_ry, pz + o_fz - p_rz);
    v[7].set(px - o_fx - p_rx, py - o_fy - p_ry, pz - o_fz - p_rz);

    v[8].set(px + p_fx + o_ux, py + p_fy + o_uy, pz + p_fz + o_uz);
    v[9].set(px - p_fx + o_ux, py - p_fy + o_uy, pz - p_fz + o_uz);
    v[10].set(px + p_fx - o_ux, py + p_fy - o_uy, pz + p_fz - o_uz);
    v[11].set(px - p_fx - o_ux, py - p_fy - o_uy, pz - p_fz - o_uz);

    // 5 top faces
    draw_crystal_face(v[0], v[1], v[8], color, cam_pos);
    draw_crystal_face(v[0], v[8], v[4], color, cam_pos);
    draw_crystal_face(v[0], v[4], v[5], color, cam_pos);
    draw_crystal_face(v[0], v[5], v[9], color, cam_pos);
    draw_crystal_face(v[0], v[9], v[1], color, cam_pos);

    // 5 bottom faces
    draw_crystal_face(v[3], v[11], v[7], color, cam_pos);
    draw_crystal_face(v[3], v[7], v[6], color, cam_pos);
    draw_crystal_face(v[3], v[6], v[10], color, cam_pos);
    draw_crystal_face(v[3], v[10], v[2], color, cam_pos);
    draw_crystal_face(v[3], v[2], v[11], color, cam_pos);

    // 10 equator faces
    draw_crystal_face(v[1], v[8], v[6], color, cam_pos);
    draw_crystal_face(v[8], v[4], v[10], color, cam_pos);
    draw_crystal_face(v[4], v[5], v[2], color, cam_pos);
    draw_crystal_face(v[5], v[9], v[11], color, cam_pos);
    draw_crystal_face(v[9], v[1], v[7], color, cam_pos);

    draw_crystal_face(v[10], v[6], v[8], color, cam_pos);
    draw_crystal_face(v[2], v[10], v[4], color, cam_pos);
    draw_crystal_face(v[11], v[2], v[5], color, cam_pos);
    draw_crystal_face(v[7], v[11], v[9], color, cam_pos);
    draw_crystal_face(v[6], v[7], v[1], color, cam_pos);

    // Wireframe pass — 30 icosahedron edges as camera-facing quads.
    // Color = 0xFC9D2B with prism's own alpha; width scales with size.
    uint edge_alpha = (color >> 24) & uint(0xFF);
    uint edge_color = (edge_alpha << 24) | uint(0xFC9D2B);
    double edge_thickness = size * 0.013;
    array<int> @ei = @prism_edge_idx;
    uint ei_n = ei.length();
    for (uint k = 0; k + 1 < ei_n; k += 2) {
      draw_prism_edge(v[ei[k]], v[ei[k + 1]], edge_color, edge_thickness,
                      cam_pos);
    }
  }

  void render_floating_prisms(const Vec3 &in cam_pos) {
    double h_fov = current_h_fov;
    double v_fov = current_v_fov;
    double h_bound_mult = current_h_bound_mult;
    double v_bound_mult = current_v_bound_mult;
    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;

    uint fp_len = floating_prisms.length();
    for (uint i = 0; i < fp_len; i++) {
      FloatingPrism @p = floating_prisms[i];

      double dx = p.pos.x - cam_pos.x;
      double dy = p.pos.y - cam_pos.y;
      double dz = p.pos.z - cam_pos.z;
      if (dx * dx + dy * dy + dz * dz > fog_end_sq)
        continue;

      double tx = dx * cfx + dy * cfy + dz * cfz;
      double bound = p.size * 2.0;

      if (tx + bound < 0.1)
        continue;

      double ty = dx * clx + dy * cly + dz * clz;
      double h_b = bound * h_bound_mult;
      double tx_h_fov = tx * h_fov;
      if (ty > tx_h_fov + h_b || -ty > tx_h_fov + h_b)
        continue;

      double tz = dx * cux + dy * cuy + dz * cuz;
      double v_b = bound * v_bound_mult;
      double tx_v_fov = tx * v_fov;
      if (tz > tx_v_fov + v_b || -tz > tx_v_fov + v_b)
        continue;

      Quaternion q;
      double ha = p.life * 0.35;
      double sha = sin(ha);
      q.w = cos(ha);
      q.x = sha * 0.3;
      q.y = sha * 0.5;
      q.z = sha * 0.8;
      q.normalize();

      // Spawn fade-in: alpha 0→base over first 0.5s. fp.life accumulates
      // even when off-camera, so far prisms emerge from fog naturally.
      double fade_t = (p.life >= 0.5) ? 1.0 : (double(p.life) * 2.0);
      uint base_alpha = (p.color >> 24) & uint(0xFF);
      uint faded_alpha = uint(double(base_alpha) * fade_t);
      uint draw_color = (faded_alpha << 24) | (p.color & uint(0xFFFFFF));

      draw_icosahedron(p.pos, p.size, q, draw_color, cam_pos);
    }
  }

  void render_prism_fragments(const Vec3 &in cam_pos) {
    double h_fov = current_h_fov;
    double v_fov = current_v_fov;
    double h_bound_mult = current_h_bound_mult;
    double v_bound_mult = current_v_bound_mult;
    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;

    uint pf_len = prism_fragments.length();
    for (uint i = 0; i < pf_len; i++) {
      PrismFragment @f = prism_fragments[i];

      double dx = f.pos.x - cam_pos.x;
      double dy = f.pos.y - cam_pos.y;
      double dz = f.pos.z - cam_pos.z;
      if (dx * dx + dy * dy + dz * dz > fog_end_sq)
        continue;

      double tx = dx * cfx + dy * cfy + dz * cfz;
      double bound = 160.0;

      if (tx + bound < 0.1)
        continue;

      double ty = dx * clx + dy * cly + dz * clz;
      double h_b = bound * h_bound_mult;
      double tx_h_fov = tx * h_fov;
      if (ty > tx_h_fov + h_b || -ty > tx_h_fov + h_b)
        continue;

      double tz = dx * cux + dy * cuy + dz * cuz;
      double v_b = bound * v_bound_mult;
      double tx_v_fov = tx * v_fov;
      if (tz > tx_v_fov + v_b || -tz > tx_v_fov + v_b)
        continue;

      Vec3 @v1 = temp_prism_v[0];
      Vec3 @v2 = temp_prism_v[1];
      Vec3 @v3 = temp_prism_v[2];
      Vec3 @v4 = temp_prism_v[3];

      double fx, fy, fz, rx, ry, rz, ux, uy, uz;
      f.rot.get_basis(fx, fy, fz, rx, ry, rz, ux, uy, uz);
      v1.x = f.p1.x * fx + f.p1.y * rx + f.p1.z * ux;
      v1.y = f.p1.x * fy + f.p1.y * ry + f.p1.z * uy;
      v1.z = f.p1.x * fz + f.p1.y * rz + f.p1.z * uz;
      v2.x = f.p2.x * fx + f.p2.y * rx + f.p2.z * ux;
      v2.y = f.p2.x * fy + f.p2.y * ry + f.p2.z * uy;
      v2.z = f.p2.x * fz + f.p2.y * rz + f.p2.z * uz;
      v3.x = f.p3.x * fx + f.p3.y * rx + f.p3.z * ux;
      v3.y = f.p3.x * fy + f.p3.y * ry + f.p3.z * uy;
      v3.z = f.p3.x * fz + f.p3.y * rz + f.p3.z * uz;
      v4.x = f.p4.x * fx + f.p4.y * rx + f.p4.z * ux;
      v4.y = f.p4.x * fy + f.p4.y * ry + f.p4.z * uy;
      v4.z = f.p4.x * fz + f.p4.y * rz + f.p4.z * uz;

      v1.x += f.pos.x;
      v1.y += f.pos.y;
      v1.z += f.pos.z;
      v2.x += f.pos.x;
      v2.y += f.pos.y;
      v2.z += f.pos.z;
      v3.x += f.pos.x;
      v3.y += f.pos.y;
      v3.z += f.pos.z;
      v4.x += f.pos.x;
      v4.y += f.pos.y;
      v4.z += f.pos.z;

      // Base alpha from f.color (matches icosahedron face opacity for both
      // mini chips and full-shatter shards), modulated by life.
      uint base_alpha = (f.color >> 24) & uint(0xFF);
      uint alpha = uint(f.life * double(base_alpha));
      if (alpha > 255)
        alpha = 255;
      if (alpha < 5)
        continue; // cull invisible early

      uint c = (f.color & 0x00FFFFFF) | (alpha << 24);

      // draw two triangles matching quad topology
      draw_crystal_face(v1, v2, v3, c, cam_pos);
      draw_crystal_face(v3, v4, v1, c, cam_pos);

      // Wireframe perimeter — 4 outer edges (diagonal omitted).
      // Thickness scales with longer diagonal; floor 0.075.
      double dx13 = v3.x - v1.x, dy13 = v3.y - v1.y, dz13 = v3.z - v1.z;
      double dx24 = v4.x - v2.x, dy24 = v4.y - v2.y, dz24 = v4.z - v2.z;
      double diag_sq_13 = dx13 * dx13 + dy13 * dy13 + dz13 * dz13;
      double diag_sq_24 = dx24 * dx24 + dy24 * dy24 + dz24 * dz24;
      double diag = sqrt(diag_sq_13 > diag_sq_24 ? diag_sq_13 : diag_sq_24);
      double frag_edge_thickness = diag * 0.006;
      if (frag_edge_thickness < 0.075)
        frag_edge_thickness = 0.075;
      uint frag_edge_color = (alpha << 24) | uint(0xFC9D2B);
      draw_prism_edge(v1, v2, frag_edge_color, frag_edge_thickness, cam_pos);
      draw_prism_edge(v2, v3, frag_edge_color, frag_edge_thickness, cam_pos);
      draw_prism_edge(v3, v4, frag_edge_color, frag_edge_thickness, cam_pos);
      draw_prism_edge(v4, v1, frag_edge_color, frag_edge_thickness, cam_pos);
    }
  }

  void render_particles(const Vec3 &in cam_pos) {
    uint p_len = particles.length();
    double fe = fog_end;
    for (uint i = 0; i < p_len; i++) {
      Particle @p = particles[i];

      double dx = p.pos.x - cam_pos.x;
      double dy = p.pos.y - cam_pos.y;
      double dz = p.pos.z - cam_pos.z;
      if (dx > fe || dx < -fe || dy > fe || dy < -fe || dz > fe || dz < -fe)
        continue;
      if (dx * dx + dy * dy + dz * dz > fog_end_sq)
        continue;

      uint a = uint(p.life * 255.0);
      if (a > 255)
        a = 255;
      uint c = (p.color & 0x00FFFFFF) | (a << 24);

      if (p.streak) {
        // Streak: thin quad in (vel, view-perp). Long = vel; short = life.
        double vx = p.vel.x, vy = p.vel.y, vz = p.vel.z;
        double vlen = sqrt(vx * vx + vy * vy + vz * vz);
        double fx, fy, fz;
        if (vlen > 1e-4) {
          double inv_v = 1.0 / vlen;
          fx = vx * inv_v;
          fy = vy * inv_v;
          fz = vz * inv_v;
        } else {
          fx = 1; fy = 0; fz = 0;
        }
        // fwd × view_dir → screen-perp axis (width faces camera).
        double rx = fy * dz - fz * dy;
        double ry = fz * dx - fx * dz;
        double rz = fx * dy - fy * dx;
        double rlen = sqrt(rx * rx + ry * ry + rz * rz);
        if (rlen > 1e-4) {
          double inv_r = 1.0 / rlen;
          rx *= inv_r;
          ry *= inv_r;
          rz *= inv_r;
        } else {
          // velocity points straight at camera — fall back to cam_left.
          rx = cam_left_vec.x;
          ry = cam_left_vec.y;
          rz = cam_left_vec.z;
        }

        // Length scales with speed; clamped so slow=dash, fast≠smear.
        double streak_len = vlen * 0.04;
        if (streak_len < 3.0) streak_len = 3.0;
        if (streak_len > 30.0) streak_len = 30.0;
        double streak_wid = 0.6 + p.life * 0.8;

        double half_len = streak_len * 0.5;
        double fxL = fx * half_len, fyL = fy * half_len, fzL = fz * half_len;
        double rxW = rx * streak_wid, ryW = ry * streak_wid, rzW = rz * streak_wid;

        temp_prism_v[0].x = p.pos.x + fxL + rxW;
        temp_prism_v[0].y = p.pos.y + fyL + ryW;
        temp_prism_v[0].z = p.pos.z + fzL + rzW;
        temp_prism_v[1].x = p.pos.x + fxL - rxW;
        temp_prism_v[1].y = p.pos.y + fyL - ryW;
        temp_prism_v[1].z = p.pos.z + fzL - rzW;
        temp_prism_v[2].x = p.pos.x - fxL - rxW;
        temp_prism_v[2].y = p.pos.y - fyL - ryW;
        temp_prism_v[2].z = p.pos.z - fzL - rzW;
        temp_prism_v[3].x = p.pos.x - fxL + rxW;
        temp_prism_v[3].y = p.pos.y - fyL + ryW;
        temp_prism_v[3].z = p.pos.z - fzL + rzW;

        submit_world_quad(temp_prism_v[0], temp_prism_v[1], temp_prism_v[2],
                          temp_prism_v[3], c, cam_pos, 300.0);
        continue;
      }

      double size = 1.0 * (p.life + 0.2);

      double lx_s = cam_left_vec.x * size;
      double ly_s = cam_left_vec.y * size;
      double lz_s = cam_left_vec.z * size;
      double ux_s = cam_up_vec.x * size;
      double uy_s = cam_up_vec.y * size;
      double uz_s = cam_up_vec.z * size;

      double p1x = p.pos.x + lx_s + ux_s;
      double p1y = p.pos.y + ly_s + uy_s;
      double p1z = p.pos.z + lz_s + uz_s;

      double p2x = p.pos.x - lx_s + ux_s;
      double p2y = p.pos.y - ly_s + uy_s;
      double p2z = p.pos.z - lz_s + uz_s;

      double p3x = p.pos.x - lx_s - ux_s;
      double p3y = p.pos.y - ly_s - uy_s;
      double p3z = p.pos.z - lz_s - uz_s;

      double p4x = p.pos.x + lx_s - ux_s;
      double p4y = p.pos.y + ly_s - uy_s;
      double p4z = p.pos.z + lz_s - uz_s;

      temp_prism_v[0].x = p1x;
      temp_prism_v[0].y = p1y;
      temp_prism_v[0].z = p1z;
      temp_prism_v[1].x = p2x;
      temp_prism_v[1].y = p2y;
      temp_prism_v[1].z = p2z;
      temp_prism_v[2].x = p3x;
      temp_prism_v[2].y = p3y;
      temp_prism_v[2].z = p3z;
      temp_prism_v[3].x = p4x;
      temp_prism_v[3].y = p4y;
      temp_prism_v[3].z = p4z;

      // z_bias 300: see submit_trail_quad.
      submit_world_quad(temp_prism_v[0], temp_prism_v[1], temp_prism_v[2],
                        temp_prism_v[3], c, cam_pos, 300.0);
    }
  }

  void render_projectiles(const Vec3 &in cam_pos) {
    uint p_len = projectiles.length();
    double fe = fog_end;
    for (uint i = 0; i < p_len; i++) {
      Projectile @p = projectiles[i];

      double dx = p.pos.x - cam_pos.x;
      double dy = p.pos.y - cam_pos.y;
      double dz = p.pos.z - cam_pos.z;
      if (dx > fe || dx < -fe || dy > fe || dy < -fe || dz > fe || dz < -fe)
        continue;
      if (dx * dx + dy * dy + dz * dz > fog_end_sq)
        continue;

      double vlen =
          sqrt(p.vel.x * p.vel.x + p.vel.y * p.vel.y + p.vel.z * p.vel.z);
      double fx = p.vel.x, fy = p.vel.y, fz = p.vel.z;
      if (vlen > 1e-4) {
        double inv_vlen = 1.0 / vlen;
        fx *= inv_vlen;
        fy *= inv_vlen;
        fz *= inv_vlen;
      } else {
        fx = 1;
        fy = 0;
        fz = 0;
      }

      double ux = 0, uy = 0, uz = 1;
      double dp = fx * ux + fy * uy + fz * uz;
      if (abs(dp) > 0.99) {
        uy = 1;
        uz = 0;
      }

      double rx = fy * uz - fz * uy;
      double ry = fz * ux - fx * uz;
      double rz = fx * uy - fy * ux;
      double rlen = sqrt(rx * rx + ry * ry + rz * rz);
      if (rlen > 1e-4) {
        double inv_rlen = 1.0 / rlen;
        rx *= inv_rlen;
        ry *= inv_rlen;
        rz *= inv_rlen;
      }

      ux = ry * fz - rz * fy;
      uy = rz * fx - rx * fz;
      uz = rx * fy - ry * fx;

      double anim = p.life * 25.0;
      double s = sin(anim), c = cos(anim);

      double lrx = rx * c - ux * s;
      double lry = ry * c - uy * s;
      double lrz = rz * c - uz * s;

      double lux = rx * s + ux * c;
      double luy = ry * s + uy * c;
      double luz = rz * s + uz * c;

      double size = 6.0;
      double len = 40.0;

      double vx_x = lrx * size, vx_y = lry * size, vx_z = lrz * size;
      double vy_x = lux * size, vy_y = luy * size, vy_z = luz * size;
      double vz_x = fx * len, vz_y = fy * len, vz_z = fz * len;

      double px = p.pos.x, py = p.pos.y, pz = p.pos.z;

      box_p000.set(px - vx_x - vy_x - vz_x, py - vx_y - vy_y - vz_y,
                   pz - vx_z - vy_z - vz_z);
      box_p100.set(px + vx_x - vy_x - vz_x, py + vx_y - vy_y - vz_y,
                   pz + vx_z - vy_z - vz_z);
      box_p010.set(px - vx_x + vy_x - vz_x, py - vx_y + vy_y - vz_y,
                   pz - vx_z + vy_z - vz_z);
      box_p110.set(px + vx_x + vy_x - vz_x, py + vx_y + vy_y - vz_y,
                   pz + vx_z + vy_z - vz_z);

      box_p001.set(px - vx_x - vy_x + vz_x, py - vx_y - vy_y + vz_y,
                   pz - vx_z - vy_z + vz_z);
      box_p101.set(px + vx_x - vy_x + vz_x, py + vx_y - vy_y + vz_y,
                   pz + vx_z - vy_z + vz_z);
      box_p011.set(px - vx_x + vy_x + vz_x, py - vx_y + vy_y + vz_y,
                   pz - vx_z + vy_z + vz_z);
      box_p111.set(px + vx_x + vy_x + vz_x, py + vx_y + vy_y + vz_y,
                   pz + vx_z + vy_z + vz_z);

      // z_bias 300; 8 shared corners projected once, 6 faces emitted.
      submit_world_box_from_corners(p.color, 300.0);
    }
  }
  
  void queue_wheel_trails(array<TrailPoint @> @trail, const Vec3 &in cam_pos) {
    // INVARIANT: OLDEST→NEWEST. Segment connects trail[i-1]→trail[i];
    // `connected` set on newer point. newness = (t_len-1) - i.
    uint t_len = trail.length();
    for (uint i = 1; i < t_len; i++) {
      TrailPoint @tp_i   = trail[i];
      if (!tp_i.connected)
        continue;
      TrailPoint @tp_im1 = trail[i - 1];

      Vec3 @p1 = tp_im1.pos;
      Vec3 @p2 = tp_i.pos;
      double p1x = p1.x, p1y = p1.y, p1z = p1.z;
      double p2x = p2.x, p2y = p2.y, p2z = p2.z;
      double dir_x = p2x - p1x, dir_y = p2y - p1y, dir_z = p2z - p1z;
      double dir_sq = dir_x * dir_x + dir_y * dir_y + dir_z * dir_z;
      if (dir_sq < 1e-4)
        continue;

      double d_mag = sqrt(dir_sq);
      double inv_dmag = 1.0 / d_mag;
      dir_x *= inv_dmag;
      dir_y *= inv_dmag;
      dir_z *= inv_dmag;

      double rx = dir_y, ry = -dir_x, rz = 0;
      double r_sq = rx * rx + ry * ry + rz * rz;
      if (r_sq < 1e-4) {
        rx = 1;
        ry = 0;
        rz = 0;
      } else {
        double r_mag = sqrt(r_sq);
        double inv_rmag = 1.0 / r_mag;
        rx *= inv_rmag;
        ry *= inv_rmag;
        rz *= inv_rmag;
      }

      double w_off_x = rx * 0.5, w_off_y = ry * 0.5, w_off_z = rz * 0.5;

      temp_q1.x = p1x - w_off_x;
      temp_q1.y = p1y - w_off_y;
      temp_q1.z = p1z - w_off_z + 0.5;
      temp_q2.x = p1x + w_off_x;
      temp_q2.y = p1y + w_off_y;
      temp_q2.z = p1z + w_off_z + 0.5;
      temp_q3.x = p2x + w_off_x;
      temp_q3.y = p2y + w_off_y;
      temp_q3.z = p2z + w_off_z + 0.5;
      temp_q4.x = p2x - w_off_x;
      temp_q4.y = p2y - w_off_y;
      temp_q4.z = p2z - w_off_z + 0.5;

      uint newness = (t_len - 1) - i;
      float fade = (newness < 5) ? (float(newness) * 0.2) : 1.0;
      uint alpha = uint(tp_i.life * 120.0 * fade);
      uint c = (alpha << 24) | 0x00111111;

      submit_trail_quad(temp_q1, temp_q2, temp_q3, temp_q4, c, cam_pos);
    }
  }

  // === Wind streamers (fx_level >= 3) =======================================
  // See file-scope WIND_* tuning constants. Both update + render gated on
  // fx_level >= 3 at call site.

  // Step global drift, advance/decay each stream's head + chain, age out,
  // probabilistically spawn up to WIND_MAX_STREAMS.
  void update_wind_streams() {
    // --- 1. Advance global wind drift phases + recompute current vector ---
    wind_drift_phase_yaw += WIND_DRIFT_RATE_YAW * DT_D;
    wind_drift_phase_pit += WIND_DRIFT_RATE_PIT * DT_D;
    wind_strength_phase  += WIND_DRIFT_RATE_STR * DT_D;
    // Wrap phases to keep double precision tight over hours of play.
    if (wind_drift_phase_yaw > 6.2831853) wind_drift_phase_yaw -= 6.2831853;
    if (wind_drift_phase_pit > 6.2831853) wind_drift_phase_pit -= 6.2831853;
    if (wind_strength_phase  > 6.2831853) wind_strength_phase  -= 6.2831853;

    double yaw_drift = WIND_DRIFT_AMP_YAW * sin(wind_drift_phase_yaw);
    double pit_drift = WIND_DRIFT_AMP_PIT * sin(wind_drift_phase_pit);

    // Build wind direction by yawing-then-pitching the unit base vector.
    double base_x = WIND_BASE_X, base_y = WIND_BASE_Y, base_z = WIND_BASE_Z;
    double base_len_inv =
        1.0 / sqrt(base_x * base_x + base_y * base_y + base_z * base_z);
    base_x *= base_len_inv;
    base_y *= base_len_inv;
    base_z *= base_len_inv;

    // Yaw around world +Z: rotate (x,y), z unchanged.
    double cy_ = cos(yaw_drift), sy_ = sin(yaw_drift);
    double yx = base_x * cy_ - base_y * sy_;
    double yy = base_x * sy_ + base_y * cy_;
    double yz = base_z;
    // Pitch: rotate the (horizontal_mag, z) plane. Preserves yaw bearing.
    double fwd_h = sqrt(yx * yx + yy * yy);
    double cp_ = cos(pit_drift), sp_ = sin(pit_drift);
    double rx, ry, rz;
    if (fwd_h > 1e-9) {
      double new_h = fwd_h * cp_ - yz * sp_;
      double new_z = fwd_h * sp_ + yz * cp_;
      double scale = new_h / fwd_h;
      rx = yx * scale;
      ry = yy * scale;
      rz = new_z;
    } else {
      rx = yx;
      ry = yy;
      rz = yz;
    }
    // Renormalize to absorb any accumulated rotation drift.
    double rl_inv = 1.0 / sqrt(rx * rx + ry * ry + rz * rz);
    rx *= rl_inv;
    ry *= rl_inv;
    rz *= rl_inv;
    wind_vec_cur.set(rx, ry, rz);
    wind_strength_cur =
        WIND_BASE_STRENGTH + WIND_STRENGTH_OSC * sin(wind_strength_phase);
    if (wind_strength_cur < 30.0) wind_strength_cur = 30.0;

    // --- 2. Advance + decay each active stream ---------------------------
    // Per-stream ws.wind_dir + ws.speed_mult drives head motion. Global
    // wind_strength_cur is shared baseline so all streams pulse together;
    // wind_vec_cur only affects NEW spawns (snapshot at spawn_wind_stream).
    double dt_d = DT_D;
    float  dt_f = float(DT_D);

    int n = int(wind_streams.length());
    for (int i = n - 1; i >= 0; i--) {
      WindStream @ws = wind_streams[i];

      ws.age += dt_f;

      // Past max_age: stop emitting/integrating head — let chain decay via
      // point_life. Stream freed below when chain empties.
      if (ws.age < ws.max_age) {
        // Integrate head: per-stream wind*dt + delta-meander on snapshot
        // perp axes. sin(prev_phase_a/b) cached in ws.sin_phase_a/b — saves
        // 2 sin() calls per stream per frame. Cache seeded at spawn.
        ws.phase_a += ws.freq_a * dt_d;
        ws.phase_b += ws.freq_b * dt_d;

        double new_sin_a = sin(ws.phase_a);
        double new_sin_b = sin(ws.phase_b);
        double ds_a = new_sin_a - ws.sin_phase_a;
        double ds_b = new_sin_b - ws.sin_phase_b;
        ws.sin_phase_a = new_sin_a;
        ws.sin_phase_b = new_sin_b;
        double amp = ws.meander_amp;
        double meander_dx = (ws.perp_a.x * ds_a + ws.perp_b.x * ds_b) * amp;
        double meander_dy = (ws.perp_a.y * ds_a + ws.perp_b.y * ds_b) * amp;
        double meander_dz = (ws.perp_a.z * ds_a + ws.perp_b.z * ds_b) * amp;

        double sm_speed = wind_strength_cur * ws.speed_mult;
        double ssx = ws.wind_dir.x * sm_speed;
        double ssy = ws.wind_dir.y * sm_speed;
        double ssz = ws.wind_dir.z * sm_speed;

        ws.head.x += ssx * dt_d + meander_dx;
        ws.head.y += ssy * dt_d + meander_dy;
        ws.head.z += ssz * dt_d + meander_dz;

        ws.emit_timer -= dt_f;
        if (ws.emit_timer <= 0.0f) {
          ws.emit_timer += WIND_EMIT_INTERVAL;
          Vec3 hp;
          hp.set(ws.head.x, ws.head.y, ws.head.z);
          ws.points.insertLast(hp);
          ws.point_life.insertLast(1.0f);
          // Cap chain length — pop oldest. Cap rarely hits since life-decay
          // beats this most of the time, but bounds memory under any tuning.
          if (ws.points.length() > WIND_MAX_POINTS_PER_STREAM) {
            ws.points.removeAt(0);
            ws.point_life.removeAt(0);
          }
        }
      }

      // Decay chain points uniformly; trim dead front (oldest first).
      array<Vec3>  @ws_points = @ws.points;
      array<float> @ws_life   = @ws.point_life;
      uint pn = ws_points.length();
      if (pn > 0) {
        float decay = WIND_POINT_LIFE_DECAY * dt_f;
        for (uint k = 0; k < pn; k++) {
          ws_life[k] -= decay;
        }
        uint drop = 0;
        while (drop < pn && ws_life[drop] <= 0.0f) drop++;
        if (drop > 0) {
          uint nn = pn - drop;
          for (uint k = 0; k < nn; k++) {
            ws_points[k] = ws_points[k + drop];
            ws_life[k]   = ws_life[k + drop];
          }
          ws_points.resize(nn);
          ws_life.resize(nn);
        }
      }

      // Recompute stream bound sphere (AABB→centroid + diag-radius) for
      // render_wind_streams's per-stream cull. Stale-bound safe: render's
      // `pn < 2 continue` gate covers the 0-point case.
      uint final_pn = ws_points.length();
      if (final_pn > 0) {
        Vec3 @pp0 = ws_points[0];
        double minx = pp0.x, miny = pp0.y, minz = pp0.z;
        double maxx = minx,  maxy = miny,  maxz = minz;
        for (uint k = 1; k < final_pn; k++) {
          Vec3 @pp = ws_points[k];
          double px = pp.x, py = pp.y, pz = pp.z;
          if (px < minx) minx = px; else if (px > maxx) maxx = px;
          if (py < miny) miny = py; else if (py > maxy) maxy = py;
          if (pz < minz) minz = pz; else if (pz > maxz) maxz = pz;
        }
        double hx = (maxx - minx) * 0.5;
        double hy = (maxy - miny) * 0.5;
        double hz = (maxz - minz) * 0.5;
        ws.bound_c.set((minx + maxx) * 0.5,
                       (miny + maxy) * 0.5,
                       (minz + maxz) * 0.5);
        ws.bound_r = sqrt(hx * hx + hy * hy + hz * hz);
      }

      // Free stream once aged past max_age AND chain has fully drained.
      if (ws.age >= ws.max_age && final_pn == 0) {
        free_wind_stream(ws);
        @wind_streams[i] = @wind_streams[n - 1];
        wind_streams.removeLast();
        n--;
      }
    }

    // --- 3. Probabilistic spawn ------------------------------------------
    // Altitude gate: see WIND_MIN_SPAWN_Z. Existing streams age out
    // naturally — not culled mid-flight.
    if (wind_streams.length() < WIND_MAX_STREAMS &&
        pos.z >= WIND_MIN_SPAWN_Z) {
      if (double(rand() % 100000) <
          100000.0 * double(WIND_SPAWN_PROB_PER_FRAME)) {
        spawn_wind_stream();
      }
    }
  }

  // Spawn one wind streamer in a sphere around plane (cam-proxy), biased
  // upwind so streams sweep through view as they age. Caller must check
  // WIND_MAX_STREAMS before calling.
  void spawn_wind_stream() {
    WindStream @ws = get_wind_stream();

    // Random point in unit sphere via rejection (~52% accept). Fallback to
    // last sample if rejection streak hits 8 (visual penalty trivial).
    double sx = 0.0, sy = 0.0, sz = 0.0;
    for (int try_i = 0; try_i < 8; try_i++) {
      sx = (double(rand() % 20001) - 10000.0) * 0.0001;
      sy = (double(rand() % 20001) - 10000.0) * 0.0001;
      sz = (double(rand() % 20001) - 10000.0) * 0.0001;
      if (sx * sx + sy * sy + sz * sz <= 1.0) break;
    }

    // Plane pos as cam-proxy — camera_pos is only interpolated at draw().
    double cx = pos.x, cy = pos.y, cz = pos.z;
    double bias_x = wind_vec_cur.x * WIND_UPWIND_BIAS;
    double bias_y = wind_vec_cur.y * WIND_UPWIND_BIAS;
    double bias_z = wind_vec_cur.z * WIND_UPWIND_BIAS;
    double spawn_x = cx + sx * WIND_SPAWN_RADIUS - bias_x;
    double spawn_y = cy + sy * WIND_SPAWN_RADIUS - bias_y;
    double spawn_z = cz + sz * WIND_SPAWN_RADIUS - bias_z;

    ws.head.set(spawn_x, spawn_y, spawn_z);
    ws.points.resize(0);
    ws.point_life.resize(0);
    ws.age = 0.0f;
    ws.max_age = WIND_STREAM_AGE_MIN +
                 (WIND_STREAM_AGE_MAX - WIND_STREAM_AGE_MIN) *
                 (float(rand() % 1000) * 0.001f);
    ws.fade_in_t  = WIND_FADE_IN_T;
    ws.fade_out_t = WIND_FADE_OUT_T;
    ws.emit_timer = 0.0f; // immediate first emit

    // ---- Archetype roll: 4 profiles, weighted toward CALM/MODERATE.
    // Each picks [amp,freq,speed,dir_jitter] ranges, sampled uniformly.
    int arch_roll = rand() % 100;
    double amp_lo, amp_hi, freq_lo, freq_hi, spd_lo, spd_hi, dir_jit;
    if (arch_roll < WIND_ARCH_CALM_PCT) {
      amp_lo  = WIND_CALM_AMP_LO;  amp_hi  = WIND_CALM_AMP_HI;
      freq_lo = WIND_CALM_FREQ_LO; freq_hi = WIND_CALM_FREQ_HI;
      spd_lo  = WIND_CALM_SPD_LO;  spd_hi  = WIND_CALM_SPD_HI;
      dir_jit = WIND_CALM_DIR_JIT;
    } else if (arch_roll < WIND_ARCH_MOD_PCT) {
      amp_lo  = WIND_MOD_AMP_LO;   amp_hi  = WIND_MOD_AMP_HI;
      freq_lo = WIND_MOD_FREQ_LO;  freq_hi = WIND_MOD_FREQ_HI;
      spd_lo  = WIND_MOD_SPD_LO;   spd_hi  = WIND_MOD_SPD_HI;
      dir_jit = WIND_MOD_DIR_JIT;
    } else if (arch_roll < WIND_ARCH_FAST_PCT) {
      amp_lo  = WIND_FAST_AMP_LO;  amp_hi  = WIND_FAST_AMP_HI;
      freq_lo = WIND_FAST_FREQ_LO; freq_hi = WIND_FAST_FREQ_HI;
      spd_lo  = WIND_FAST_SPD_LO;  spd_hi  = WIND_FAST_SPD_HI;
      dir_jit = WIND_FAST_DIR_JIT;
    } else {
      amp_lo  = WIND_TURB_AMP_LO;  amp_hi  = WIND_TURB_AMP_HI;
      freq_lo = WIND_TURB_FREQ_LO; freq_hi = WIND_TURB_FREQ_HI;
      spd_lo  = WIND_TURB_SPD_LO;  spd_hi  = WIND_TURB_SPD_HI;
      dir_jit = WIND_TURB_DIR_JIT;
    }

    // ---- Per-stream wind direction snapshot from wind_vec_cur + per-
    // stream yaw/pitch jitter (±dir_jit radians). Frozen at spawn — gives
    // different streams visibly different headings.
    double yaw_jit = (double(rand() % 2001) - 1000.0) * 0.001 * dir_jit;
    double pit_jit = (double(rand() % 2001) - 1000.0) * 0.001 * dir_jit;
    double bx = wind_vec_cur.x, by = wind_vec_cur.y, bz = wind_vec_cur.z;
    // Yaw around world +Z: rotate (x,y), z unchanged.
    double cy_j = cos(yaw_jit), sy_j = sin(yaw_jit);
    double j_yx = bx * cy_j - by * sy_j;
    double j_yy = bx * sy_j + by * cy_j;
    double j_yz = bz;
    // Pitch: rotate (horizontal_mag, z). Preserves yaw bearing.
    double j_fwd_h = sqrt(j_yx * j_yx + j_yy * j_yy);
    double cp_j = cos(pit_jit), sp_j = sin(pit_jit);
    double sdx, sdy, sdz;
    if (j_fwd_h > 1e-9) {
      double new_h = j_fwd_h * cp_j - j_yz * sp_j;
      double new_z = j_fwd_h * sp_j + j_yz * cp_j;
      double scale = new_h / j_fwd_h;
      sdx = j_yx * scale;
      sdy = j_yy * scale;
      sdz = new_z;
    } else {
      sdx = j_yx; sdy = j_yy; sdz = j_yz;
    }
    double sd_inv = 1.0 / sqrt(sdx * sdx + sdy * sdy + sdz * sdz);
    sdx *= sd_inv; sdy *= sd_inv; sdz *= sd_inv;
    ws.wind_dir.set(sdx, sdy, sdz);

    // ---- Perp axes to per-stream wind dir. Meander wobble lives in this
    // perp plane so it tracks the stream's heading (not global).
    //   perp_a = stream_dir × world-up (fallback if collinear)
    //   perp_b = stream_dir × perp_a (orthonormal triad)
    double wx = sdx, wy = sdy, wz = sdz;
    double ax = wy;            // stream_dir × (0,0,1) = (wy, -wx, 0)
    double ay = -wx;
    double az = 0.0;
    double alen = sqrt(ax * ax + ay * ay + az * az);
    if (alen < 1e-4) {
      // Stream dir ≈ vertical: fall back to dir × (1,0,0) = (0, wz, -wy).
      ax = 0.0;
      ay = wz;
      az = -wy;
      alen = sqrt(ax * ax + ay * ay + az * az);
    }
    double ainv = (alen > 1e-9) ? (1.0 / alen) : 1.0;
    ax *= ainv; ay *= ainv; az *= ainv;
    double pbx = wy * az - wz * ay;
    double pby = wz * ax - wx * az;
    double pbz = wx * ay - wy * ax;
    double blen = sqrt(pbx * pbx + pby * pby + pbz * pbz);
    double binv = (blen > 1e-9) ? (1.0 / blen) : 1.0;
    pbx *= binv; pby *= binv; pbz *= binv;
    ws.perp_a.set(ax, ay, az);
    ws.perp_b.set(pbx, pby, pbz);

    // ---- Sample meander shape + speed_mult from archetype ranges.
    // Independent freq samples avoid resonance; randomized phases break
    // lockstep across streams.
    double t01 = double(rand() % 1000) * 0.001;
    double u01 = double(rand() % 1000) * 0.001;
    double v01 = double(rand() % 1000) * 0.001;
    double s01 = double(rand() % 1000) * 0.001;
    ws.freq_a = freq_lo + (freq_hi - freq_lo) * t01;
    ws.freq_b = freq_lo + (freq_hi - freq_lo) * u01;
    ws.phase_a = double(rand() % 1000) * 0.001 * 6.2831853;
    ws.phase_b = double(rand() % 1000) * 0.001 * 6.2831853;
    // Seed cached sin(phase_a/b) so frame-0 delta-meander has correct
    // initial value (otherwise ds_a/ds_b would jolt head).
    ws.sin_phase_a = sin(ws.phase_a);
    ws.sin_phase_b = sin(ws.phase_b);
    ws.meander_amp = amp_lo + (amp_hi - amp_lo) * v01;
    ws.speed_mult  = spd_lo + (spd_hi - spd_lo) * s01;
    // bound_c / bound_r left default-init — render's `pn < 2 continue`
    // skips before bound test on frame 0, so stale bound never read.

    wind_streams.insertLast(ws);
  }

  // Render each active stream as a chain of camera-facing thin ribbons via
  // submit_world_quad (z_bias 200 — under shadow=290, above terrain=0).
  // Per-segment alpha = peak * stream_env * pos-in-chain envelope.
  void render_wind_streams(const Vec3 &in cam_pos) {
    uint sn = wind_streams.length();
    if (sn == 0) return;

    double cpx = cam_pos.x, cpy = cam_pos.y, cpz = cam_pos.z;
    double cfx = cam_fwd_vec.x,  cfy = cam_fwd_vec.y,  cfz = cam_fwd_vec.z;
    double clx = cam_left_vec.x, cly = cam_left_vec.y, clz = cam_left_vec.z;
    double cux = cam_up_vec.x,   cuy = cam_up_vec.y,   cuz = cam_up_vec.z;
    double hfov = current_h_fov;
    double vfov = current_v_fov;
    double hbm  = current_h_bound_mult;
    double vbm  = current_v_bound_mult;
    double fes  = fog_end_sq;

    for (uint si = 0; si < sn; si++) {
      WindStream @ws = wind_streams[si];

      // Stream-level envelope — ramp in/plateau/ramp out by age.
      float env;
      if (ws.age < ws.fade_in_t) {
        env = ws.age / ws.fade_in_t;
      } else if (ws.age > ws.max_age - ws.fade_out_t) {
        env = (ws.max_age - ws.age) / ws.fade_out_t;
      } else {
        env = 1.0f;
      }
      if (env < 0.0f) env = 0.0f;
      if (env > 1.0f) env = 1.0f;
      if (env <= 0.001f) continue;

      array<Vec3> @ws_points = @ws.points;
      uint pn = ws_points.length();
      if (pn < 2) continue; // need at least one segment

      // Stream-level cull — sphere bound from update_wind_streams. Mirrors
      // render_floating_prisms behind-cam + frustum-cone cull. Per-segment
      // fog cull kept since bound sphere is loose for long chains.
      double bdx = ws.bound_c.x - cpx;
      double bdy = ws.bound_c.y - cpy;
      double bdz = ws.bound_c.z - cpz;
      double br  = ws.bound_r;
      double tx_b = bdx * cfx + bdy * cfy + bdz * cfz;
      if (tx_b + br < 0.1) continue; // fully behind near plane
      double ty_b = bdx * clx + bdy * cly + bdz * clz;
      double h_b  = br * hbm;
      double tx_h = tx_b * hfov;
      if (ty_b > tx_h + h_b || -ty_b > tx_h + h_b) continue;
      double tz_b = bdx * cux + bdy * cuy + bdz * cuz;
      double v_b  = br * vbm;
      double tx_v = tx_b * vfov;
      if (tz_b > tx_v + v_b || -tz_b > tx_v + v_b) continue;

      // Reciprocal for pos_in_chain — inner loop becomes one mul per seg.
      float inv_pn_minus_1 = 1.0f / float(pn - 1);

      for (uint i = 1; i < pn; i++) {
        Vec3 @p1 = ws_points[i - 1];
        Vec3 @p2 = ws_points[i];
        double midx = (p1.x + p2.x) * 0.5;
        double midy = (p1.y + p2.y) * 0.5;
        double midz = (p1.z + p2.z) * 0.5;
        double dx = midx - cpx;
        double dy = midy - cpy;
        double dz = midz - cpz;
        double dist_sq = dx * dx + dy * dy + dz * dz;
        if (dist_sq > fes) continue; // past fog horizon

        // Perp = edge × (mid → cam): camera-facing thin ribbon. Width
        // scales linearly with distance for ~constant on-screen thickness
        // (~1.1 px). Same construction as draw_prism_edge.
        double ex = p2.x - p1.x;
        double ey = p2.y - p1.y;
        double ez = p2.z - p1.z;
        double mx = -dx, my = -dy, mz = -dz; // mid → cam
        double rx = ey * mz - ez * my;
        double ry = ez * mx - ex * mz;
        double rz = ex * my - ey * mx;
        double rlen_sq = rx * rx + ry * ry + rz * rz;
        if (rlen_sq < 1e-8) continue; // edge collinear with view ray
        double dist_to_cam = sqrt(dist_sq);
        double effective_thickness = WIND_THICKNESS_PER_U * dist_to_cam;
        if (effective_thickness < WIND_THICKNESS_MIN) continue; // ribbon too close
        double inv_r = effective_thickness / sqrt(rlen_sq);
        rx *= inv_r; ry *= inv_r; rz *= inv_r;

        // BILATERAL FADE — parabolic bell 4·pos·(1-pos) tapers BOTH head
        // and tail to zero, reading as discrete wisp not comet. point_life
        // intentionally absent from alpha (would only ever fade tail);
        // it still drives chain trim in update_wind_streams.
        float pos_in_chain = float(i) * inv_pn_minus_1;       // 0..1
        float pos_env = 4.0f * pos_in_chain * (1.0f - pos_in_chain);
        if (pos_env <= 0.001f) continue; // segment is at the very tip

        float alpha_f = WIND_PEAK_ALPHA * env * pos_env;
        uint alpha = uint(alpha_f);
        if (alpha == 0) continue;
        if (alpha > 255) alpha = 255;
        uint c = (alpha << 24) | 0x00FFFFFF; // white tint

        // Reuse class-scratch temp_edge_v[0..3] — shared with draw_prism_
        // edge. submit_world_quad reads p*.x/y/z to scalars before return,
        // so scratch is safe to reuse next iter (avoids GC pressure).
        Vec3 @q1 = temp_edge_v[0];
        Vec3 @q2 = temp_edge_v[1];
        Vec3 @q3 = temp_edge_v[2];
        Vec3 @q4 = temp_edge_v[3];
        q1.x = p1.x + rx; q1.y = p1.y + ry; q1.z = p1.z + rz;
        q2.x = p1.x - rx; q2.y = p1.y - ry; q2.z = p1.z - rz;
        q3.x = p2.x - rx; q3.y = p2.y - ry; q3.z = p2.z - rz;
        q4.x = p2.x + rx; q4.y = p2.y + ry; q4.z = p2.z + rz;
        submit_world_quad(q1, q2, q3, q4, c, cam_pos, WIND_Z_BIAS);
      }
    }
  }

  void render_fx(const Quaternion &in camera_orientation,
                 const Vec3 &in camera_pos) {
    render_trail(@trail_L, camera_orientation, camera_pos);
    render_trail(@trail_R, camera_orientation, camera_pos);
  }

  void render_trail(array<TrailPoint @> @trail, const Quaternion &in camera_orientation, const Vec3 &in camera_pos) {
    uint t_len = trail.length();

    // Cache heavily hit matrices
    double cpx = camera_pos.x, cpy = camera_pos.y, cpz = camera_pos.z;
    double fwx = cam_fwd_vec.x, fwy = cam_fwd_vec.y, fwz = cam_fwd_vec.z;
    double lfx = cam_left_vec.x, lfy = cam_left_vec.y, lfz = cam_left_vec.z;
    double upx = cam_up_vec.x, upy = cam_up_vec.y, upz = cam_up_vec.z;
    double cfov = camera_fov;

    for (uint i = 1; i < t_len; i++) {
      TrailPoint @tp_i = trail[i];
      if (!tp_i.connected) continue;
      TrailPoint @tp_im1 = trail[i - 1];
      Vec3 @pos_im1 = tp_im1.pos;
      Vec3 @pos_i   = tp_i.pos;

      // INLINED project_fast (Point 1)
      double dx1 = pos_im1.x - cpx;
      double dy1 = pos_im1.y - cpy;
      double dz1 = pos_im1.z - cpz;
      double rx1 = dx1 * fwx + dy1 * fwy + dz1 * fwz;
      if (rx1 < 0.1) continue;

      // INLINED project_fast (Point 2)
      double dx2 = pos_i.x - cpx;
      double dy2 = pos_i.y - cpy;
      double dz2 = pos_i.z - cpz;
      double rx2 = dx2 * fwx + dy2 * fwy + dz2 * fwz;
      if (rx2 < 0.1) continue;

      double scale1 = cfov / rx1;
      float x1 = float(-(dx1 * lfx + dy1 * lfy + dz1 * lfz) * scale1);
      float y1 = float((dx1 * upx + dy1 * upy + dz1 * upz) * scale1);

      double scale2 = cfov / rx2;
      float x2 = float(-(dx2 * lfx + dy2 * lfy + dz2 * lfz) * scale2);
      float y2 = float((dx2 * upx + dy2 * upy + dz2 * upz) * scale2);

      uint newness = (t_len - 1) - i;
      float fade = (newness < 5) ? (float(newness) * 0.2f) : 1.0f;
      uint alpha = uint(tp_i.life * 120.0 * fade);
      uint c = (col_primary & 0x00FFFFFF) | (alpha << 24);

      // INLINED draw_line_hud_corrected
      float cx1 = (x1 - cached_hud_offset) * cached_hud_scale;
      float cy1 = -y1 * cached_hud_scale;
      float cx2 = (x2 - cached_hud_offset) * cached_hud_scale;
      float cy2 = -y2 * cached_hud_scale;

      // Speed-scaled thickness from emission-time factor on tp_i.
      float t = tp_i.speed_scale;
      float colored_w = (1.2f + 2.4f * t) * cached_hud_scale; // 1.2 → 3.6
      float white_w   = (0.6f * t)        * cached_hud_scale; // 0.0 → 0.6
      float white_alpha_mult = 0.65f * t;                     // 0.0 → 0.65

      // Dual-color stripe: white parallel trail offset left by
      // half-sum-of-widths. Skipped below sub-pixel threshold.
      if (white_w > 0.02f * cached_hud_scale) {
        float seg_dx = cx2 - cx1;
        float seg_dy = cy2 - cy1;
        float seg_len_sq = seg_dx * seg_dx + seg_dy * seg_dy;
        if (seg_len_sq > 1e-8f) {
          float inv_seg_len = 1.0f / float(sqrt(seg_len_sq));
          // Perpendicular LEFT (HUD y-down): (dy, -dx).
          float nx = seg_dy * inv_seg_len;
          float ny = -seg_dx * inv_seg_len;
          float off = 0.5f * (colored_w + white_w);
          float off_x = nx * off;
          float off_y = ny * off;
          uint white_alpha = uint(float(alpha) * white_alpha_mult);
          uint c_white = 0x00FFFFFF | (white_alpha << 24);
          g.draw_line_hud(10, 1, cx1 + off_x, cy1 + off_y,
                                 cx2 + off_x, cy2 + off_y,
                                 white_w, c_white);
        }
      }

      g.draw_line_hud(10, 1, cx1, cy1, cx2, cy2, colored_w, c);
    }
  }

  void update_projectiles() {
    const int num_steps = 3;
    double step_dt = DT * 0.3333333333333333;
    // Projectile-vs-prism hit-sphere tuning. Icosahedron vertex tip
    // ≈ 1.902*size; mid-edge ≈ 1.618*size; face ≈ 1.512*size. K=phi
    // covers a generous outer ring without sticking past tips.
    //   PRISM_HIT_K     1.512=inscribed, 1.618=mid-edge, 1.902=tips
    //   PROJECTILE_PAD  extra slack in world units
    double PRISM_HIT_K = 1.618;
    double PROJECTILE_PAD = 6.0;
    // fp_k re-fetched per outer-i because prism-shatter can pop entries.
    int proj_n = int(projectiles.length());
    for (int i = proj_n - 1; i >= 0; i--) {
      Projectile @p = projectiles[i];
      bool hit = false;
      double n_x = 0, n_y = 0, n_z = 0;
      double hit_dist = 0.0;

      int fp_k = int(floating_prisms.length());
      for (int s = 0; s < num_steps; s++) {
        p.pos.x += p.vel.x * step_dt;
        p.pos.y += p.vel.y * step_dt;
        p.pos.z += p.vel.z * step_dt;

        for (int k = fp_k - 1; k >= 0; k--) {
          // Swap-pop below mutates the slot, not the handle, so reusing
          // @fp_k_h after assignment-to-slot is safe.
          FloatingPrism @fp_k_h = floating_prisms[k];
          double dx = fp_k_h.pos.x - p.pos.x;
          double dy = fp_k_h.pos.y - p.pos.y;
          double dz = fp_k_h.pos.z - p.pos.z;
          double hit_r =
              double(fp_k_h.size) * PRISM_HIT_K + PROJECTILE_PAD;
          if (dx > hit_r || dx < -hit_r || dy > hit_r || dy < -hit_r ||
              dz > hit_r || dz < -hit_r)
            continue;
          if (dx * dx + dy * dy + dz * dz < hit_r * hit_r) {
            // Mirror plane-collision impact: shard burst + smoke crescent.
            // Spawn BEFORE shatter/free/swap so the prism handle stays live.
            spawn_plane_prism_impact_fragments(fp_k_h, p.pos.x,
                                               p.pos.y, p.pos.z, p.vel);
            spawn_plane_prism_impact_smoke_crescent(
                fp_k_h, p.pos.x, p.pos.y, p.pos.z, p.vel);
            shatter_prism(fp_k_h, p.pos, p.vel);
            free_prism(fp_k_h);
            @floating_prisms[k] = @floating_prisms[fp_k - 1];
            floating_prisms.removeLast();
            fp_k--;
            // HUD counter — projectile kills feed the same hex grid.
            prisms_destroyed++;
            maybe_end_level_on_prisms_complete();
            hit = true;
            double vl =
                sqrt(p.vel.x * p.vel.x + p.vel.y * p.vel.y + p.vel.z * p.vel.z);
            if (vl > 1e-4) {
              double inv_vl = 1.0 / vl;
              n_x = -p.vel.x * inv_vl;
              n_y = -p.vel.y * inv_vl;
              n_z = -p.vel.z * inv_vl;
            } else {
              n_x = 0;
              n_y = 0;
              n_z = 1;
            }
            hit_dist = 0.0;
            break;
          }
        }
        if (!hit) {
          double bx = p.pos.x, by = p.pos.y, bz = p.pos.z;
          // Iterate ready_chunks (generated + non-empty subset).
          array<Chunk @> @rdy_chunks = @chunk_manager.ready_chunks;
          uint p_len = rdy_chunks.length();
          for (uint c_idx = 0; c_idx < p_len; c_idx++) {
            Chunk @c = rdy_chunks[c_idx];
            if (bx < c.min_x - 15 || bx > c.max_x + 15 || by < c.min_y - 15 ||
                by > c.max_y + 15 || bz < c.min_z - 15 || bz > c.max_z + 15)
              continue;

            uint t_count = c.active_triangles;
            array<Triangle @> @chunk_tris = @c.triangles;
            for (uint t_idx = 0; t_idx < t_count; t_idx++) {
              Triangle @tri = chunk_tris[t_idx];
              if (bx < tri.min_x - 15 || bx > tri.max_x + 15 ||
                  by < tri.min_y - 15 || by > tri.max_y + 15 ||
                  bz < tri.min_z - 15 || bz > tri.max_z + 15)
                continue;
              if (p.vel.x * tri.nx + p.vel.y * tri.ny + p.vel.z * tri.nz >= 0.0)
                continue;

              double plane_dist =
                  bx * tri.nx + by * tri.ny + bz * tri.nz + tri.plane_d;
              double pr = 6.0;
              if (plane_dist < pr && plane_dist > -40.0) {
                double proj_x = bx - tri.nx * plane_dist;
                double proj_y = by - tri.ny * plane_dist;
                double proj_z = bz - tri.nz * plane_dist;
                double v2_x = proj_x - tri.p1x, v2_y = proj_y - tri.p1y,
                       v2_z = proj_z - tri.p1z;
                double d20 = v2_x * tri.v0x + v2_y * tri.v0y + v2_z * tri.v0z;
                double d21 = v2_x * tri.v1x + v2_y * tri.v1y + v2_z * tri.v1z;
                bool is_inside = false;
                double u_bary = -1.0, v_bary = -1.0, w_bary = -1.0;
                if (tri.invDenom != 0.0) {
                  v_bary = (tri.d11 * d20 - tri.d01 * d21) * tri.invDenom;
                  w_bary = (tri.d00 * d21 - tri.d01 * d20) * tri.invDenom;
                  u_bary = 1.0 - v_bary - w_bary;
                  if (u_bary >= -1e-4 && v_bary >= -1e-4 && w_bary >= -1e-4)
                    is_inside = true;
                }
                if (is_inside) {
                  n_x = tri.nx;
                  n_y = tri.ny;
                  n_z = tri.nz;
                  hit_dist = plane_dist;
                  hit = true;
                  break;
                } else {
                  double cl_x, cl_y, cl_z;
                  if (tri.invDenom != 0.0) {
                    closest_point_on_triangle_edges(bx, by, bz, tri, u_bary,
                                                    v_bary, w_bary, cl_x, cl_y,
                                                    cl_z);
                  } else {
                    closest_point_on_triangle_degenerate(bx, by, bz, tri, cl_x,
                                                         cl_y, cl_z);
                  }
                  double diff_x = bx - cl_x, diff_y = by - cl_y,
                         diff_z = bz - cl_z;
                  if (diff_x * diff_x + diff_y * diff_y + diff_z * diff_z <
                      pr * pr) {
                    n_x = tri.nx;
                    n_y = tri.ny;
                    n_z = tri.nz;
                    hit_dist = plane_dist;
                    hit = true;
                    break;
                  }
                }
              }
            }
            if (hit)
              break;
          }
        }

        if (hit) {
          double dot_vn = p.vel.x * n_x + p.vel.y * n_y + p.vel.z * n_z;
          double tx = p.vel.x - dot_vn * n_x;
          double ty = p.vel.y - dot_vn * n_y;
          double tz = p.vel.z - dot_vn * n_z;
          double impact_speed = abs(dot_vn);

          double spawn_x = p.pos.x - n_x * hit_dist + n_x * 2.0;
          double spawn_y = p.pos.y - n_y * hit_dist + n_y * 2.0;
          double spawn_z = p.pos.z - n_z * hit_dist + n_z * 2.0;

          // Spark generator (unchanged)
          for (int j = 0; j < 24; j++) {
            Particle @part = get_particle();
            part.pos.x = spawn_x;
            part.pos.y = spawn_y;
            part.pos.z = spawn_z;

            double hvx =
                fast_hash(uint(p.pos.x * 10.0) ^ uint(j * 333)) * 2.0 - 1.0;
            double hvy =
                fast_hash(uint(p.pos.y * 10.0) ^ uint(j * 666)) * 2.0 - 1.0;
            double hvz =
                fast_hash(uint(p.pos.z * 10.0) ^ uint(j * 999)) * 2.0 - 1.0;
            double h_dot_n = hvx * n_x + hvy * n_y + hvz * n_z;
            double radially_x = hvx - h_dot_n * n_x,
                   radially_y = hvy - h_dot_n * n_y,
                   radially_z = hvz - h_dot_n * n_z;
            double r_len =
                sqrt(radially_x * radially_x + radially_y * radially_y +
                     radially_z * radially_z);
            if (r_len > 1e-4) {
              double inv_rlen = 1.0 / r_len;
              radially_x *= inv_rlen;
              radially_y *= inv_rlen;
              radially_z *= inv_rlen;
            }
            double radial_force = (0.3 + fast_hash(uint(j * 123)) * 0.7) *
                                  (impact_speed * 0.15 + 80.0);
            double out_force = (0.2 + fast_hash(uint(j * 111)) * 0.8) * 120.0;
            part.vel.set(
                tx * 0.15 + radially_x * radial_force + n_x * out_force,
                ty * 0.15 + radially_y * radial_force + n_y * out_force,
                tz * 0.15 + radially_z * radial_force + n_z * out_force);
            part.life = 0.4 + fast_hash(uint(j + 100)) * 0.6;
            uint c_rand = uint(fast_hash(uint(j + 200)) * 100);
            part.color = lerp_color(0xFFFFFFFF, col_primary, c_rand * 0.01);
            particles.insertLast(part);
          }

          // NEW: Smoke Box Cloud generator
          for (int k = 0; k < 5; k++) {
            Smoke @smk = get_smoke();
            smk.pos.set(spawn_x, spawn_y, spawn_z);

            double svx =
                fast_hash(uint(p.pos.x * 30.0) ^ uint(k * 111)) * 2.0 - 1.0;
            double svy =
                fast_hash(uint(p.pos.y * 30.0) ^ uint(k * 222)) * 2.0 - 1.0;
            double svz =
                fast_hash(uint(p.pos.z * 30.0) ^ uint(k * 333)) * 2.0 - 1.0;

            double r_len = sqrt(svx * svx + svy * svy + svz * svz);
            if (r_len > 1e-4) {
              double inv_rlen = 1.0 / r_len;
              svx *= inv_rlen;
              svy *= inv_rlen;
              svz *= inv_rlen;
            }

            smk.vel.set(n_x * 40.0 + svx * 60.0 + tx * 0.1,
                        n_y * 40.0 + svy * 60.0 + ty * 0.1,
                        n_z * 40.0 + svz * 60.0 + tz * 0.1);

            smk.max_life =
                0.3 + fast_hash(uint(k * 444)) * 0.3; // 0.3 to 0.6 seconds
            smk.inv_max_life = 1.0f / smk.max_life;
            smk.life = smk.max_life;
            smk.base_size = 4.0 + fast_hash(uint(k * 555)) * 6.0;

            // 50% character color, 50% white
            if (fast_hash(uint(k * 777)) > 0.5) {
              smk.color = col_primary;
            } else {
              smk.color = 0xFFFFFFFF;
            }

            smk.rot.w = 1.0;
            smk.rot.x = 0;
            smk.rot.y = 0;
            smk.rot.z = 0;
            smk.rot_vel_x = svx * 6.0;
            smk.rot_vel_y = svy * 6.0;
            smk.rot_vel_z = svz * 6.0;

            smokes.insertLast(smk);
          }
          break;
        }
      }

      p.life -= DT;
      if (hit || p.life <= 0) {
        free_projectile(p);
        @projectiles[i] = @projectiles[proj_n - 1];
        projectiles.removeLast();
        proj_n--;
      }
    }
  }

  // Spawn PrismFragment burst at impact. 4-vertex shards via
  // draw_crystal_face (lit/fogged/spin). Color sourced from prism.
  // impact_vel = striker velocity (plane or projectile) — sets
  // tangential burst smear + degenerate-normal fallback.
  void spawn_plane_prism_impact_fragments(FloatingPrism @prism, double hx,
                                          double hy, double hz,
                                          const Vec3 &in impact_vel) {
    // Impact normal: prism centroid → contact point. Falls back to
    // -impact_vel on degenerate (contact at centroid).
    double n_x = hx - prism.pos.x;
    double n_y = hy - prism.pos.y;
    double n_z = hz - prism.pos.z;
    double n_len = sqrt(n_x * n_x + n_y * n_y + n_z * n_z);
    if (n_len > 1e-4) {
      double inv_n = 1.0 / n_len;
      n_x *= inv_n;
      n_y *= inv_n;
      n_z *= inv_n;
    } else {
      double v_len = sqrt(impact_vel.x * impact_vel.x +
                          impact_vel.y * impact_vel.y +
                          impact_vel.z * impact_vel.z);
      if (v_len > 1e-4) {
        double inv_v = 1.0 / v_len;
        n_x = -impact_vel.x * inv_v;
        n_y = -impact_vel.y * inv_v;
        n_z = -impact_vel.z * inv_v;
      } else {
        n_x = 0;
        n_y = 0;
        n_z = 1;
      }
    }

    // Tangential vel (⊥ impact normal) — burst inherits strike motion.
    double v_dot_n =
        impact_vel.x * n_x + impact_vel.y * n_y + impact_vel.z * n_z;
    double tx = impact_vel.x - v_dot_n * n_x;
    double ty = impact_vel.y - v_dot_n * n_y;
    double tz = impact_vel.z - v_dot_n * n_z;
    double impact_speed = sqrt(impact_vel.x * impact_vel.x +
                               impact_vel.y * impact_vel.y +
                               impact_vel.z * impact_vel.z);

    // Mid-range alpha 0xBF — more punch than icosahedron's 0xAA face
    // alpha but not full opaque. Renderer modulates by f.life.
    uint shard_color = (prism.color & 0x00FFFFFF) | 0xBF000000;

    // 3× particle-burst velocity scale = bigger footprint.
    const double EXPLOSION_SCALE = 3.0;

    for (int j = 0; j < 24; j++) {
      PrismFragment @f = get_prism_fragment();
      f.pos.set(hx, hy, hz);

      // Shard shape: 4 random offsets, sized > real shatter so
      // chips read first then real shatter takes over.
      double radius = 10.0 + fast_hash(uint(j * 919)) * 6.0; // 10-16

      // Distinct hash seed per vertex+axis = irregular tetra chips.
      double v1x = (fast_hash(uint(j * 11 + 1)) * 2.0 - 1.0) * radius;
      double v1y = (fast_hash(uint(j * 13 + 1)) * 2.0 - 1.0) * radius;
      double v1z = (fast_hash(uint(j * 17 + 1)) * 2.0 - 1.0) * radius;
      double v2x = (fast_hash(uint(j * 11 + 2)) * 2.0 - 1.0) * radius;
      double v2y = (fast_hash(uint(j * 13 + 2)) * 2.0 - 1.0) * radius;
      double v2z = (fast_hash(uint(j * 17 + 2)) * 2.0 - 1.0) * radius;
      double v3x = (fast_hash(uint(j * 11 + 3)) * 2.0 - 1.0) * radius;
      double v3y = (fast_hash(uint(j * 13 + 3)) * 2.0 - 1.0) * radius;
      double v3z = (fast_hash(uint(j * 17 + 3)) * 2.0 - 1.0) * radius;
      double v4x = (fast_hash(uint(j * 11 + 4)) * 2.0 - 1.0) * radius;
      double v4y = (fast_hash(uint(j * 13 + 4)) * 2.0 - 1.0) * radius;
      double v4z = (fast_hash(uint(j * 17 + 4)) * 2.0 - 1.0) * radius;
      f.p1.set(v1x, v1y, v1z);
      f.p2.set(v2x, v2y, v2z);
      f.p3.set(v3x, v3y, v3z);
      f.p4.set(v4x, v4y, v4z);

      // -- Velocity: 3× the previous radial-tangent + outward-normal mix
      double hvx = fast_hash(uint(hx * 10.0) ^ uint(j * 333)) * 2.0 - 1.0;
      double hvy = fast_hash(uint(hy * 10.0) ^ uint(j * 666)) * 2.0 - 1.0;
      double hvz = fast_hash(uint(hz * 10.0) ^ uint(j * 999)) * 2.0 - 1.0;
      double h_dot_n = hvx * n_x + hvy * n_y + hvz * n_z;
      double radially_x = hvx - h_dot_n * n_x;
      double radially_y = hvy - h_dot_n * n_y;
      double radially_z = hvz - h_dot_n * n_z;
      double r_len = sqrt(radially_x * radially_x + radially_y * radially_y +
                          radially_z * radially_z);
      if (r_len > 1e-4) {
        double inv_rlen = 1.0 / r_len;
        radially_x *= inv_rlen;
        radially_y *= inv_rlen;
        radially_z *= inv_rlen;
      }
      double radial_force = (0.3 + fast_hash(uint(j * 123)) * 0.7) *
                            (impact_speed * 0.15 + 80.0) * EXPLOSION_SCALE;
      double out_force =
          (0.2 + fast_hash(uint(j * 111)) * 0.8) * 120.0 * EXPLOSION_SCALE;
      f.vel.set(tx * 0.15 + radially_x * radial_force + n_x * out_force,
                ty * 0.15 + radially_y * radial_force + n_y * out_force,
                tz * 0.15 + radially_z * radial_force + n_z * out_force);

      // -- Spin: random axis, modest speed (matches real shatter look) --
      double sax = fast_hash(uint(j * 211)) * 2.0 - 1.0;
      double say = fast_hash(uint(j * 223)) * 2.0 - 1.0;
      double saz = fast_hash(uint(j * 227)) * 2.0 - 1.0;
      double slen = sqrt(sax * sax + say * say + saz * saz);
      if (slen > 1e-9) {
        double inv_slen = 1.0 / slen;
        sax *= inv_slen;
        say *= inv_slen;
        saz *= inv_slen;
      }
      f.spin_axis.set(sax, say, saz);
      f.spin_speed = 4.0 + fast_hash(uint(j * 311)) * 6.0; // 4–10 rad/s

      f.rot.w = 1.0;
      f.rot.x = 0.0;
      f.rot.y = 0.0;
      f.rot.z = 0.0;

      f.color = shard_color;
      f.life = 1.0; // decays at 0.25/frame in update_prism_fragments

      prism_fragments.insertLast(f);
    }
  }

  // Prism-color smoke crescent: N flat petals along 180° arc ⊥ impact
  // normal (half-shell "C"). Very transparent (alpha_mul=0.22) so shards
  // aren't washed out. impact_vel orients the crescent with strike motion.
  void spawn_plane_prism_impact_smoke_crescent(FloatingPrism @prism,
                                               double hx, double hy,
                                               double hz,
                                               const Vec3 &in impact_vel) {
    // -- Impact normal -------------------------------------------------
    double n_x = hx - prism.pos.x;
    double n_y = hy - prism.pos.y;
    double n_z = hz - prism.pos.z;
    double n_len = sqrt(n_x * n_x + n_y * n_y + n_z * n_z);
    if (n_len > 1e-4) {
      double inv_n = 1.0 / n_len;
      n_x *= inv_n;
      n_y *= inv_n;
      n_z *= inv_n;
    } else {
      double v_len = sqrt(impact_vel.x * impact_vel.x +
                          impact_vel.y * impact_vel.y +
                          impact_vel.z * impact_vel.z);
      if (v_len > 1e-4) {
        double inv_v = 1.0 / v_len;
        n_x = -impact_vel.x * inv_v;
        n_y = -impact_vel.y * inv_v;
        n_z = -impact_vel.z * inv_v;
      } else {
        n_x = 0;
        n_y = 0;
        n_z = 1;
      }
    }

    // Orthonormal basis (n, e1, e2). e1 = impact_vel projected onto
    // ⊥-n plane (orients crescent with motion). Fallback if vel ∥ n.
    double v_dot_n =
        impact_vel.x * n_x + impact_vel.y * n_y + impact_vel.z * n_z;
    double e1x = impact_vel.x - v_dot_n * n_x;
    double e1y = impact_vel.y - v_dot_n * n_y;
    double e1z = impact_vel.z - v_dot_n * n_z;
    double e1_len = sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
    if (e1_len > 1e-4) {
      double inv_e = 1.0 / e1_len;
      e1x *= inv_e;
      e1y *= inv_e;
      e1z *= inv_e;
    } else {
      // Fallback: project world-Z (or world-X if n near ±Z).
      if (n_z > -0.9 && n_z < 0.9) {
        double dot = n_z;
        e1x = -dot * n_x;
        e1y = -dot * n_y;
        e1z = 1.0 - dot * n_z;
      } else {
        double dot = n_x;
        e1x = 1.0 - dot * n_x;
        e1y = -dot * n_y;
        e1z = -dot * n_z;
      }
      double l = sqrt(e1x * e1x + e1y * e1y + e1z * e1z);
      double inv_l = 1.0 / l;
      e1x *= inv_l;
      e1y *= inv_l;
      e1z *= inv_l;
    }

    // e2 = n × e1 (third basis axis, completes right-handed frame)
    double e2x = n_y * e1z - n_z * e1y;
    double e2y = n_z * e1x - n_x * e1z;
    double e2z = n_x * e1y - n_y * e1x;

    // -- Petal arc — half-circle of N petals --------------------------
    const int N_PETALS = 7;
    const double ARC_RADIUS = 18.0;

    // Per-impact phase jitter so arc endpoints vary.
    double phase = (fast_hash(uint(hx * 13.0 + hy * 7.0 + hz * 11.0)) * 0.4 -
                    0.2);

    for (int k = 0; k < N_PETALS; k++) {
      Smoke @smk = get_smoke();

      // theta in [phase, π + phase], evenly spaced — half-circle arc.
      double theta = (3.14159265358979 * k / double(N_PETALS - 1)) + phase;
      double cos_t = cos(theta);
      double sin_t = sin(theta);

      // Outward radial in ⊥-n plane (spans 180° as theta=0..π).
      double rx = cos_t * e1x + sin_t * e2x;
      double ry = cos_t * e1y + sin_t * e2y;
      double rz = cos_t * e1z + sin_t * e2z;

      // Petal position: offset from impact along the outward radial.
      smk.pos.set(hx + rx * ARC_RADIUS, hy + ry * ARC_RADIUS,
                  hz + rz * ARC_RADIUS);

      // Align local +X to outward radial — sheet thin axis (size_x)
      // points outward, petal tangent to the arc.
      Quaternion q_align;
      double half_dot = 1.0 + rx;
      if (half_dot < 1e-6) {
        q_align.w = 0.0;
        q_align.x = 0.0;
        q_align.y = 1.0;
        q_align.z = 0.0;
      } else {
        // cross((1,0,0), (rx,ry,rz)) = (0, -rz, ry)
        q_align.w = half_dot;
        q_align.x = 0.0;
        q_align.y = -rz;
        q_align.z = ry;
        q_align.normalize();
      }
      smk.rot = q_align;

      // Slow outward drift; no tangential vel keeps rim arc-shaped.
      smk.vel.set(rx * 55.0, ry * 55.0, rz * 55.0);

      // Sheet: thin along radial (+X), wide on tangents (+Y/+Z).
      smk.size_x = 0.18f; // thin (sheet thickness, radial outward)
      smk.size_y = 1.4f;  // wide
      smk.size_z = 1.0f;  // wide

      // Force-full-alpha; renderer fades from life.
      smk.color = (prism.color & 0x00FFFFFF) | 0xFF000000;
      smk.alpha_mul = 0.22f;

      smk.base_size = 14.0 + fast_hash(uint(k * 555)) * 4.0;

      smk.max_life = 0.30 + fast_hash(uint(k * 444)) * 0.15;
      smk.inv_max_life = 1.0f / smk.max_life;
      smk.life = smk.max_life;

      // No rotation — preserves crescent silhouette over lifetime.
      smk.rot_vel_x = 0.0;
      smk.rot_vel_y = 0.0;
      smk.rot_vel_z = 0.0;

      smokes.insertLast(smk);
    }
  }


  // Apple-collect smoke pop — spherical burst of apple-red + soft grey
  // puffs at the apple's position. Pure Smoke pool reuse.
  // Called from step()'s apple loop (Plane_Physics.cpp) before despawn.
  void spawn_apple_collect_smoke(double x, double y, double z) {
    const int N_PUFFS = 8;
    for (int k = 0; k < N_PUFFS; k++) {
      Smoke @smk = get_smoke();

      // Random outward unit direction via 3-axis hash (same pattern as
      // the projectile-impact box-cloud spawner above).
      double svx = fast_hash(uint(x * 11.0) ^ uint(k * 111)) * 2.0 - 1.0;
      double svy = fast_hash(uint(y * 13.0) ^ uint(k * 222)) * 2.0 - 1.0;
      double svz = fast_hash(uint(z * 17.0) ^ uint(k * 333)) * 2.0 - 1.0;
      double rlen = sqrt(svx * svx + svy * svy + svz * svz);
      if (rlen > 1e-4) {
        double inv = 1.0 / rlen;
        svx *= inv;
        svy *= inv;
        svz *= inv;
      } else {
        svx = 0.0;
        svy = 0.0;
        svz = 1.0;
      }

      // Position offset 12-30u along outward dir so puffs don't all
      // overlap at the centroid.
      double off = 12.0 + fast_hash(uint(k * 919)) * 18.0;
      smk.pos.set(x + svx * off, y + svy * off, z + svz * off);

      // ~70-120u/s outward + small upward bias — vanishes upward.
      double spd = 70.0 + fast_hash(uint(k * 257)) * 50.0;
      smk.vel.set(svx * spd, svy * spd, svz * spd + 12.0);

      // ~75% apple-red vs ~25% grey. Force full alpha; renderer fades
      // from life. alpha_mul 0.55 = solid-but-not-opaque.
      if (fast_hash(uint(k * 753)) > 0.25) {
        smk.color = 0xFF994C58; // apple body red
      } else {
        smk.color = 0xFFC8C8C8; // soft grey
      }
      smk.alpha_mul = 0.55f;

      smk.base_size = 12.0 + fast_hash(uint(k * 555)) * 8.0;

      smk.max_life = 0.30 + fast_hash(uint(k * 444)) * 0.20;
      smk.inv_max_life = 1.0f / smk.max_life;
      smk.life = smk.max_life;

      smk.rot.w = 1.0;
      smk.rot.x = 0;
      smk.rot.y = 0;
      smk.rot.z = 0;
      smk.rot_vel_x = svx * 3.0;
      smk.rot_vel_y = svy * 3.0;
      smk.rot_vel_z = svz * 3.0;

      smokes.insertLast(smk);
    }
  }


}