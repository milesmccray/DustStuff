#include "./Hitmarker.cpp";
#include "./EdgeTrigger.cpp";

const string EMBED_gunshot = "./shooter/sfx/gunshot.ogg";
const string EMBED_cocking = "./shooter/sfx/cocking.ogg";
const string EMBED_hitmarker = "./shooter/sfx/hitmarker.ogg";
const string EMBED_clank = "./shooter/sfx/clank2.ogg";
const string EMBED_letsdothis = "./shooter/sfx/lets-do-this.ogg";

const array<uint> HITMARKER_COLOURS = {
  0xCCBBBBBB,
  0x99BBBBBB,
  0x55BBBBBB,
  0x11BBBBBB
};
const array<uint> FADE_COLOURS = {
  0x11000000,
  0x33000000,
  0x55000000,
  0x77000000,
  0x99000000,
  0xBB000000,
  0xDD000000,
  0xEE000000,
  0xFF000000
};

class script : callback_base {
  scene@ g;
  controllable@ player;

  hitbox@ shot;
  array<Hitmarker> hitmarkers;

  bool enabled = false;

  bool level_ended = false;

  bool held_click = false;

  bool cocking_sfx_played = false;
  bool letsdothis_sfx_played = false;
  int frames_since_cocking_sfx = 0;

  int letterbox_width = 0;
  int letterbox_max_width = 50;
  bool letterbox_drawn = false;
  bool overlay_disabled = false;

  int fade_frames = 0;
  int fade_still_frames = 0;
  int fade_still_frames_max = 60;
  bool faded_in = false;
  bool fade_complete = false;

  int fade_enable_functionality_after = 61;

  bool enlarge_crosshair = false;
  int enlarge_crosshair_frames = 0;

  // annotations, as determined by the edge trigger
  bool _letterbox = false;
  bool _letsDoThis = false;
  bool _dramaticFadeToBlack = false;

  script() {
    @g = get_scene();
    add_broadcast_receiver( "toggle", this, "toggle" );
  }

  void toggle( string id, message@ msg ) {
    // toggle the script on / off

    enabled = ( msg.get_int( "enable" ) == 1 ) ? true : false;
    if ( !enabled ) {
      // reset script variables
      reset_vars();
      return;
    }

    // get annotation values from the edge trigger
    _letterbox = ( msg.get_int( "letterbox" ) == 1 ) ? true : false;
    _letsDoThis = ( msg.get_int( "letsDoThis" ) == 1 ) ? true : false;
    _dramaticFadeToBlack = ( msg.get_int( "dramaticFadeToBlack" ) == 1 ) ? true : false;
  }

  void build_sounds( message @msg ) {
    msg.set_string( "gunshot", "gunshot" );
    msg.set_string( "cocking", "cocking" );
    msg.set_string( "hitmarker", "hitmarker" );
    msg.set_string( "clank", "clank" );
    msg.set_string( "letsdothis", "letsdothis" );
  }

  void on_level_start() {
    @player = controller_controllable( 0 );
  }

  void checkpoint_load() {
    @player = controller_controllable( 0 );
  }

  void on_level_end() {
    level_ended = true;
  }

  void step( int entities ) {
    if ( !enabled || level_ended ) {
      return;
    }

    @player = controller_controllable( 0 );
    if ( @player == null ) {
      return;
    }

    if ( !cocking_sfx_played ) {
      g.play_script_stream( "cocking", 3, 0, 0, false, 0.3 );
      cocking_sfx_played = true;
    }
    else if ( _letsDoThis && !letsdothis_sfx_played ) {
      frames_since_cocking_sfx++;

      if ( frames_since_cocking_sfx > 40 ) {
        g.play_script_stream( "letsdothis", 3, 0, 0, false, 0.4 );
        letsdothis_sfx_played = true;
      }
    }

    if ( _dramaticFadeToBlack ) {
      if ( fade_still_frames < fade_enable_functionality_after ) {
        // wait till the screen fades out of black before drawing the crosshair
        return;
      }
    }

    float mouse_x = g.mouse_x_world( 0, 19 );
    float mouse_y = g.mouse_y_world( 0, 19 );

    if ( held_click ) {
      if ( !get_left_mouse_down( 0 ) ) {
        // the player is no longer holding their left mouse button, so unblock
        // shooting
        held_click = false;
      }
    }

    if ( get_left_mouse_down( 0 ) && !held_click ) {
      @shot = create_hitbox( player, 0, mouse_x, mouse_y, -20, 20, -20, 20 );
      shot.timer_speed( 500 );
      shot.attack_strength( 200 );
      shot.activate_time( 0 );
      shot.can_parry( true );

      // have the direction of the attack be a radius outwards from the center
      // of the hitbox, rather than using a set direction
      shot.aoe( true );

      shot.on_hit_filter_callback( this, "on_hit", 0 );

      // hitboxes aren"t automatically added to the scene, so do this manually
      g.add_entity( shot.as_entity() );

      g.play_script_stream( "gunshot", 3, 0, 0, false, 0.2 );

      enlarge_crosshair = true;

      // prematurely assume the player is holding their left mouse button until
      // we see otherwise, as we want to prevent players holding to shoot
      held_click = true;
    }
  }

  bool on_hit( hitbox@ hitbox, hittable@ hittable, int arg ) {
    entity@ last_hitbox;
    if ( hitmarkers.length > 0 ) {
      @last_hitbox = hitmarkers[ hitmarkers.length - 1 ].hitbox.as_entity();
    }

    if ( @last_hitbox == null || ( !hitbox.as_entity().is_same( last_hitbox ) ) ) {
      // "hittable" corresponds to the object that was hit by the attack
      string hittable_type = hittable.as_entity().type_name();
      if ( hittable_type == "enemy_tutorial_hexagon" ) {
        // play a clank sound for heavy prisms, since the shots don't actually
        // affect them
        g.play_script_stream( "clank", 3, 0, 0, false, 0.2 );
      }
      else {
        Hitmarker hm( hitbox, g.mouse_x_world( 0, 19 ), g.mouse_y_world( 0, 19 ) );
        hitmarkers.insertLast( hm );
        g.play_script_stream( "hitmarker", 3, 0, 0, false, 0.3 );
      }
    }

    // increase the combo count with each hit shot
    dustman@ dm = player.as_dustman();
    int ct = dm.combo_count();
    dm.combo_count( ct + 1 );
    dm.combo_timer( 1 );

    return true;
  }

  void draw( float sub_frame ) {
    if ( !enabled || level_ended ) {
      return;
    }

    float mouse_x = g.mouse_x_world( 0, 19 );
    float mouse_y = g.mouse_y_world( 0, 19 );

    if ( _dramaticFadeToBlack ) {
      draw_fade();
    }

    draw_crosshair( mouse_x, mouse_y );

    if ( _letterbox ) {
      draw_letterbox();
    }

    for ( int i = int( hitmarkers.length() ) - 1; i >= 0; i-- ) {
      if ( hitmarkers[ i ].expired ) {
        hitmarkers.removeAt( i );
      }
      else {
        hitmarkers[ i ].draw( sub_frame );
      }
		}
  }

  void draw_crosshair( float x, float y ) {
    if ( _dramaticFadeToBlack ) {
      if ( fade_still_frames < fade_enable_functionality_after ) {
        // wait till the screen fades out of black before drawing the crosshair
        return;
      }
    }

    int length = 37;
    int offset = 20;

    if ( enlarge_crosshair_frames > 5 ) {
      enlarge_crosshair = false;
      enlarge_crosshair_frames = 0;
    }

    if ( enlarge_crosshair ) {
      enlarge_crosshair_frames++;

      offset += ( enlarge_crosshair_frames + 2 );
    }

    int length_from_center = length + offset;

    // vertical top
    g.draw_line_world(
      20, 20, x, ( y - length_from_center ), x, ( y - offset ), 5, 0xFFFFFFFF
    );
    // vertical bottom
    g.draw_line_world(
      20, 20, x, ( y + offset ), x, ( y + length_from_center ), 5, 0xFFFFFFFF
    );

    // horizontal left
    g.draw_line_world(
      20, 20, ( x - length_from_center ), y, ( x - offset ), y, 5, 0xFFFFFFFF
    );
    // horizontal right
    g.draw_line_world(
      20, 20, ( x + offset ), y, ( x + length_from_center ), y, 5, 0xFFFFFFFF
    );
  }

  void draw_letterbox() {
    if ( _dramaticFadeToBlack ) {
      if ( fade_still_frames < fade_enable_functionality_after ) {
        // wait till the screen fades out of black before drawing the crosshair
        return;
      }
    }

    if ( !overlay_disabled ) {
      // just disable the score overlay, since we're blocking it anyway
      g.disable_score_overlay( true );
      overlay_disabled = true;
    }

    if ( !letterbox_drawn ) {
      uint increase = ( letterbox_max_width - letterbox_width ) / 7;

      if ( increase == 0 ) {
        increase = 1;
      }
      letterbox_width += increase;

      if ( letterbox_width >= letterbox_max_width ) {
        letterbox_drawn = true;
      }
    }

    int screen_radius = 450;

    // draw bars on the top and bottom side (for aesthetics)
    g.draw_rectangle_hud(
      20, 1, -800, -450, 1600, ( -screen_radius + letterbox_width ), 0, 0xFF000000
    );
    g.draw_rectangle_hud(
      20, 1, -800, 450, 1600, ( screen_radius - letterbox_width ), 0, 0xFF000000
    );
  }

  void draw_fade() {
    if ( fade_complete ) {
      if ( fade_still_frames <= fade_enable_functionality_after ) {
        fade_still_frames++;
      }

      return;
    }

    if ( faded_in ) {
      if ( _letterbox && !overlay_disabled ) {
        // just disable the score overlay, since we're blocking it with the
        // letterbox anyway
        g.disable_score_overlay( true );
        overlay_disabled = true;
      }

      if ( fade_still_frames <= fade_still_frames_max ) {
        fade_still_frames++;

        g.draw_rectangle_hud(
          20, 1, -800, -450, 1600, 450, 0, FADE_COLOURS[ FADE_COLOURS.length - 1 ]
        );

        return;
      }

      fade_frames--;
    }
    else {
      fade_frames++;
    }

    // fade the hitmarker in
    uint index = ( fade_frames / 2 );

    if ( index == FADE_COLOURS.length ) {
      faded_in = true;
      index = FADE_COLOURS.length - 1;
    }

    uint colour = FADE_COLOURS[ index ];

    // draw bars on the top and bottom side (for aesthetics)
    g.draw_rectangle_hud(
      20, 1, -800, -450, 1600, 450, 0, colour
    );

    if ( faded_in && ( index == 0 ) ) {
      fade_complete = true;
    }
  }

  bool get_left_mouse_down( int player ) {
    return ( g.mouse_state( player ) & 0x04 ) == 0x04;
  }

  void reset_vars() {
    // reset script variables
    cocking_sfx_played = false;
    frames_since_cocking_sfx = 0;
    letsdothis_sfx_played = false;

    letterbox_width = 0;
    letterbox_drawn = false;
    g.disable_score_overlay( false );
    overlay_disabled = false;

    fade_frames = 0;
    fade_still_frames = 0;
    faded_in = false;
    fade_complete = false;

    enlarge_crosshair = false;
    enlarge_crosshair_frames = 0;

    _letterbox = false;
    _letsDoThis = false;
    _dramaticFadeToBlack = false;
  }
}

