#include "../lib/triggers/EnterExitTrigger.cpp";

class EdgeTrigger : trigger_base, EnterExitTrigger {
  scripttrigger@ self;

  [persistent] bool _onlyEnableOnEnter = false;
  [persistent] bool _onlyDisableOnEnter = false;

  [persistent] bool _letterbox = false;
  [persistent] bool _letsDoThis = false;
  [persistent] bool _dramaticFadeToBlack = false;

  void init(script@ s, scripttrigger@ self) {
    @this.self = self;
  }

  void activate( controllable@ c ) {
    activate_enter_exit( c );
  }

  void step() {
    step_enter_exit();
  }

  bool can_trigger_enter_exit( controllable@ c ) {
		return ( c.player_index() != -1 );
	}

  void on_trigger_enter( controllable@ c ) {
    if ( _onlyDisableOnEnter ) {
      broadcast_disable();
      return;
    }

    broadcast_enable();
  }

  void on_trigger_exit( controllable@ c ) {
    if ( _onlyEnableOnEnter || _onlyDisableOnEnter ) {
      // we only care to toggle the script on/off when we enter the trigger
      // radius
      return;
    }

    message@ msg = create_message();
		msg.set_int( "enable", 0 );
    broadcast_message( "toggle", msg );
  }

  void broadcast_enable() {
    message@ msg = create_message();
		msg.set_int( "enable", 1 );

    // pass on any annotation values
    if ( _letterbox ) {
      msg.set_int( "letterbox", 1 );
    }
    if ( _letsDoThis ) {
      msg.set_int( "letsDoThis", 1 );
    }
    if ( _dramaticFadeToBlack ) {
      msg.set_int( "dramaticFadeToBlack", 1 );
    }

    broadcast_message( "toggle", msg );
  }

  void broadcast_disable() {
    message@ msg = create_message();
		msg.set_int( "enable", 0 );
    broadcast_message( "toggle", msg );
  }
}
