class Hitmarker {
  hitbox@ hitbox;

  uint lifetime = 0;
  float x;
  float y;

  bool expired = false;

  uint colour = 0xFFBBBBBB;

  scene@ g;

  Hitmarker( hitbox@ hitbox, float x, float y ) {
    @g = get_scene();

    @this.hitbox = hitbox;
    this.x = x;
    this.y = y;
  }

  void draw( float sub_frame ) {
    if ( expired ) {
      return;
    }

    lifetime++;

    int length = 30;
    int offset = 8;

    if ( lifetime > 20 ) {
      // fade the hitmarker out
      uint index = ( ( lifetime-20 ) / 2 );

      if ( index == HITMARKER_COLOURS.length ) {
        expired = true;
        return;
      }

      colour = HITMARKER_COLOURS[ index ];
    }

    // bottom left
    g.draw_line_world(
      20, 1, x-length, y+length, x-offset, y+offset, 5, colour
    );

    // bottom right
    g.draw_line_world(
      20, 1, x+length, y+length, x+offset, y+offset, 5, colour
    );

    // top left
    g.draw_line_world(
      20, 1, x-length, y-length, x-offset, y-offset, 5, colour
    );

    // top right
    g.draw_line_world(
      20, 1, x+length, y-length, x+offset, y-offset, 5, colour
    );
  }

  Hitmarker() {}
}
