#include "../lib/std.cpp"
#include "../lib/math/math.cpp"
#include "../lib/math/Vec2.cpp"
#include "../lib/easing/quad.cpp"

// -- Replay-Compatible Randomness Framework --

// Dummy class for the replay encoders, required for replay-consistent randomness.
class replay_rand_dummy : enemy_base {
  void init(script@, scriptenemy@ self) {
    self.auto_physics(false);
  }
}

// Helper class for replay-consistent randomness.
// This ensures that random events are the same in both live gameplay and replays.
class replay_rand {
  scene@ g;
  array<uint> encoders;
  uint seed = 1;
  
  bool _is_initialised = false;
  bool _failed = false;

  int ecx = 0;
  int ecy = 0;
  uint frame_counter = 0;
  
  uint NUM_ENCODERS = 4;

  replay_rand() {
    @g = @get_scene();
  }

  // Called every frame to manage the seed encoding/decoding process.
  void step() {
    if (_failed) return;
    
    // Create dummy entities for encoding/decoding the seed.
    if (frame_counter == 10) {
        if (!init_encoders()) {
            puts("replay_rand: FAILED to init encoders. Randomness will not be replay-consistent.");
            _failed = true;
        }
    }

    // In a live game, generate a seed and encode it into the dummy entities' positions.
    if (frame_counter == 20 && !is_replay()) {
        encode_seed();
    }
    
    // After frame 20, the seed is considered set.
    // In a live game, we use the seed we just generated.
    // In a replay, we decode the seed from the dummy positions.
    if (frame_counter == 30) {
        if (is_replay()) {
            if (!decode_seed()) {
                puts("replay_rand: FAILED to decode seed. Randomness will not be replay-consistent.");
                _failed = true;
                return;
            }
        }
        _is_initialised = true;
        puts("replay_rand: Initialised. Seed is " + seed);
    }

    frame_counter++;
  }
  
  // Check if the random generator is ready to be used.
  bool is_ready() {
      return _is_initialised && !_failed;
  }

  // Returns a pseudo-random integer.
  uint rand() {
    if (!is_ready()) {
       // This warning indicates that game logic is attempting to use randomness
       // before the replay-safe seed has been established.
       puts("replay_rand: WARNING - rand() called before initialisation!");
       return 0; // Return a predictable value if not ready
    }
    return seed = (seed * 16807) % 2147483647;
  }
  
  // Returns a pseudo-random float between 0.0 and 1.0.
  float frand() {
    if (!is_ready()) {
        puts("replay_rand: WARNING - frand() called before initialisation!");
        return 0.5f;
    }
    return float(rand()) / 2147483647.0f;
  }

  // Returns a pseudo-random integer within a specified range.
  int rand_range(int min, int max) {
    if (!is_ready()) {
        puts("replay_rand: WARNING - rand_range(int) called before initialisation!");
        return min;
    }
    if (max <= min) return min;
    return min + (rand() % (max - min));
  }

  // Returns a pseudo-random float within a specified range.
  float rand_range(float min, float max) {
    if (!is_ready()) {
        puts("replay_rand: WARNING - rand_range(float) called before initialisation!");
        return min;
    }
    return min + (max - min) * frand();
  }
  
  // Creates the dummy entities used for encoding the seed.
  private bool init_encoders() {
    controllable@ ec = @controller_controllable(0);
    if (@ec == null) {
      // Can't get player position, so we can't create encoders.
      return false;
    }

    ecx = int(ec.x());
    ecy = int(ec.y());
    for (uint i = 0; i < NUM_ENCODERS; i++) {
      scriptenemy@ ent = create_scriptenemy(replay_rand_dummy());
      ent.x(ecx);
      ent.y(ecy);
      g.add_entity(@ent.as_entity(), true); 
      encoders.insertLast(ent.id());
    }
    puts("replay_rand: Dummy encoders created at (" + ecx + ", " + ecy + ")");
    return true;
  }

  // Moves the dummy entities to positions that encode the seed value.
  private void encode_seed() {
    // Generate the seed right before encoding
    seed = timestamp_now() + get_time_us();
    uint val_to_encode = seed;

    for (uint i = 0; i < NUM_ENCODERS; i++) {
      entity@ ent = @entity_by_id(encoders[i]);
      if (@ent == null) {
        puts("replay_rand: Encoding seed failed - entity missing.");
        _failed = true;
        return;
      }
      ent.x(ecx - 128 + ((val_to_encode >> (i * 8)) & 0xFF));
      ent.y(ecy + 100);
    }
    puts("replay_rand: Seed " + val_to_encode + " encoded.");
  }

  // Reads the positions of the dummy entities to reconstruct the seed in a replay.
  private bool decode_seed() {
    uint decoded_val = 0;
    for (uint i = 0; i < NUM_ENCODERS; i++) {
      entity@ ent = @entity_by_id(encoders[i]);
      if (@ent == null) {
        puts("replay_rand: Seed reconstruction failed - entity missing.");
        return false;
      }
      int enc_x = int(round(ent.x())) + 128 - ecx;
      int enc_y = int(round(ent.y()));
      if (enc_y == ecy) {
        puts("replay_rand: Desync frames missing, seed reconstruction failed.");
        return false;
      }
      decoded_val |= enc_x << (i * 8);
    }
    seed = decoded_val;
    puts("replay_rand: Decoded seed: " + seed);
    return true;
  }
}

// -- Team Enum Definition --
enum Team { Friendly, Enemy };

// -- Horde Mode Constants --
const int HORDE_KILL_GOAL = 50;
const int HORDE_MAX_MINIONS = 18;
const int HORDE_INITIAL_MINIONS = 10;
const float HORDE_SPAWN_MIN_RADIUS = 6.0f;
const float HORDE_SPAWN_MAX_RADIUS = 12.0f;

// -- Vector3 Class Definition --
// A basic 3D vector class for position and math operations.
class Vec3
{
    float x, y, z;

    Vec3(float x=0, float y=0, float z=0) { this.x = x; this.y = y; this.z = z; }

    // Assignment operator to copy Vec3 values.
    Vec3 &opAssign(const Vec3 &in other)
    {
        x = other.x;
        y = other.y;
        z = other.z;
        return this;
    }

    void set(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
    
    float length() const { return sqrt(x*x + y*y + z*z); }
    
    Vec3 normalize() const {
        float l = length();
        if (l > 1e-6) {
            return Vec3(x / l, y / l, z / l);
        }
        return Vec3(0, 0, 0);
    }
    
    Vec3 opAdd(const Vec3 &in other) const { return Vec3(x + other.x, y + other.y, z + other.z); }
    Vec3 opSub(const Vec3 &in other) const { return Vec3(x - other.x, y - other.y, z - other.z); }
    Vec3 opMul(float scalar) const { return Vec3(x * scalar, y * scalar, z * scalar); }
};

// Helper function for the dot product of two Vec3 vectors.
float dot(const Vec3 &in v1, const Vec3 &in v2) {
    return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}

// Helper function for the cross product of two Vec3 vectors.
Vec3 cross(const Vec3 &in a, const Vec3 &in b) {
    return Vec3(
        a.y * b.z - a.z * b.y,
        a.z * b.x - a.x * b.z,
        a.x * b.y - a.y * b.x
    );
}

// -- Interfaces for drawing and camera --
interface IMobaCamera
{
    void project_to_screen(Vec3 world_pos, float cam_world_x, float cam_world_y, float &out screen_x, float &out screen_y);
    Vec2 get_camera_pos();
    Vec2 get_prev_camera_pos();
}

// -- Gold Indicator Effect --
// This class manages the display and animation of the gold coin when a last hit occurs.
class GoldIndicator
{
    Vec3 pos;
    float life = 60; // 60 frames = 1 second
    float initial_life = 60;

    // Animation properties
    float rise_height = 1.0f;
    float coin_radius = 0.15f; // Slightly larger coin

    GoldIndicator(Vec3 start_pos)
    {
        this.pos = start_pos;
    }

    // Returns true if the indicator's life is over
    bool step()
    {
        life--;
        return life <= 0;
    }

    void draw(scene@ g, float sub_frame, IMobaCamera@ camera_provider)
    {
        if (life <= 0) return;

        float t = 1.0 - (life / initial_life); // Animation progress from 0 to 1

        // Animation logic: rise and fall
        float y_offset;
        if (t < 0.5) {
            // Rising phase (ease-out)
            float t_rise = t * 2.0;
            y_offset = ease_out_quad(t_rise) * rise_height;
        } else {
            // Falling phase (ease-in)
            float t_fall = (t - 0.5) * 2.0;
            y_offset = (1.0 - ease_in_quad(t_fall)) * rise_height;
        }

        // Fade in/out logic
        float alpha;
        if (t < 0.15) {
            // Fade in
            alpha = t / 0.15;
        } else if (t > 0.7) {
            // Fade out
            alpha = 1.0 - ((t - 0.7) / 0.3);
        } else {
            alpha = 1.0;
        }
        alpha = clamp(alpha, 0.0, 1.0);

        // Get screen position
        float screen_x, screen_y;
        Vec2 cam_pos = camera_provider.get_camera_pos();
        Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
        float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
        float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);
        camera_provider.project_to_screen(Vec3(pos.x, pos.y, pos.z + y_offset), interp_camera_x, interp_camera_y, screen_x, screen_y);

        // --- Drawing ---
        uint gold_colour = 0xFFFFD700;
        uint shadow_colour = 0x00000000;
        uint final_gold_colour = (gold_colour & 0x00FFFFFF) | (uint(alpha * 255) << 24);
        uint final_shadow_colour = (shadow_colour & 0x00FFFFFF) | (uint(alpha * 128) << 24); // Shadow is semi-transparent

        // Draw Coin
        float coin_x = screen_x;
        float coin_y = screen_y;
        
        // Coin Shadow
        draw_rect_circle(g, 21, 24, coin_x + 2, coin_y + 2, coin_radius * 10, 8, final_shadow_colour);
        // Coin
        draw_rect_circle(g, 21, 25, coin_x, coin_y, coin_radius * 10, 8, final_gold_colour);
    }
    
    // Helper to draw a circle with rectangles
    void draw_rect_circle(scene@ g, int layer, int sub_layer, float cx, float cy, float radius, int segments, uint colour)
    {
        float angle_step = 360.0 / segments;
        for(int i = 0; i < segments; i++)
        {
            float angle = i * angle_step;
            float x = cx + cos(angle * DEG2RAD) * radius * 0.5;
            float y = cy + sin(angle * DEG2RAD) * radius * 0.5;
            g.draw_rectangle_hud(layer, sub_layer, x-2, y-2, x+2, y+2, angle + 45, colour);
        }
    }

    // Easing function for smooth animation
    float ease_out_quad(float t) { return t * (2.0 - t); }
    float ease_in_quad(float t) { return t * t; }
};


// -- Data structure for configuring minion properties --
class MinionSpawnConfig
{
    Team team;
    float attack_range;
    float attack_damage_multiplier;
    float starting_health;
    bool is_stationary;
    float sprite_scale;
    float health_bar_width;
    float health_bar_height;
    float auto_attack_particle_size;
    float auto_attack_particle_speed;
    float auto_attack_height;
    float attack_cooldown;
    // Rectangular hitbox for right-click targeting
    float right_click_hitbox_width;
    float right_click_hitbox_height;

    MinionSpawnConfig(Team team, float range, float damage_mult, float health,
                      bool is_stationary=false, float sprite_scale=0.64f,
                      float health_bar_width=40, float health_bar_height=5,
                      float auto_attack_particle_size=0.1f, float auto_attack_particle_speed=0.05f,
                      float auto_attack_height = 0.3f, float attack_cooldown = 35.0f,
                      float right_click_hitbox_width=50, float right_click_hitbox_height=50)
    {
        this.team = team;
        this.attack_range = range;
        this.attack_damage_multiplier = damage_mult;
        this.starting_health = health;
        this.is_stationary = is_stationary;
        this.sprite_scale = sprite_scale;
        this.health_bar_width = health_bar_width;
        this.health_bar_height = health_bar_height;
        this.auto_attack_particle_size = auto_attack_particle_size;
        this.auto_attack_particle_speed = auto_attack_particle_speed;
        this.auto_attack_height = auto_attack_height;
        this.attack_cooldown = attack_cooldown;
        this.right_click_hitbox_width = right_click_hitbox_width;
        this.right_click_hitbox_height = right_click_hitbox_height;
    }
};

class SpawnPoint
{
    Vec2 pos;
    SpawnPoint(float x, float y) { pos.set(x, y); }
};

class Wave
{
    array<MinionSpawnConfig@> minions_config;
    float spawn_delay; // in seconds
    array<SpawnPoint@> spawn_points;
    
    bool active = false;
    int minions_spawned = 0;
    float spawn_timer = 0;
    int wave_id = -1; // New field to track the side of the wave

    Wave(const array<MinionSpawnConfig@> &in configs, float delay, const array<SpawnPoint@> &in points, int id)
    {
        this.minions_config = configs;
        this.spawn_delay = delay;
        this.spawn_points = points;
        this.wave_id = id;
    }
};


interface IDrawableCharacter
{
    float x();
    float y();
    float prev_x();
    float prev_y();
    float hitbox_radius();
    void draw(float sub_frame, IMobaCamera@ camera_provider, int sub_layer);
    Team getTeam();
}

// Interface for any character that can take damage.
interface IDamageable
{
    void take_damage(float amount, Vec3 attacker_pos, scriptenemy@ attacker);
}

// Helper to draw a projected quad on the ground plane
void draw_projected_quad(scene@ g, int layer, int sub_layer, IMobaCamera@ camera_provider, float sub_frame, Vec3 pos, float width, float length, float angle, uint colour)
{
    Vec2 cam_pos = camera_provider.get_camera_pos();
    Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
    float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
    float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);

    float hw = width * 0.5;
    float hl = length * 0.5;

    // Define corners relative to origin
    array<Vec2> corners(4);
    corners[0].set(-hw, -hl); // Top-left
    corners[1].set(hw, -hl);  // Top-right
    corners[2].set(hw, hl);   // Bottom-right
    corners[3].set(-hw, hl);  // Bottom-left

    // Rotate and translate corners
    float s = sin(angle);
    float c = cos(angle);
    for(int i = 0; i < 4; i++)
    {
        float x = corners[i].x;
        float y = corners[i].y;
        corners[i].x = x * c - y * s + pos.x;
        corners[i].y = x * s + y * c + pos.y;
    }

    // Project corners to screen space
    array<Vec2> screen_corners(4);
    for(int i = 0; i < 4; i++)
    {
        camera_provider.project_to_screen(Vec3(corners[i].x, corners[i].y, pos.z), interp_camera_x, interp_camera_y, screen_corners[i].x, screen_corners[i].y);
    }
    
    // Draw the quad
    g.draw_quad_hud(layer, sub_layer, false,
        screen_corners[0].x, screen_corners[0].y,
        screen_corners[1].x, screen_corners[1].y,
        screen_corners[2].x, screen_corners[2].y,
        screen_corners[3].x, screen_corners[3].y,
        colour, colour, colour, colour);
}

// A check to see if there is a clear shot from a starting position to a target.
// An attack is blocked by any unit not on the attacker's team (that isn't the target).
//
// @param start_pos The starting position of the line-of-sight check.
// @param attacker_team The team of the attacker.
// @param target The character being targeted.
// @param obstacles A list of all characters that could potentially block the shot.
// @param self_to_ignore An optional character to ignore during the check (usually the attacker itself).
bool is_line_of_sight_clear(Vec2 start_pos, Team attacker_team, IDrawableCharacter@ target, array<IDrawableCharacter@>@ obstacles, IDrawableCharacter@ self_to_ignore = null)
{
    Vec2 end_pos(target.x(), target.y());

    Vec2 dir = end_pos - start_pos;
    const float dist = dir.magnitude();
    if (dist < 0.001f) return true; // Too close, consider it clear
    dir.normalise();

    const float half_width = 0.15f * 1.5f * 0.5f; // From AttackParticle hitbox * 1.5 / 2

    for (uint i = 0; i < obstacles.length(); i++)
    {
        IDrawableCharacter@ obs = obstacles[i];
        // Ignore the attacker and the target in the check
        if ((@self_to_ignore !is null and @obs is self_to_ignore) or @obs is target) continue;
        
        // CORRECTED LOGIC: Shots pass through allies, but are blocked by other entities.
        if (obs.getTeam() == attacker_team) continue;
        
        Minion@ minion = cast<Minion@>(obs);
        if (@minion is null) continue; // Only check against minions

        Vec2 obs_pos(obs.x(), obs.y());
        
        // Project obstacle's center onto the line between start and target
        Vec2 to_obs = obs_pos - start_pos;
        float projected_dist = dot(to_obs, dir);

        // If obstacle is behind the start or beyond the target, it's not blocking
        if (projected_dist < 0 || projected_dist > dist) continue;

        // Calculate the perpendicular distance from the obstacle's center to the line
        float perp_dist = abs(to_obs.x * dir.y - to_obs.y * dir.x);

        // Check for collision
        if (perp_dist < obs.hitbox_radius() + half_width)
        {
            return false; // Blocked
        }
    }

    return true; // Clear
}

// -- ParticleFX Class Definition --
class ParticleFX
{
    Vec3 pos;
    Vec3 vel;
    float life;
    float initial_life;
    float size;
    uint colour;

    ParticleFX(Vec3 pos, Vec3 vel, float size, uint colour, float life = 20)
    {
        this.pos = pos;
        this.vel = vel;
        this.size = size;
        this.colour = colour;
        this.life = life;
        this.initial_life = life > 0 ? life : 1;
    }

    void step()
    {
        pos = pos + vel;
        vel.z -= 0.00; // Gravity
        if (pos.z < 0) {
            pos.z = 0;
            vel.z *= -0.3; // Bounce with damping
        }
        life--;
    }

    void draw(scene@ g, float sub_frame, IMobaCamera@ camera_provider)
    {
        if(life <= 0) return;
        float t = life / initial_life;
        uint alpha = uint(round(clamp(t * 255.0f, 0.0f, 255.0f)));
        uint final_colour = (colour & 0x00FFFFFF) | (alpha << 24);
        
        float angle = atan2(vel.y, vel.x);
        draw_projected_quad(g, 20, 22, camera_provider, sub_frame, pos, size * t, size * t, angle, final_colour);
    }
};

// -- AttackParticle Class Definition --
class AttackParticle
{
    scriptenemy@ dealer;
    Vec3 pos;
    Vec3 vel;
    float life = 34;
    float length = 0.3f;
    float width = 0.1f;
    uint colour = 0xFFFFC852;
    int particle_timer = 0;
    float hitbox_radius = 0.15f; // Circular hitbox radius
    // Configurable trail colours
    uint trail_colour1;
    uint trail_colour2;

    AttackParticle(Vec3 pos, Vec3 vel, scriptenemy@ dealer, uint trail_colour1=0xFFE3694C, uint trail_colour2=0xFFFFFFFF)
    {
        this.pos = pos;
        this.vel = vel;
        @this.dealer = dealer;
        this.trail_colour1 = trail_colour1;
        this.trail_colour2 = trail_colour2;
    }

    void step(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        pos = pos + vel;
        if (pos.z < 0) {
             pos.z = 0;
             vel.z = 0;
        }
        life--;
        particle_timer++;
        if(particle_timer % 2 == 0) // Increased frequency
        {
            // Original orange trail - tighter and smaller
            float trail_speed = 0.01; 
            Vec3 trail_vel((rrnd.frand() - 0.5) * trail_speed, (rrnd.frand() - 0.5) * trail_speed, (rrnd.frand() - 0.5) * trail_speed * 0.5);
            // UPDATED: Use configurable trail colour
            fx_list.insertLast(ParticleFX(pos, trail_vel, 0.06f, this.trail_colour1, 20));

            // New white trail - even smaller and tighter
            float white_trail_speed = 0.005;
            Vec3 white_trail_vel((rrnd.frand() - 0.5) * white_trail_speed, (rrnd.frand() - 0.5) * white_trail_speed, (rrnd.frand() - 0.5) * white_trail_speed * 0.5);
            // UPDATED: Use configurable trail colour
            fx_list.insertLast(ParticleFX(pos, white_trail_vel, 0.04f, this.trail_colour2, 20));
        }
    }

    void draw(scene@ g, float sub_frame, IMobaCamera@ camera_provider)
    {
        if(life <= 0) return;
        float angle = atan2(vel.y, vel.x) + PI / 2.0;
        draw_projected_quad(g, 20, 23, camera_provider, sub_frame, pos, width, length, angle, colour);
    }
};

// -- HeavyAttackParticle Class Definition --
class HeavyAttackParticle
{
    scriptenemy@ dealer;
    Vec3 pos;
    Vec3 vel;
    float life = 60; // Longer lifespan
    float width = 0.9f;  // 3x wider
    float length = 0.25f; // 3x longer
    uint colour = 0xFFFFC852;
    int particle_timer = 0;
    
    // Store IDs of enemies already hit to prevent multiple hits on the same target
    array<int> hit_enemies;
    // Configurable trail colours
    uint trail_colour1;
    uint trail_colour2;

    HeavyAttackParticle(Vec3 pos, Vec3 vel, scriptenemy@ dealer, uint trail_colour1=0xFFE3694C, uint trail_colour2=0xFFFFFFFF)
    {
        this.pos = pos;
        this.vel = vel;
        @this.dealer = dealer;
        this.trail_colour1 = trail_colour1;
        this.trail_colour2 = trail_colour2;
    }

    void step(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        pos = pos + vel;
        if (pos.z < 0) {
             pos.z = 0;
             vel.z = 0;
        }
        life--;
        particle_timer++;
        if(particle_timer % 2 == 0)
        {
            // Get the direction perpendicular to the velocity for the width
            Vec2 tangent(-vel.y, vel.x);
            if(tangent.magnitude() > 1e-6) tangent.normalise();

            // Spawn multiple particles across the width
            for(int i = 0; i < 4; i++) // Spawn a few particles each frame for density
            {
                // Generate a random offset along the width.
                // Using a power of 3 to bias the distribution towards the edges.
                float offset_t = rrnd.frand() * 2.0 - 1.0; // -1 to 1
                float width_offset = (offset_t * offset_t * offset_t) * width * 0.5;

                Vec3 spawn_pos = pos + Vec3(tangent.x * width_offset, tangent.y * width_offset, 0);

                // Lifespan is shorter in the center and longer at the edges
                float max_life = 20;
                float min_life = 5;
                float life_t = abs(offset_t); // 0 at center, 1 at edge
                float particle_life = lerp(min_life, max_life, life_t);

                // Same trailing effects as light attack, but with new position and life
                float trail_speed = 0.01; 
                Vec3 trail_vel((rrnd.frand() - 0.5) * trail_speed, (rrnd.frand() - 0.5) * trail_speed, (rrnd.frand() - 0.5) * trail_speed * 0.5);
                // UPDATED: Use configurable trail colour
                fx_list.insertLast(ParticleFX(spawn_pos, trail_vel, 0.06f, this.trail_colour1, particle_life));

                float white_trail_speed = 0.005;
                Vec3 white_trail_vel((rrnd.frand() - 0.5) * white_trail_speed, (rrnd.frand() - 0.5) * white_trail_speed, (rrnd.frand() - 0.5) * white_trail_speed * 0.5);
                // UPDATED: Use configurable trail colour
                fx_list.insertLast(ParticleFX(spawn_pos, white_trail_vel, 0.04f, this.trail_colour2, particle_life * 0.75));
            }
        }
    }

    void draw(scene@ g, float sub_frame, IMobaCamera@ camera_provider)
    {
        if(life <= 0) return;
        // Rotated 90 degrees to be wider
        float angle = atan2(vel.y, vel.x) + PI / 2.0;
        draw_projected_quad(g, 20, 23, camera_provider, sub_frame, pos, width, length, angle, colour);
    }
    
    bool has_hit(int id)
    {
        for(uint i = 0; i < hit_enemies.length(); i++)
        {
            if(hit_enemies[i] == id) return true;
        }
        return false;
    }
    
    void add_hit(int id)
    {
        hit_enemies.insertLast(id);
    }
};

// -- AutoAttackParticle Class Definition --
class AutoAttackParticle
{
    scriptenemy@ dealer;
    Vec3 pos;
    Vec3 vel;
    scriptenemy@ target;
    float speed;
    float life;
    float size;
    uint colour;
    float damage;
    float width = 0.1f;
    // Configurable impact colours
    uint impact_colour1;
    uint impact_colour2;

    AutoAttackParticle(Vec3 start_pos, scriptenemy@ target, scriptenemy@ dealer, uint projectile_colour, float projectile_speed, float damage, uint impact_colour1, uint impact_colour2, float particle_size)
    {
        this.pos = start_pos;
        @this.target = target;
        @this.dealer = dealer;
        this.colour = projectile_colour;
        this.speed = projectile_speed;
        this.damage = damage;
        this.impact_colour1 = impact_colour1;
        this.impact_colour2 = impact_colour2;
        this.size = particle_size;
        
        // --- FIX: Initialize velocity and life in the constructor ---
        if (@target !is null && !target.destroyed())
        {
            IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(target.get_object());
            if (@target_char !is null)
            {
                float target_height = 0;
                MobaPlayer@ player_target = cast<MobaPlayer@>(target.get_object());
                if(@player_target !is null)
                {
                    target_height = player_target.auto_attack_height;
                }
                else
                {
                    Minion@ minion_target = cast<Minion@>(target.get_object());
                    if(@minion_target !is null)
                    {
                        target_height = minion_target.auto_attack_height;
                    }
                }
                Vec3 target_pos(target_char.x(), target_char.y(), target_height);
                Vec3 dir = (target_pos - pos);
                float dist = dir.length();
                dir = dir.normalize();

                if(speed > 0)
                {
                    this.life = (dist / speed) + 30; // Time to reach target + 30 frames buffer
                }
                else
                {
                    this.life = 400; // Fallback for stationary projectiles
                }

                this.vel = dir * speed;
            }
        }
        else
        {
            this.life = 0; // No target, so no life
        }
    }

    bool step(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        if (@target is null || target.destroyed())
        {
            life = 0;
            return true;
        }

        // Auto attack should ignore dying enemy minions.
        Minion@ target_minion = cast<Minion@>(target.get_object());
        if (@target_minion !is null && target_minion.state == M_STATE_DEATH)
        {
            life = 0;
            return true;
        }

        IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(target.get_object());
        if (@target_char is null)
        {
            life = 0;
            return true;
        }

        // Get target's auto attack height from the appropriate class
        float target_height = 0;
        MobaPlayer@ player_target = cast<MobaPlayer@>(target.get_object());
        if(@player_target !is null)
        {
            target_height = player_target.auto_attack_height;
        }
        else
        {
            Minion@ minion_target = cast<Minion@>(target.get_object());
            if(@minion_target !is null)
            {
                target_height = minion_target.auto_attack_height;
            }
        }

        Vec3 target_pos(target_char.x(), target_char.y(), target_height);
        Vec3 dir = target_pos - pos;
        float dist = dir.length();
        dir = dir.normalize();

        if (dist < speed)
        {
            IDamageable@ damageable_target = cast<IDamageable@>(target.get_object());
            if(@damageable_target !is null)
            {
                damageable_target.take_damage(damage, pos, dealer);
            }
            
            // --- Auto-Attack Impact Effect ---
            Vec3 attack_dir = vel.normalize();
            Vec3 front_dir(-attack_dir.y, attack_dir.x, 0); 
            for(int k = 0; k < 15; k++)
            {
                float offset_dist = (rrnd.frand() - 0.5) * width;
                Vec3 spawn_pos = pos + front_dir * offset_dist;
                spawn_pos.z = pos.z;
                float base_speed = rrnd.frand() * 0.03 + 0.015;
                Vec3 particle_vel = attack_dir * base_speed;
                particle_vel = particle_vel + front_dir * (rrnd.frand() - 0.5) * 0.01;
                particle_vel.z += rrnd.frand() * 0.01;
                // UPDATED: Use configurable impact colours
                uint particle_colour = rrnd.frand() < 0.8 ? impact_colour1 : impact_colour2;
                float particle_size = rrnd.frand() * 0.06 + 0.05;
                fx_list.insertLast(ParticleFX(spawn_pos, particle_vel, particle_size, particle_colour, 20));
            }

            life = 0;
            return true;
        }

        // Homing logic: velocity is continuously re-calculated to point towards the target
        vel = dir * speed;
        
        // Apply a "homing" gravity that pulls the particle towards the target's height
        float gravity_accel = 0.0025f; // A small constant for vertical acceleration
        if (pos.z < target_pos.z)
        {
            vel.z += gravity_accel;
        }
        else
        {
            vel.z -= gravity_accel;
        }

        pos = pos + vel;
        life--;
        return life <= 0;
    }

    void draw(scene@ g, float sub_frame, IMobaCamera@ camera_provider)
    {
        if(life <= 0) return;
        float angle = atan2(vel.y, vel.x);
        // Draw outline
        draw_projected_quad(g, 20, 22, camera_provider, sub_frame, pos, size * 1.2f, size * 1.2f, angle, 0x00000000);
        // Draw main particle
        draw_projected_quad(g, 20, 23, camera_provider, sub_frame, pos, size, size, angle, colour);
    }
};

// Define player states as an enum for compile-time constants
enum PlayerState
{
    P_STATE_IDLE = 0,
    P_STATE_RUN = 2,
    P_STATE_SKID = 3,
    P_STATE_LIGHT_ATTACK = 4,
    P_STATE_AUTO_ATTACK = 5,
    P_STATE_DEATH = 6, // Death state
    P_STATE_HEAVY_ATTACK = 7, // Heavy attack state
    P_STATE_BLINK_STARTUP = 51,
    P_STATE_BLINK_ARRIVAL = 52
};

class BlinkAfterImage
{
    sprites@ player_sprite;
    Vec2 pos;
    int face;
    float life;
    float animation_duration;
    float spawn_delay; // Delay in frames before the after-image appears
    bool spawned = false;

    BlinkAfterImage(Vec2 start_pos, int start_face, sprites@ player_sprite_ref, float delay_frames)
    {
        pos = start_pos;
        face = start_face;
        @player_sprite = player_sprite_ref;
        animation_duration = 3.6f; // Original animation length
        life = animation_duration;
        spawn_delay = delay_frames;

        // If there's no delay, spawn immediately
        if (spawn_delay <= 0) {
            spawned = true;
        }
    }

    // Returns true if the after-image should be removed
    bool step()
    {
        // Countdown spawn delay if not yet spawned
        if (!spawned)
        {
            spawn_delay -= 1; // Decrement per frame
            if (spawn_delay <= 0)
            {
                spawned = true;
            }
            return false;
        }
        
        // Countdown life once spawned
        life -= DT * 12;
        return life <= 0;
    }

    void draw(float sub_frame, IMobaCamera@ camera_provider, int sub_layer)
    {
        // Don't draw if it hasn't spawned yet
        if (!spawned) return;

        float screen_x, screen_y;
        Vec2 cam_pos = camera_provider.get_camera_pos();
        Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
        float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
        float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);

        camera_provider.project_to_screen(Vec3(pos.x, pos.y, 0), interp_camera_x, interp_camera_y, screen_x, screen_y);
        
        string sprite_name = "dash";
        uint frame = uint(floor((animation_duration - life) / (animation_duration / 5.0)));
        
        const int length = player_sprite.get_animation_length(sprite_name);
        if(length > 0) frame = frame % length;

        // Make the after-image fade out
        uint alpha = uint(round(clamp((life / animation_duration) * 255.0f, 0.0f, 255.0f)));
        uint final_colour = 0x00FFFFFF | (alpha << 24);

        player_sprite.draw_hud(20, sub_layer, sprite_name, frame, 1, screen_x, screen_y, 0, float(face) * 0.8, 0.8, final_colour);
    }
};


// -- Right Click Indicator Effect --
// This class manages the display and animation of the visual feedback when a move command is issued.
class RightClickIndicator
{
    private scene@ g;
    private Vec3 pos;
    private float life = 45; // 45 frames = 0.75 seconds
    private float initial_life = 45;
    private uint indicator_colour;

    RightClickIndicator(Vec3 start_pos, uint colour = 0xAA04db04)
    {
        @g = get_scene();
        this.pos = start_pos;
        this.indicator_colour = colour;
    }

    // Returns true if the indicator's life is over
    bool step()
    {
        life--;
        return life <= 0;
    }

    void draw(float sub_frame, IMobaCamera@ camera_provider)
    {
        if(life <= 0) return;

        float t = 1.0 - (life / initial_life); // Animation progress from 0 to 1

        // Loop for each of the 4 arrows forming the "plus" sign
        for(int i = 0; i < 4; i++)
        {
            float angle_rad = i * (PI / 2.0);
            Vec2 dir(cos(angle_rad), sin(angle_rad));

            // Animation properties
            float start_dist = 0.75f;
            float current_dist;
            float current_z_offset = 0;
            float current_angle_deg = (angle_rad * RAD2DEG);
            float current_alpha = (indicator_colour >> 24) & 0xFF;

            // Define base arrow shape
            float arrow_width = 0.08f;
            float arrow_length = 0.25f;

            float convergence_duration = 0.4f;
            if (t < convergence_duration) // Phase 1: Converging
            {
                float convergence_t = t / convergence_duration;
                current_dist = lerp(start_dist, 0.0f, ease_out_quad(convergence_t));
            }
            else // Phase 2: Diving into the ground
            {
                float dive_t = (t - convergence_duration) / (1.0f - convergence_duration);
                current_dist = 0;
                
                // Simulate curving down by moving down and foreshortening
                current_z_offset = ease_in_quad(dive_t) * -0.4f;
                arrow_length = lerp(arrow_length, arrow_width, ease_in_quad(dive_t));

                // Fade out
                current_alpha = lerp(current_alpha, 0.0f, dive_t);
            }

            Vec3 arrow_pos(
                pos.x + dir.x * current_dist,
                pos.y + dir.y * current_dist,
                pos.z + current_z_offset
            );
            uint final_colour = (indicator_colour & 0x00FFFFFF) | (uint(round(clamp(current_alpha, 0.0f, 255.0f))) << 24);

            draw_projected_quad(g, 10, 10, camera_provider, sub_frame, arrow_pos, arrow_width, arrow_length, current_angle_deg * DEG2RAD, final_colour);
        }
    }
    
    // Easing functions for smooth animation
    float ease_out_quad(float t) { return t * (2.0 - t); }
    float ease_in_quad(float t) { return t * t; }
};

// -- Attack Indicator Effect (Ground Projected & Animated) --
// This class manages the display of the red cross icon when an attack command is issued.
class AttackIndicator
{
    private scene@ g;
    private scriptenemy@ target; // Follow the target unit
    private float life = 45; // 45 frames = 0.75 seconds
    private float initial_life = 45;
    private uint indicator_colour = 0xCCFF2222; // Brighter Red, semi-transparent

    AttackIndicator(scriptenemy@ target_unit)
    {
        @g = get_scene();
        @this.target = target_unit;
    }

    // Returns true if the indicator's life is over
    bool step()
    {
        // If target is destroyed or gone, fade out faster
        if (@target is null || target.destroyed()) {
            life -= 3;
        } else {
            life--;
        }
        return life <= 0;
    }

    void draw(float sub_frame, IMobaCamera@ camera_provider)
    {
        if (life <= 0) return;

        // Don't draw if the target is gone
        IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(target.get_object());
        if (@target_char is null) return;

        // Get the interpolated world position of the target's center on the ground plane
        float target_x = lerp(target_char.prev_x(), target_char.x(), sub_frame);
        float target_y = lerp(target_char.prev_y(), target_char.y(), sub_frame);
        Vec3 center_pos(target_x, target_y, 0);

        float t = 1.0 - (life / initial_life); // Animation progress from 0 to 1

        // Loop for each of the 4 arms of the plus/cross sign
        for(int i = 0; i < 4; i++)
        {
            float angle_rad = i * (PI / 2.0);
            Vec2 dir(cos(angle_rad), sin(angle_rad));

            // Animation properties
            float start_dist = 0.6f;
            float current_dist;
            float current_alpha = (indicator_colour >> 24) & 0xFF;

            // Define the shape of each arm of the cross
            float arm_width = 0.12f;
            float arm_length = 0.4f;

            float convergence_duration = 0.3f; // Time for arms to converge
            if (t < convergence_duration) // Phase 1: Converging
            {
                float convergence_t = t / convergence_duration;
                current_dist = lerp(start_dist, 0.0f, ease_out_quad(convergence_t));
            }
            else // Phase 2: Fading out at the center
            {
                float fade_t = (t - convergence_duration) / (1.0f - convergence_duration);
                current_dist = 0;
                // Fade out using an ease-in curve (t*t) for a snappy disappearance
                current_alpha = lerp(current_alpha, 0.0f, fade_t * fade_t);
            }

            // Calculate the position for the center of the quad that forms the arm.
            // We offset it from the target's center by the current animation distance plus half the arm's length.
            float final_dist_from_center = current_dist + (arm_length * 0.5f);
            Vec3 arm_pos(
                center_pos.x + dir.x * final_dist_from_center,
                center_pos.y + dir.y * final_dist_from_center,
                center_pos.z
            );
            
            uint final_colour = (indicator_colour & 0x00FFFFFF) | (uint(round(clamp(current_alpha, 0.0f, 255.0f))) << 24);

            // Use the existing helper function to draw the arm projected onto the ground
            draw_projected_quad(g, 10, 11, camera_provider, sub_frame, arm_pos, arm_width, arm_length, angle_rad, final_colour);
        }
    }
    
    // Easing function for smooth animation
    float ease_out_quad(float t) { return t * (2.0 - t); }
};

// -- Healing Fountain Effect --
// This class manages the healing area at the player's spawn point.
class Fountain
{
    private Vec3 pos;
    private float radius = 2.2f;

    // Visuals
    private uint colour = 0x3387CEEB; // Light blue, semi-transparent
    private array<ParticleFX@> particles;
    private int particle_spawn_timer = 0;

    // References
    private scene@ g;
    private IMobaCamera@ camera_provider;
    private replay_rand@ rrnd;

    Fountain(Vec3 start_pos, IMobaCamera@ camera, replay_rand@ rrnd)
    {
        @g = get_scene();
        this.pos = start_pos;
        @this.camera_provider = camera;
        @this.rrnd = rrnd;
    }

    // Called every frame to spawn and update healing particles
    void step()
    {
        // Update existing particles
        for(int i = int(particles.length()) - 1; i >= 0; i--)
        {
            particles[i].step();
            if(particles[i].life <= 0)
            {
                particles.removeAt(i);
            }
        }

        // Spawn new particles periodically
        particle_spawn_timer--;
        if(particle_spawn_timer <= 0)
        {
            for(int i = 0; i < 3; i++) // Spawn a small cluster of particles
            {
                float angle = rrnd.rand_range(0.0f, 360.0f) * DEG2RAD;
                float dist = rrnd.rand_range(0.0f, radius);
                Vec3 spawn_pos = pos + Vec3(cos(angle) * dist, sin(angle) * dist, 0);

                Vec3 vel(0, 0, rrnd.rand_range(0.01f, 0.03f)); // Slow rising velocity
                uint particle_colour = rrnd.frand() < 0.7 ? 0xAAFFFFFF : 0xAAEBF4FF;
                float size = rrnd.rand_range(0.05f, 0.1f);
                float life = rrnd.rand_range(60, 120);

                particles.insertLast(ParticleFX(spawn_pos, vel, size, particle_colour, life));
            }
            particle_spawn_timer = 10;
        }
    }

    // Draws the fountain area and its particles
    void draw(float sub_frame)
    {
        // Draw the main circular area on the ground
        draw_filled_ground_circle(g, 9, 9, camera_provider, sub_frame, pos.x, pos.y, radius, 32, colour);

        // Draw all the active particles
        for(uint i = 0; i < particles.length(); i++)
        {
            particles[i].draw(g, sub_frame, camera_provider);
        }
    }

    // Checks if a given 2D position is inside the fountain's radius
    bool is_inside(Vec2 check_pos)
    {
        return dist_sqr(check_pos.x, check_pos.y, pos.x, pos.y) < radius * radius;
    }
};

// -- Regeneration Particle Effect --
// This class manages the visual particle effect that plays when the player regenerates.
class RegenVisualEffect
{
    private IDrawableCharacter@ character;
    private replay_rand@ rrnd;
    private float life_timer;
    private int particle_spawn_timer = 0;
    private float current_angle = 0;

    RegenVisualEffect(IDrawableCharacter@ character, replay_rand@ rrnd, float duration)
    {
        @this.character = character;
        @this.rrnd = rrnd;
        // Convert the duration from seconds to frames
        this.life_timer = duration * 60.0f;
        // Start at a random angle to vary the effect
        if(@rrnd !is null)
        {
            current_angle = rrnd.rand_range(0.0f, 360.0f) * DEG2RAD;
        }
    }

    // Returns true if the effect's life is over.
    // Adds new particles to the main fx_list.
    bool step(array<ParticleFX@>@ fx_list)
    {
        if (life_timer <= 0) return true;

        particle_spawn_timer--;
        
        bool is_dead = false;
        MobaPlayer@ player = cast<MobaPlayer@>(character);
        if(@player !is null)
        {
            if(player.state == P_STATE_DEATH) is_dead = true;
        }
        else
        {
            Champion@ champion = cast<Champion@>(character);
            if(@champion !is null)
            {
                if(champion.state == CHAMP_STATE_DEATH) is_dead = true;
            }
        }

        // Only spawn particles if the character is alive and the timer is ready
        if (particle_spawn_timer <= 0 && !is_dead && @rrnd !is null && rrnd.is_ready())
        {
            // -- MODIFIED VALUES FOR A MORE VERTICAL EFFECT --
            const float ORBIT_RADIUS = 0.4f;      // Spawn closer to the player
            const float ORBIT_SPEED = 0.015f;     // Spin more slowly
            const float RISE_SPEED_MIN = 0.005f;    // Rise slightly faster
            const float RISE_SPEED_MAX = 0.015f;     // Rise slightly faster
            const float ANGLE_INCREMENT = 10 * DEG2RAD; // Rotate spawn points slower
            current_angle += ANGLE_INCREMENT;

            // --- Health Particle (Green) ---
            Vec3 spawn_pos_health(
                character.x() + cos(current_angle) * ORBIT_RADIUS,
                character.y() + sin(current_angle) * ORBIT_RADIUS,
                0.1f // Start slightly above ground
            );
            // Tangential velocity for orbiting + upward velocity for rising
            Vec3 particle_vel_health(
                -sin(current_angle) * ORBIT_SPEED,
                cos(current_angle) * ORBIT_SPEED,
                rrnd.rand_range(RISE_SPEED_MIN, RISE_SPEED_MAX)
            );
            // Green colours for health
            uint health_colour = rrnd.frand() < 0.7 ? 0xAA04db04 : 0xAA98FB98; // Green and PaleGreen
            float particle_size = rrnd.rand_range(0.05f, 0.1f);
            float particle_life = rrnd.rand_range(45, 75);
            fx_list.insertLast(ParticleFX(spawn_pos_health, particle_vel_health, particle_size, health_colour, particle_life));

            // --- Mana Particle (Blue) ---
            float mana_angle = current_angle + PI; // Spawn on the opposite side
            Vec3 spawn_pos_mana(
                character.x() + cos(mana_angle) * ORBIT_RADIUS,
                character.y() + sin(mana_angle) * ORBIT_RADIUS,
                0.1f
            );
            // Tangential velocity for orbiting + upward velocity for rising
            Vec3 particle_vel_mana(
                -sin(mana_angle) * ORBIT_SPEED,
                cos(mana_angle) * ORBIT_SPEED,
                rrnd.rand_range(RISE_SPEED_MIN, RISE_SPEED_MAX)
            );
            // Blue colours for mana
            uint mana_colour = rrnd.frand() < 0.7 ? 0xAA1E90FF : 0xAAADD8E6; // DodgerBlue and LightBlue
            particle_size = rrnd.rand_range(0.05f, 0.1f);
            particle_life = rrnd.rand_range(45, 75);
            fx_list.insertLast(ParticleFX(spawn_pos_mana, particle_vel_mana, particle_size, mana_colour, particle_life));

            // Reset spawn timer
            particle_spawn_timer = 20;
        }

        life_timer--;
        return false;
    }
};


// New class to handle regeneration over time.
class RegenEffect
{
    float health_per_second;
    float mana_per_second;
    float life_timer;

    RegenEffect(float hps, float mps, float duration)
    {
        health_per_second = hps;
        mana_per_second = mps;
        life_timer = duration * 60.0f; // Convert seconds to frames
    }

    // Applies regeneration and returns true if the effect is finished.
    bool step(MobaPlayer@ player)
    {
        if(life_timer <= 0) return true;
        
        if (player.current_health > 0 && player.state != P_STATE_DEATH)
        {
             player.current_health = min(player.max_health, player.current_health + health_per_second * DT);
        }
       
        player.current_mana = min(player.max_mana, player.current_mana + mana_per_second * DT);
        
        life_timer--;
        return false;
    }

    // Applies regeneration and returns true if the effect is finished.
    bool step(Champion@ champion)
    {
        if(life_timer <= 0) return true;
        
        if (champion.current_health > 0 && champion.state != CHAMP_STATE_DEATH)
        {
             champion.current_health = min(champion.max_health, champion.current_health + health_per_second * DT);
        }
       
        champion.current_mana = min(champion.max_mana, champion.current_mana + mana_per_second * DT);
        
        life_timer--;
        return false;
    }
}

// Helper function to draw a line using a quad, as draw_line_hud is disallowed.
void draw_line_as_quad(scene@ g, int layer, int sub_layer, float x1, float y1, float x2, float y2, float thickness, uint colour)
{
    float dx = x2 - x1;
    float dy = y2 - y1;
    float length = sqrt(dx * dx + dy * dy);
    if(length <= 1e-6) return;

    // Normalize the direction vector
    dx /= length;
    dy /= length;
    
    // Calculate the perpendicular vector for the quad's width
    float px = -dy * (thickness * 0.5f);
    float py = dx * (thickness * 0.5f);

    // Define the 4 corners of the quad
    float qx1 = x1 + px;
    float qy1 = y1 + py;
    float qx2 = x2 + px;
    float qy2 = y2 + py;
    float qx3 = x2 - px;
    float qy3 = y2 - py;
    float qx4 = x1 - px;
    float qy4 = y1 - py;

    g.draw_quad_hud(layer, sub_layer, true, qx1, qy1, qx2, qy2, qx3, qy3, qx4, qy4, colour, colour, colour, colour);
}

void outline_rect_hud(scene@ g, uint layer, uint sub_layer, float x1, float y1, float x2, float y2, float thickness, uint colour)
{
    draw_line_as_quad(g, layer, sub_layer, x1, y1, x2, y1, thickness, colour); // Top
    draw_line_as_quad(g, layer, sub_layer, x2, y1, x2, y2, thickness, colour); // Right
    draw_line_as_quad(g, layer, sub_layer, x2, y2, x1, y2, thickness, colour); // Bottom
    draw_line_as_quad(g, layer, sub_layer, x1, y2, x1, y1, thickness, colour); // Left
}

// -- Replay Cursor --
// Draws a cursor in replays to show the recorded mouse position.
class ReplayCursor
{
    private scene@ g;

    ReplayCursor()
    {
        @g = get_scene();
    }

    void draw(float sub_frame, IMobaCamera@ camera_provider)
    {
        if(!is_replay()) return;

        // Get the recorded mouse position directly in HUD coordinates.
        float mx = g.mouse_x_hud(0, true);
        float my = g.mouse_y_hud(0, true);

        // Define the cursor's appearance
        const float s = 15.0f; // New, smaller size
        const float border_thickness = 3.0f;
        const float highlight_thickness = 1.0f;

        // Colors
        const uint gold_colour = 0xFFD7AF00;
        const uint black_colour = 0xFF000000;
        const uint highlight_colour = 0xFFFFF5EE;

        // Symmetrical vertices for a classic concave arrowhead shape
        const float p1x = mx,                    p1y = my;                   // Tip, at the mouse position
        const float p2x = mx + s,                p2y = my + s * 0.4f;        // Right wingtip
        const float p3x = mx + s * 0.6f,         p3y = my + s * 0.6f;        // Inner nook (the "inwards indented point")
        const float p4x = mx + s * 0.4f,         p4y = my + s;               // Left wingtip

        // 1. Draw the black border using the line helper
        draw_line_as_quad(g, 22, 21, p1x, p1y, p2x, p2y, border_thickness, black_colour);
        draw_line_as_quad(g, 22, 21, p2x, p2y, p3x, p3y, border_thickness, black_colour);
        draw_line_as_quad(g, 22, 21, p3x, p3y, p4x, p4y, border_thickness, black_colour);
        draw_line_as_quad(g, 22, 21, p4x, p4y, p1x, p1y, border_thickness, black_colour);
        
        // 2. Draw the main gold-filled shape (using two triangles, drawn as quads)
        // Triangle 1 (top-right side)
        g.draw_quad_hud(22, 22, true, p1x, p1y, p2x, p2y, p3x, p3y, p3x, p3y, 
                        gold_colour, gold_colour, gold_colour, gold_colour);
        // Triangle 2 (bottom-left side)
        g.draw_quad_hud(22, 22, true, p1x, p1y, p3x, p3y, p4x, p4y, p4x, p4y, 
                        gold_colour, gold_colour, gold_colour, gold_colour);

        // 3. Draw a highlight on the top-left edge
        draw_line_as_quad(g, 22, 23, p1x + 0.5, p1y + 1, p4x + 0.5, p4y, highlight_thickness, highlight_colour);
    }
};


// Helper for hsl_to_rgb
float hue_to_rgb(float p, float q, float t)
{
    if(t < 0) t += 1;
    if(t > 1) t -= 1;
    if(t < 1.0/6.0) return p + (q - p) * 6.0 * t;
    if(t < 1.0/2.0) return q;
    if(t < 2.0/3.0) return p + (q - p) * (2.0/3.0 - t) * 6.0;
    return p;
}

// Converts an HSL color value to RGB.
uint hsl_to_rgb(float h, float s, float l, float a = 1.0f)
{
    float r, g, b;

    if(s == 0)
    {
        r = g = b = l; // achromatic
    }
    else
    {
        const float q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        const float p = 2 * l - q;
        r = hue_to_rgb(p, q, h + 1.0/3.0);
        g = hue_to_rgb(p, q, h);
        b = hue_to_rgb(p, q, h - 1.0/3.0);
    }
    
    return
        (uint(round(a * 255)) << 24) |
        (uint(round(r * 255)) << 16) |
        (uint(round(g * 255)) << 8) |
        (uint(round(b * 255)));
}

// Converts an RGB color value to HSL.
void rgb_to_hsl(uint r_in, uint g_in, uint b_in, float &out h, float &out s, float &out l)
{
    float r = r_in / 255.0;
    float g = g_in / 255.0;
    float b = b_in / 255.0;

    float _max = max(max(r, g), b);
    float _min = min(min(r, g), b);
    l = (_max + _min) / 2.0;

    if(_max == _min)
    {
        h = s = 0; // achromatic
    }
    else
    {
        float d = _max - _min;
        s = l > 0.5 ? d / (2.0 - _max - _min) : d / (_max + _min);

        if(_max == r)
            h = (g - b) / d + (g < b ? 6.0 : 0.0);
        else if(_max == g)
            h = (b - r) / d + 2.0;
        else if(_max == b)
            h = (r - g) / d + 4.0;

        h /= 6.0;
    }
}

// -- New Color Interpolation Function --
// Replaces the old `lerp_colour` to provide a smoother gradient by working in HSL color space.
uint lerp_colour(const uint start_rgb, const uint end_rgb, float t)
{
    t = clamp(t, 0.0f, 1.0f);

    // Deconstruct start color
    const float sa = ((start_rgb >> 24) & 0xff) / 255.0f;
    const uint sr = (start_rgb >> 16) & 0xff;
    const uint sg = (start_rgb >> 8) & 0xff;
    const uint sb = (start_rgb) & 0xff;

    // Deconstruct end color
    const float ea = ((end_rgb >> 24) & 0xff) / 255.0f;
    const uint er = (end_rgb >> 16) & 0xff;
    const uint eg = (end_rgb >> 8) & 0xff;
    const uint eb = (end_rgb) & 0xff;

    // Convert to HSL
    float sh, ss, sl, eh, es, el;
    rgb_to_hsl(sr, sg, sb, sh, ss, sl);
    rgb_to_hsl(er, eg, eb, eh, es, el);
    
    // Interpolate HSL values
    // Handle shortest path for hue (which is circular)
    float h;
    float dist = eh - sh;
    if (dist > 0.5f) dist -= 1.0f;
    if (dist < -0.5f) dist += 1.0f;
    h = sh + dist * t;
    if (h < 0) h += 1.0f;
    if (h > 1.0f) h -= 1.0f;

    float s = lerp(ss, es, t);
    float l = lerp(sl, el, t);
    float a = lerp(sa, ea, t);

    return hsl_to_rgb(h, s, l, a);
}

// -- Ability Icon UI --
// Draws a single ability icon with its cooldown overlay.
class AbilityIcon
{
    private sprites@ player_sprite;
    private string sprite_name;
    private uint frame;
    private float x, y, size, icon_scale;
    private uint bg_colour = 0x55000000;
    private uint cd_colour = 0x55FFFFFF;

    AbilityIcon(sprites@ player_sprite, string sprite_name, uint frame, float size, float icon_scale=0.02)
    {
        @this.player_sprite = player_sprite;
        this.sprite_name = sprite_name;
        this.frame = frame;
        this.size = size;
        this.icon_scale = icon_scale;
    }

    void set_position(float x, float y)
    {
        this.x = x;
        this.y = y;
    }

    // Helper function to find where an angle intersects the bounding box
    void get_square_intersection(float angle_deg, float cx, float cy, float p_size, float &out ix, float &out iy)
    {
        float hs = p_size / 2.0;
        float angle_rad = angle_deg * DEG2RAD;
        float cos_a = cos(angle_rad);
        float sin_a = sin(angle_rad);

        if (abs(cos_a) < 1e-6 && abs(sin_a) < 1e-6) {
            ix = cx; iy = cy; return;
        }
        float t = hs / max(abs(cos_a), abs(sin_a));
        
        ix = cx + t * cos_a;
        iy = cy + t * sin_a;
    }

    void draw(scene@ g, float cooldown_percent, float sprite_x_offset = 0, float sprite_y_offset = 0)
    {
        // Draw icon background
        g.draw_rectangle_hud(22, 1, x - size / 2, y - size / 2, x + size / 2, y + size / 2, 0, bg_colour);

        // Draw icon sprite, applying the horizontal offset
        player_sprite.draw_hud(22, 22, sprite_name, frame, 1, x + sprite_x_offset, y+11 + sprite_y_offset, 0, icon_scale, icon_scale, 0xFFFFFFFF);

        // Draw cooldown "pie" overlay that fills the square
        if (cooldown_percent > 0)
        {
            // The angle where the filled part of the cooldown ends (fixed at the top)
            const float angle_end = 270; 
            // The angle where the filled part begins, moving clockwise as the cooldown progresses
            float current_angle = -90 + (1.0 - cooldown_percent) * 360;

            // Prevent floating point inaccuracies from drawing a full circle when cooldown is complete
            if (cooldown_percent <= 0.001) {
                current_angle = angle_end;
            }

            float hs = size / 2.0;

            // Define the angles and coordinates of the square's corners relative to its center
            const array<float> corner_angles = {-45, 45, 135, 225}; // TR, BR, BL, TL
            
            // Loop until the full cooldown arc is drawn
            while(current_angle < angle_end)
            {
                float next_segment_angle = angle_end;
                
                // Find the next corner in the path of the arc
                for(uint i = 0; i < corner_angles.length(); i++)
                {
                    float corner_angle = corner_angles[i];
                    // Adjust for angle wrapping around 270 degrees
                    if(current_angle > 180 && corner_angle < 0) corner_angle += 360;

                    if(corner_angle > current_angle && corner_angle < next_segment_angle)
                    {
                        next_segment_angle = corner_angle;
                    }
                }
                
                float x1 = x;
                float y1 = y;
                float x2, y2, x3, y3;
                // The first point of the triangle fan is on the perimeter at the current angle
                get_square_intersection(current_angle, x, y, size, x2, y2);
                // The second point is either the next corner or the final angle
                get_square_intersection(next_segment_angle, x, y, size, x3, y3);

                // Draw the segment as a triangle from the center to the two perimeter points
                g.draw_quad_hud(22, 3, false, x1, y1, x2, y2, x3, y3, x3, y3, cd_colour, cd_colour, cd_colour, cd_colour);
                
                // Move to the next segment's start angle
                current_angle = next_segment_angle;
            }
        }
        
        // Draw icon border
        outline_rect_hud(g, 22, 4, x - size / 2, y - size / 2, x + size / 2, y + size / 2, 2, 0x99FFFFFF);
    }
}
// -- Ability Bar UI --
// Manages the layout and drawing of all ability icons.
class AbilityBar
{
    private array<AbilityIcon@> icons;
    private float icon_size = 40; // Reduced icon container size
    private float icon_spacing = 10; // Reduced spacing

    void init(sprites@ player_sprite)
    {
        // Reduced the icon_scale factor for each ability icon
        icons.insertLast(AbilityIcon(player_sprite, "groundstrike1", 1, icon_size, 0.32));
        icons.insertLast(AbilityIcon(player_sprite, "dash", 1, icon_size, 0.32));
        icons.insertLast(AbilityIcon(player_sprite, "airsmash", 1, icon_size, 0.32));
    }

    void draw(MobaPlayer@ player)
    {
        scene@ g = get_scene();
        float total_width = (icons.length() * icon_size) + ((icons.length() - 1) * icon_spacing);
        float start_x = -total_width / 2;
        float y = 450 - (icon_size / 2) - 15; // Adjusted padding from bottom

        for (uint i = 0; i < icons.length(); i++)
        {
            float x = start_x + (i * (icon_size + icon_spacing)) + (icon_size / 2);
            icons[i].set_position(x, y);

            float cooldown_percent = 0;
            if (i == 0)      // Light Attack
                cooldown_percent = player.light_attack_cooldown_timer / player.light_attack_cooldown;
            else if (i == 1) // Blink
                cooldown_percent = player.blink_cooldown_timer / player.blink_cooldown;
            else if (i == 2) // Heavy Attack
                cooldown_percent = player.heavy_attack_cooldown_timer / player.heavy_attack_cooldown;
            
            // Apply a horizontal offset only for the middle icon
            float sprite_x_offset = 0;
            float sprite_y_offset = 0;
            if (i == 1)
            {
                sprite_x_offset = -5; // Adjust this value as needed
            }
            else if (i == 0)
            {
                sprite_x_offset = -2;
                sprite_y_offset = 2;
            }
            icons[i].draw(g, cooldown_percent, sprite_x_offset, sprite_y_offset);
        }
    }
}

class MobaPlayer : enemy_base, IMobaCamera, IDrawableCharacter, IDamageable
{
    scene@ g;
    scriptenemy@ self;
    camera@ cam;
    textfield@ level_text;
    script@ main_script;
    
    sprites@ player_sprite;
    Vec2 pos;
    Vec2 prev_pos;
    float z = 0;
    Vec2 target_pos;
    bool has_target;
    int state = 0; 
    float state_timer = 0;
    int face = 1;
    int last_mouse_state = 0;
    array<Vec2> velocity_history;
    int velocity_history_index = 0;
    uint VELOCITY_HISTORY_SIZE = 30; // 0.5 seconds at 60fps
    int pre_attack_state = 0;
    int pre_attack_face = 1;
    bool pre_attack_has_target = false;
    Vec2 pre_attack_target_pos;
    array<AttackParticle@> attack_particles;
    array<HeavyAttackParticle@> heavy_attack_particles;
    array<ParticleFX@> fx_list;
    array<BlinkAfterImage@> after_images;
    array<RightClickIndicator@> click_indicators;
    array<AttackIndicator@> attack_indicators; 
    
    // Ability Bar UI
    AbilityBar@ ability_bar;
    
    float world_bounds_x = 20.0;
    float world_bounds_y = 20.0;
    float tile_size = 0.48;
    
    Vec2 _camera_pos;
    Vec2 _prev_camera_pos;
    Vec3 camera_3d_offset;
    Vec2 camera_start_offset;
    Vec2 camera_jump_offset;
    float fov = 60.0;
    float camera_pan_speed = 0.1;
    float screen_edge_margin = 20.0;

    array<Vec2> ground_vertices;
    int ground_grid_width = 0;
    int ground_grid_height = 0;

    // Auto-attack properties
    float attack_range = 4.0f;
    scriptenemy@ aggression_target = null;
    array<AutoAttackParticle@> auto_attack_particles;

    [colour,alpha] uint auto_attack_colour = 0xFFF7C24F;
    [text] float auto_attack_speed = 0.2f;
    [text] float auto_attack_damage = 9.0f;
    [text] float light_attack_height = 0.4f;
    [text] float auto_attack_height = 0.5f;
    float FOUNTAIN_HEAL_RATE = 0.0f;
    float FOUNTAIN_MANA_RATE = 8.0f;

    [colour,alpha] uint auto_attack_impact_colour1 = 0xFFFFC852;
    [colour,alpha] uint auto_attack_impact_colour2 = 0xFFE3694C;

    // Health properties
    float max_health = 120;
    float current_health = 120;
    float pending_damage_health = 100;
    [text] float health_decay_speed = 40.0f;
    [text] float health_bar_width = 90;
    [text] float health_bar_height = 10;
    [text] float health_bar_y_offset = -99;
    [text] float health_bar_outline = 2;
    [text] float health_tick_interval = 20;
    
    // Mana properties
    float max_mana = 100;
    float current_mana = 100;
    float pending_mana_cost = 100;
    float mana_regen_rate = 1.0f;
    [text] float mana_decay_speed = 30.0f;
    [text] float mana_bar_height = 6;

    // Level Icon properties
    [text] int player_level = 3;
    [text] float level_icon_size = 22;
    [colour,alpha] uint level_icon_bg_colour = 0xFF003356;

    // Blink ability properties
    float BLINK_MAX_RANGE = 3.0f;
    float BLINK_ANIMATION_DURATION_TIMER = 3.6f;
    float blink_cooldown = 240;
    float blink_cooldown_timer = 0;
    Vec2 blink_target_pos;
    
    bool has_buffered_move = false;
    Vec2 buffered_target_pos;

    bool pre_blink_has_target = false;
    Vec2 pre_blink_target_pos;

    // Buffered attack properties
    bool light_attack_active = false;
    float light_attack_timer = 0;
    Vec2 light_attack_target_pos;
    float light_attack_cooldown = 240;
    float light_attack_cooldown_timer = 0;
    float light_attack_mana_cost = 10;
    
    bool heavy_attack_active = false;
    float heavy_attack_timer = 0;
    Vec2 heavy_attack_target_pos;
    float heavy_attack_cooldown = 480;
    float heavy_attack_cooldown_timer = 0;
    float heavy_attack_mana_cost = 20;

    bool camera_pan_locked = true;

    Vec2 spawn_position;
    string death_animation_name = "stun1";
    
    // Manage active regeneration effects
    array<RegenEffect@> regen_effects;
    array<RegenVisualEffect@> regen_visual_effects;
    replay_rand@ rrnd_ref;

    MobaPlayer()
    {
        @g = get_scene();
        @cam = get_camera(0);
        camera_start_offset.set(1.5, 1.5); 
        camera_jump_offset.set(1, 1); 
        
        @level_text = create_textfield();
        level_text.set_font("envy_bold", 20);
        level_text.align_horizontal(0);
        level_text.align_vertical(0);
        
        // Instantiate the ability bar
        @ability_bar = AbilityBar();
        velocity_history.resize(VELOCITY_HISTORY_SIZE);
    }
    
    void init(script@ s, scriptenemy@ self)
    {
        @this.self = self;
        @this.main_script = s;
        self.auto_physics(false);
        cam.script_camera(true);
        
        @player_sprite = create_sprites();
        player_sprite.add_sprite_set("leafsprite");
        
        // Initialize the ability bar with the player's sprites
        ability_bar.init(player_sprite);
        
        pos.set(-5.0, -7.0);
        prev_pos.set(pos.x, pos.y);
        spawn_position.set(-7.0, -7.0);
        self.x(pos.x);
        self.y(pos.y);

        _camera_pos.set(self.x() + camera_start_offset.x, self.y() + camera_start_offset.y);
        _prev_camera_pos.set(_camera_pos.x, _camera_pos.y);
        
        has_target = false;
        camera_3d_offset.set(0, -3.5, 6.0);
        
        current_health = max_health;
        pending_damage_health = max_health;
        
        current_mana = max_mana;
        pending_mana_cost = max_mana;
    }
    
    Vec2 get_average_velocity()
    {
        Vec2 avg_vel(0, 0);
        if (velocity_history.length() == 0) return avg_vel;

        for (uint i = 0; i < VELOCITY_HISTORY_SIZE; i++)
        {
            avg_vel = avg_vel + velocity_history[i];
        }
        
        return avg_vel * (1.0f / VELOCITY_HISTORY_SIZE);
    }
    
    // Method to add a regeneration effect
    void add_regen_effect(float hps, float mps, float duration)
    {
        regen_effects.insertLast(RegenEffect(hps, mps, duration));
        
        // Also create the visual effect that spawns particles
        if(@rrnd_ref !is null)
        {
            regen_visual_effects.insertLast(RegenVisualEffect(this, rrnd_ref, duration));
        }
    }
    
    void take_damage(float amount, Vec3 attacker_pos, scriptenemy@ attacker)
    {
        if (current_health <= 0) return;

        current_health -= amount;
        if(current_health <= 0)
        {
            g.combo_break_count(g.combo_break_count() + 1);
            current_health = 0;
            state = P_STATE_DEATH;
            state_timer = 0;
            float attack_dx = attacker_pos.x - pos.x;
            if (attack_dx * face > 0)
            {
                death_animation_name = "stun1";
            }
            else
            {
                death_animation_name = "stun2";
            }

            MobaPlayer@ player_attacker = cast<MobaPlayer@>(attacker.get_object());
            Champion@ champion_attacker = cast<Champion@>(attacker.get_object());
            if (@player_attacker !is null)
            {
                // Find the main script instance to add the indicator
                if (@main_script !is null)
                {
                    main_script.add_gold_indicator(Vec3(pos.x, pos.y, 1.0f));
                }
                
                // Add the regen effect for getting the last hit
                const float total_regen = 10.0f;
                const float duration_seconds = 3.0f;
                player_attacker.add_regen_effect(total_regen / duration_seconds, total_regen / duration_seconds / 3, duration_seconds);
            }
            else if (@champion_attacker !is null)
            {
                // Find the main script instance to add the indicator
                if (@main_script !is null)
                {
                    main_script.add_gold_indicator(Vec3(pos.x, pos.y, 1.0f));
                }
                
                // Add the regen effect for getting the last hit
                const float total_regen = 10.0f;
                const float duration_seconds = 3.0f;
                champion_attacker.add_regen_effect(total_regen / duration_seconds, total_regen / duration_seconds / 3, duration_seconds);
            }
        }
    }
    // This is a replay-safe helper method to replace the old unproject_from_screen logic.
    void _unproject_manual_helper(float screen_x, float screen_y, float cam_world_x, float cam_world_y, Vec3 &out world_pos)
    {
        Vec3 cam_pos, cam_forward, cam_right, cam_up;
        get_camera_transform(cam_world_x, cam_world_y, cam_pos, cam_forward, cam_right, cam_up);
        float ndc_x = screen_x / 800.0;
        float ndc_y = -screen_y / 450.0;
        float aspect_ratio = 1920.0 / 1080.0;
        float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
        float view_x = ndc_x * aspect_ratio / fov_adjust;
        float view_y = ndc_y / fov_adjust;
        Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
        Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
        ray_dir_world = ray_dir_world.normalize();
        if(abs(ray_dir_world.z) >= 1e-6)
        {
            float t = -cam_pos.z / ray_dir_world.z;
            world_pos = cam_pos + ray_dir_world * t;
        }
    }
    
    void respawn()
    {
        pos.set(spawn_position.x, spawn_position.y);
        prev_pos.set(pos.x, pos.y);
        current_health = max_health;
        pending_damage_health = max_health;
        current_mana = max_mana;
        pending_mana_cost = max_mana;
        state = P_STATE_IDLE;
        state_timer = 0;
        has_target = false;
        @aggression_target = null;
    }

    // Interface implementations
    Vec2 get_camera_pos() { return _camera_pos; }
    Vec2 get_prev_camera_pos() { return _prev_camera_pos; }
    float x() { return pos.x; }
    float y() { return pos.y; }
    float prev_x() { return prev_pos.x; }
    float prev_y() { return prev_pos.y; }
    float hitbox_radius() { return 0.4; }
    Team getTeam() { return Team::Friendly; }

    void move_player()
    {
        if(!has_target) return;
        float dx = target_pos.x - pos.x;
        float dy = target_pos.y - pos.y;
        float dist = sqrt(dx * dx + dy * dy);
        float move_speed = 0.03;
        if(dist < move_speed)
        {
            pos.set(target_pos.x, target_pos.y);
            has_target = false;
            if(state != P_STATE_LIGHT_ATTACK && state != P_STATE_AUTO_ATTACK && state != P_STATE_HEAVY_ATTACK) { state = P_STATE_IDLE; state_timer = 0; }
        }
        else
        {
            float new_pos_x = pos.x + (dx / dist) * move_speed;
            float new_pos_y = pos.y + (dy / dist) * move_speed;
            new_pos_x = clamp(new_pos_x, -world_bounds_x, world_bounds_x);
            new_pos_y = clamp(new_pos_y, -world_bounds_y, world_bounds_y);
            pos.set(new_pos_x, new_pos_y);
            if(state != P_STATE_LIGHT_ATTACK && state != P_STATE_AUTO_ATTACK && state != P_STATE_HEAVY_ATTACK)
            {
                float skid_distance = 21 * move_speed;
                if(dist < skid_distance) { if(state != P_STATE_SKID) { state = P_STATE_SKID; state_timer = 0; } }
                else { if(state != P_STATE_RUN) { state = P_STATE_RUN; state_timer = 0; } }
                Vec3 cam_p, cam_f, cam_r, cam_u;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_p, cam_f, cam_r, cam_u);
                Vec3 move_vec_world(dx, dy, 0);
                float right_dot = dot(move_vec_world, cam_r);
                if(abs(right_dot) > 0.5) { face = right_dot > 0 ? 1 : -1; }
            }
        }
    }
    
    void step(array<scriptenemy@>@ minions, array<scriptenemy@>@ champions, replay_rand@ rrnd)
    {
        // Cache the replay_rand reference if we don't have it yet.
        if(@rrnd_ref == null) @rrnd_ref = rrnd;

        if (light_attack_cooldown_timer > 0)
        {
            light_attack_cooldown_timer -= DT * 60;
        }
        
        if (heavy_attack_cooldown_timer > 0)
        {
            heavy_attack_cooldown_timer -= DT * 60;
        }
        
        if (blink_cooldown_timer > 0)
        {
            blink_cooldown_timer -= DT * 60;
        }
        
        if (state == P_STATE_DEATH)
        {
            state_timer++;
            if (state_timer >= 120) // 2 second respawn timer
            {
                respawn();
            }
            return; // Don't process other logic while dead
        }

        // Step through active stat regen effects
        for(int i = int(regen_effects.length()) - 1; i >= 0; i--)
        {
            if(regen_effects[i].step(this))
            {
                regen_effects.removeAt(i);
            }
        }

        // Step through regen visual effects (particle spawning)
        for(int i = int(regen_visual_effects.length()) - 1; i >= 0; i--)
        {
            // The visual effect step will add particles to the main fx_list
            if(regen_visual_effects[i].step(fx_list))
            {
                regen_visual_effects.removeAt(i);
            }
        }

        // Mana Regeneration
        if (current_mana < max_mana)
        {
            current_mana += mana_regen_rate * DT;
            if (current_mana > max_mana)
            {
                current_mana = max_mana;
            }
        }

        if (pending_damage_health > current_health)
        {
            pending_damage_health -= health_decay_speed * DT;
            if (pending_damage_health < current_health)
            {
                pending_damage_health = current_health;
            }
        }
        else
        {
            pending_damage_health = current_health;
        }

        if (pending_mana_cost > current_mana)
        {
            pending_mana_cost -= mana_decay_speed * DT;
            if (pending_mana_cost < current_mana)
            {
                pending_mana_cost = current_mana;
            }
        }
        else
        {
            pending_mana_cost = current_mana;
        }

        Vec2 current_velocity(pos.x - prev_pos.x, pos.y - prev_pos.y);
        velocity_history[velocity_history_index] = current_velocity;
        velocity_history_index = (velocity_history_index + 1) % VELOCITY_HISTORY_SIZE;
 



        prev_pos.set(pos.x, pos.y);
        _prev_camera_pos.set(_camera_pos.x, _camera_pos.y);
        float raw_mouse_x = g.mouse_x_hud(0, false);
        float raw_mouse_y = g.mouse_y_hud(0, false);
        // Quantize the raw mouse coordinates to the specified precision.
        float raw_width = g.hud_screen_width(false);
        float raw_height = g.hud_screen_height(false);
        float mouse_hud_x = (raw_mouse_x / raw_width) * 1600;
        float mouse_hud_y = (raw_mouse_y / raw_height) * 900;

        if (camera_pan_locked)
        {
            if (abs(mouse_hud_x) < (800 - screen_edge_margin) && abs(mouse_hud_y) < (450 - screen_edge_margin))
            {
                camera_pan_locked = false;
            }
        }

        if(self.jump_intent() > 0) { _camera_pos.set(pos.x + camera_jump_offset.x, pos.y + camera_jump_offset.y); }
        else if(!camera_pan_locked)
        {
            float screen_width_half = 800;
            float screen_height_half = 450;
            float new_cam_x = _camera_pos.x;
            float new_cam_y = _camera_pos.y;
            if (mouse_hud_x < -screen_width_half + screen_edge_margin) { new_cam_x -= camera_pan_speed; }
            else if (mouse_hud_x > screen_width_half - screen_edge_margin) { new_cam_x += camera_pan_speed; }
            if (mouse_hud_y < -screen_height_half + screen_edge_margin) { new_cam_y += camera_pan_speed; }
            else if (mouse_hud_y > screen_height_half - screen_edge_margin) { new_cam_y -= camera_pan_speed; }
            _camera_pos.set(new_cam_x, new_cam_y);
        }
        float clamped_x, clamped_y;
        clamp_camera(_camera_pos.x, _camera_pos.y, clamped_x, clamped_y);
        _camera_pos.set(clamped_x, clamped_y);

        int current_mouse_state = g.mouse_state(0);
        bool right_click_press = (current_mouse_state & 8) != 0 && (last_mouse_state & 8) == 0;
        // --- Input Handling ---

        // Taunt-based Attack-Move Logic
        if (self.taunt_intent() == 1)
        {
            self.taunt_intent(2); // Consume the input to prevent repeated calls

            Vec3 world_pos;
            _unproject_manual_helper(mouse_hud_x, mouse_hud_y, _camera_pos.x, _camera_pos.y, world_pos);
            if(main_script.click_precision > 0)
            {
                world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
            }
            
            const float inner_radius = 1.0f;
            const float outer_radius = 3.0f;
            scriptenemy@ best_target = null;
            
            // Step 1: Check for closest champion within the inner radius first
            float best_dist_sq = inner_radius * inner_radius;
            for (uint i = 0; i < champions.length(); i++)
            {
                scriptenemy@ champ_ent = champions[i];
                Champion@ champ_logic = cast<Champion@>(champ_ent.get_object());
                if (@champ_logic is null || champ_logic.getTeam() == Team::Friendly || champ_logic.state == CHAMP_STATE_DEATH) continue;

                float dist_sq = dist_sqr(world_pos.x, world_pos.y, champ_logic.x(), champ_logic.y());
                if (dist_sq < best_dist_sq)
                {
                    best_dist_sq = dist_sq;
                    @best_target = champ_ent;
                }
            }

            // Step 2: If no champion was found in the inner radius, find the closest of any unit in the outer radius
            if (@best_target is null)
            {
                best_dist_sq = outer_radius * outer_radius;
                
                // Check all champions in the outer radius
                for (uint i = 0; i < champions.length(); i++)
                {
                    scriptenemy@ champ_ent = champions[i];
                    Champion@ champ_logic = cast<Champion@>(champ_ent.get_object());
                    if (@champ_logic is null || champ_logic.getTeam() == Team::Friendly || champ_logic.state == CHAMP_STATE_DEATH) continue;

                    float dist_sq = dist_sqr(world_pos.x, world_pos.y, champ_logic.x(), champ_logic.y());
                    if (dist_sq < best_dist_sq)
                    {
                        best_dist_sq = dist_sq;
                        @best_target = champ_ent;
                    }
                }
                
                // Check all minions in the outer radius
                for (uint i = 0; i < minions.length(); i++)
                {
                    scriptenemy@ minion_ent = minions[i];
                    Minion@ minion_logic = cast<Minion@>(minion_ent.get_object());
                    if (@minion_logic is null || minion_logic.getTeam() == Team::Friendly || minion_logic.state == M_STATE_DEATH) continue;

                    float dist_sq = dist_sqr(world_pos.x, world_pos.y, minion_logic.x(), minion_logic.y());
                    if (dist_sq < best_dist_sq)
                    {
                        best_dist_sq = dist_sq;
                        @best_target = minion_ent;
                    }
                }
            }

            // Step 3: Action based on whether a target was found
            if (@best_target !is null)
            {
                IDrawableCharacter@ char_logic = cast<IDrawableCharacter@>(best_target.get_object());
                attack_indicators.insertLast(AttackIndicator(best_target));
                @aggression_target = best_target;
                has_target = true;
                target_pos.set(char_logic.x(), char_logic.y());
            }
            else // No target found, treat as a normal move command
            {
                @aggression_target = null;
                target_pos.set(world_pos.x, world_pos.y);
                has_target = true;
                if (state == P_STATE_AUTO_ATTACK)
                {
                    state = P_STATE_RUN;
                    state_timer = 0;
                }
                click_indicators.insertLast(RightClickIndicator(world_pos, 0xCCFF2222));
            }
        }


        // --- Input Handling ---
        if (state == P_STATE_BLINK_STARTUP || state == P_STATE_BLINK_ARRIVAL || state == P_STATE_HEAVY_ATTACK)
        {
            if (right_click_press)
            {
                Vec3 world_pos;
                {
                    
                    Vec3 cam_pos, cam_forward, cam_right, cam_up;
                    get_camera_transform(_camera_pos.x, _camera_pos.y, cam_pos, cam_forward, cam_right, cam_up);
                    float ndc_x = mouse_hud_x / 800.0;
                    float ndc_y = -mouse_hud_y / 450.0;
                    float aspect_ratio = 1920.0 / 1080.0;
                    float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
                    float view_x = ndc_x * aspect_ratio / fov_adjust;
                    float view_y = ndc_y / fov_adjust;
                    Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
                    Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
                    ray_dir_world = ray_dir_world.normalize();
                    if(abs(ray_dir_world.z) >= 1e-6)
                    {
                        float t = -cam_pos.z / ray_dir_world.z;
                        world_pos = cam_pos + ray_dir_world * t;
                        string mode = is_replay() ? "[REPLAY]" : "[LIVE]";
                        float w = g.hud_screen_width(false);
                        float h = g.hud_screen_height(false);
                    }

                }
                // Quantize the final world coordinates
                if(main_script.click_precision > 0)
                {
                    world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                    world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
                }
                buffered_target_pos.set(world_pos.x, world_pos.y);
                has_buffered_move = true;
            }
        }

        else if(right_click_press)
        {
            Vec3 world_pos;
            {
                Vec3 cam_pos, cam_forward, cam_right, cam_up;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_pos, cam_forward, cam_right, cam_up);
                float ndc_x = mouse_hud_x / 800.0;
                float ndc_y = -mouse_hud_y / 450.0;
                float aspect_ratio = 1920.0 / 1080.0;
                float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
                float view_x = ndc_x * aspect_ratio / fov_adjust;
                float view_y = ndc_y / fov_adjust;
                Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
                Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
                ray_dir_world = ray_dir_world.normalize();
                if(abs(ray_dir_world.z) >= 1e-6)
                {
                    float t = -cam_pos.z / ray_dir_world.z;
                    world_pos = cam_pos + ray_dir_world * t;
                }
                if(main_script.click_precision > 0)
                {
                    world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                    world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
                }

                string mode = is_replay() ? "[REPLAY]" : "[LIVE]";
                float w = g.hud_screen_width(false);
                float h = g.hud_screen_height(false);
            }

            
            scriptenemy@ clicked_character = null;
            // Check for minions first
            for (uint i = 0; i < minions.length(); i++)
            {
                scriptenemy@ minion_ent = minions[i];
                Minion@ minion_logic = cast<Minion@>(minion_ent.get_object());
                if (@minion_logic is null || minion_logic.getTeam() == Team::Friendly) continue;

                // Rectangular hitbox check in screen space
                float screen_x, screen_y;
                project_to_screen(Vec3(minion_logic.x(), minion_logic.y(), 0), _camera_pos.x, _camera_pos.y, screen_x, screen_y);
                float hw = minion_logic.right_click_hitbox_width * 0.5f;
                float hh = minion_logic.right_click_hitbox_height;
                bool rect_hit = (mouse_hud_x >= screen_x - hw && mouse_hud_x <= screen_x + hw &&
                                    mouse_hud_y >= screen_y - hh && mouse_hud_y <= screen_y);
                
                // Circular hitbox check in world space
                float dist_sq = dist_sqr(world_pos.x, world_pos.y, minion_logic.x(), minion_logic.y());
                bool circle_hit = dist_sq < (minion_logic.hitbox_radius() * minion_logic.hitbox_radius());

                if (rect_hit || circle_hit)
                {
                    @clicked_character = minion_ent;
                    break;
                }
            }
            // If no minion was clicked, check for champions
            if (@clicked_character is null)
            {
                    for (uint i = 0; i < champions.length(); i++)
                {
                    scriptenemy@ champ_ent = champions[i];
                    Champion@ champ_logic = cast<Champion@>(champ_ent.get_object());
                    if (@champ_logic is null || champ_logic.getTeam() == Team::Friendly) continue;

                    // Rectangular hitbox check in screen space
                    float screen_x, screen_y;
                    project_to_screen(Vec3(champ_logic.x(), champ_logic.y(), 0), _camera_pos.x, _camera_pos.y, screen_x, screen_y);
                    float hw = champ_logic.right_click_hitbox_width * 0.5f;
                    float hh = champ_logic.right_click_hitbox_height;
                    bool rect_hit = (mouse_hud_x >= screen_x - hw && mouse_hud_x <= screen_x + hw &&
                                        mouse_hud_y >= screen_y - hh && mouse_hud_y <= screen_y);

                    // Circular hitbox check in world space
                    float dist_sq = dist_sqr(world_pos.x, world_pos.y, champ_logic.x(), champ_logic.y());
                    bool circle_hit = dist_sq < (champ_logic.hitbox_radius() * champ_logic.hitbox_radius());

                    if (rect_hit || circle_hit)
                    {
                        @clicked_character = champ_ent;
                        break;
                    }
                }
            }

            if (@clicked_character !is null)
            {
                IDrawableCharacter@ char_logic = cast<IDrawableCharacter@>(clicked_character.get_object());
                if (@char_logic !is null && char_logic.getTeam() != Team::Friendly)
                {
                    // Check if it's a minion and dying
                    Minion@ minion_logic = cast<Minion@>(char_logic);
                    if(@minion_logic !is null && minion_logic.state == M_STATE_DEATH)
                    {
                        // Don't target dying minions
                    }
                    else
                    {
                        // UPDATED: Create attack indicator
                        attack_indicators.insertLast(AttackIndicator(clicked_character));

                        if(@clicked_character is aggression_target && state == P_STATE_AUTO_ATTACK) {}
                        else
                        {
                            @aggression_target = clicked_character;
                            has_target = true;
                            target_pos.set(char_logic.x(), char_logic.y());
                        }
                    }
                }
                else // Friendly or dying minion clicked, treat as move command
                {
                    @aggression_target = null;
                    target_pos.set(world_pos.x, world_pos.y);
                    has_target = true;
                    if (state == P_STATE_AUTO_ATTACK)
                    {
                        state = P_STATE_RUN;
                        state_timer = 0;
                    }
                }
            }
            else
            {
                @aggression_target = null;
                target_pos.set(world_pos.x, world_pos.y);
                has_target = true;
                if (state == P_STATE_AUTO_ATTACK)
                {
                    state = P_STATE_RUN;
                    state_timer = 0;
                }
                // Add the right-click move indicator
                click_indicators.insertLast(RightClickIndicator(world_pos));
            }
        }

        // --- Ability Activation ---

        // Blink Ability Trigger
        if(self.dash_intent() == 1 && state != P_STATE_BLINK_STARTUP && state != P_STATE_BLINK_ARRIVAL && blink_cooldown_timer <= 0)
        {
            self.dash_intent(2);
            blink_cooldown_timer = blink_cooldown;
            state = P_STATE_BLINK_STARTUP;
            state_timer = 0;
            pre_blink_has_target = has_target;
            if (has_target) { pre_blink_target_pos.set(target_pos.x, target_pos.y); }
            has_target = false;
            Vec3 world_pos;
            {
                Vec3 cam_pos, cam_forward, cam_right, cam_up;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_pos, cam_forward, cam_right, cam_up);
                float ndc_x = mouse_hud_x / 800.0;
                float ndc_y = -mouse_hud_y / 450.0;
                float aspect_ratio = 1920.0 / 1080.0;
                float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
                float view_x = ndc_x * aspect_ratio / fov_adjust;
                float view_y = ndc_y / fov_adjust;
                Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
                Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
                ray_dir_world = ray_dir_world.normalize();
                if(abs(ray_dir_world.z) >= 1e-6)
                {
                    float t = -cam_pos.z / ray_dir_world.z;
                    world_pos = cam_pos + ray_dir_world * t;
                }
                if(main_script.click_precision > 0)
                {
                    world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                    world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
                }
            }
            blink_target_pos.set(world_pos.x, world_pos.y);
        }
        
        // Light Attack Trigger
        if(self.light_intent() > 0 && !light_attack_active && current_mana >= light_attack_mana_cost && light_attack_cooldown_timer <= 0)
        {
            current_mana -= light_attack_mana_cost;
            light_attack_cooldown_timer = light_attack_cooldown;

            light_attack_active = true;
            light_attack_timer = 0;
            
            Vec3 world_pos;
            {
                Vec3 cam_pos, cam_forward, cam_right, cam_up;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_pos, cam_forward, cam_right, cam_up);
                float ndc_x = mouse_hud_x / 800.0;
                float ndc_y = -mouse_hud_y / 450.0;
                float aspect_ratio = 1920.0 / 1080.0;
                float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
                float view_x = ndc_x * aspect_ratio / fov_adjust;
                float view_y = ndc_y / fov_adjust;
                Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
                Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
                ray_dir_world = ray_dir_world.normalize();
                if(abs(ray_dir_world.z) >= 1e-6)
                {
                    float t = -cam_pos.z / ray_dir_world.z;
                    world_pos = cam_pos + ray_dir_world * t;
                }
                if(main_script.click_precision > 0)
                {
                    world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                    world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
                }
            }

            light_attack_target_pos.set(world_pos.x, world_pos.y);
            
            if (state != P_STATE_BLINK_STARTUP && state != P_STATE_BLINK_ARRIVAL)
            {
                pre_attack_state = state;
                pre_attack_face = face;
                pre_attack_has_target = has_target;
                if(has_target) { pre_attack_target_pos.set(target_pos.x, target_pos.y); }
                state = P_STATE_LIGHT_ATTACK; 
                state_timer = 0;
                has_target = false;
                
                float dx_mouse = world_pos.x - pos.x;
                float dy_mouse = world_pos.y - pos.y;
                Vec3 cam_p, cam_f, cam_r, cam_u;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_p, cam_f, cam_r, cam_u);
                Vec3 move_vec_world(dx_mouse, dy_mouse, 0);
                float right_dot = dot(move_vec_world, cam_r);
                face = right_dot > 0 ? 1 : -1;
            }
            
            self.light_intent(11);
        }
        
        // Heavy Attack Trigger
        if(self.heavy_intent() > 0 && !heavy_attack_active && current_mana >= heavy_attack_mana_cost && heavy_attack_cooldown_timer <= 0)
        {
            current_mana -= heavy_attack_mana_cost;
            heavy_attack_cooldown_timer = heavy_attack_cooldown;

            heavy_attack_active = true;
            heavy_attack_timer = 0;
            
            Vec3 world_pos;
            {
                Vec3 cam_pos, cam_forward, cam_right, cam_up;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_pos, cam_forward, cam_right, cam_up);
                float ndc_x = mouse_hud_x / 800.0;
                float ndc_y = -mouse_hud_y / 450.0;
                float aspect_ratio = 1920.0 / 1080.0;
                float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
                float view_x = ndc_x * aspect_ratio / fov_adjust;
                float view_y = ndc_y / fov_adjust;
                Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
                Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
                ray_dir_world = ray_dir_world.normalize();
                if(abs(ray_dir_world.z) >= 1e-6)
                {
                    float t = -cam_pos.z / ray_dir_world.z;
                    world_pos = cam_pos + ray_dir_world * t;
                }
                if(main_script.click_precision > 0)
                {
                    world_pos.x = round(world_pos.x * main_script.click_precision) / main_script.click_precision;
                    world_pos.y = round(world_pos.y * main_script.click_precision) / main_script.click_precision;
                }
            }
            heavy_attack_target_pos.set(world_pos.x, world_pos.y);
            
            if (state != P_STATE_BLINK_STARTUP && state != P_STATE_BLINK_ARRIVAL)
            {
                pre_attack_state = state;
                pre_attack_face = face;
                pre_attack_has_target = has_target;
                if(has_target) { pre_attack_target_pos.set(target_pos.x, target_pos.y); }
                state = P_STATE_HEAVY_ATTACK; 
                state_timer = 0;
                has_target = false;
                
                float dx_mouse = world_pos.x - pos.x;
                float dy_mouse = world_pos.y - pos.y;
                Vec3 cam_p, cam_f, cam_r, cam_u;
                get_camera_transform(_camera_pos.x, _camera_pos.y, cam_p, cam_f, cam_r, cam_u);
                Vec3 move_vec_world(dx_mouse, dy_mouse, 0);
                float right_dot = dot(move_vec_world, cam_r);
                face = right_dot > 0 ? 1 : -1;
            }
            
            self.heavy_intent(11);
        }

        // --- Parallel Logic ---

        // Light Attack Projectile Firing (runs independently of main state)
        if (light_attack_active)
        {
            light_attack_timer += DT * 12;
            if (light_attack_timer >= 3 && light_attack_timer < 3.2)
            {
                Vec2 dir = light_attack_target_pos - pos;
                dir.normalise();
                float attack_speed = 0.15;
                attack_particles.insertLast(AttackParticle(Vec3(pos.x, pos.y, light_attack_height), Vec3(dir.x * attack_speed, dir.y * attack_speed, 0), self));
            }
            if (light_attack_timer >= 7) // Full duration of the attack action
            {
                light_attack_active = false;
                if (state == P_STATE_LIGHT_ATTACK)
                {
                    state = pre_attack_state;
                    face = pre_attack_face;
                    state_timer = 0;
                    if(!has_target)
                    {
                        has_target = pre_attack_has_target;
                        if(has_target) { target_pos.set(pre_attack_target_pos.x, pre_attack_target_pos.y); }
                    }
                }
            }
        }
        
        // Heavy Attack Projectile Firing
        if (heavy_attack_active)
        {
            heavy_attack_timer += DT * 12;
            float total_windup_time = (0.05 + 0.1 + 0.05 + 0.3) * 60 * DT * 12;
            if (heavy_attack_timer >= total_windup_time && heavy_attack_timer < total_windup_time + (DT * 12))
            {
                Vec2 dir = heavy_attack_target_pos - pos;
                dir.normalise();
                float attack_speed = 0.15;
                heavy_attack_particles.insertLast(HeavyAttackParticle(Vec3(pos.x, pos.y, light_attack_height), Vec3(dir.x * attack_speed, dir.y * attack_speed, 0), self));
            }
            float total_attack_time = total_windup_time + (0.1 * 60 * DT * 12);
            if (heavy_attack_timer >= total_attack_time)
            {
                heavy_attack_active = false;
                if (state == P_STATE_HEAVY_ATTACK)
                {
                    state = pre_attack_state;
                    face = pre_attack_face;
                    state_timer = 0;
                    if(!has_target)
                    {
                        has_target = pre_attack_has_target;
                        if(has_target) { target_pos.set(pre_attack_target_pos.x, pre_attack_target_pos.y); }
                    }
                }
            }
        }

        // --- Main State Machine ---

        // Aggression Logic (only when not performing a blocking action)
        if (state != P_STATE_LIGHT_ATTACK && state != P_STATE_AUTO_ATTACK && state != P_STATE_BLINK_STARTUP && state != P_STATE_BLINK_ARRIVAL && state != P_STATE_HEAVY_ATTACK)
        {
            if (@aggression_target !is null)
            {
                IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                if (@target_char is null || aggression_target.destroyed())
                {
                    @aggression_target = null;
                    has_target = false;
                    state = P_STATE_IDLE;
                }
                else
                {
                    target_pos.set(target_char.x(), target_char.y());
                    float dist_to_target = distance(pos.x, pos.y, target_char.x(), target_char.y());

                    if (dist_to_target <= attack_range)
                    {
                        has_target = false;
                        state = P_STATE_AUTO_ATTACK;
                        state_timer = 0;
                        
                        float dx_target = target_char.x() - pos.x;
                        float dy_target = target_char.y() - pos.y;
                        Vec3 cam_p, cam_f, cam_r, cam_u;
                        get_camera_transform(_camera_pos.x, _camera_pos.y, cam_p, cam_f, cam_r, cam_u);
                        Vec3 move_vec_world(dx_target, dy_target, 0);
                        float right_dot = dot(move_vec_world, cam_r);
                        face = right_dot > 0 ? 1 : -1;
                    }
                    else
                    {
                        has_target = true;
                    }
                }
            }
        }

        // State-based movement and transitions
        switch(state)
        {
            case P_STATE_BLINK_STARTUP:
                state_timer += DT * 12;
                if (state_timer >= BLINK_ANIMATION_DURATION_TIMER)
                {
                    Vec2 start_pos = pos;
                    Vec2 direction_vec(blink_target_pos.x - pos.x, blink_target_pos.y - pos.y);
                    
                    Vec3 cam_p, cam_f, cam_r, cam_u;
                    get_camera_transform(_camera_pos.x, _camera_pos.y, cam_p, cam_f, cam_r, cam_u);
                    Vec3 move_vec_world(direction_vec.x, direction_vec.y, 0);
                    float right_dot = dot(move_vec_world, cam_r);
                    if(abs(direction_vec.x) > 0.1 || abs(direction_vec.y) > 0.1)
                    {
                            face = right_dot > 0 ? 1 : -1;
                    }
                    
                    float distance = direction_vec.magnitude();
                    Vec2 final_pos;

                    if (distance > BLINK_MAX_RANGE)
                    {
                        direction_vec.normalise();
                        final_pos = pos + direction_vec * BLINK_MAX_RANGE;
                    }
                    else
                    {
                        final_pos = blink_target_pos;
                    }
                    
                    // --- Create three after-images along the blink path ---
                    const float delay_step = 1; // 0.015s is ~1 frame

                    // After-image 1 (at 25% of the path), spawns instantly
                    Vec2 pos1 = start_pos + (final_pos - start_pos) * 0.25f;
                    after_images.insertLast(BlinkAfterImage(pos1, face, player_sprite, 0));
                    
                    // After-image 2 (at 50% of the path), spawns after a delay
                    Vec2 pos2 = start_pos + (final_pos - start_pos) * 0.5f;
                    after_images.insertLast(BlinkAfterImage(pos2, face, player_sprite, delay_step));

                    // After-image 3 (at 75% of the path), spawns after a further delay
                    Vec2 pos3 = start_pos + (final_pos - start_pos) * 0.75f;
                    after_images.insertLast(BlinkAfterImage(pos3, face, player_sprite, delay_step * 2));
                    
                    // Update player position
                    pos = final_pos;
                    
                    pos.x = clamp(pos.x, -world_bounds_x, world_bounds_y);
                    pos.y = clamp(pos.y, -world_bounds_y, world_bounds_y);
                    
                    state = P_STATE_BLINK_ARRIVAL;
                    state_timer = 0;

                    if (has_buffered_move)
                    {
                        target_pos.set(buffered_target_pos.x, buffered_target_pos.y);
                        has_target = true;
                        has_buffered_move = false;
                        @aggression_target = null;
                    }
                    else if (pre_blink_has_target)
                    {
                        target_pos.set(pre_blink_target_pos.x, pre_blink_target_pos.y);
                        has_target = true;
                    }
                }
                break;
            
            case P_STATE_BLINK_ARRIVAL:
                state_timer += DT * 12;
                move_player(); 
                
                if (state_timer >= BLINK_ANIMATION_DURATION_TIMER)
                {
                    state = has_target ? P_STATE_RUN : P_STATE_IDLE;
                    state_timer = 0;
                }
                break;
                
            case P_STATE_LIGHT_ATTACK:
            case P_STATE_HEAVY_ATTACK:
                state_timer += DT * 12;
                if(state_timer >= 5.0) { 
                    if(has_buffered_move)
                    {
                        target_pos.set(buffered_target_pos.x, buffered_target_pos.y);
                        has_target = true;
                        has_buffered_move = false;
                        @aggression_target = null;
                        state = P_STATE_RUN;
                        state_timer = 0;
                    }
                    move_player(); 
                }
                break;
                
            case P_STATE_AUTO_ATTACK:
                if (@aggression_target is null || aggression_target.destroyed())
                {
                    state = P_STATE_IDLE;
                    state_timer = 0;
                    @aggression_target = null;
                    break;
                }
                
                if (@aggression_target !is null && !aggression_target.destroyed())
                {
                    IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                    if (@target_char !is null)
                    {
                        float dist_to_target = distance(pos.x, pos.y, target_char.x(), target_char.y());
                        if (dist_to_target > attack_range)
                        {
                            state = P_STATE_RUN;
                            state_timer = 0;
                            has_target = true;
                            target_pos.set(target_char.x(), target_char.y());
                            break; 
                        }
                    }
                }

                if(state_timer >= 3 && state_timer < 3.2)
                {
                    if(@aggression_target !is null && !aggression_target.destroyed())
                    {
                        auto_attack_particles.insertLast(AutoAttackParticle(Vec3(pos.x, pos.y, auto_attack_height), aggression_target, self, auto_attack_colour, auto_attack_speed, auto_attack_damage, auto_attack_impact_colour1, auto_attack_impact_colour2, 0.1f));
                    }
                }
                if(state_timer >= 7)
                {
                    state_timer = 0;
                }
                state_timer += DT * 12;
                break;
                
            default:
                move_player();
                if(!has_target && state != P_STATE_IDLE) { state = P_STATE_IDLE; state_timer = 0; }
                state_timer += DT * 12;
                break;
        }
        
        for(int i = int(attack_particles.length()) - 1; i >= 0; i--)
        {
            AttackParticle@ particle = attack_particles[i];
            particle.step(fx_list, rrnd);
            
            float angle_rad = atan2(particle.vel.y, particle.vel.x) + PI / 2.0;
            float c = cos(-angle_rad);
            float s = sin(-angle_rad);
            float particle_hw = particle.width * 0.5;
            float particle_hh = particle.length * 0.5;

            array<scriptenemy@> potential_targets;
            for(uint j=0; j < minions.length(); j++) potential_targets.insertLast(minions[j]);
            for(uint j=0; j < champions.length(); j++) potential_targets.insertLast(champions[j]);

            bool hit = false;
            for (uint j = 0; j < potential_targets.length(); j++)
            {
                scriptenemy@ target_ent = potential_targets[j];
                if (@target_ent is null || target_ent.destroyed()) continue;

                IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(target_ent.get_object());
                if (@target_char is null || target_char.getTeam() == Team::Friendly) continue;
                
                Minion@ minion_target = cast<Minion@>(target_char);
                if(@minion_target !is null && minion_target.state == M_STATE_DEATH) continue;

                float tmx = target_char.x() - particle.pos.x;
                float tmy = target_char.y() - particle.pos.y;
                float rmx = tmx * c - tmy * s;
                float rmy = tmx * s + tmy * c;

                float closest_x = clamp(rmx, -particle_hw, particle_hw);
                float closest_y = clamp(rmy, -particle_hh, particle_hh);

                float dist_x = rmx - closest_x;
                float dist_y = rmy - closest_y;
                float dist_sq = (dist_x * dist_x) + (dist_y * dist_y);

                if (dist_sq < (target_char.hitbox_radius() * target_char.hitbox_radius()))
                {
                    IDamageable@ damageable_target = cast<IDamageable@>(target_char);
                    if (@damageable_target !is null)
                    {
                        damageable_target.take_damage(25, particle.pos, particle.dealer);
                    }
                    
                    hit = true;
                    break;
                }
            }

            if(hit || particle.life <= 0) {
                if(hit) {
                    const float cooldown_reduction = 2.0f * 60.0f;
                    if(light_attack_cooldown_timer > 0)
                    {
                        light_attack_cooldown_timer = max(0.0f, light_attack_cooldown_timer - cooldown_reduction);
                    }
                    if(heavy_attack_cooldown_timer > 0)
                    {
                        heavy_attack_cooldown_timer = max(0.0f, heavy_attack_cooldown_timer - cooldown_reduction);
                    }
                    if(blink_cooldown_timer > 0)
                    {
                        blink_cooldown_timer = max(0.0f, blink_cooldown_timer - cooldown_reduction);
                    }
                    
                    current_mana = min(max_mana, current_mana + light_attack_mana_cost / 2.0f);
                    
                    Vec3 attack_dir = particle.vel.normalize();
                    Vec3 front_dir(-attack_dir.y, attack_dir.x, 0); 
                    for(int k = 0; k < 15; k++)
                    {
                        float offset_dist = (rrnd.frand() - 0.5) * particle.width;
                        Vec3 spawn_pos = particle.pos + front_dir * offset_dist;
                        spawn_pos.z = particle.pos.z;
                        float base_speed = rrnd.frand() * 0.03 + 0.015;
                        Vec3 particle_vel = attack_dir * base_speed;
                        particle_vel = particle_vel + front_dir * (rrnd.frand() - 0.5) * 0.01;
                        particle_vel.z += rrnd.frand() * 0.01;
                        uint particle_colour = rrnd.frand() < 0.8 ? 0xFFFFC852 : 0xFFFFB070;
                        float particle_size = rrnd.frand() * 0.06 + 0.05;
                        fx_list.insertLast(ParticleFX(spawn_pos, particle_vel, particle_size, particle_colour, 20));
                    }
                }
                attack_particles.removeAt(i);
            }
        }
        
        for(int i = int(heavy_attack_particles.length()) - 1; i >= 0; i--)
        {
            HeavyAttackParticle@ particle = heavy_attack_particles[i];
            particle.step(fx_list, rrnd);
            
            float angle_rad = atan2(particle.vel.y, particle.vel.x) + PI / 2.0;
            float c = cos(-angle_rad);
            float s = sin(-angle_rad);
            float particle_hw = particle.width * 0.5;
            float particle_hh = particle.length * 0.5;

            array<scriptenemy@> potential_targets;
            for(uint j=0; j < minions.length(); j++) potential_targets.insertLast(minions[j]);
            for(uint j=0; j < champions.length(); j++) potential_targets.insertLast(champions[j]);

            for (uint j = 0; j < potential_targets.length(); j++)
            {
                scriptenemy@ target_ent = potential_targets[j];
                if (@target_ent is null || target_ent.destroyed() || particle.has_hit(target_ent.id())) continue;

                IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(target_ent.get_object());
                if (@target_char is null || target_char.getTeam() == Team::Friendly) continue;
                
                Minion@ minion_target = cast<Minion@>(target_char);
                if(@minion_target !is null && minion_target.state == M_STATE_DEATH) continue;

                float tmx = target_char.x() - particle.pos.x;
                float tmy = target_char.y() - particle.pos.y;
                float rmx = tmx * c - tmy * s;
                float rmy = tmx * s + tmy * c;

                float closest_x = clamp(rmx, -particle_hw, particle_hw);
                float closest_y = clamp(rmy, -particle_hh, particle_hh);

                float dist_x = rmx - closest_x;
                float dist_y = rmy - closest_y;
                float dist_sq = (dist_x * dist_x) + (dist_y * dist_y);

                if (dist_sq < (target_char.hitbox_radius() * target_char.hitbox_radius()))
                {
                    IDamageable@ damageable_target = cast<IDamageable@>(target_char);
                    if (@damageable_target !is null)
                    {
                        damageable_target.take_damage(35, particle.pos, particle.dealer);
                        particle.add_hit(target_ent.id());
                    }
                }
            }

            if(heavy_attack_particles[i].life <= 0) { heavy_attack_particles.removeAt(i); }
        }
        
        for(int i = int(auto_attack_particles.length()) - 1; i >= 0; i--)
        {
            if(auto_attack_particles[i].step(fx_list, rrnd))
            {
                auto_attack_particles.removeAt(i);
            }
        }

        for(int i = int(after_images.length()) - 1; i >= 0; i--)
        {
            if(after_images[i].step())
            {
                after_images.removeAt(i);
            }
        }
        for(int i = int(click_indicators.length()) - 1; i >= 0; i--)
        {
            if(click_indicators[i].step())
            {
                click_indicators.removeAt(i);
            }
        }
        for(int i = int(attack_indicators.length()) - 1; i >= 0; i--)
        {
            if(attack_indicators[i].step())
            {
                attack_indicators.removeAt(i);
            }
        }
        self.x(pos.x);
        self.y(pos.y);
        last_mouse_state = current_mouse_state;
    }
    


    void draw(float sub_frame, IMobaCamera@ camera_provider, int sub_layer)
    {
        float interp_player_x = lerp(prev_pos.x, pos.x, sub_frame);
        float interp_player_y = lerp(prev_pos.y, pos.y, sub_frame);
        float interp_camera_x = lerp(_prev_camera_pos.x, _camera_pos.x, sub_frame);
        float interp_camera_y = lerp(_prev_camera_pos.y, _camera_pos.y, sub_frame);
        clamp_camera(interp_camera_x, interp_camera_y, interp_camera_x, interp_camera_y);
        draw_ground(interp_camera_x, interp_camera_y);
        float screen_x, screen_y;
        project_to_screen(Vec3(interp_player_x, interp_player_y, z), interp_camera_x, interp_camera_y, screen_x, screen_y);
        
        string sprite_name;
        uint frame;

        if (state == P_STATE_DEATH)
        {
            sprite_name = death_animation_name;
            frame = state_timer < 30 ? 0 : 1;
        }
        else if (state == P_STATE_BLINK_STARTUP)
        {
            sprite_name = "crouch";
            frame = uint(floor(state_timer / (BLINK_ANIMATION_DURATION_TIMER / 3.0)));
        }
        else if (state == P_STATE_BLINK_ARRIVAL)
        {
            sprite_name = "dash";
            frame = uint(floor(state_timer / (BLINK_ANIMATION_DURATION_TIMER / 5.0)));
        }
        else if (state == P_STATE_HEAVY_ATTACK)
        {
            float t = state_timer;
            float crouch_duration = 0.05 * 60 * DT * 12;
            float rising1_duration = 0.1 * 60 * DT * 12;
            float rising2_duration = 0.05 * 60 * DT * 12;
            float airsmash1_duration = 0.3 * 60 * DT * 12;

            if (t < crouch_duration) {
                sprite_name = "crouch";
                frame = uint(floor(t / (crouch_duration / 3.0)));
            } else if (t < crouch_duration + rising1_duration) {
                sprite_name = "rising";
                frame = uint(floor((t - crouch_duration) / (rising1_duration / 3.0)));
            } else if (t < crouch_duration + rising1_duration + rising2_duration) {
                sprite_name = "rising";
                frame = uint(floor((t - crouch_duration - rising1_duration) / (rising2_duration / 3.0)));
            } else if (t < crouch_duration + rising1_duration + rising2_duration + airsmash1_duration) {
                sprite_name = "airsmash";
                frame = uint(floor((t - crouch_duration - rising1_duration - rising2_duration) / (airsmash1_duration / 5.0)));
            } else {
                sprite_name = "airsmash";
                frame = 5 + uint(floor((t - crouch_duration - rising1_duration - rising2_duration - airsmash1_duration) / (0.1 * 60 * DT * 12 / 8.0)));
            }
        }
        else
        {
            switch(state)
            {
                case P_STATE_RUN: sprite_name = "sprint"; break;
                case P_STATE_SKID: sprite_name = "skidturn"; break;
                case P_STATE_LIGHT_ATTACK: sprite_name = "groundstrike1"; break;
                case P_STATE_AUTO_ATTACK: sprite_name = "groundstrike2"; break;
                default: sprite_name = "idle";
            }
            frame = uint(state_timer);
        }

        const int length = player_sprite.get_animation_length(sprite_name);
        if(length > 0) frame = frame % length;

        player_sprite.draw_hud(20, sub_layer, sprite_name, frame, 1, screen_x, screen_y, 0, float(face) * 0.8, 0.8, 0xFFFFFFFF);
        
        // Draw the ability bar UI
        if (@ability_bar !is null)
        {
            ability_bar.draw(this);
        }
        
        if (state == P_STATE_DEATH) return; // Don't draw UI when dead
        
        // --- Calculate Bar Assembly Coordinates ---
        const float total_width = level_icon_size + health_bar_width;
        const float start_x = screen_x - total_width / 2;

        const float health_y = screen_y + health_bar_y_offset;
        const float mana_y = health_y + health_bar_height + health_bar_outline;
        const float bars_total_height = health_bar_height + mana_bar_height + health_bar_outline;
        const float level_icon_y = health_y + (bars_total_height / 2) - (level_icon_size / 2);

        const float level_icon_x = start_x;
        const float bars_x = start_x + level_icon_size;

        // --- Draw Level Icon ---
        g.draw_rectangle_hud(21, 23, 
            level_icon_x - health_bar_outline, level_icon_y - health_bar_outline, 
            level_icon_x + level_icon_size + health_bar_outline, level_icon_y + level_icon_size + health_bar_outline, 
            0, 0xFF000000);
        g.draw_rectangle_hud(21, 24, 
            level_icon_x, level_icon_y, 
            level_icon_x + level_icon_size, level_icon_y + level_icon_size, 
            0, level_icon_bg_colour);
        level_text.text('' + player_level);
        level_text.colour(0xFFFFFFFF);
        level_text.draw_hud(21, 25, level_icon_x + level_icon_size / 2 - 1, level_icon_y + level_icon_size / 2 - 2, 1, 1, 0);

        // --- Draw Health Bar ---
        // Outline
        g.draw_rectangle_hud(21, 23, 
            bars_x - health_bar_outline, health_y - health_bar_outline, 
            bars_x + health_bar_width + health_bar_outline, health_y + health_bar_height + health_bar_outline, 
            0, 0xFF000000);
        // Red "pending damage" bar (single colour)
        const float pending_health_percentage = pending_damage_health / max_health;
        g.draw_rectangle_hud(21, 24, 
            bars_x, health_y, 
            bars_x + health_bar_width * pending_health_percentage, health_y + health_bar_height, 
            0, 0xFFfc2d2d); // Red color
            
        // Green "current health" bar (drawn on top of the red bar)
        const float health_percentage = current_health / max_health;
        const float current_bar_width = health_bar_width * health_percentage;
        const float health_highlight_height = health_bar_height * 0.25f;
        // Main part (bottom 3/4)
        g.draw_rectangle_hud(21, 25, 
            bars_x, health_y + health_highlight_height, 
            bars_x + current_bar_width, health_y + health_bar_height, 
            0, 0xFF04db04); // Darker Green
        // Highlight part (top 1/4)
        g.draw_rectangle_hud(21, 25, 
            bars_x, health_y, 
            bars_x + current_bar_width, health_y + health_highlight_height, 
            0, 0xFF00f208); // Lighter Green
        // Ticks
        if (health_tick_interval > 0)
        {
            const float tick_width = health_bar_outline;
            const float tick_height = health_bar_height * 0.75f;
            for (float i = health_tick_interval; i < max_health; i += health_tick_interval)
            {
                const float tick_x = bars_x + (i / max_health) * health_bar_width;
                g.draw_rectangle_hud(21, 26, tick_x - tick_width / 2, health_y, tick_x + tick_width / 2, health_y + tick_height, 0, 0xFF000000);
            }
        }

        // --- Draw Mana Bar ---
        // Outline
        g.draw_rectangle_hud(21, 23, 
            bars_x - health_bar_outline, mana_y - health_bar_outline, 
            bars_x + health_bar_width + health_bar_outline, mana_y + mana_bar_height + health_bar_outline, 
            0, 0xFF000000);
        // Light Blue "pending cost" bar (single colour)
        const float pending_mana_percentage = pending_mana_cost / max_mana;
        g.draw_rectangle_hud(21, 24, 
            bars_x, mana_y, 
            bars_x + health_bar_width * pending_mana_percentage, mana_y + mana_bar_height, 
            0, 0xFF8FD7FF); // Light Blue

        // Blue "current mana" bar
        const float mana_percentage = current_mana / max_mana;
        const float current_mana_width = health_bar_width * mana_percentage;
        const float mana_highlight_height = mana_bar_height * 0.5f;
        // Main part (bottom 1/2)
        g.draw_rectangle_hud(21, 25, 
            bars_x, mana_y + mana_highlight_height, 
            bars_x + current_mana_width, mana_y + mana_bar_height, 
            0, 0xFF228BFC);
        // Highlight part (top 1/2)
        g.draw_rectangle_hud(21, 25, 
            bars_x, mana_y, 
            bars_x + current_mana_width, mana_y + mana_highlight_height, 
            0, 0xFF3595fc); // Lighter Blue


        for(uint i = 0; i < attack_particles.length(); i++) { attack_particles[i].draw(g, sub_frame, this); }
        for(uint i = 0; i < heavy_attack_particles.length(); i++) { heavy_attack_particles[i].draw(g, sub_frame, this); }
        for(uint i = 0; i < auto_attack_particles.length(); i++) { auto_attack_particles[i].draw(g, sub_frame, this); }
        for(uint i = 0; i < after_images.length(); i++) { after_images[i].draw(sub_frame, this, sub_layer - 1); }
        for(uint i = 0; i < click_indicators.length(); i++) { click_indicators[i].draw(sub_frame, this); }
        for(uint i = 0; i < attack_indicators.length(); i++) { attack_indicators[i].draw(sub_frame, this); }
    }
    
    void clamp_camera(float camera_x, float camera_y, float &out clamped_x, float &out clamped_y)
        {
            Vec3 top_left, top_right, bot_left, bot_right;
            
            _unproject_manual_helper(-800, -450, camera_x, camera_y, top_left);
            _unproject_manual_helper( 800, -450, camera_x, camera_y, top_right);
            _unproject_manual_helper(-800,  450, camera_x, camera_y, bot_left);
            _unproject_manual_helper( 800,  450, camera_x, camera_y, bot_right);

            float min_view_x = top_left.x;
            if (top_right.x < min_view_x) min_view_x = top_right.x;
            if (bot_left.x < min_view_x) min_view_x = bot_left.x;
            if (bot_right.x < min_view_x) min_view_x = bot_right.x;

            float max_view_x = top_left.x;
            if (top_right.x > max_view_x) max_view_x = top_right.x;
            if (bot_left.x > max_view_x) max_view_x = bot_left.x;
            if (bot_right.x > max_view_x) max_view_x = bot_right.x;

            float min_view_y = top_left.y;
            if (top_right.y < min_view_y) min_view_y = top_right.y;
            if (bot_left.y < min_view_y) min_view_y = bot_left.y;
            if (bot_right.y < min_view_y) min_view_y = bot_right.y;

            float max_view_y = top_left.y;
            if (top_right.y > max_view_y) max_view_y = top_right.y;
            if (bot_left.y > max_view_y) max_view_y = bot_left.y;
            if (bot_right.y > max_view_y) max_view_y = bot_right.y;

            float overshoot_x = 0;
            if (min_view_x < -world_bounds_x) overshoot_x = min_view_x + world_bounds_x;
            else if (max_view_x > world_bounds_x) overshoot_x = max_view_x - world_bounds_x;
            float overshoot_y = 0;
            if (min_view_y < -world_bounds_y) overshoot_y = min_view_y + world_bounds_y;
            else if (max_view_y > world_bounds_y) overshoot_y = max_view_y - world_bounds_y;
            clamped_x = camera_x - overshoot_x;
            clamped_y = camera_y - overshoot_y;
        }

    void draw_ground(float camera_x, float camera_y)
    {
        Vec3 top_left, top_right, bot_left, bot_right;
        unproject_from_screen(-800, -450, camera_x, camera_y, top_left);
        unproject_from_screen( 800, -450, camera_x, camera_y, top_right);
        unproject_from_screen(-800,  450, camera_x, camera_y, bot_left);
        unproject_from_screen( 800,  450, camera_x, camera_y, bot_right);

        float min_world_x = top_left.x;
        if (top_right.x < min_world_x) min_world_x = top_right.x;
        if (bot_left.x < min_world_x) min_world_x = bot_left.x;
        if (bot_right.x < min_world_x) min_world_x = bot_right.x;

        float max_world_x = top_left.x;
        if (top_right.x > max_world_x) max_world_x = top_right.x;
        if (bot_left.x > max_world_x) max_world_x = bot_left.x;
        if (bot_right.x > max_world_x) max_world_x = bot_right.x;

        float min_world_y = top_left.y;
        if (top_right.y < min_world_y) min_world_y = top_right.y;
        if (bot_left.y < min_world_y) min_world_y = bot_left.y;
        if (bot_right.y < min_world_y) min_world_y = bot_right.y;

        float max_world_y = top_left.y;
        if (top_right.y > max_world_y) max_world_y = top_right.y;
        if (bot_left.y > max_world_y) max_world_y = bot_left.y;
        if (bot_right.y > max_world_y) max_world_y = bot_right.y;

        int tile_start_x = floor_int(min_world_x / tile_size) - 1;
        int tile_end_x   = floor_int(max_world_x / tile_size) + 1;
        int tile_start_y = floor_int(min_world_y / tile_size) - 1;
        int tile_end_y   = floor_int(max_world_y / tile_size) + 1;
        ground_grid_width = tile_end_x - tile_start_x + 1;
        ground_grid_height = tile_end_y - tile_start_y + 1;
        if(ground_vertices.length() < uint(ground_grid_width * ground_grid_height))
            ground_vertices.resize(ground_grid_width * ground_grid_height);
        for (int j = 0; j < ground_grid_height; j++)
        {
            for (int i = 0; i < ground_grid_width; i++)
            {
                float world_x = (tile_start_x + i) * tile_size;
                float world_y = (tile_start_y + j) * tile_size;
                float screen_x, screen_y;
                project_to_screen(Vec3(world_x, world_y, 0), camera_x, camera_y, screen_x, screen_y);
                ground_vertices[j * ground_grid_width + i].set(screen_x, screen_y);
            }
        }

        // Define colours and lane properties for the new ground effect
        // const uint pale_blue_1 = 0xFF3f5763;
        // const uint pale_blue_2 = 0xFF293840;
        const uint pale_blue_1 = 0xFF323336;
        const uint pale_blue_2 = 0xFF1e1f21;
        const uint dark_blue_1 = 0xFF031030;
        const uint dark_blue_2 = 0xFF020a1f;
        const float lane_half_width = 2.5f;
        const float fade_distance = 3.0f;

        for (int j = 0; j < ground_grid_height - 1; j++)
        {
            for (int i = 0; i < ground_grid_width - 1; i++)
            {
                Vec2@ v1 = @ground_vertices[j * ground_grid_width + i];
                Vec2@ v2 = @ground_vertices[j * ground_grid_width + i + 1];
                Vec2@ v3 = @ground_vertices[(j + 1) * ground_grid_width + i + 1];
                Vec2@ v4 = @ground_vertices[(j + 1) * ground_grid_width + i];
                
                // --- New colour logic with easing ---
                float world_x = (tile_start_x + i) * tile_size + tile_size * 0.5;
                float world_y = (tile_start_y + j) * tile_size + tile_size * 0.5;

                // The lane is centered along y=x. Calculate the shortest distance to that line.
                const float dist_from_lane = abs(world_x - world_y) / sqrt(2.0f);
                
                float t = 0;
                if (dist_from_lane > lane_half_width)
                {
                    // Calculate interpolation factor, clamped between 0 and 1
                    t = clamp((dist_from_lane - lane_half_width) / fade_distance, 0.0f, 1.0f);
                }
                
                // Apply an easing function for a smoother visual falloff
                t = ease_out_quad(t);

                // Interpolate the two checkerboard colours using the new HSL-based lerp
                const uint checker_colour_1 = lerp_colour(pale_blue_1, dark_blue_1, t);
                const uint checker_colour_2 = lerp_colour(pale_blue_2, dark_blue_2, t);

                uint colour = (tile_start_x + i + tile_start_y + j) % 2 == 0 ? checker_colour_1 : checker_colour_2;

                g.draw_quad_hud(0, 0, false, v1.x, v1.y, v2.x, v2.y, v3.x, v3.y, v4.x, v4.y, colour, colour, colour, colour);
            }
        }
    }    
    void get_camera_transform(float cam_world_x, float cam_world_y, Vec3 &out cam_pos, Vec3 &out cam_forward, Vec3 &out cam_right, Vec3 &out cam_up)
    {
        Vec3 camera_ground_pos(cam_world_x, cam_world_y, 0);
        cam_pos = camera_ground_pos + camera_3d_offset;
        Vec3 cam_target = camera_ground_pos;
        cam_forward = (cam_target - cam_pos).normalize();
        cam_right = cross(cam_forward, Vec3(0, 0, 1)).normalize();
        cam_up = cross(cam_right, cam_forward);
    }

    void project_to_screen(Vec3 world_pos, float cam_world_x, float cam_world_y, float &out screen_x, float &out screen_y)
    {
        Vec3 cam_pos, cam_forward, cam_right, cam_up;
        get_camera_transform(cam_world_x, cam_world_y, cam_pos, cam_forward, cam_right, cam_up);
        Vec3 p = world_pos - cam_pos;
        float p_local_z = dot(p, cam_forward);
        if(p_local_z < 0.1) { screen_x = -99999; screen_y = -99999; return; }
        float p_local_x = dot(p, cam_right);
        float p_local_y = dot(p, cam_up);
        float aspect_ratio = 1920.0 / 1080.0;
        float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
        float ndc_x = (p_local_x * fov_adjust) / (p_local_z * aspect_ratio);
        float ndc_y = (p_local_y * fov_adjust) / p_local_z;
        screen_x = ndc_x * 800;
        screen_y = -ndc_y * 450;
    }
    
    void unproject_from_screen(float screen_x, float screen_y, float cam_world_x, float cam_world_y, Vec3 &out world_pos)
    {
        Vec3 cam_pos, cam_forward, cam_right, cam_up;
        get_camera_transform(cam_world_x, cam_world_y, cam_pos, cam_forward, cam_right, cam_up);
        float ndc_x = screen_x / 800.0;
        float ndc_y = -screen_y / 450.0;
        float aspect_ratio = 1920.0 / 1080.0;
        float fov_adjust = 1.0 / tan(fov * DEG2RAD * 0.5);
        float view_x = ndc_x * aspect_ratio / fov_adjust;
        float view_y = ndc_y / fov_adjust;
        Vec3 ray_dir_cam = Vec3(view_x, view_y, 1.0).normalize();
        Vec3 ray_dir_world = (cam_right * ray_dir_cam.x) + (cam_up * ray_dir_cam.y) + (cam_forward * ray_dir_cam.z);
        ray_dir_world = ray_dir_world.normalize();
        if(abs(ray_dir_world.z) < 1e-6) { world_pos.set(0,0,0); return; }
        float t = -cam_pos.z / ray_dir_world.z;
        world_pos = cam_pos + ray_dir_world * t;
    }
};

// Define minion states as an enum for compile-time constants
enum MinionState
{
    M_STATE_SPAWNING = 50,
    M_STATE_IDLE = 0,
    M_STATE_RUN = 2,
    M_STATE_SKID = 3,
    M_STATE_AUTO_ATTACK = 6,
    M_STATE_DEATH = 7
};

// -- Minion Class Definition --
class Minion : enemy_base, IDrawableCharacter, IDamageable
{
    scene@ g;
    scriptenemy@ self;
    script@ main_script;
    
    bool is_horde_minion;
    scriptenemy@ player_ref;
	
    sprites@ minion_sprite;
    Vec2 pos;
    Vec2 prev_pos;
    Vec2 target_pos;
    bool has_target;
    
    int state;
    float state_timer = 0;
    int face = 1;

    float world_bounds_x = 20.0;
    float world_bounds_y = 20.0;

    // Auto-attack properties for Minion
    float attack_range;
    scriptenemy@ aggression_target = null;
    array<AutoAttackParticle@> auto_attack_particles;
    [colour,alpha] uint auto_attack_colour_enemy = 0x88D699FF;
    [colour,alpha] uint auto_attack_colour_friendly = 0x88FFDE9A;
    float auto_attack_speed;
    float auto_attack_damage;
    float auto_attack_height;
    float auto_attack_particle_size;
    float attack_cooldown;
    
    // Configurable auto-attack impact colours for minions
    [colour,alpha] uint auto_attack_impact_colour1_enemy = 0xFFD699FF;
    [colour,alpha] uint auto_attack_impact_colour2_enemy = 0xFF725187;
    [colour,alpha] uint auto_attack_impact_colour1_friendly = 0xFFFFDE9A;
    [colour,alpha] uint auto_attack_impact_colour2_friendly = 0xFF99855C;
    
    Vec2 final_destination;
    int wave_index = -1;
    float aggression_radius = 3.0f;
    [text] float leash_radius = 3.5f; 

    // Health properties
    float max_health;
    float current_health;
    float pending_damage_health; // For health bar animation
    [text] float health_decay_speed = 30.0f; // Speed at which the damage preview bar decays
    float health_bar_width;
    float health_bar_height;
    [text] float health_bar_y_offset = -50;
    [text] float health_bar_outline = 2;

    string death_animation_name = "stun1";
    
    // Pathing and collision properties
    array<Vec2> position_history;
    int history_index = 0;
    int consecutive_collisions = 0;
    float pathing_variation_angle = 0;
    int pathing_variation_timer = 0;
    
    Team team;
    bool is_stationary;
    float sprite_scale;

    // Rectangular hitbox for right-click targeting
    float right_click_hitbox_width;
    float right_click_hitbox_height;

    Minion(MinionSpawnConfig@ config, bool is_horde = false, scriptenemy@ p_ref = null)
    {
        @g = get_scene();
        position_history.resize(20);
        this.team = config.team;
        this.attack_range = config.attack_range;
        this.auto_attack_damage = config.attack_damage_multiplier;
        this.max_health = config.starting_health;
        this.current_health = config.starting_health;
        this.pending_damage_health = config.starting_health;
        this.is_stationary = config.is_stationary;
        this.sprite_scale = config.sprite_scale;
        this.health_bar_width = config.health_bar_width;
        this.health_bar_height = config.health_bar_height;
        this.auto_attack_particle_size = config.auto_attack_particle_size;
        this.auto_attack_speed = config.auto_attack_particle_speed;
        this.auto_attack_height = config.auto_attack_height;
        this.attack_cooldown = config.attack_cooldown;
        this.right_click_hitbox_width = config.right_click_hitbox_width;
        this.right_click_hitbox_height = config.right_click_hitbox_height;
        this.is_horde_minion = is_horde;
        @this.player_ref = p_ref;
    }
    
    void init(script@ s, scriptenemy@ self)
    {
        @this.self = self;
        @this.main_script = s;
        self.auto_physics(false);
        @minion_sprite = create_sprites();
        if (team == Team::Friendly)
        {
            minion_sprite.add_sprite_set("trashking");
        }
        else
        {
            minion_sprite.add_sprite_set("dustkid");
        }
        
        // Position is now set by the spawner before init
        self.x(pos.x);
        self.y(pos.y);
        prev_pos.set(pos.x, pos.y);
        
        state = M_STATE_SPAWNING;
        
        has_target = false;
    }
    
    void take_damage(float amount, Vec3 attacker_pos, scriptenemy@ attacker)
    {
        if (current_health <= 0) return;

        current_health -= amount;
        if(current_health <= 0)
        {
            if (is_horde_minion) {
                MobaPlayer@ player_attacker = cast<MobaPlayer@>(attacker.get_object());
                if (@player_attacker !is null) {
                    main_script.on_horde_minion_killed();
                }
            }
            current_health = 0;
            state = M_STATE_DEATH;
            state_timer = 0;
            float attack_dx = attacker_pos.x - pos.x;
            if (attack_dx * face > 0)
            {
                death_animation_name = "stun1";
            }
            else
            {
                death_animation_name = "stun2";
            }
            if (@self.hit_collision() !is null)
            {
                self.hit_collision().remove();
            }
            if (@self.base_collision() !is null)
            {
                self.base_collision().remove();
            }

            // --- Start of Fix ---
            // Check for both player and champion attackers, not just the player.
            MobaPlayer@ player_attacker = cast<MobaPlayer@>(attacker.get_object());
            Champion@ champion_attacker = cast<Champion@>(attacker.get_object());

            if (@player_attacker !is null)
            {
                // Find the main script instance to add the indicator
                if (@main_script !is null)
                {
                    main_script.add_gold_indicator(Vec3(pos.x, pos.y, 1.0f));
                }
                
                // Add the regen effect for getting the last hit
                const float total_regen = 10.0f;
                const float duration_seconds = 3.0f;
                player_attacker.add_regen_effect(total_regen / duration_seconds, total_regen / duration_seconds / 3, duration_seconds);
            }
            else if (@champion_attacker !is null)
            {
                // Add the regen effect for getting the last hit, but do not show the gold indicator.
                const float total_regen = 10.0f;
                const float duration_seconds = 3.0f;
                champion_attacker.add_regen_effect(total_regen / duration_seconds, total_regen / duration_seconds, duration_seconds);
            }
            // --- End of Fix ---
        }
    }
    float x() { return pos.x; }
    float y() { return pos.y; }
    float prev_x() { return prev_pos.x; }
    float prev_y() { return prev_pos.y; }
    float hitbox_radius() { return 0.4 * sprite_scale; }
    float pathing_hitbox_radius() { return hitbox_radius() * 0.5f; }
    Team getTeam() { return team; }

    void move_to_target(array<IDrawableCharacter@>@ all_characters, replay_rand@ rrnd)
    {
        if(!has_target) 
        {
            if(state == M_STATE_RUN) 
            { 
                state = M_STATE_IDLE; 
                state_timer = 0;
            }
            return;
        }

        Vec2 to_target = target_pos - pos;
        float dist_to_target = to_target.magnitude();
        float move_speed = 0.015;

        if(dist_to_target < move_speed)
        {
            pos.set(target_pos.x, target_pos.y);
            has_target = false;
            if(state == M_STATE_RUN)
            {
                state = M_STATE_SKID;
                state_timer = 0;
            }
            return;
        }

        Vec2 desired_velocity = to_target;
        desired_velocity.normalise();
        
        Vec2 avoidance_force(0, 0);
        float avoidance_radius = pathing_hitbox_radius() * 3.0f;

        bool is_colliding = false;
        for (uint i = 0; i < all_characters.length(); i++)
        {
            IDrawableCharacter@ other = all_characters[i];
            enemy_base@ other_base = cast<enemy_base@>(other);
            if (@other_base !is null && @other_base is self.get_object()) continue;

            Minion@ other_minion = cast<Minion@>(other);
            if (@other_minion !is null && (other_minion.state == M_STATE_DEATH || other_minion.is_stationary))
            {
                continue;
            }

            Vec2 to_other(other.x() - pos.x, other.y() - pos.y);
            float dist_to_other = to_other.magnitude();
            
            if (dist_to_other < (pathing_hitbox_radius() + other.hitbox_radius()))
            {
                is_colliding = true;
            }
            
            if (dist_to_other > 0 && dist_to_other < avoidance_radius)
            {
                float strength = 1.0 - (dist_to_other / avoidance_radius);
                Vec2 repulsion_vec = to_other;
                repulsion_vec.normalise();
                avoidance_force = avoidance_force - repulsion_vec * strength;
            }
        }
        
        if(is_colliding)
        {
            consecutive_collisions++;
        }
        else
        {
            consecutive_collisions = 0;
        }

        if(consecutive_collisions >= 20)
        {
            pathing_variation_angle = (rrnd.frand() - 0.5) * PI / 2.0; // Random angle between -45 and 45 degrees
            pathing_variation_timer = 30; // Apply variation for 30 frames
            consecutive_collisions = 0; // Reset counter to give the new path a chance to work.
        }
        
        if (pathing_variation_timer > 0)
        {
            float angle = atan2(desired_velocity.y, desired_velocity.x) + pathing_variation_angle;
            desired_velocity.x = cos(angle);
            desired_velocity.y = sin(angle);
            pathing_variation_timer--;
        }

        desired_velocity = desired_velocity * move_speed;
        
        float avoidance_weight = 0.5f;
        Vec2 final_velocity = desired_velocity + avoidance_force * avoidance_weight;
        
        final_velocity.normalise();
        final_velocity = final_velocity * move_speed;

        float new_pos_x = pos.x + final_velocity.x;
        float new_pos_y = pos.y + final_velocity.y;
        
        new_pos_x = clamp(new_pos_x, -world_bounds_x, world_bounds_x);
        new_pos_y = clamp(new_pos_y, -world_bounds_y, world_bounds_y);
        pos.set(new_pos_x, new_pos_y);
        
        position_history[history_index].set(pos.x, pos.y);
        history_index = (history_index + 1) % 20;

        if(state != M_STATE_RUN) { state = M_STATE_RUN; state_timer = 0; }
        if(abs(to_target.x) > 0.1) { face = to_target.x > 0 ? 1 : -1; }
    }
    
    void step(array<IDrawableCharacter@>@ all_characters, array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        if (state == M_STATE_DEATH)
        {
            state_timer++;
            if (state_timer >= 60) // 1 second total (30 frames per animation frame)
            {
                g.remove_entity(self.as_entity());
            }
            return;
        }


        // UPDATED: Health bar decay logic
        if (pending_damage_health > current_health)
        {
            pending_damage_health -= health_decay_speed * DT;
            if (pending_damage_health < current_health)
            {
                pending_damage_health = current_health;
            }
        }
        else
        {
            pending_damage_health = current_health;
        }

        prev_pos.set(pos.x, pos.y);
        
        if (state == M_STATE_SPAWNING)
        {
            if (state_timer >= 10)
            {
                state = is_stationary ? M_STATE_IDLE : M_STATE_RUN;
                state_timer = 0;
                if(!is_stationary)
                {
                    target_pos = final_destination;
                    has_target = true;
                }
            }
            else
            {
                state_timer += DT * 12;
            }
            self.x(pos.x); self.y(pos.y);
            return;
        }
        if (is_horde_minion) {
            if (@player_ref !is null && !player_ref.destroyed()) {
                MobaPlayer@ player_logic = cast<MobaPlayer@>(player_ref.get_object());
                if (@player_logic !is null) {
                    @aggression_target = @player_ref;
                }
            }
        } else {
			if (@aggression_target !is null)
			{
				IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
				if (aggression_target.destroyed() || @target_char is null || target_char.getTeam() == this.team)
				{
					@aggression_target = null;
				}
				else
				{
					float dist_to_target = distance(pos.x, pos.y, target_char.x(), target_char.y());
					if(dist_to_target > leash_radius)
					{
						@aggression_target = null;
					}
				}
			}
			
			if (@aggression_target is null)
			{
				 float closest_dist_sq = aggression_radius * aggression_radius;
				 for (uint i = 0; i < all_characters.length(); i++)
				 {
					 IDrawableCharacter@ character = all_characters[i];
					 enemy_base@ enemy = cast<enemy_base@>(character);
					 if(@enemy is null) continue;
					 
					 scriptenemy@ target_ent = null;
					 Minion@ minion_char = cast<Minion@>(character);
					 if(@minion_char !is null)
					 {
						 @target_ent = @minion_char.self;
					 }
					 else
					 {
						 MobaPlayer@ player_char = cast<MobaPlayer@>(character);
						 if(@player_char !is null)
						 {
							 @target_ent = @player_char.self;
						 }
						 else
						 {
							 Champion@ champ_char = cast<Champion@>(character);
							 if(@champ_char !is null)
							 {
								 @target_ent = @champ_char.self;
							 }
						 }
					 }
					 if(@target_ent is null || @target_ent is self) continue;
					 
					 if(character.getTeam() == this.team) continue;
					 
					 float dist_sq = dist_sqr(pos.x, pos.y, character.x(), character.y());
					 if (dist_sq < closest_dist_sq)
					 {
						 closest_dist_sq = dist_sq;
						 @aggression_target = @target_ent;
					 }
				 }
			}

			if (@aggression_target !is null)
			{
				IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
				target_pos.set(target_char.x(), target_char.y());
				has_target = true;
				float dist_to_target = distance(pos.x, pos.y, target_pos.x, target_pos.y);

				if (dist_to_target <= attack_range)
				{
					has_target = false;
					if (state != M_STATE_AUTO_ATTACK)
					{
						state = M_STATE_AUTO_ATTACK;
						state_timer = 0;
					}
				}
				else
				{
					if(is_stationary)
					{
						@aggression_target = null;
						state = M_STATE_IDLE;
					}
					else
					{
						has_target = true;
						state = M_STATE_RUN;
					}
				}
			}
			else
			{
				if(!is_stationary)
				{
					if (state != M_STATE_RUN && state != M_STATE_SKID)
					{
						float dist_from_dest = distance(pos.x, pos.y, final_destination.x, final_destination.y);
						if (dist_from_dest > 0.1f)
						{
							target_pos = final_destination;
							has_target = true;
							state = M_STATE_RUN;
						}
						else if (state != M_STATE_IDLE)
						{
							has_target = false;
							state = M_STATE_IDLE;
						}
					}
				}
				else
				{
					state = M_STATE_IDLE;
				}
			}
		}
        
        if(state == M_STATE_RUN && !is_stationary)
        {
            move_to_target(all_characters, rrnd);
        }
        else if (state == M_STATE_SKID)
        {
            if(state_timer >= 10) 
            {
                state = M_STATE_IDLE;
                state_timer = 0;
            }
        }
        else if(state == M_STATE_AUTO_ATTACK)
        {
            IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
            float dx_target = target_char.x() - pos.x;
            if(abs(dx_target) > 0.1) { face = dx_target > 0 ? 1 : -1; }

            float timer_end_point = attack_cooldown * DT * 12;
            float timer_fire_point = timer_end_point * 0.4;

            if(state_timer >= timer_fire_point && state_timer < timer_fire_point + (DT * 12))
            {
                if(@aggression_target !is null && !aggression_target.destroyed())
                {
                    uint attack_colour = team == Team::Friendly ? auto_attack_colour_friendly : auto_attack_colour_enemy;
                    uint impact1 = team == Team::Friendly ? auto_attack_impact_colour1_friendly : auto_attack_impact_colour1_enemy;
                    uint impact2 = team == Team::Friendly ? auto_attack_impact_colour2_friendly : auto_attack_impact_colour2_enemy;
                    auto_attack_particles.insertLast(AutoAttackParticle(Vec3(pos.x, pos.y, auto_attack_height), aggression_target, self, attack_colour, auto_attack_speed, auto_attack_damage, impact1, impact2, auto_attack_particle_size));
                }
            }
            if(state_timer >= timer_end_point)
            {
                state = M_STATE_IDLE;
                state_timer = 0;
            }
        }
        
        for(int i = int(auto_attack_particles.length()) - 1; i >= 0; i--)
        {
            if(auto_attack_particles[i].step(fx_list, rrnd))
            {
                auto_attack_particles.removeAt(i);
            }
        }

        state_timer += DT * 12;
        self.x(pos.x);
        self.y(pos.y);
    }
    
    void draw(float sub_frame, IMobaCamera@ camera_provider, int sub_layer)
    {
        float interp_minion_x = lerp(prev_pos.x, pos.x, sub_frame);
        float interp_minion_y = lerp(prev_pos.y, pos.y, sub_frame);
        Vec2 cam_pos = camera_provider.get_camera_pos();
        Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
        float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
        float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);
        float screen_x, screen_y;
        camera_provider.project_to_screen(Vec3(interp_minion_x, interp_minion_y, 0), interp_camera_x, interp_camera_y, screen_x, screen_y);
        
        string sprite_name;
        uint frame;

        if (state == M_STATE_DEATH)
        {
            sprite_name = death_animation_name;
            frame = state_timer < 30 ? 0 : 1;
        }
        else
        {
            switch(state)
            {
                case M_STATE_SPAWNING: sprite_name = "idle"; break;
                case M_STATE_RUN: sprite_name = "sprint"; break;
                case M_STATE_SKID: sprite_name = "skidturn"; break;
                case M_STATE_AUTO_ATTACK: sprite_name = "groundstrike2"; break;
                default: sprite_name = "idle";
            }

            frame = uint(state_timer);
            const int length = minion_sprite.get_animation_length(sprite_name);
            if(length > 0) frame = frame % length;
        }
        
        minion_sprite.draw_hud(20, sub_layer, sprite_name, frame, 1, screen_x, screen_y, 0, float(face) * sprite_scale, sprite_scale, 0xFFFFFFFF);
    
        // --- Draw Health Bar ---
        if (state != M_STATE_DEATH)
        {
            const float health_percentage = current_health / max_health;
            const float pending_health_percentage = pending_damage_health / max_health;

            if (pending_health_percentage > 0)
            {
                // Use a different y_offset for turrets
                const float y_offset = is_stationary ? -85.0f : health_bar_y_offset;
                const float hb_x = screen_x - health_bar_width / 2;
                const float hb_y = screen_y + y_offset;

                // Black background/outline
                g.draw_rectangle_hud(21, 24,
                    hb_x - health_bar_outline,
                    hb_y - health_bar_outline,
                    hb_x + health_bar_width + health_bar_outline,
                    hb_y + health_bar_height + health_bar_outline,
                    0, 0xFF000000);

                // Yellow "pending damage" bar
                g.draw_rectangle_hud(21, 25,
                    hb_x,
                    hb_y,
                    hb_x + health_bar_width * pending_health_percentage,
                    hb_y + health_bar_height,
                    0, 0xFFFFFF00); // Yellow

                uint health_colour = team == Team::Friendly ? 0xFF04db04 : 0xFFfc2d2d;
                g.draw_rectangle_hud(21, 26,
                    hb_x,
                    hb_y,
                    hb_x + health_bar_width * health_percentage,
                    hb_y + health_bar_height,
                    0, health_colour);
            }
        }

        for(uint i = 0; i < auto_attack_particles.length(); i++)
        {
            auto_attack_particles[i].draw(g, sub_frame, camera_provider);
        }
    }
};

// -- Champion State Enum --
enum ChampionState
{
    CHAMP_STATE_SPAWNING = 50,
    CHAMP_STATE_IDLE = 0,
    CHAMP_STATE_RUN = 2,
    CHAMP_STATE_SKID = 3,
    CHAMP_STATE_LIGHT_ATTACK = 4,
    CHAMP_STATE_HEAVY_ATTACK = 5,
    CHAMP_STATE_AUTO_ATTACK = 6,
    CHAMP_STATE_DEATH = 7,
    CHAMP_STATE_REPOSITIONING = 8,
    CHAMP_STATE_LAST_HITTING_POSITIONING = 9,
    CHAMP_STATE_PUSHING_LANE = 10,
    CHAMP_STATE_BLINK_STARTUP = 11,
    CHAMP_STATE_BLINK_ARRIVAL = 12,
    CHAMP_STATE_EVASIVE_MANEUVER = 13,
    CHAMP_STATE_RETREAT_FROM_MINIONS = 14,
    CHAMP_STATE_TAUNT = 15,
    CHAMP_STATE_BLINK_TAUNT = 16 // Taunt variant with blinking
};

// -- Champion Class Definition --
class Champion : enemy_base, IDrawableCharacter, IDamageable
{
    scene@ g;
    scriptenemy@ self;
    script@ main_script;
    textfield@ level_text;
    
    sprites@ champion_sprite;
    Vec2 pos;
    Vec2 prev_pos;
    Vec2 target_pos;
    bool has_target;
    
    int state;
    float state_timer = 0;
    int face = 1;

    float world_bounds_x = 20.0;
    float world_bounds_y = 20.0;

    // Attack properties
    float attack_range = 4.0f;
    float light_attack_range = 5.5f;
    float heavy_attack_range = 8.0f;
    scriptenemy@ aggression_target = null;
    array<AutoAttackParticle@> auto_attack_particles;
    array<AttackParticle@> light_attack_particles; // For light attacks
    array<HeavyAttackParticle@> heavy_attack_particles;
    array<RegenEffect@> regen_effects;
    replay_rand@ rrnd_ref;
    array<RegenVisualEffect@> regen_visual_effects;
    float attack_cooldown_timer = 0;
    float light_attack_cooldown_timer = 0;
    float heavy_attack_cooldown_timer = 0;
    float light_attack_cooldown = 240; // 5 seconds * 60 fps
    float heavy_attack_cooldown = 600; // 10 seconds
    float light_attack_mana_cost = 10;
    float heavy_attack_mana_cost = 20;
    // Heavy attack state management
    bool heavy_attack_active = false;
    float heavy_attack_timer = 0;
    Vec2 heavy_attack_target_pos;
    int pre_attack_state;
    int pre_attack_face;
    bool pre_attack_has_target;
    Vec2 pre_attack_target_pos;
    Vec2 moonwalk_direction;
    int blink_taunt_phase = 0;
    
    // AI properties
    [text] float retreat_trigger_margin = 0.0f;
    [text] float retreat_stop_margin = -1.5f;
    Vec2 path_destination;
    float aggression_radius = 8.0f;
    float player_aggression_radius = 4.1f; // Increased player-specific aggression range
    float leash_radius = 12.0f;
    Vec2 spawn_position;
    float reposition_timer = 0.0f;
    float reposition_direction = 1.0f;
    float last_hit_reposition_timer = 0;
    float post_attack_move_timer = 0; // Kiting timer
    
    // Blink properties
    array<BlinkAfterImage@> after_images;
    float BLINK_MAX_RANGE = 4.0f;
    float BLINK_ANIMATION_DURATION_TIMER = 3.6f;
    float blink_cooldown = 300; // 8 seconds
    float blink_cooldown_timer = 0;
    Vec2 blink_target_pos;
    // Added variables to store pre-blink pathing state
    bool pre_blink_has_target = false;
    Vec2 pre_blink_target_pos;

    // Minion damage retreat properties
    float minion_damage_taken_in_aggro = 0;
    int minion_aggro_timer = 0;
    int MINION_AGGRO_DURATION = 180; // 3 seconds at 60fps

    // Taunt properties
    float taunt_timer = 0;
    float taunt_sub_state_timer = 0;
    bool taunt_is_dancing = false;
    uint victory_cancel_frame = 0;

    // Properties to track projectiles dodged by blink
    AttackParticle@ _found_threat_light;
    HeavyAttackParticle@ _found_threat_heavy;
    AttackParticle@ dodged_by_blink_light;
    HeavyAttackParticle@ dodged_by_blink_heavy;


    // Stats
    float max_health = 120;
    float current_health = 120;
    float pending_damage_health = 120;
    float health_decay_speed = 40.0f;
    float max_mana = 100;
    float current_mana = 100;
    float pending_mana_cost = 100;
    float mana_decay_speed = 30.0f;
    float mana_regen_rate = 1.0f; // Mana per second
    int champion_level = 3;

    // UI Properties
    float health_bar_width = 90;
    float health_bar_height = 10;
    float mana_bar_height = 6;
    float health_bar_y_offset = -99;
    float health_bar_outline = 2;
    float level_icon_size = 22;
    uint level_icon_bg_colour = 0xFF003356;
    float health_tick_interval = 20;
    
    string death_animation_name = "stun1";

    // Rectangular hitbox for right-click targeting
    [text] float right_click_hitbox_width = 50;
    [text] float right_click_hitbox_height = 70;

    Champion()
    {
        @g = get_scene();
        @level_text = create_textfield();
        level_text.set_font("envy_bold", 20);
        level_text.align_horizontal(0);
        level_text.align_vertical(0);
    }

    void init(script@ s, scriptenemy@ self)
    {
        @this.self = self;
        @this.main_script = s;
        self.auto_physics(false);
        @champion_sprite = create_sprites();
        champion_sprite.add_sprite_set("dustman");
        
        // MODIFIED: Set initial position directly to the spawn point
        pos.set(12.0, 12.0);
        prev_pos.set(pos.x, pos.y);
        spawn_position.set(7.0, 7.0); // Set respawn position
        self.x(pos.x); // Sync entity position
        self.y(pos.y); // Sync entity position
        
        state = CHAMP_STATE_SPAWNING;
        has_target = false;
        
        current_mana = max_mana;
        pending_mana_cost = max_mana;
    }
    
    // --- Interface Implementations ---
    float x() { return pos.x; }
    float y() { return pos.y; }
    float prev_x() { return prev_pos.x; }
    float prev_y() { return prev_pos.y; }
    float hitbox_radius() { return 0.45; }
    Team getTeam() { return Team::Enemy; }

    // Method to add a regeneration effect
    void add_regen_effect(float hps, float mps, float duration)
    {
        regen_effects.insertLast(RegenEffect(hps, mps, duration));
        
        // Also create the visual effect that spawns particles
        if(@rrnd_ref !is null)
        {
            regen_visual_effects.insertLast(RegenVisualEffect(this, rrnd_ref, duration));
        }
    }
    
    void take_damage(float amount, Vec3 attacker_pos, scriptenemy@ attacker)
        {
            if (state == CHAMP_STATE_DEATH) return;

            current_health -= amount;

            // Minion damage tracking logic
            Minion@ minion_attacker = cast<Minion@>(attacker.get_object());
            if (@minion_attacker !is null)
            {
                // If not currently under minion aggro, reset the accumulator.
                if (minion_aggro_timer <= 0)
                {
                    minion_damage_taken_in_aggro = 0;
                }
                // Add damage and reset the timer.
                minion_damage_taken_in_aggro += amount;
                minion_aggro_timer = MINION_AGGRO_DURATION;
            }

            if(current_health <= 0)
            {
                current_health = 0;
                state = CHAMP_STATE_DEATH;
                state_timer = 0;
                float attack_dx = attacker_pos.x - pos.x;
                if (attack_dx * face > 0)
                {
                    death_animation_name = "stun1";
                }
                else
                {
                    death_animation_name = "stun2";
                }
                
                if (@main_script !is null)
                {
                    main_script.on_champion_death();
                }
                
                // Gold indicator logic
                MobaPlayer@ player_attacker = cast<MobaPlayer@>(attacker.get_object());
                if (@player_attacker !is null)
                {
                    // Find the main script instance to add the indicator
                    if (@main_script !is null)
                    {
                        main_script.add_gold_indicator(Vec3(pos.x, pos.y, 1.5f));
                    }
                    const float total_regen = 10.0f;
                    const float duration_seconds = 3.0f;
                    player_attacker.add_regen_effect(total_regen / duration_seconds, total_regen / duration_seconds / 3, duration_seconds);
                }
            }
        }

    void respawn()
    {
        pos.set(spawn_position.x, spawn_position.y);
        prev_pos.set(pos.x, pos.y);
        current_health = max_health;
        pending_damage_health = max_health;
        current_mana = max_mana; // MODIFIED
        pending_mana_cost = max_mana; // MODIFIED
        state = CHAMP_STATE_IDLE;
        state_timer = 0;
        has_target = false;
        @aggression_target = null;
    }

    void execute_blink(Vec2 target)
    {
        if (blink_cooldown_timer > 0 || state == CHAMP_STATE_BLINK_STARTUP || state == CHAMP_STATE_BLINK_ARRIVAL) return;

        blink_cooldown_timer = blink_cooldown;
        state = CHAMP_STATE_BLINK_STARTUP;
        state_timer = 0;

        // MODIFIED: Store pre-blink pathing state
        pre_blink_has_target = has_target;
        if(has_target) { pre_blink_target_pos.set(target_pos.x, target_pos.y); }

        has_target = false; // Stop current movement
        blink_target_pos = target;
    }


    bool find_blink_position(MobaPlayer@ player, float front_line_dot, Vec2 minion_travel_dir, array<IDrawableCharacter@>@ all_characters, replay_rand@ rrnd, Vec2 &out blink_pos, bool force_defensive = false, bool friendly_minions_exist = false)
    {
        // --- NEW: Forced Defensive Blink Logic ---
        if (force_defensive)
        {
            float best_score = -99999.0f;
            bool found_spot = false;
            
            // Generate candidate positions behind the front line or towards spawn
            for (int i = 0; i < 32; i++)
            {
                Vec2 base_target = friendly_minions_exist ? pos + minion_travel_dir * -1.0f : spawn_position;
                
                float random_angle = rrnd.rand_range(-PI / 3.0f, PI / 3.0f); // +/- 60 degrees
                float random_dist = rrnd.rand_range(BLINK_MAX_RANGE * 0.7f, BLINK_MAX_RANGE);
                
                Vec2 dir_to_base = base_target - pos;
                if(dir_to_base.sqr_magnitude() > 1e-6) dir_to_base.normalise();
                else dir_to_base.set(-1, -1);
                
                rotate(dir_to_base.x, dir_to_base.y, random_angle, dir_to_base.x, dir_to_base.y);

                Vec2 candidate_pos = pos + dir_to_base * random_dist;

                candidate_pos.x = clamp(candidate_pos.x, -world_bounds_x, world_bounds_x);
                candidate_pos.y = clamp(candidate_pos.y, -world_bounds_y, world_bounds_y);

                if (distance(pos.x, pos.y, candidate_pos.x, candidate_pos.y) > BLINK_MAX_RANGE)
                    continue;

                float score = 0;
                // Score based on distance from player (higher is better)
                score += distance(candidate_pos.x, candidate_pos.y, player.x(), player.y()) * 10;

                // Score based on how far behind the front line it is
                float candidate_advancement = dot(candidate_pos, minion_travel_dir);
                if (friendly_minions_exist) {
                    score -= (candidate_advancement - front_line_dot) * 20; // Penalize going past the line
                }

                if (score > best_score)
                {
                    best_score = score;
                    blink_pos = candidate_pos;
                    found_spot = true;
                }
            }
            return found_spot;
        }

        // --- 1. Defensive Blink ---
        HeavyAttackParticle@ heavy_threat = null;
        float threat_dist_sq = 9999.0f;

        // Find the most immediate threat, prioritizing heavy attacks.
        for (uint i = 0; i < player.heavy_attack_particles.length(); i++)
        {
            HeavyAttackParticle@ p = player.heavy_attack_particles[i];
            float dist_sq = dist_sqr(p.pos.x, p.pos.y, pos.x, pos.y);
            
            // Broad phase check to avoid expensive calculations
            if (dist_sq < 7.0f * 7.0f)
            {
                Vec2 p_vel(p.vel.x, p.vel.y);
                float p_speed = p_vel.magnitude();
                if (p_speed > 1e-6)
                {
                    Vec2 p_dir = p_vel * (1.0f / p_speed);
                    Vec2 to_champ = pos - Vec2(p.pos.x, p.pos.y);

                    // Check if particle is moving towards the champion
                    if (dot(to_champ, p_dir) > 0)
                    {
                        // Calculate the perpendicular distance from the champion's center to the projectile's path.
                        const float perp_dist = abs(to_champ.x * p_dir.y - to_champ.y * p_dir.x);
                        // The total width to check against is the champion's radius plus half the projectile's width.
                        const float collision_radius = hitbox_radius() + p.width * 0.5f;

                        // If the perpendicular distance is greater than the combined radii, it's a guaranteed miss.
                        if (perp_dist >= collision_radius)
                            continue;
                        
                        // Calculate time to impact in animation frames
                        float dist_to_impact = dot(to_champ, p_dir);
                        float time_to_impact_frames = dist_to_impact / p_speed;

                        // Blink if impact is within ~30 frames (~0.5s), giving enough time to react and blink.
                        // The blink animation startup takes about 18 frames.
                        float blink_time_threshold_frames = 30.0f; 

                        // Check if it's time to blink
                        if (time_to_impact_frames <= blink_time_threshold_frames)
                        {
                            if(dist_sq < threat_dist_sq)
                            {
                                @heavy_threat = p;
                                threat_dist_sq = dist_sq;
                            }
                        }
                    }
                }
            }
        }

        // If no heavy threat is found, check for light attack threats that can't be dodged by running.
        AttackParticle@ light_threat = null;
        if (@heavy_threat == null)
        {
            for (uint i = 0; i < player.attack_particles.length(); i++)
            {
                AttackParticle@ p = player.attack_particles[i];
                Vec2 p_vel(p.vel.x, p.vel.y);
                float p_speed = p_vel.magnitude();
                if (p_speed < 1e-6) continue;

                Vec2 p_dir = p_vel * (1.0f / p_speed);
                Vec2 to_champ = pos - Vec2(p.pos.x, p.pos.y);

                // Only consider projectiles that are moving towards the champion and are reasonably close
                if (dot(to_champ, p_dir) <= 0 || to_champ.sqr_magnitude() > 7.0f * 7.0f)
                    continue;

                // --- Check if the projectile is actually on a collision course ---
                const float perp_dist = abs(to_champ.x * p_dir.y - to_champ.y * p_dir.x);
                const float collision_radius = hitbox_radius() + p.hitbox_radius;

                if (perp_dist >= collision_radius)
                    continue; // Will miss, no need to dodge.

                // --- The projectile will hit. Now, determine if we need to blink. ---
                
                // Time until the projectile is at its closest point to the champion
                const float dist_to_impact = dot(to_champ, p_dir);
                const float time_to_impact_frames = dist_to_impact / p_speed;

                // Time needed to dodge by moving. Champion must move the overlapping distance.
                const float distance_to_clear = collision_radius - perp_dist;
                const float time_to_run_dodge = distance_to_clear / 0.02f; // Champion move speed

                // Blink animation startup takes about 18 frames.
                const float BLINK_STARTUP_FRAMES = 18.0f;
                
                // Condition: Blink if champion can't run away in time, but has enough time to start a blink.
                if(time_to_impact_frames <= time_to_run_dodge && time_to_impact_frames > BLINK_STARTUP_FRAMES)
                {
                    // Only blink if the champion is not safely behind minions.
                    if (is_line_of_sight_clear(Vec2(player.x(), player.y()), player.getTeam(), this, all_characters, player))
                    {
                        float current_dist_sq = to_champ.sqr_magnitude();
                        if(current_dist_sq < threat_dist_sq)
                        {
                            @light_threat = p;
                            threat_dist_sq = current_dist_sq;
                        }
                    }
                }
            }
        }

        if(@heavy_threat == null && @light_threat == null)
        {
            return false; // No threat found, no reason to blink.
        }

        @_found_threat_heavy = @heavy_threat;
        @_found_threat_light = @light_threat;

        // --- A threat was found, calculate the best defensive blink position ---
        Vec2 threat_pos;
        Vec2 threat_vel;
        float threat_width = 0;
        
        if(@heavy_threat != null)
        {
            threat_pos.set(heavy_threat.pos.x, heavy_threat.pos.y);
            threat_vel.set(heavy_threat.vel.x, heavy_threat.vel.y);
            threat_width = heavy_threat.width;
        }
        else // Must be a light threat
        {
            threat_pos.set(light_threat.pos.x, light_threat.pos.y);
            threat_vel.set(light_threat.vel.x, light_threat.vel.y);
            threat_width = light_threat.hitbox_radius * 2; // Approximate width for generic dodge logic
        }
        
        threat_vel.normalise();

        float best_score = -99999.0f;
        Vec2 best_pos;
        bool found_spot = false;
        
        Vec2 threat_dir_perp(-threat_vel.y, threat_vel.x);
        // Determine which side of the projectile the champion is on
        float side_of_line = dot(pos - threat_pos, threat_dir_perp) > 0 ? 1.0 : -1.0;

        // Generate and score candidate positions
        for(int i = 0; i < 24; i++) // Increased candidates
        {
            float angle_offset = (rrnd.frand() - 0.5f) * PI; // Randomize dodge angle by +/- 90 degrees
            Vec2 dodge_dir = threat_dir_perp * side_of_line; // Start with a perpendicular dodge
            rotate(dodge_dir.x, dodge_dir.y, angle_offset, dodge_dir.x, dodge_dir.y);

            for(float dist_multiplier = 0.5f; dist_multiplier <= 1.0f; dist_multiplier += 0.25f)
            {
                Vec2 candidate_pos = pos + dodge_dir * (BLINK_MAX_RANGE * dist_multiplier);
                
                candidate_pos.x = clamp(candidate_pos.x, -world_bounds_x, world_bounds_x);
                candidate_pos.y = clamp(candidate_pos.y, -world_bounds_y, world_bounds_y);
                
                // --- NEW: Collision Check for Blink Destination ---
                // Project candidate position onto the attack's path
                Vec2 to_candidate = candidate_pos - threat_pos;
                float parallel_dist = dot(to_candidate, threat_vel);
                
                // Perpendicular distance from candidate pos to the attack's line of travel
                float perp_dist = abs(dot(to_candidate, threat_dir_perp));

                // If the candidate position is within the attack's width, it's unsafe.
                // Add a small buffer based on champion's hitbox.
                if (parallel_dist > 0 && perp_dist < (threat_width * 0.5f + hitbox_radius()))
                {
                    continue; // This is an invalid spot, skip it.
                }
                // --- END NEW ---

                float score = 0;

                // 1. Safety Score: Prioritize positions behind the minion front line.
                if(front_line_dot > -1e5f)
                {
                    float candidate_advancement = dot(candidate_pos, minion_travel_dir);
                    if(candidate_advancement <= front_line_dot + 1.0)
                    {
                        score += 100;
                        score -= abs(candidate_advancement - front_line_dot) * 10;
                    }
                    else
                    {
                        score -= (candidate_advancement - front_line_dot) * 20;
                    }
                }

                // 2. Offensive Score: Prioritize positions for a counter-attack.
                float dist_to_player = distance(candidate_pos.x, candidate_pos.y, player.x(), player.y());
                if(dist_to_player <= light_attack_range)
                {
                    score += 50;
                    if(light_attack_cooldown_timer <= 0) score += 25;
                }
                score -= dist_to_player * 5;

                // 3. Dodge Score: Prefer to cross over the projectile path ("jump over").
                float new_side_of_line = dot(candidate_pos - threat_pos, threat_dir_perp) > 0 ? 1.0 : -1.0;
                if (new_side_of_line != side_of_line)
                {
                     score += 200;
                }
                
                // 4. Distance Score: Prefer longer blinks to create more distance.
                score += dist_multiplier * 50;


                if(score > best_score)
                {
                    best_score = score;
                    best_pos = candidate_pos;
                    found_spot = true;
                }
            }
        }
        
        if(found_spot)
        {
            blink_pos = best_pos;
            return true;
        }

        // Fallback: If no strategic spot is found, perform a simple perpendicular dodge that is checked for safety.
        for(float dist_multiplier = 1.0f; dist_multiplier >= 0.5f; dist_multiplier -= 0.1f)
        {
            Vec2 dodge_dir = threat_dir_perp * side_of_line; // Dodge perpendicularly away
            Vec2 candidate_pos = pos + dodge_dir * BLINK_MAX_RANGE * dist_multiplier;
            
            // Check if fallback is safe
            Vec2 to_candidate = candidate_pos - threat_pos;
            float parallel_dist = dot(to_candidate, threat_vel);
            float perp_dist = abs(dot(to_candidate, threat_dir_perp));

            if (parallel_dist > 0 && perp_dist < (threat_width * 0.5f + hitbox_radius()))
            {
                continue; // Unsafe, try shorter blink.
            }

            blink_pos = candidate_pos;
            return true;
        }

        // Ultimate fallback if even perpendicular dodge is somehow unsafe (very unlikely)
        // Just blink backward away from player
        Vec2 dir_from_player = (pos - Vec2(player.x(), player.y()));
        dir_from_player.normalise();
        blink_pos = pos + dir_from_player * BLINK_MAX_RANGE;
        return true;
    }


/**
    * @brief NEW: Function to find an offensive blink position.
    * This function evaluates potential blink locations to engage the player,
    * balancing aggression with safety by checking for line-of-sight and
    * preferring positions behind allied minions.
    */
    bool find_offensive_blink_position(MobaPlayer@ player, float front_line_dot, Vec2 minion_travel_dir, array<IDrawableCharacter@>@ all_characters, replay_rand@ rrnd, Vec2 &out blink_pos)
    {
        // 1. Check if an offensive blink is even possible/desirable
        if (blink_cooldown_timer > 0 || light_attack_cooldown_timer > 0 || current_mana < light_attack_mana_cost)
            return false;

        const Vec2 player_pos(player.x(), player.y());
        const int num_candidates = 32;
        float best_score = -99999.0f;
        bool found_spot = false;

        // 3. Generate and score candidate positions
        for (int i = 0; i < num_candidates; i++)
        {
            // Generate a random position around the player, within light attack range
            // FIX: Use float literals to avoid ambiguous call to rand_range.
            float angle = rrnd.rand_range(0.0f, 2.0f * PI);
            float dist = rrnd.rand_range(light_attack_range * 0.5f, light_attack_range * 0.95f); // Don't get too close
            Vec2 candidate_pos = player_pos + Vec2(cos(angle) * dist, sin(angle) * dist);

            // Check if this candidate is within blink range from the champion's current position
            if (distance(pos.x, pos.y, candidate_pos.x, candidate_pos.y) > BLINK_MAX_RANGE)
                continue;
            
            candidate_pos.x = clamp(candidate_pos.x, -world_bounds_x, world_bounds_x);
            candidate_pos.y = clamp(candidate_pos.y, -world_bounds_y, world_bounds_y);

            // Check for line of sight from the candidate position
            if (!is_line_of_sight_clear(candidate_pos, getTeam(), player, all_characters, this))
                continue;

            float score = 100; // Base score for a valid spot

            // Safety Score: Prefer positions behind the minion front line.
            float candidate_advancement = dot(candidate_pos, minion_travel_dir);
            if(front_line_dot > -1e5f && candidate_advancement <= front_line_dot + 1.0)
            {
                score += 100;
            }
            else
            {
                score -= (candidate_advancement - front_line_dot) * 20; // Penalize overextending
            }

            if (score > best_score)
            {
                best_score = score;
                blink_pos = candidate_pos;
                found_spot = true;
            }
        }

        return found_spot;
    }
    
    void step(array<IDrawableCharacter@>@ all_characters, MobaPlayer@ player, array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
        {
            
            // Cache the replay_rand reference if we don't have it yet.
            if(@rrnd_ref == null) @rrnd_ref = rrnd;

            // Step through active stat regen effects
            for(int i = int(regen_effects.length()) - 1; i >= 0; i--)
            {
                if(regen_effects[i].step(this))
                {
                    regen_effects.removeAt(i);
                }
            }

            // Step through regen visual effects (particle spawning)
            for(int i = int(regen_visual_effects.length()) - 1; i >= 0; i--)
            {
                // The visual effect step will add particles to the main fx_list
                if(regen_visual_effects[i].step(fx_list))
                {
                    regen_visual_effects.removeAt(i);
                }
            }

            // Clear dodged particle handles if they are no longer active
            if (@dodged_by_blink_light !is null && dodged_by_blink_light.life <= 0)
                @dodged_by_blink_light = null;
            if (@dodged_by_blink_heavy !is null && dodged_by_blink_heavy.life <= 0)
                @dodged_by_blink_heavy = null;

            if (state == CHAMP_STATE_DEATH)
            {
                state_timer++;
                if (state_timer >= 120) // 2 second respawn timer
                {
                    respawn();
                }
                return;
            }

            // Mana Regeneration
            if (current_mana < max_mana)
            {
                current_mana += mana_regen_rate * DT;
                if (current_mana > max_mana)
                {
                    current_mana = max_mana;
                }
            }

            if (pending_damage_health > current_health)
            {
                pending_damage_health -= health_decay_speed * DT;
                if (pending_damage_health < current_health)
                {
                    pending_damage_health = current_health;
                }
            }
            else
            {
                pending_damage_health = current_health;
            }

            if (pending_mana_cost > current_mana)
            {
                pending_mana_cost -= mana_decay_speed * DT;
                if (pending_mana_cost < current_mana)
                {
                    pending_mana_cost = current_mana;
                }
            }
            else
            {
                pending_mana_cost = current_mana;
            }

            prev_pos.set(pos.x, pos.y);
            if (attack_cooldown_timer > 0) { attack_cooldown_timer -= DT * 60; }
            if (light_attack_cooldown_timer > 0) { light_attack_cooldown_timer -= DT * 60; }
            if (heavy_attack_cooldown_timer > 0) { heavy_attack_cooldown_timer -= DT * 60; }
            if (blink_cooldown_timer > 0) { blink_cooldown_timer -= DT * 60; }
            if (reposition_timer > 0) { reposition_timer -= DT * 60; }
            if (last_hit_reposition_timer > 0) { last_hit_reposition_timer -= DT * 60; }
            if (post_attack_move_timer > 0) { post_attack_move_timer -= DT * 60; }

            if (minion_aggro_timer > 0)
            {
                minion_aggro_timer--;
                if (minion_aggro_timer <= 0)
                {
                    minion_damage_taken_in_aggro = 0;
                }
            }

            // Check if player target is dead and enter a taunt state
            if (state != CHAMP_STATE_TAUNT && state != CHAMP_STATE_BLINK_TAUNT && @aggression_target !is null)
            {
                if (@player !is null && @aggression_target is player.self && player.state == P_STATE_DEATH)
                {
                    if (rrnd.frand() < 1.0 / 1.8) // 1/3 chance for blink taunt
                    {
                        state = CHAMP_STATE_BLINK_TAUNT;
                        blink_taunt_phase = 0; // Start with initiating the blink
                    }
                    else // 2/3 chance for original taunt
                    {
                        state = CHAMP_STATE_TAUNT;
                        taunt_timer = 3 * 60;
                        taunt_is_dancing = true; // Start with victory animation
                        taunt_sub_state_timer = 0.5 * 60;
                        victory_cancel_frame = rrnd.rand_range(3, 8);
                    }
                    state_timer = 0;
                    @aggression_target = null;
                    has_target = false;
                }
            }

            if (heavy_attack_active)
            {
                heavy_attack_timer += DT * 12;
                float crouch_duration = 0.05 * 60 * DT * 12;
                float rising1_duration = 0.1 * 60 * DT * 12;
                float rising2_duration = 0.05 * 60 * DT * 12;
                float airsmash1_duration = 0.3 * 60 * DT * 12;
                float airsmash2_duration = 0.1 * 60 * DT * 12;
                float total_windup_time = crouch_duration + rising1_duration + rising2_duration + airsmash1_duration;

                if (heavy_attack_timer >= total_windup_time && heavy_attack_timer < total_windup_time + (DT * 12))
                {
                    Vec2 dir = heavy_attack_target_pos - pos;
                    dir.normalise();
                    float attack_speed = 0.15;
                    // UPDATED: Create heavy attack with blue trail particles
                    heavy_attack_particles.insertLast(HeavyAttackParticle(Vec3(pos.x, pos.y, 0.4), Vec3(dir.x * attack_speed, dir.y * attack_speed, 0), self, 0xFF33AAAA, 0xFFCCFFFF));
                    heavy_attack_particles[heavy_attack_particles.length()-1].colour = 0xFF44CCFF;
                }
                float total_attack_time = total_windup_time + airsmash2_duration;
                if (heavy_attack_timer >= total_attack_time)
                {
                    heavy_attack_active = false;
                    if (state == CHAMP_STATE_HEAVY_ATTACK)
                    {
                        state = CHAMP_STATE_RUN;
                        state_timer = 0;
                    }
                }
            }

            // --- Safe Positioning Logic ---
            Vec2 minion_travel_dir(-1, -1);
            minion_travel_dir.normalise();

            float front_line_dot = -1e6f;
            bool friendly_minions_exist = false;
            for (uint i = 0; i < all_characters.length(); i++)
            {
                if (all_characters[i].getTeam() == Team::Enemy)
                {
                    Minion@ minion = cast<Minion@>(all_characters[i]);
                    if (@minion !is null && !minion.is_stationary)
                    {
                        Vec2 minion_pos(minion.x(), minion.y());
                        float advancement = dot(minion_pos, minion_travel_dir);
                        if (advancement > front_line_dot)
                        {
                            front_line_dot = advancement;
                        }
                        friendly_minions_exist = true;
                    }
                }
            }

            float champ_advancement = dot(pos, minion_travel_dir);
            bool is_overextended = friendly_minions_exist && champ_advancement > (front_line_dot + retreat_trigger_margin);
            bool is_safe = !friendly_minions_exist || champ_advancement <= (front_line_dot + retreat_stop_margin);

            // --- Blink Decision Logic ---
            if (blink_cooldown_timer <= 0 && state != CHAMP_STATE_BLINK_STARTUP && state != CHAMP_STATE_BLINK_ARRIVAL && state != CHAMP_STATE_DEATH)
            {
                Vec2 blink_target;
                // Clear temporary threats before checking for a blink position
                @_found_threat_light = null;
                @_found_threat_heavy = null;

                // --- NEW: Proximity-based Defensive Blink ---
                // If too close to the player and at a health disadvantage, blink away defensively.
                float proximity_threshold = 3.0f;
                float health_disadvantage_margin = 5.0f;
                if (distance(pos.x, pos.y, player.x(), player.y()) <= proximity_threshold &&
                    current_health < (player.current_health - health_disadvantage_margin))
                {
                    if (find_blink_position(player, front_line_dot, minion_travel_dir, all_characters, rrnd, blink_target, true, friendly_minions_exist))
                    {
                        execute_blink(blink_target);
                    }
                }

               // --- NEW: High Priority Defensive Blink when Overextended and Low Health ---
                if (is_overextended && (current_health < player.current_health) && blink_cooldown_timer <= 0 && state != CHAMP_STATE_BLINK_STARTUP && state != CHAMP_STATE_BLINK_ARRIVAL && state != CHAMP_STATE_DEATH)
                {
                    if (find_blink_position(player, front_line_dot, minion_travel_dir, all_characters, rrnd, blink_target, true, friendly_minions_exist))
                    {
                        execute_blink(blink_target);
                        // The rest of the AI logic for this frame will be skipped because the state is now BLINK_STARTUP
                    }
                }

                // Try defensive blink first
                if (find_blink_position(player, front_line_dot, minion_travel_dir, all_characters, rrnd, blink_target, false, friendly_minions_exist))
                {
                    execute_blink(blink_target);
                    // Persist the handle of the particle that was just dodged
                    @dodged_by_blink_light = @_found_threat_light;
                    @dodged_by_blink_heavy = @_found_threat_heavy;
                }
                // If no defensive blink, try offensive blink with a low probability
                else if(
                    (state == CHAMP_STATE_IDLE || state == CHAMP_STATE_RUN || state == CHAMP_STATE_REPOSITIONING || state == CHAMP_STATE_LAST_HITTING_POSITIONING) &&
                    distance(pos.x, pos.y, player.x(), player.y()) <= player_aggression_radius * 1.5f &&
                    rrnd.frand() < 0.01f && // Low chance to use offensive blink
                    find_offensive_blink_position(player, front_line_dot, minion_travel_dir, all_characters, rrnd, blink_target))
                {
                    execute_blink(blink_target);
                }
            }

            // --- Evasive Pathing Logic ---
            bool is_maneuvering = false;
            if (state != CHAMP_STATE_BLINK_STARTUP && state != CHAMP_STATE_BLINK_ARRIVAL && state != CHAMP_STATE_LIGHT_ATTACK && state != CHAMP_STATE_HEAVY_ATTACK && state != CHAMP_STATE_AUTO_ATTACK)
            {
                for (uint i = 0; i < player.heavy_attack_particles.length(); i++)
                {
                    HeavyAttackParticle@ p = player.heavy_attack_particles[i];
                    if (@p is dodged_by_blink_heavy) continue;
                    Vec2 p_vel(p.vel.x, p.vel.y);
                    if (p_vel.sqr_magnitude() < 1e-6) continue;

                    Vec2 to_champ = pos - Vec2(p.pos.x, p.pos.y);
                    if (to_champ.sqr_magnitude() < 5.0f * 5.0f && dot(to_champ, p_vel) > 0)
                    {
                        p_vel.normalise();

                        // Check if the projectile is on a collision course.
                        const float perp_dist = abs(to_champ.x * p_vel.y - to_champ.y * p_vel.x);
                        const float collision_radius = hitbox_radius() + p.width * 0.5f;

                        if (perp_dist - 0.5f >= collision_radius)
                            continue;

                        Vec2 dodge_dir(-p_vel.y, p_vel.x);
                        if (dot(dodge_dir, to_champ) < 0) { dodge_dir *= -1; }
                        
                        state = CHAMP_STATE_EVASIVE_MANEUVER;
                        has_target = true;
                        target_pos = pos + dodge_dir * 1.0f;
                        is_maneuvering = true;
                        break;
                    }
                }


                if (!is_maneuvering)
                {
                    // Only try to evade light attacks if the player is close enough to be a threat.
                    if (distance(pos.x, pos.y, player.x(), player.y()) <= light_attack_range + 1.0f)
                    {
                        for (uint i = 0; i < player.attack_particles.length(); i++)
                        {
                            AttackParticle@ p = player.attack_particles[i];
                            if (@p is dodged_by_blink_light) continue;
                            Vec2 p_vel(p.vel.x, p.vel.y);
                            if (p_vel.sqr_magnitude() < 1e-6) continue;

                            Vec2 to_champ = pos - Vec2(p.pos.x, p.pos.y);
                            if (to_champ.sqr_magnitude() < 4.0f * 4.0f && dot(to_champ, p_vel) > 0)
                            {
                                if (is_line_of_sight_clear(Vec2(player.x(), player.y()), player.getTeam(), this, all_characters, player))
                                {
                                    // Always try to evade light attacks with movement if possible.
                                    p_vel.normalise();
                                    Vec2 dodge_dir(-p_vel.y, p_vel.x);
                                    if (dot(dodge_dir, to_champ) < 0) { dodge_dir *= -1; }
                                    
                                    state = CHAMP_STATE_EVASIVE_MANEUVER;
                                    has_target = true;
                                    target_pos = pos + dodge_dir * 0.5f; // Halved distance for light attacks
                                    is_maneuvering = true;
                                    break;
                                }
                                else
                                {
                                    Vec2 player_pos(player.x(), player.y());
                                    Vec2 dir_from_player = (pos - player_pos);
                                    dir_from_player.normalise();

                                    state = CHAMP_STATE_EVASIVE_MANEUVER;
                                    has_target = true;
                                    target_pos = pos + dir_from_player * 0.375f; // Halved distance for light attacks
                                    is_maneuvering = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            if (is_maneuvering)
            {
                state_timer = 0;
            }
            // --- Main AI Logic ---
            else if (state == CHAMP_STATE_EVASIVE_MANEUVER)
            {
            }
            else if (state == CHAMP_STATE_LIGHT_ATTACK || state == CHAMP_STATE_HEAVY_ATTACK || state == CHAMP_STATE_AUTO_ATTACK || state == CHAMP_STATE_BLINK_STARTUP || state == CHAMP_STATE_BLINK_ARRIVAL || state == CHAMP_STATE_DEATH || state == CHAMP_STATE_TAUNT || state == CHAMP_STATE_BLINK_TAUNT)
            {
            }
            else if (minion_damage_taken_in_aggro > max_health * 0.1f)
            {
                state = CHAMP_STATE_RETREAT_FROM_MINIONS;
                state_timer = 0;
                @aggression_target = null;
                has_target = true;
                float target_advancement = front_line_dot + retreat_stop_margin;
                float k = target_advancement - champ_advancement;
                target_pos = pos + minion_travel_dir * k;
                
                minion_damage_taken_in_aggro = 0;
                minion_aggro_timer = 0;
            }
            else if (state == CHAMP_STATE_RETREAT_FROM_MINIONS)
            {
                // The only goal in this state is to retreat to a safe position.
                // Once the champion is safe, it will transition back to IDLE.
                // It will not look for attack opportunities while in this state.
                if (is_safe) 
                { 
                    has_target = false; 
                    state = CHAMP_STATE_IDLE; 
                    state_timer = 0; 
                }
                else 
                { 
                    // Continue retreating by dynamically updating the target position
                    // relative to the current minion front line.
                    has_target = true; 
                    float target_advancement = front_line_dot + retreat_stop_margin; 
                    float k = target_advancement - champ_advancement; 
                    target_pos = pos + minion_travel_dir * k; 
                }
            }
            else if (state == CHAMP_STATE_REPOSITIONING)
            {
                if (post_attack_move_timer > 0)
                {
                    if (is_safe) { has_target = false; state = CHAMP_STATE_IDLE; state_timer = 0; }
                    else { has_target = true; float target_advancement = front_line_dot + retreat_stop_margin; float k = target_advancement - champ_advancement; target_pos = pos + minion_travel_dir * k; }
                }
                else
                {
                    bool is_attacking = false;
                    if (@player !is null)
                    {
                        float dist_to_player = distance(pos.x, pos.y, player.x(), player.y());
                        if (dist_to_player <= light_attack_range && light_attack_cooldown_timer <= 0 && current_mana >= light_attack_mana_cost)
                        {
                            if (is_line_of_sight_clear(pos, getTeam(), player, all_characters, this))
                            {
                                state = CHAMP_STATE_LIGHT_ATTACK; @aggression_target = @player.self; is_attacking = true;
                            }
                        }
                        if (!is_attacking && dist_to_player <= attack_range && attack_cooldown_timer <= 0)
                        {
                            state = CHAMP_STATE_AUTO_ATTACK; @aggression_target = @player.self; is_attacking = true;
                        }
                    }
                    
                    if (!is_attacking && light_attack_cooldown_timer <= 0 && current_mana >= light_attack_mana_cost)
                    {
                        Minion@ last_hit_target = null;
                        float min_dist_sq = light_attack_range * light_attack_range;
                        
                        for (uint i = 0; i < all_characters.length(); i++)
                        {
                            Minion@ minion = cast<Minion@>(all_characters[i]);
                            if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH || minion.getTeam() == getTeam()) continue;
                            
                            if (minion.current_health <= 16.0f) // Light attack damage
                            {
                                float dist_sq = dist_sqr(pos.x, pos.y, minion.x(), minion.y());
                                if (dist_sq < min_dist_sq)
                                {
                                    if (is_line_of_sight_clear(pos, getTeam(), minion, all_characters, this))
                                    {
                                        min_dist_sq = dist_sq;
                                        @last_hit_target = minion;
                                    }
                                }
                            }
                        }
                        
                        if(@last_hit_target !is null)
                        {
                            state = CHAMP_STATE_LIGHT_ATTACK;
                            @aggression_target = @last_hit_target.self;
                            is_attacking = true;
                        }
                    }

                    if (is_attacking)
                    {
                        state_timer = 0;
                        if (@aggression_target !is null)
                        {
                            IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                            float dx_target = target_char.x() - pos.x;
                            if(abs(dx_target) > 0.1) { face = dx_target > 0 ? 1 : -1; }
                        }
                    }
                    else
                    {
                        if (is_safe) { has_target = false; state = CHAMP_STATE_IDLE; state_timer = 0; }
                        else { has_target = true; float target_advancement = front_line_dot + retreat_stop_margin; float k = target_advancement - champ_advancement; target_pos = pos + minion_travel_dir * k; }
                    }
                }
            }
            else if (is_overextended)
            {
                state = CHAMP_STATE_REPOSITIONING; state_timer = 0; @aggression_target = null; has_target = true;
                float target_advancement = front_line_dot + retreat_stop_margin;
                float k = target_advancement - champ_advancement; target_pos = pos + minion_travel_dir * k;
            }
            else
            {
                // 1. TARGET AND ACTION SELECTION
                @aggression_target = null;
                scriptenemy@ potential_target = null;

                // 1a. Prioritize player if nearby.
                if (@player !is null)
                {
                    const float dist_to_player = distance(pos.x, pos.y, player.x(), player.y());
                    // Check for a long-range heavy attack opportunity first.
                    if(dist_to_player <= heavy_attack_range && !heavy_attack_active && heavy_attack_cooldown_timer <= 0 && current_mana >= heavy_attack_mana_cost)
                    {
                        @potential_target = player.self;
                    }
                    // Otherwise, check for normal aggression range for other attacks.
                    else if (dist_to_player <= player_aggression_radius)
                    {
                        @potential_target = player.self;
                    }
                }
                @aggression_target = potential_target;

                // 1b. NEW: Prioritize light-attack last hit on a minion if player is not a target.
                Minion@ light_attack_minion_target = null;
                if (@aggression_target is null && light_attack_cooldown_timer <= 0 && current_mana >= light_attack_mana_cost)
                {
                    float min_dist_sq = 1e9f;
                    for (uint i = 0; i < all_characters.length(); i++)
                    {
                        Minion@ minion = cast<Minion@>(all_characters[i]);
                        if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH || minion.getTeam() != Team::Friendly) continue;
                        if (minion.current_health <= 16.0f) // Light attack deals 16 damage
                        {
                            float dist_sq = dist_sqr(pos.x, pos.y, minion.x(), minion.y());
                            if (dist_sq < min_dist_sq) { min_dist_sq = dist_sq; @light_attack_minion_target = minion; }
                        }
                    }
                    if (@light_attack_minion_target !is null) { @aggression_target = light_attack_minion_target.self; }
                }
                
                // 1c. Find auto-attack last-hit target if no other target found yet.
                if (@aggression_target is null)
                {
                    Minion@ last_hit_target = null; float min_health_for_last_hit = 1e9f;
                    for (uint i = 0; i < all_characters.length(); i++)
                    {
                        Minion@ minion = cast<Minion@>(all_characters[i]);
                        if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH || minion.getTeam() != Team::Friendly) continue;
                        float dist_to_minion = distance(pos.x, pos.y, minion.x(), minion.y());
                        if (minion.current_health <= 8.0f && dist_to_minion <= attack_range && attack_cooldown_timer <= 0)
                        {
                            if (minion.current_health < min_health_for_last_hit) { min_health_for_last_hit = minion.current_health; @last_hit_target = minion; }
                        }
                    }
                    if (@last_hit_target !is null) { @aggression_target = last_hit_target.self; }
                }

                // 2. ACTION EXECUTION
                if (@aggression_target !is null)
                {
                    IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                    float dist_to_target = distance(pos.x, pos.y, target_char.x(), target_char.y());
                    MobaPlayer@ player_target = cast<MobaPlayer@>(target_char);

                    // High-priority action: Heavy attack on player if conditions are met
                    if (@player_target !is null &&
                        (player_target.current_health / player_target.max_health < 0.4f || (rrnd.frand() < 0.03f && dist_to_target <= heavy_attack_range)) &&
                        !heavy_attack_active && heavy_attack_cooldown_timer <= 0 && current_mana >= heavy_attack_mana_cost)
                    {
                        // ... Heavy attack prediction and execution logic ...
                        const float windup_frames = (0.05 + 0.1 + 0.05 + 0.3) * 60;
                        Vec2 player_pos = player_target.pos;
                        Vec2 player_vel = player_target.get_average_velocity();
                                            Vec2 player_pos_at_fire = player_pos + player_vel * windup_frames;
                        const float projectile_speed = 0.30f; 
                        // ... (rest of the prediction calculation remains the same) ...
                        Vec2 champ_pos = pos; Vec2 d = player_pos_at_fire - champ_pos;
                        float a = dot(player_vel, player_vel) - (projectile_speed * projectile_speed); float b = 2 * dot(d, player_vel); float c = dot(d, d);
                        float discriminant = b*b - 4*a*c; Vec2 final_predicted_pos;
                        if (discriminant >= 0) {
                            float t_intercept = -1;
                            if (abs(a) > 1e-6) {
                                float t1 = (-b - sqrt(discriminant)) / (2 * a); float t2 = (-b + sqrt(discriminant)) / (2 * a);
                                if (t1 > 0 && t2 > 0) { t_intercept = min(t1, t2); } else if (t1 > 0) { t_intercept = t1; } else { t_intercept = t2; }
                            }
                            if (t_intercept > 0) { final_predicted_pos = player_pos_at_fire + player_vel * t_intercept; } else { final_predicted_pos = player_pos_at_fire; }
                        } else { final_predicted_pos = player_pos_at_fire; }
                        final_predicted_pos.x = clamp(final_predicted_pos.x, -world_bounds_x, world_bounds_x); final_predicted_pos.y = clamp(final_predicted_pos.y, -world_bounds_y, world_bounds_y);
                        current_mana -= heavy_attack_mana_cost; heavy_attack_cooldown_timer = heavy_attack_cooldown; heavy_attack_active = true;
                        heavy_attack_timer = 0; heavy_attack_target_pos.set(final_predicted_pos.x, final_predicted_pos.y); 
                        pre_attack_state = state; pre_attack_face = face; pre_attack_has_target = has_target;
                        if(has_target) { pre_attack_target_pos.set(target_pos.x, target_pos.y); }
                        state = CHAMP_STATE_HEAVY_ATTACK; state_timer = 0; float dx_target = heavy_attack_target_pos.x - pos.x; if(abs(dx_target) > 0.1) { face = dx_target > 0 ? 1 : -1; }
                    }
                    // Next action: Light attack on player or minion
                    else if (dist_to_target <= light_attack_range && light_attack_cooldown_timer <= 0 && current_mana >= light_attack_mana_cost)
                    {
                        if (is_line_of_sight_clear(pos, getTeam(), target_char, all_characters, this)) {
                            state = CHAMP_STATE_LIGHT_ATTACK; state_timer = 0; has_target = false;
                        } else if (@light_attack_minion_target !is null && @aggression_target is light_attack_minion_target.self) {
                            state = CHAMP_STATE_LAST_HITTING_POSITIONING; has_target = true;
                            Minion@ shield_minion = null; float closest_shield_dist_sq = 1e9f;
                            for (uint i = 0; i < all_characters.length(); i++) {
                                Minion@ minion = cast<Minion@>(all_characters[i]);
                                if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH || minion.getTeam() != Team::Enemy) continue;
                                float dist_sq = dist_sqr(pos.x, pos.y, minion.x(), minion.y());
                                if (dist_sq < closest_shield_dist_sq) { closest_shield_dist_sq = dist_sq; @shield_minion = minion; }
                            }
                            Vec2 ideal_safe_pos; bool has_safe_pos = false;
                            if (@shield_minion !is null && @player !is null) {
                                Vec2 shield_pos(shield_minion.x(), shield_minion.y()); Vec2 player_pos_val(player.x(), player.y()); Vec2 dir_from_player = (shield_pos - player_pos_val);
                                if (dir_from_player.sqr_magnitude() > 1e-6) { dir_from_player.normalise(); ideal_safe_pos = shield_pos + dir_from_player * (shield_minion.hitbox_radius() + hitbox_radius() + 0.5f); has_safe_pos = true; }
                            }
                            Vec2 attack_target_pos(target_char.x(), target_char.y()); Vec2 final_target_pos;
                            if (has_safe_pos) {
                                Vec2 dir_to_safe_pos = ideal_safe_pos - attack_target_pos; float dist_to_safe_pos = dir_to_safe_pos.magnitude();
                                if (dist_to_safe_pos > light_attack_range * 0.9f) { dir_to_safe_pos.normalise(); final_target_pos = attack_target_pos + dir_to_safe_pos * (light_attack_range * 0.9f); } else { final_target_pos = ideal_safe_pos; }
                            } else {
                                if (@player !is null) { Vec2 player_pos_val(player.x(), player.y()); Vec2 dir_from_player = (attack_target_pos - player_pos_val); if(dir_from_player.sqr_magnitude() < 1e-6) { dir_from_player.set(0, -1); } dir_from_player.normalise(); final_target_pos = attack_target_pos + dir_from_player * (light_attack_range * 0.9f); } else { Vec2 dir_away = pos - attack_target_pos; dir_away.normalise(); final_target_pos = attack_target_pos + dir_away * (light_attack_range * 0.9f); }
                            }
                            target_pos.set(final_target_pos.x + (rrnd.frand() - 0.5f) * 1.0f, final_target_pos.y + (rrnd.frand() - 0.5f) * 1.0f);
                        }
                    }
                    // Next action: Auto-attack
                    else if (dist_to_target <= attack_range && attack_cooldown_timer <= 0)
                    {
                        state = CHAMP_STATE_AUTO_ATTACK; state_timer = 0; has_target = false;
                    }
                    // Fallback: Move towards target
                    else
                    {
                        state = CHAMP_STATE_RUN;
                        target_pos.set(target_char.x(), target_char.y());
                        has_target = true;
                    }
                }
                else // No target found
                {
                    if(last_hit_reposition_timer <= 0)
                    {
                        Minion@ lowest_health_minion = null; float min_health = 1e9f; float total_friendly_minion_health = 0; float total_enemy_minion_health = 0;
                        for (uint i = 0; i < all_characters.length(); i++)
                        {
                            Minion@ minion = cast<Minion@>(all_characters[i]);
                            if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH) continue;
                            if(minion.getTeam() == Team::Friendly) { total_friendly_minion_health += minion.current_health; if (minion.current_health < min_health) { min_health = minion.current_health; @lowest_health_minion = minion; } }
                            else if(minion.getTeam() == Team::Enemy) { total_enemy_minion_health += minion.current_health; }
                        }
                        
                        if(@lowest_health_minion !is null)
                        {
                            float attack_chance = 0.05f; if (total_enemy_minion_health < total_friendly_minion_health) { attack_chance += 0.3f; }
                            if (rrnd.frand() < attack_chance && distance(pos.x, pos.y, lowest_health_minion.x(), lowest_health_minion.y()) <= attack_range && attack_cooldown_timer <= 0) { @aggression_target = lowest_health_minion.self; has_target=true; target_pos.set(lowest_health_minion.x(), lowest_health_minion.y()); }
                            else {
                                state = CHAMP_STATE_LAST_HITTING_POSITIONING; has_target = true;
                                Minion@ shield_minion = null; float closest_shield_dist_sq = 1e9f;
                                for (uint i = 0; i < all_characters.length(); i++)
                                {
                                    Minion@ minion = cast<Minion@>(all_characters[i]);
                                    if (@minion is null || minion.is_stationary || minion.state == M_STATE_DEATH || minion.getTeam() != Team::Enemy) continue;
                                    float dist_sq = dist_sqr(pos.x, pos.y, minion.x(), minion.y());
                                    if (dist_sq < closest_shield_dist_sq) { closest_shield_dist_sq = dist_sq; @shield_minion = minion; }
                                }
                                Vec2 ideal_safe_pos; bool has_safe_pos = false;
                                if (@shield_minion !is null && @player !is null)
                                {
                                    Vec2 shield_pos(shield_minion.x(), shield_minion.y()); Vec2 player_pos_val(player.x(), player.y()); Vec2 dir_from_player = (shield_pos - player_pos_val);
                                    if (dir_from_player.sqr_magnitude() > 1e-6) { dir_from_player.normalise(); ideal_safe_pos = shield_pos + dir_from_player * (shield_minion.hitbox_radius() + hitbox_radius() + 0.5f); has_safe_pos = true; }
                                }
                                Vec2 attack_target_pos(lowest_health_minion.x(), lowest_health_minion.y()); Vec2 final_target_pos;
                                if (has_safe_pos) { Vec2 dir_to_safe_pos = ideal_safe_pos - attack_target_pos; float dist_to_safe_pos = dir_to_safe_pos.magnitude(); if (dist_to_safe_pos > attack_range * 0.9f) { dir_to_safe_pos.normalise(); final_target_pos = attack_target_pos + dir_to_safe_pos * (attack_range * 0.9f); } else { final_target_pos = ideal_safe_pos; } }
                                else { if (@player !is null) { Vec2 player_pos_val(player.x(), player.y()); Vec2 dir_from_player = (attack_target_pos - player_pos_val); if(dir_from_player.sqr_magnitude() < 1e-6) { dir_from_player.set(0, -1); } dir_from_player.normalise(); final_target_pos = attack_target_pos + dir_from_player * (attack_range * 0.9f); } else { Vec2 dir_away = pos - attack_target_pos; dir_away.normalise(); final_target_pos = attack_target_pos + dir_away * (attack_range * 0.9f); } }
                                target_pos.set(final_target_pos.x + (rrnd.frand() - 0.5f) * 1.0f, final_target_pos.y + (rrnd.frand() - 0.5f) * 1.0f);
                            }
                            last_hit_reposition_timer = 12;
                        } else { // No friendly minions, push lane
                            state = CHAMP_STATE_PUSHING_LANE; has_target = true; Minion@ furthest_enemy_minion = null; float max_advancement = -1e9f;
                            for (uint i = 0; i < all_characters.length(); i++) {
                                 if (all_characters[i].getTeam() != Team::Enemy) continue; Minion@ minion = cast<Minion@>(all_characters[i]); if (@minion is null || minion.is_stationary) continue;
                                 Vec2 minion_pos(minion.x(), minion.y()); float advancement = dot(minion_pos, minion_travel_dir); if(advancement > max_advancement) { max_advancement = advancement; @furthest_enemy_minion = minion; }
                            }
                            if(@furthest_enemy_minion !is null) { target_pos.set(furthest_enemy_minion.x() + minion_travel_dir.x * 1.5, furthest_enemy_minion.y() + minion_travel_dir.y * 1.5); }
                            else { for (uint i = 0; i < all_characters.length(); i++) { if (all_characters[i].getTeam() != Team::Friendly) continue; Minion@ minion = cast<Minion@>(all_characters[i]); if (@minion is null && minion.is_stationary) { target_pos.set(minion.x(), minion.y()); break; } } }
                        }
                    } else { // Timer active, just keep moving
                        state = CHAMP_STATE_LAST_HITTING_POSITIONING;
                        has_target = true;
                    }
                }
            }
            
            // --- Action Execution ---
            switch(state)
            {
                case CHAMP_STATE_RUN:
                case CHAMP_STATE_REPOSITIONING:
                case CHAMP_STATE_LAST_HITTING_POSITIONING:
                case CHAMP_STATE_PUSHING_LANE:
                case CHAMP_STATE_RETREAT_FROM_MINIONS:
                {
                    MobaPlayer@ player_target_check = null;
                    if (@aggression_target !is null) { @player_target_check = cast<MobaPlayer@>(aggression_target.get_object()); }
                    if (@player_target_check !is null) { move(rrnd); } else { move_to_destination(); }
                    break;
                }
                case CHAMP_STATE_AUTO_ATTACK: execute_auto_attack(fx_list, rrnd); break;
                case CHAMP_STATE_LIGHT_ATTACK: execute_light_attack(fx_list, rrnd); break;
                case CHAMP_STATE_HEAVY_ATTACK:
                    // Logic is handled by the heavy_attack_active block
                    break;
                case CHAMP_STATE_BLINK_STARTUP:
                    state_timer += DT * 12;
                    if (state_timer >= BLINK_ANIMATION_DURATION_TIMER)
                    {
                        Vec2 start_pos = pos;
                        Vec2 direction_vec = blink_target_pos - pos;
                        if(abs(direction_vec.x) > 0.1) { face = direction_vec.x > 0 ? 1 : -1; }
                        
                        float distance = direction_vec.magnitude();
                        Vec2 final_pos;

                        if (distance > BLINK_MAX_RANGE) {
                            direction_vec.normalise();
                            final_pos = pos + direction_vec * BLINK_MAX_RANGE;
                        } else {
                            final_pos = blink_target_pos;
                        }
                        
                        // --- Create three after-images along the blink path ---
                        const float delay_step = 1; // 0.015s is ~1 frame

                        // After-image 1 (at 25% of the path), spawns instantly
                        Vec2 pos1 = start_pos + (final_pos - start_pos) * 0.25f;
                        after_images.insertLast(BlinkAfterImage(pos1, face, champion_sprite, 0));
                        
                        // After-image 2 (at 50% of the path), spawns after a delay
                        Vec2 pos2 = start_pos + (final_pos - start_pos) * 0.5f;
                        after_images.insertLast(BlinkAfterImage(pos2, face, champion_sprite, delay_step));

                        // After-image 3 (at 75% of the path), spawns after a further delay
                        Vec2 pos3 = start_pos + (final_pos - start_pos) * 0.75f;
                        after_images.insertLast(BlinkAfterImage(pos3, face, champion_sprite, delay_step * 2));

                        // Update champion position
                        pos = final_pos;

                        pos.x = clamp(pos.x, -world_bounds_x, world_bounds_y);
                        pos.y = clamp(pos.y, -world_bounds_y, world_bounds_y);
                        state = CHAMP_STATE_BLINK_ARRIVAL;
                        state_timer = 0;

                        // Restore pathing after blink
                        if(pre_blink_has_target)
                        {
                            target_pos.set(pre_blink_target_pos.x, pre_blink_target_pos.y);
                            has_target = true;
                        }
                    }
                    break;
                case CHAMP_STATE_BLINK_ARRIVAL:
                    state_timer += DT * 12;
                    
                    // Allow movement during arrival animation
                    if(has_target)
                    {
                        move_to_destination();
                    }

                    if (state_timer >= BLINK_ANIMATION_DURATION_TIMER) 
                    { 
                        state = has_target ? CHAMP_STATE_RUN : CHAMP_STATE_IDLE; 
                        state_timer = 0; 
                    }
                    break;
                case CHAMP_STATE_EVASIVE_MANEUVER:
                    move_to_destination();
                    if (state_timer > 15 || !has_target)
                    {
                        state = CHAMP_STATE_IDLE;
                        state_timer = 0;
                    }
                    break;
                case CHAMP_STATE_TAUNT:
                    taunt_timer -= DT * 60;
                    if (taunt_timer <= 0)
                    {
                        state = CHAMP_STATE_IDLE;
                        state_timer = 0;
                        break;
                    }

                    taunt_sub_state_timer -= DT * 60;
                    state_timer += DT * 12;

                    if (taunt_is_dancing)
                    {
                        const float frame_duration = (0.5 * 60) / 8.0;
                        uint current_frame = uint(floor(state_timer / frame_duration));
                        
                        if(current_frame >= victory_cancel_frame || taunt_sub_state_timer <= 0)
                        {
                            // Switch to moonwalking
                            taunt_is_dancing = false;
                            state_timer = 0;
                            taunt_sub_state_timer = 45 + rrnd.rand_range(0, 45); // Moonwalk for 0.75-1.5 seconds
                            // Set moonwalk direction away from player
                            moonwalk_direction = pos - player.pos;
                            if(moonwalk_direction.sqr_magnitude() > 1e-6) moonwalk_direction.normalise();
                            else moonwalk_direction.set(1, 0); // Fallback
                        }
                    }
                    else // Moonwalking
                    {
                        pos = pos + moonwalk_direction * 0.015;

                        if (taunt_sub_state_timer <= 0)
                        {
                            // Switch to dancing
                            taunt_is_dancing = true;
                            state_timer = 0;
                            taunt_sub_state_timer = 0.5 * 60; // Dance for max 0.5 seconds
                            victory_cancel_frame = rrnd.rand_range(3, 8);
                        }
                    }
                    break;
                case CHAMP_STATE_BLINK_TAUNT:
                    if(blink_taunt_phase == 0) // Phase 0: Initiate Blink
                    {
                        blink_target_pos = player.pos; 
                        state_timer = 0;
                        has_target = false;
                        blink_taunt_phase = 1;
                    }
                    else if(blink_taunt_phase == 1) // Phase 1: Blinking (Startup)
                    {
                        state_timer += DT * 12;
                        if (state_timer >= BLINK_ANIMATION_DURATION_TIMER)
                        {
                            // Teleport logic
                            Vec2 start_pos = pos;
                            Vec2 direction_vec = blink_target_pos - pos;
                            if(abs(direction_vec.x) > 0.1) { face = direction_vec.x > 0 ? 1 : -1; }
                            
                            float distance = direction_vec.magnitude();
                            Vec2 final_pos;
                            if (distance > BLINK_MAX_RANGE) { 
                                direction_vec.normalise(); 
                                final_pos = pos + direction_vec * BLINK_MAX_RANGE; 
                            } else { 
                                final_pos = blink_target_pos; 
                            }

                            // --- Create three after-images along the blink path ---
                            const float delay_step = 1; // 0.015s is ~1 frame

                            // After-image 1 (at 25% of the path), spawns instantly
                            Vec2 pos1 = start_pos + (final_pos - start_pos) * 0.25f;
                            after_images.insertLast(BlinkAfterImage(pos1, face, champion_sprite, 0));
                            
                            // After-image 2 (at 50% of the path), spawns after a delay
                            Vec2 pos2 = start_pos + (final_pos - start_pos) * 0.5f;
                            after_images.insertLast(BlinkAfterImage(pos2, face, champion_sprite, delay_step));

                            // After-image 3 (at 75% of the path), spawns after a further delay
                            Vec2 pos3 = start_pos + (final_pos - start_pos) * 0.75f;
                            after_images.insertLast(BlinkAfterImage(pos3, face, champion_sprite, delay_step * 2));

                            // Move the champion
                            pos = final_pos;

                            pos.x = clamp(pos.x, -world_bounds_x, world_bounds_y);
                            pos.y = clamp(pos.y, -world_bounds_y, world_bounds_y);
                            
                            state_timer = 0;
                            blink_taunt_phase = 2;
                        }
                    }
                    else if(blink_taunt_phase == 2) // Phase 2: First Victory Pose
                    {
                        state_timer += DT * 12;
                        if(state_timer >= 0.5 * 30)
                        {
                            state_timer = 0;
                            blink_taunt_phase = 3;
                            moonwalk_direction = pos - player.pos;
                            if(moonwalk_direction.sqr_magnitude() < 1e-6) { moonwalk_direction.set(1, 0); }
                            moonwalk_direction.normalise();
                            face = moonwalk_direction.x > 0 ? -1 : 1;
                        }
                    }
                    else if(blink_taunt_phase == 3) // Phase 3: Moonwalk Cancel
                    {
                        state_timer += DT * 12;
                        pos = pos + moonwalk_direction * 0.025;
                        if(state_timer >= 0.25 * 40)
                        {
                            state_timer = 0;
                            blink_taunt_phase = 4;
                        }
                    }
                    else if(blink_taunt_phase == 4) // Phase 4: Second Victory Pose
                    {
                        state_timer += DT * 12;
                        if(state_timer >= 1.0 * 20)
                        {
                            state = CHAMP_STATE_IDLE;
                            state_timer = 0;
                        }
                    }
                    break;
            }

            // Process particles and after-images
            for(int i = int(auto_attack_particles.length()) - 1; i >= 0; i--) { if(auto_attack_particles[i].step(fx_list, rrnd)) { auto_attack_particles.removeAt(i); } }
            for(int i = int(light_attack_particles.length()) - 1; i >= 0; i--)
            {
                AttackParticle@ particle = light_attack_particles[i]; particle.step(fx_list, rrnd);
                for (uint j = 0; j < all_characters.length(); j++)
                {
                    IDrawableCharacter@ character = all_characters[j]; if (character.getTeam() != Team::Friendly) continue;
                    enemy_base@ enemy = cast<enemy_base@>(character); if(@enemy is null) continue;
                    scriptenemy@ target_ent = null;
                    Minion@ minion_char = cast<Minion@>(character); if(@minion_char !is null) { @target_ent = @minion_char.self; } else { MobaPlayer@ player_char = cast<MobaPlayer@>(character); if(@player_char !is null) { @target_ent = @player_char.self; } }
                    if(@target_ent is null || target_ent.destroyed()) continue;
                    float dist_sq = dist_sqr(particle.pos.x, particle.pos.y, character.x(), character.y()); float combined_radius = particle.hitbox_radius + character.hitbox_radius();
                    if (dist_sq < combined_radius * combined_radius)
                    {
                        IDamageable@ damageable_target = cast<IDamageable@>(character); if (@damageable_target !is null) { damageable_target.take_damage(16, particle.pos, self); }
                        particle.life = 0; break;
                    }
                }
                if(particle.life <= 0) { light_attack_particles.removeAt(i); }
            }
            for(int i = int(heavy_attack_particles.length()) - 1; i >= 0; i--)
            {
                HeavyAttackParticle@ particle = heavy_attack_particles[i]; particle.step(fx_list, rrnd);
                for (uint j = 0; j < all_characters.length(); j++)
                {
                    IDrawableCharacter@ character = all_characters[j]; if (character.getTeam() != Team::Friendly) continue;
                    enemy_base@ enemy = cast<enemy_base@>(character); if(@enemy is null) continue;
                    scriptenemy@ target_ent = null;
                    Minion@ minion_char = cast<Minion@>(character); if(@minion_char !is null) { @target_ent = @minion_char.self; } else { MobaPlayer@ player_char = cast<MobaPlayer@>(character); if(@player_char !is null) { @target_ent = @player_char.self; } }
                    if(@target_ent is null || target_ent.destroyed() || particle.has_hit(target_ent.id())) continue;
                    float dist_sq = dist_sqr(particle.pos.x, particle.pos.y, character.x(), character.y()); float combined_radius = particle.width * 0.5 + character.hitbox_radius();
                    if (dist_sq < combined_radius * combined_radius)
                    {
                        IDamageable@ damageable_target = cast<IDamageable@>(character); if (@damageable_target !is null) { damageable_target.take_damage(35, particle.pos, self); particle.add_hit(target_ent.id()); }
                    }
                }
                if(particle.life <= 0) { heavy_attack_particles.removeAt(i); }
            }
            for(int i = int(after_images.length()) - 1; i >= 0; i--) { if(after_images[i].step()) { after_images.removeAt(i); } }

            state_timer += DT * 12;
            self.x(pos.x);
            self.y(pos.y);
        }
    void move_to_destination()
    {
        if(!has_target)
        {
            if(state == CHAMP_STATE_RUN || state == CHAMP_STATE_REPOSITIONING || state == CHAMP_STATE_LAST_HITTING_POSITIONING || state == CHAMP_STATE_PUSHING_LANE)
            {
                state = CHAMP_STATE_IDLE;
                state_timer = 0;
            }
            return;
        }
    
        float move_speed = 0.02;
        float dx = target_pos.x - pos.x;
        float dy = target_pos.y - pos.y;
        float dist = sqrt(dx * dx + dy * dy);
    
        if(dist < move_speed)
        {
            pos.set(target_pos.x, target_pos.y);
            has_target = false;
            if(state != CHAMP_STATE_AUTO_ATTACK && state != CHAMP_STATE_LIGHT_ATTACK && state != CHAMP_STATE_HEAVY_ATTACK)
            {
                state = CHAMP_STATE_IDLE;
                state_timer = 0;
            }
        }
        else
        {
            pos.x += (dx / dist) * move_speed;
            pos.y += (dy / dist) * move_speed;
            if(abs(dx) > 0.1) { face = dx > 0 ? 1 : -1; }
        }
    }

    void move(replay_rand@ rrnd)
    {
        if(!has_target) return;
        
        float move_speed = 0.02;

        if (@aggression_target !is null)
        {
            IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
            Vec2 target_current_pos(target_char.x(), target_char.y());
            float dist_to_target = distance(pos.x, pos.y, target_current_pos.x, target_current_pos.y);

            // Update repositioning logic
            if(reposition_timer <= 0)
            {
                reposition_timer = 120 + rrnd.frand() * 120; // Reposition every 2-4 seconds
                reposition_direction = rrnd.frand() > 0.5f ? 1.0f : -1.0f; // -1 for clockwise, 1 for counter-clockwise
            }

            Vec2 move_dir;
            
            // If too far, move towards the target but also strafe to approach at an angle
            if(dist_to_target > attack_range)
            {
                Vec2 to_target = target_current_pos - pos;
                to_target.normalise();
                Vec2 tangent(-to_target.y, to_target.x); // Perpendicular vector for strafing
                move_dir = to_target * 0.7f + tangent * reposition_direction * 0.3f;
            }
            // If in range, kite around the target
            else
            {
                Vec2 from_target_to_self = pos - target_current_pos;
                Vec2 tangent(-from_target_to_self.y, from_target_to_self.x); // Perpendicular vector for circling
                move_dir = tangent * reposition_direction;
                
                // Add a component to move away if too close, to maintain distance.
                if(dist_to_target < attack_range * 0.9f)
                {
                    from_target_to_self.normalise();
                    move_dir = move_dir + from_target_to_self;
                }
            }
            
            move_dir.normalise();
            
            pos.x += move_dir.x * move_speed;
            pos.y += move_dir.y * move_speed;
            
            // Face the target while moving
            if(abs(target_current_pos.x - pos.x) > 0.1) { face = (target_current_pos.x - pos.x) > 0 ? 1 : -1; }
        }
        else // No aggression target, so just move to the destination (e.g., furthest minion or safe spot)
        {
            float dx = target_pos.x - pos.x;
            float dy = target_pos.y - pos.y;
            float dist = sqrt(dx * dx + dy * dy);
            if(dist < move_speed)
            {
                pos.set(target_pos.x, target_pos.y);
                has_target = false;
                // Don't set state to IDLE here, let the main step logic handle state transitions
            }
            else
            {
                pos.x += (dx / dist) * move_speed;
                pos.y += (dy / dist) * move_speed;
                if(abs(dx) > 0.1) { face = dx > 0 ? 1 : -1; }
            }
        }
    }

    void execute_auto_attack(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        if(state_timer >= 3 && state_timer < 3.2 && attack_cooldown_timer <= 0)
        {
            if(@aggression_target !is null && !aggression_target.destroyed())
            {
                auto_attack_particles.insertLast(AutoAttackParticle(Vec3(pos.x, pos.y, 0.5), aggression_target, self, 0xFF44CCFF, 0.2f, 8.0f, 0xFF44CCFF, 0xFFADD8E6, 0.1f));
                attack_cooldown_timer = 45; // Cooldown
            }
        }
        if(state_timer >= 7)
        {
            state = CHAMP_STATE_RUN;
            state_timer = 0;
            // Only force repositioning if attacking the player.
            MobaPlayer@ player_target = null;
            if (@aggression_target !is null)
            {
                @player_target = cast<MobaPlayer@>(aggression_target.get_object());
            }
            if (@player_target !is null)
            {
                post_attack_move_timer = 20; // Move for 20 frames (1/3 second)
            }
        }
    }

    void execute_light_attack(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        if(state_timer >= 3 && state_timer < 3.2 && light_attack_cooldown_timer <= 0)
        {
            if(@aggression_target !is null && !aggression_target.destroyed())
            {
                current_mana -= light_attack_mana_cost;
                light_attack_cooldown_timer = light_attack_cooldown;

                IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                Vec2 target_current_pos(target_char.x(), target_char.y());
                Vec2 dir = target_current_pos - pos;
                dir.normalise();
                // UPDATED: Create light attack with blue trail particles
                light_attack_particles.insertLast(AttackParticle(Vec3(pos.x, pos.y, 0.4), Vec3(dir.x * 0.15, dir.y * 0.15, 0), self, 0xFF33AAAA, 0xFFCCFFFF));
                light_attack_particles[light_attack_particles.length()-1].colour = 0xFF44CCFF;
            }
        }
        if(state_timer >= 7)
        {
            state = CHAMP_STATE_RUN;
            state_timer = 0;
            // Only force repositioning if attacking the player.
            MobaPlayer@ player_target = null;
            if (@aggression_target !is null)
            {
                @player_target = cast<MobaPlayer@>(aggression_target.get_object());
            }
            if (@player_target !is null)
            {
                post_attack_move_timer = 20; // Move for 20 frames (1/3 second)
            }
        }
    }

    void execute_heavy_attack(array<ParticleFX@>@ fx_list, replay_rand@ rrnd)
    {
        if(state_timer >= 3 && state_timer < 3.2 && heavy_attack_cooldown_timer <= 0)
        {
            if(@aggression_target !is null && !aggression_target.destroyed())
            {
                current_mana -= heavy_attack_mana_cost;
                heavy_attack_cooldown_timer = heavy_attack_cooldown;

                IDrawableCharacter@ target_char = cast<IDrawableCharacter@>(aggression_target.get_object());
                Vec2 target_current_pos(target_char.x(), target_char.y());
                Vec2 dir = target_current_pos - pos;
                dir.normalise();
                // UPDATED: Create heavy attack with blue trail particles
                heavy_attack_particles.insertLast(HeavyAttackParticle(Vec3(pos.x, pos.y, 0.4), Vec3(dir.x * 0.15, dir.y * 0.15, 0), self, 0xFF33AAAA, 0xFFCCFFFF));
                heavy_attack_particles[heavy_attack_particles.length()-1].colour = 0xFF44CCFF;
            }
        }
        if(state_timer >= 7)
        {
            state = CHAMP_STATE_RUN;
            state_timer = 0;
            // Only force repositioning if attacking the player.
            MobaPlayer@ player_target = null;
            if (@aggression_target !is null)
            {
                @player_target = cast<MobaPlayer@>(aggression_target.get_object());
            }
            if (@player_target !is null)
            {
                post_attack_move_timer = 20; // Move for 20 frames (1/3 second)
            }
        }
    }


// In class Champion

    void draw(float sub_frame, IMobaCamera@ camera_provider, int sub_layer)
    {
        float interp_x = lerp(prev_pos.x, pos.x, sub_frame);
        float interp_y = lerp(prev_pos.y, pos.y, sub_frame);
        Vec2 cam_pos = camera_provider.get_camera_pos();
        Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
        float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
        float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);
        float screen_x, screen_y;
        camera_provider.project_to_screen(Vec3(interp_x, interp_y, 0), interp_camera_x, interp_camera_y, screen_x, screen_y);
        
        string sprite_name;
        uint frame;

        switch(state)
        {
            case CHAMP_STATE_RUN: 
            case CHAMP_STATE_REPOSITIONING: 
            case CHAMP_STATE_LAST_HITTING_POSITIONING:
            case CHAMP_STATE_PUSHING_LANE:
            case CHAMP_STATE_EVASIVE_MANEUVER:
            case CHAMP_STATE_RETREAT_FROM_MINIONS:
                sprite_name = "sprint"; 
                break;
            case CHAMP_STATE_LIGHT_ATTACK: sprite_name = "groundstrike1"; break;
            case CHAMP_STATE_HEAVY_ATTACK:
            {
                float t = state_timer;
                float crouch_duration = 0.05 * 60 * DT * 12;
                float rising1_duration = 0.1 * 60 * DT * 12;
                float rising2_duration = 0.05 * 60 * DT * 12;
                float airsmash1_duration = 0.3 * 60 * DT * 12;

                if (t < crouch_duration) {
                    sprite_name = "crouch";
                    frame = uint(floor(t / (crouch_duration / 3.0)));
                } else if (t < crouch_duration + rising1_duration) {
                    sprite_name = "rising";
                    frame = uint(floor((t - crouch_duration) / (rising1_duration / 3.0)));
                } else if (t < crouch_duration + rising1_duration + rising2_duration) {
                    sprite_name = "rising";
                    frame = uint(floor((t - crouch_duration - rising1_duration) / (rising2_duration / 3.0)));
                } else if (t < crouch_duration + rising1_duration + rising2_duration + airsmash1_duration) {
                    sprite_name = "airsmash";
                    frame = uint(floor((t - crouch_duration - rising1_duration - rising2_duration) / (airsmash1_duration / 5.0)));
                } else {
                    sprite_name = "airsmash";
                    frame = 5 + uint(floor((t - crouch_duration - rising1_duration - rising2_duration - airsmash1_duration) / (0.1 * 60 * DT * 12 / 8.0)));
                }
            }
                break;
            case CHAMP_STATE_AUTO_ATTACK: sprite_name = "groundstrike2"; break;
            case CHAMP_STATE_DEATH: sprite_name = death_animation_name; break;
            case CHAMP_STATE_BLINK_STARTUP:
                sprite_name = "crouch";
                frame = uint(floor(state_timer / (BLINK_ANIMATION_DURATION_TIMER / 3.0)));
                break;
            case CHAMP_STATE_BLINK_ARRIVAL:
                sprite_name = "dash";
                frame = uint(floor(state_timer / (BLINK_ANIMATION_DURATION_TIMER / 5.0)));
                break;
            case CHAMP_STATE_TAUNT:
                if(taunt_is_dancing)
                {
                    sprite_name = "victory";
                    const float frame_duration = (0.5 * 60) / 8.0;
                    frame = uint(floor(state_timer / frame_duration));
                }
                else // Moonwalking
                {
                    sprite_name = "sprint";
                    frame = uint(state_timer);
                    if(uint(state_timer) % 20 < 10)
                    {
                        face = -face;
                    }
                }
                break;
            case CHAMP_STATE_BLINK_TAUNT:
                if(blink_taunt_phase == 1)
                {
                    sprite_name = "crouch";
                    frame = uint(floor(state_timer / (BLINK_ANIMATION_DURATION_TIMER / 3.0)));
                }
                else if(blink_taunt_phase == 2 || blink_taunt_phase == 4) // Victory Poses
                {
                    sprite_name = "victory";
                    const float frame_duration = (0.5 * 60) / 8.0;
                    frame = uint(floor(state_timer / frame_duration));
                }
                else if(blink_taunt_phase == 3) // Moonwalking
                {
                    sprite_name = "sprint";
                    frame = uint(state_timer);
                }
                break;
            default: sprite_name = "idle";
        }
        
        if (state != CHAMP_STATE_BLINK_STARTUP && state != CHAMP_STATE_BLINK_ARRIVAL && state != CHAMP_STATE_HEAVY_ATTACK && state != CHAMP_STATE_TAUNT && state != CHAMP_STATE_BLINK_TAUNT)
        {
            frame = uint(state_timer);
            const int length = champion_sprite.get_animation_length(sprite_name);
            if(length > 0) frame = frame % length;
        }
        else if (state == CHAMP_STATE_TAUNT && !taunt_is_dancing)
        {
            const int length = champion_sprite.get_animation_length(sprite_name);
            if(length > 0) frame = frame % length;
        }
        else if (state == CHAMP_STATE_BLINK_TAUNT && blink_taunt_phase == 3)
        {
            const int length = champion_sprite.get_animation_length(sprite_name);
            if(length > 0) frame = frame % length;
        }


        champion_sprite.draw_hud(20, sub_layer, sprite_name, frame, 1, screen_x, screen_y, 0, float(face) * 0.8, 0.8, 0xFFFFFFFF);
        
        if (state == CHAMP_STATE_DEATH) return;
        
        const float total_width = level_icon_size + health_bar_width;
        const float start_x = screen_x - total_width / 2;
        const float health_y = screen_y + health_bar_y_offset;
        const float mana_y = health_y + health_bar_height + health_bar_outline;
        const float bars_total_height = health_bar_height + mana_bar_height + health_bar_outline;
        const float level_icon_y = health_y + (bars_total_height / 2) - (level_icon_size / 2);
        const float level_icon_x = start_x;
        const float bars_x = start_x + level_icon_size;

        g.draw_rectangle_hud(21, 23, level_icon_x - health_bar_outline, level_icon_y - health_bar_outline, level_icon_x + level_icon_size + health_bar_outline, level_icon_y + level_icon_size + health_bar_outline, 0, 0xFF000000);
        g.draw_rectangle_hud(21, 24, level_icon_x, level_icon_y, level_icon_x + level_icon_size, level_icon_y + level_icon_size, 0, level_icon_bg_colour);
        level_text.text('' + champion_level);
        level_text.colour(0xFFFFFFFF);
        level_text.draw_hud(21, 25, level_icon_x + level_icon_size / 2 - 1, level_icon_y + level_icon_size / 2 - 2, 1, 1, 0);

        // --- Draw Health Bar ---
        const float health_highlight_height = health_bar_height * 0.25f;
        // Outline
        g.draw_rectangle_hud(21, 23, bars_x - health_bar_outline, health_y - health_bar_outline, bars_x + health_bar_width + health_bar_outline, health_y + health_bar_height + health_bar_outline, 0, 0xFF000000);
        // Pending Damage Bar (single colour)
        g.draw_rectangle_hud(21, 24, bars_x, health_y, bars_x + health_bar_width * (pending_damage_health / max_health), health_y + health_bar_height, 0, 0xFFFFFF00); // Yellow
        // Current Health Bar
        const float current_health_width = health_bar_width * (current_health / max_health);
        // Main Part
        g.draw_rectangle_hud(21, 25, bars_x, health_y + health_highlight_height, bars_x + current_health_width, health_y + health_bar_height, 0, 0xFFfc2d2d); // Red
        // Highlight Part
        g.draw_rectangle_hud(21, 25, bars_x, health_y, bars_x + current_health_width, health_y + health_highlight_height, 0, 0xFFff5252); // Lighter Red
        
        if (health_tick_interval > 0)
        {
            const float tick_width = health_bar_outline;
            const float tick_height = health_bar_height * 0.75f;
            for (float i = health_tick_interval; i < max_health; i += health_tick_interval)
            {
                const float tick_x = bars_x + (i / max_health) * health_bar_width;
                g.draw_rectangle_hud(21, 26, tick_x - tick_width / 2, health_y, tick_x + tick_width / 2, health_y + tick_height, 0, 0xFF000000);
            }
        }

        // --- Draw Mana Bar ---
        const float mana_highlight_height = mana_bar_height * 0.5f;
        // Outline
        g.draw_rectangle_hud(21, 23, bars_x - health_bar_outline, mana_y - health_bar_outline, bars_x + health_bar_width + health_bar_outline, mana_y + mana_bar_height + health_bar_outline, 0, 0xFF000000);
        // Pending Mana Bar (single colour)
        const float pending_mana_percentage = pending_mana_cost / max_mana;
        g.draw_rectangle_hud(21, 24, 
            bars_x, mana_y, 
            bars_x + health_bar_width * pending_mana_percentage, mana_y + mana_bar_height, 
            0, 0xFF8FD7FF);
        // Current Mana Bar
        const float current_mana_width = health_bar_width * (current_mana / max_mana);
        // Main Part
        g.draw_rectangle_hud(21, 25, bars_x, mana_y + mana_highlight_height, bars_x + current_mana_width, mana_y + mana_bar_height, 0, 0xFF228BFC);
        // Highlight Part
        g.draw_rectangle_hud(21, 25, bars_x, mana_y, bars_x + current_mana_width, mana_y + mana_highlight_height, 0, 0xFF3595fc);


        for(uint i = 0; i < after_images.length(); i++)
        {
            after_images[i].draw(sub_frame, camera_provider, sub_layer - 1);
        }

        for(uint i = 0; i < auto_attack_particles.length(); i++)
        {
            auto_attack_particles[i].draw(g, sub_frame, camera_provider);
        }
        for(uint i = 0; i < light_attack_particles.length(); i++)
        {
            light_attack_particles[i].draw(g, sub_frame, camera_provider);
        }
        for(uint i = 0; i < heavy_attack_particles.length(); i++)
        {
            heavy_attack_particles[i].draw(g, sub_frame, camera_provider);
        }
    }

};

// Helper to draw a projected circle on the ground plane
void draw_filled_ground_circle(scene@ g, int layer, int sub_layer, IMobaCamera@ camera_provider, float sub_frame, float cx, float cy, float radius, uint segments, uint colour)
{
    if(segments < 3) segments = 3;
    
    Vec2 cam_pos = camera_provider.get_camera_pos();
    Vec2 prev_cam_pos = camera_provider.get_prev_camera_pos();
    float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
    float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);

    float center_sx, center_sy;
    camera_provider.project_to_screen(Vec3(cx, cy, 0), interp_camera_x, interp_camera_y, center_sx, center_sy);

    float prev_screen_x, prev_screen_y;
    float angle = 0;
    const float angle_step = PI * 2 / segments;

    // Calculate the first point before the loop to initialize prev_screen variables
    float first_world_x = cx + cos(angle) * radius;
    float first_world_y = cy + sin(angle) * radius;
    camera_provider.project_to_screen(Vec3(first_world_x, first_world_y, 0), interp_camera_x, interp_camera_y, prev_screen_x, prev_screen_y);
    angle += angle_step;

    for(uint i = 1; i <= segments; i++)
    {
        float world_x = cx + cos(angle) * radius;
        float world_y = cy + sin(angle) * radius;
        
        float screen_x, screen_y;
        camera_provider.project_to_screen(Vec3(world_x, world_y, 0), interp_camera_x, interp_camera_y, screen_x, screen_y);

        g.draw_quad_hud(layer, sub_layer, false,
            center_sx, center_sy,
            prev_screen_x, prev_screen_y,
            screen_x, screen_y,
            screen_x, screen_y,
            colour, colour, colour, colour);
            
        prev_screen_x = screen_x;
        prev_screen_y = screen_y;
        angle += angle_step;
    }
}

class script
{
    scene@ g;
    array<scriptenemy@> minions;
    array<scriptenemy@> champions;
    [text] bool draw_hitboxes = true;
    [text] bool draw_pathing_hitboxes = false;
    [text] bool draw_right_click_hitboxes = true;
    // -- Horde Mode Variables --
    [text] bool horde_mode = false;
    [hidden] int minions_killed = 0;
    [hidden] int horde_minions_alive = 0;
    float click_precision = 10;
    // --- New Wave Spawning Logic ---
    array<Wave@> waves;
    array<SpawnPoint@> spawn_points_enemy;
    array<SpawnPoint@> spawn_points_friendly;
    [hidden] int right_click_count = 0;
    bool champion_spawned = false;
    
    // Gold indicator list
    array<GoldIndicator@> gold_indicators;
    
    // Replay-compatible randomness
    replay_rand rrnd;
    
    // Replay cursor tracker
    ReplayCursor replay_cursor;
    
    // Champion death counter
    int champion_deaths = 0;
    
    // Fountain and player reference
    Fountain@ fountain;
    MobaPlayer@ player_logic_ref;
    
    // Configurable fountain position
    float fountain_pos_x = -8.0;
    float fountain_pos_y = -8.0;

    script()
    {
        @g = get_scene();
        setup_waves();
    }
	
    void on_horde_minion_killed()
    {
        if (horde_mode)
        {
            minions_killed++;
            horde_minions_alive--;
        }
    }
	
    // Helper method to spawn a single horde minion.
    void spawn_horde_minion(scriptenemy@ player_ent)
    {
        MobaPlayer@ player_logic = cast<MobaPlayer@>(player_ent.get_object());
        if (@player_logic is null) return;

        // Calculate a random spawn position around the player
        float angle = rrnd.rand_range(0.0f, 360.0f);
        float dist = rrnd.rand_range(HORDE_SPAWN_MIN_RADIUS, HORDE_SPAWN_MAX_RADIUS);
        Vec2 spawn_pos(player_logic.pos.x + cos(angle * DEG2RAD) * dist,
                       player_logic.pos.y + sin(angle * DEG2RAD) * dist);

        // Configuration for horde minions (1 health)
        MinionSpawnConfig@ horde_config = MinionSpawnConfig(
            Team::Enemy, 100.0f, 1.0f, 1.0f, // team, range, damage, health
            false, 0.64f, // is_stationary, sprite_scale
            40, 5, // health_bar_width, health_bar_height
            0.1f, 0.05f, 0.3f, 35.0f, // particle size, speed, height, cooldown
            50, 50 // right_click_hitbox
        );

        spawn_minion(spawn_pos, horde_config, player_logic.pos, -1, true, player_ent);
        horde_minions_alive++;
    }
	
    // Method to be called when the champion dies
    void on_champion_death()
    {
        champion_deaths++;
        if (champion_deaths >= 2)
        {
            controllable@ p = controller_controllable(0);
            if (@p !is null)
            {
                g.end_level(p.x(), p.y());
            }
            else
            {
                g.end_level(0, 0);
            }
        }
    }

    void setup_waves()
    {
        spawn_points_enemy.insertLast(SpawnPoint(7.0, 7.0));
        
        array<MinionSpawnConfig@> enemy_wave_configs;
        // Melee minions
        for(int i = 0; i < 3; i++) { enemy_wave_configs.insertLast(MinionSpawnConfig(Team::Enemy, 1.5f, 1.0f, 60.0f, false, 0.64f, 40, 5, 0.1f, 0.05f, 0.3f, 35.0f, 50, 50)); }
        // Ranged minions
        for(int i = 0; i < 3; i++) { enemy_wave_configs.insertLast(MinionSpawnConfig(Team::Enemy, 3.0f, 1.2f, 50.0f, false, 0.64f, 40, 5, 0.1f, 0.05f, 0.3f, 35.0f, 50, 50)); }
        waves.insertLast(Wave(enemy_wave_configs, 1.0f, spawn_points_enemy, Team::Enemy));
        
        spawn_points_friendly.insertLast(SpawnPoint(-7.0, -7.0));
        
        array<MinionSpawnConfig@> friendly_wave_configs;
        // Melee minions
        for(int i = 0; i < 3; i++) { friendly_wave_configs.insertLast(MinionSpawnConfig(Team::Friendly, 1.5f, 1.0f, 60.0f, false, 0.64f, 40, 5, 0.1f, 0.05f, 0.3f, 35.0f, 50, 50)); }
        // Ranged minions
        for(int i = 0; i < 3; i++) { friendly_wave_configs.insertLast(MinionSpawnConfig(Team::Friendly, 3.0f, 1.2f, 50.0f, false, 0.64f, 40, 5, 0.1f, 0.05f, 0.3f, 35.0f, 50, 50)); }
        waves.insertLast(Wave(friendly_wave_configs, 1.0f, spawn_points_friendly, Team::Friendly));
    }

    void on_level_start()
    {
        if (horde_mode) {
            // Horde mode setup
            if(@fountain == null && @player_logic_ref != null)
            {
                @fountain = Fountain(Vec3(fountain_pos_x, fountain_pos_y, 0.0f), player_logic_ref, @rrnd);
            }
            // No turrets or initial waves in horde mode.
        } else {
            // Original logic
            if(@fountain == null && @player_logic_ref != null)
            {
                @fountain = Fountain(Vec3(fountain_pos_x, fountain_pos_y, 0.0f), player_logic_ref, @rrnd);
            }

            MinionSpawnConfig@ friendly_turret_config = MinionSpawnConfig(Team::Friendly, 5.0f, 20.0f, 500.0f, true);
            MinionSpawnConfig@ enemy_turret_config = MinionSpawnConfig(Team::Enemy, 5.0f, 20.0f, 500.0f, true);

            spawn_minion(Vec2(-5.0, -5.0), friendly_turret_config, spawn_points_enemy[0].pos, -1);
            spawn_minion(Vec2(5.0, 5.0), enemy_turret_config, spawn_points_friendly[0].pos, -1);
            
            if (!champion_spawned)
            {
                spawn_champion(Vec2(7.0, 7.0));
                champion_spawned = true;
            }

            waves[0].active = true;
            waves[1].active = true;
        }
    }
    
	void spawn_minion(Vec2 pos, MinionSpawnConfig@ config, Vec2 destination, int wave_index, bool is_horde = false, scriptenemy@ player_ref = null)
	{
		Minion@ minion_logic = Minion(config, is_horde, player_ref);
		minion_logic.pos.set(pos.x, pos.y);
		minion_logic.final_destination = destination;
		minion_logic.wave_index = wave_index;
		scriptenemy@ minion_ent = create_scriptenemy(@minion_logic);
		minions.insertLast(minion_ent);
		g.add_entity(minion_ent.as_entity());
	}

    void spawn_champion(Vec2 pos)
    {
        Champion@ champion_logic = Champion();
        scriptenemy@ champion_ent = create_scriptenemy(@champion_logic);
        champion_ent.x(pos.x);
        champion_ent.y(pos.y);
        champions.insertLast(champion_ent);
        g.add_entity(champion_ent.as_entity());
    }
    
    void spawn_player(message@ msg)
    {
        @player_logic_ref = MobaPlayer();
        scriptenemy@ player_ent = create_scriptenemy(@player_logic_ref);
        
        if (horde_mode) {
            // Center the player for horde mode
            player_ent.x(0);
            player_ent.y(0);
            player_logic_ref.pos.set(0, 0);
            player_logic_ref.prev_pos.set(0, 0);
            player_logic_ref.spawn_position.set(0, 0);
        } else {
            // Original spawn logic
            player_ent.x(msg.get_float("x"));
            player_ent.y(msg.get_float("y"));
        }
        
        msg.set_entity("player", @player_ent.as_entity());
    }
    
    void add_gold_indicator(Vec3 pos)
    {
        gold_indicators.insertLast(GoldIndicator(pos));
    }
    
    void step(int /*entities*/)
    {
        rrnd.step();
        if (!rrnd.is_ready()) return;

        // -- START of Horde Mode Logic --
        if (horde_mode) {
            if (minions_killed >= HORDE_KILL_GOAL) {
                controllable@ p = controller_controllable(0);
                if (@p !is null) {
                    g.end_level(p.x(), p.y());
                } else {
                    g.end_level(0, 0);
                }
                return; // End of game
            }

            controllable@ p = controller_controllable(0);
            if (@p !is null) {
                scriptenemy@ player_ent = p.as_scriptenemy();
                if (@player_ent !is null) {
                    // Spawn initial wave
                    if (horde_minions_alive == 0 && minions_killed == 0) {
                        for (int i = 0; i < HORDE_INITIAL_MINIONS; i++) {
                            spawn_horde_minion(player_ent);
                        }
                    }
                    // Spawn more minions if below the cap
                    else if (horde_minions_alive < HORDE_MAX_MINIONS) {
                        spawn_horde_minion(player_ent);
                    }
                }
            }
        }

        // Step the fountain logic
        if(@fountain != null)
        {
            fountain.step();
        }

        controllable@ p = controller_controllable(0);
        if(@p is null) return;
        scriptenemy@ se = p.as_scriptenemy();
        if(@se is null) return;
        MobaPlayer@ player_logic = cast<MobaPlayer@>(se.get_object());
        if(@player_logic is null) return;

        // --- Wave Spawning ---
        for (uint i = 0; i < waves.length(); i++)
        {
            Wave@ wave = waves[i];
            if (wave.active && wave.minions_spawned < int(wave.minions_config.length()))
            {
                wave.spawn_timer -= DT;
                if (wave.spawn_timer <= 0)
                {
                    MinionSpawnConfig@ config = wave.minions_config[wave.minions_spawned];
                    SpawnPoint@ sp = wave.spawn_points[rrnd.rand_range(0, wave.spawn_points.length())];
                    
                    Vec2 destination;
                    if(config.team == Team::Enemy)
                    {
                        destination = spawn_points_friendly[0].pos;
                    }
                    else
                    {
                        destination = spawn_points_enemy[0].pos;
                    }
                    spawn_minion(sp.pos, config, destination, i);
                    
                    wave.minions_spawned++;
                    wave.spawn_timer = wave.spawn_delay;
                }
            }
        }
        
        // Build the list of all characters for collision detection
        array<IDrawableCharacter@> all_characters;
        all_characters.insertLast(player_logic);
        for (uint i = 0; i < minions.length(); i++)
        {
            if(minions[i].destroyed())
            {
                minions.removeAt(i);
                i--;
                continue;
            }
            IDrawableCharacter@ minion_char = cast<IDrawableCharacter@>(minions[i].get_object());
            if (@minion_char !is null)
            {
                all_characters.insertLast(minion_char);
            }
        }
        for (uint i = 0; i < champions.length(); i++)
        {
            if(champions[i].destroyed())
            {
                champions.removeAt(i);
                i--;
                continue;
            }
            IDrawableCharacter@ champ_char = cast<IDrawableCharacter@>(champions[i].get_object());
            if (@champ_char !is null)
            {
                all_characters.insertLast(champ_char);
            }
        }
        
        // --- Check for next wave condition ---
        for (uint i = 0; i < waves.length(); i++)
        {
            Wave@ wave = waves[i];
            if (wave.active && wave.minions_spawned >= int(wave.minions_config.length()))
            {
                bool wave_cleared = true;
                for (uint j = 0; j < minions.length(); j++)
                {
                    Minion@ minion_logic = cast<Minion@>(minions[j].get_object());
                    if (@minion_logic !is null && minion_logic.wave_index == int(i))
                    {
                        wave_cleared = false;
                        break;
                    }
                }

                if (wave_cleared)
                {
                    // Respawn this wave
                    wave.minions_spawned = 0;
                    wave.spawn_timer = 0;
                }
            }
        }

        // Update player
        player_logic.step(minions, champions, @rrnd);

        // Apply fountain healing after player step
        if(@fountain != null && @player_logic_ref != null && player_logic_ref.state != P_STATE_DEATH)
        {
            if(fountain.is_inside(player_logic_ref.pos))
            {
                // Regenerate health
                if(player_logic_ref.current_health < player_logic_ref.max_health)
                {
                    player_logic_ref.current_health += player_logic_ref.FOUNTAIN_HEAL_RATE * DT;
                    if(player_logic_ref.current_health > player_logic_ref.max_health)
                    {
                        player_logic_ref.current_health = player_logic_ref.max_health;
                    }
                }
                // Regenerate mana
                if(player_logic_ref.current_mana < player_logic_ref.max_mana)
                {
                    player_logic_ref.current_mana += player_logic_ref.FOUNTAIN_MANA_RATE * DT;
                    if(player_logic_ref.current_mana > player_logic_ref.max_mana)
                    {
                        player_logic_ref.current_mana = player_logic_ref.max_mana;
                    }
                }
            }
        }

        // Update minions
        for (uint i = 0; i < minions.length(); i++)
        {
            Minion@ minion_logic = cast<Minion@>(minions[i].get_object());
            if (@minion_logic !is null)
            {
                minion_logic.step(all_characters, player_logic.fx_list, @rrnd);
            }
        }

        // Update champions
        for (uint i = 0; i < champions.length(); i++)
        {
            Champion@ champion_logic = cast<Champion@>(champions[i].get_object());
            if (@champion_logic !is null)
            {
                // MODIFIED: Pass the player object to the champion's step for advanced AI checks
                champion_logic.step(all_characters, player_logic, player_logic.fx_list, @rrnd);
            }
        }
        // --- NEW: Process the global particle effects list here ---
        for(int i = int(player_logic.fx_list.length()) - 1; i >= 0; i--)
        {
            player_logic.fx_list[i].step();
            if(player_logic.fx_list[i].life <= 0) 
            { 
                player_logic.fx_list.removeAt(i); 
            }
        }

        // Update gold indicators
        for(int i = int(gold_indicators.length()) - 1; i >= 0; i--)
        {
            if(gold_indicators[i].step())
            {
                gold_indicators.removeAt(i);
            }
        }
    }
    
    void draw(float sub_frame)
    {
        controllable@ p = controller_controllable(0);
        if(@p is null) return;
        scriptenemy@ se = p.as_scriptenemy();
        if(@se is null) return;
        MobaPlayer@ player_logic = cast<MobaPlayer@>(se.get_object());
        if(@player_logic is null) return;
        
        // Draw the fountain
        if(@fountain != null)
        {
            fountain.draw(sub_frame);
        }

        array<IDrawableCharacter@> all_characters;
        all_characters.insertLast(player_logic);
        for (uint i = 0; i < minions.length(); i++)
        {
            if(minions[i].destroyed())
            {
                minions.removeAt(i);
                i--;
                continue;
            }
            IDrawableCharacter@ minion_char = cast<IDrawableCharacter@>(minions[i].get_object());
            if (@minion_char !is null)
            {
                all_characters.insertLast(minion_char);
            }
        }
        for (uint i = 0; i < champions.length(); i++)
        {
            if(champions[i].destroyed())
            {
                champions.removeAt(i);
                i--;
                continue;
            }
            IDrawableCharacter@ champ_char = cast<IDrawableCharacter@>(champions[i].get_object());
            if (@champ_char !is null)
            {
                all_characters.insertLast(champ_char);
            }
        }

        // Manual insertion sort for layering
        for (uint i = 1; i < all_characters.length(); i++)
        {
            IDrawableCharacter@ key = all_characters[i];
            int j = int(i) - 1;

            // Sort descending by y-coordinate
            while (j >= 0 && all_characters[j].y() < key.y())
            {
                @all_characters[j + 1] = @all_characters[j];
                j = j - 1;
            }
            @all_characters[j + 1] = @key;
        }

        for (uint i = 0; i < all_characters.length(); i++)
        {
            IDrawableCharacter@ character = all_characters[i];
            character.draw(sub_frame, player_logic, i + 1);

            if(draw_hitboxes)
            {
                float interp_char_x = lerp(character.prev_x(), character.x(), sub_frame);
                float interp_char_y = lerp(character.prev_y(), character.y(), sub_frame);
                
                draw_filled_ground_circle(g, 21, 0, player_logic, sub_frame, interp_char_x, interp_char_y, character.hitbox_radius(), 16, 0x44FFFFFF);
            }
            
            if(draw_pathing_hitboxes)
            {
                Minion@ minion_char = cast<Minion@>(character);
                if(@minion_char !is null)
                {
                    float interp_char_x = lerp(character.prev_x(), character.x(), sub_frame);
                    float interp_char_y = lerp(character.prev_y(), character.y(), sub_frame);
                    draw_filled_ground_circle(g, 21, 1, player_logic, sub_frame, interp_char_x, interp_char_y, minion_char.pathing_hitbox_radius(), 16, 0x44FF0000);
                }
            }
            
            if(draw_right_click_hitboxes && character.getTeam() == Team::Enemy)
            {
                float width = 0, height = 0;
                bool is_enemy = false;

                Minion@ minion_char = cast<Minion@>(character);
                if(@minion_char !is null)
                {
                    width = minion_char.right_click_hitbox_width;
                    height = minion_char.right_click_hitbox_height;
                    is_enemy = true;
                }
                else
                {
                    Champion@ champ_char = cast<Champion@>(character);
                    if(@champ_char !is null)
                    {
                        width = champ_char.right_click_hitbox_width;
                        height = champ_char.right_click_hitbox_height;
                        is_enemy = true;
                    }
                }

                if(is_enemy)
                {
                    float interp_char_x = lerp(character.prev_x(), character.x(), sub_frame);
                    float interp_char_y = lerp(character.prev_y(), character.y(), sub_frame);
                    float screen_x, screen_y;
                    
                    Vec2 cam_pos = player_logic.get_camera_pos();
                    Vec2 prev_cam_pos = player_logic.get_prev_camera_pos();
                    float interp_camera_x = lerp(prev_cam_pos.x, cam_pos.x, sub_frame);
                    float interp_camera_y = lerp(prev_cam_pos.y, cam_pos.y, sub_frame);

                    player_logic.project_to_screen(Vec3(interp_char_x, interp_char_y, 0), interp_camera_x, interp_camera_y, screen_x, screen_y);

                    float hw = width * 0.5f;
                    g.draw_rectangle_hud(22, 22, screen_x - hw, screen_y - height, screen_x + hw, screen_y, 0, 0x88FF0000);
                }
            }
        }
        for(uint i = 0; i < player_logic.fx_list.length(); i++)
        {
            player_logic.fx_list[i].draw(g, sub_frame, player_logic);
        }
        // Draw gold indicators
        for(uint i = 0; i < gold_indicators.length(); i++)
        {
            gold_indicators[i].draw(g, sub_frame, player_logic);
        }
        
        // Draw replay cursor
        replay_cursor.draw(sub_frame, player_logic);
    }
};