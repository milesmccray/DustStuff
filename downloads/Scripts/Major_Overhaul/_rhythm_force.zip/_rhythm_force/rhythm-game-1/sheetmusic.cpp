class Enemy {
  float song_position;
  float beat;
  bool heavy = false;
  bool teleported = false;
  bool hit = false;

  // position indexes are mapped in the following way:
  // 0 -> left
  // 1 -> right
  // 2 -> upleft
  // 3 -> upright
  int spawn_position = 0;

  int entity_id;
  entity@ entity;

  bool second = false;

  Enemy( float beat, int spawn_position, bool heavy = false ) {
    this.beat = beat;
    this.spawn_position = spawn_position;
    this.heavy = heavy;
  }

  Enemy() {}
}

class Wave {
  int measure;
  array<Enemy@> enemies = {};

  Wave( int measure, array<Enemy@> enemies ) {
    this.measure = measure;
    this.enemies = enemies;
  }
  Wave() {}
}

array<Wave@> get_waves() {
  return array<Wave@> = {
    // Shoot 'Em Up 1 Tabs
    Wave( 1, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 3, 1 ),
    } ),

    Wave( 3, array<Enemy@> = {
      Enemy( 1, 2 ),
      Enemy( 3, 3 ),
    } ),

    Wave( 5, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 3, 2 ),
      Enemy( 4, 3 ),
    } ),
    Wave( 7, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 3, 2 ),
      Enemy( 4, 3 ),
    } ),
    Wave( 9, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 3, 2 ),
      Enemy( 4, 3 ),
    } ),
    Wave( 11, array<Enemy@> = {
      Enemy( 2, 2 ),
      Enemy( 4, 3 )
    } ),

    Wave( 13, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 2.5, 2 ),
      Enemy( 3.5, 3 ),
    } ),
    Wave( 15, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 2.5, 2 ),
      Enemy( 3.5, 3 ),
    } ),
    Wave( 17, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 2.5, 2 ),
      Enemy( 3.5, 3 ),
    } ),
    Wave( 19, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 2, 1 ),
      Enemy( 2.5, 2 ),
      Enemy( 3.5, 3 ),
    } ),

    Wave( 23, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3.5, 2 ),
    } ),
    Wave( 25, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),

      Enemy( 4, 3 ),
      Enemy( 4.5, 3 ),
    } ),
    Wave( 27, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3.5, 2 ),
    } ),
    Wave( 29, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),

      Enemy( 4, 3 ),
    } ),

    Wave( 31, array<Enemy@> = {
      Enemy( 1, 0 ),

      Enemy( 2, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),
    } ),
    Wave( 33, array<Enemy@> = {
      Enemy( 1, 0 ),

      Enemy( 2, 1 ),

      Enemy( 3, 2 ),

      Enemy( 3.5, 3 ),
    } ),
    Wave( 35, array<Enemy@> = {
      Enemy( 1, 0 ),

      Enemy( 2, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),
    } ),
    Wave( 37, array<Enemy@> = {
      Enemy( 1, 0 ),

      Enemy( 2, 1 ),

      Enemy( 3, 2 ),

      Enemy( 3.5, 3 ),
    } ),

    Wave( 41, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),

      Enemy( 4, 3 ),
      Enemy( 4.5, 3 ),
    } ),
    Wave( 43, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),

      Enemy( 4, 3 ),
      Enemy( 4.5, 3 ),
    } ),
    Wave( 45, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),
      Enemy( 3.5, 2 ),

      Enemy( 4, 3 ),
      Enemy( 4.5, 3 ),
    } ),
    Wave( 47, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.5, 0 ),

      Enemy( 2, 1 ),
      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),

      Enemy( 3.5, 3 ),
      Enemy( 4, 3 ),
    } ),

    Wave( 49, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.75, 0 ),

      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),
    } ),
    Wave( 51, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.75, 0 ),

      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),

      Enemy( 4, 3 ),
    } ),
    Wave( 53, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.75, 0 ),

      Enemy( 2.5, 1 ),

      Enemy( 3, 2 ),

      Enemy( 4, 3 ),
    } ),
    Wave( 55, array<Enemy@> = {
      Enemy( 1, 0 ),
      Enemy( 1.75, 0 ),

      Enemy( 2.5, 1 ),
      Enemy( 3, 1 ),

      Enemy( 3.75, 2 ),

      Enemy( 4.5, 3 ),
    } ),

    Wave( 57, array<Enemy@> = {
      Enemy( 3.5, 0 ),
      Enemy( 4, 1 ),

      Enemy( 4.5, 2 ),
    } ),

    // // Shoot 'Em Up 2 Tabs
    // Wave( 1, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 3, 1 ),
    // } ),

    // Wave( 3, array<Enemy@> = {
    //   Enemy( 1, 2 ),
    //   Enemy( 3, 3 ),
    // } ),

    // Wave( 5, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),
    // Wave( 7, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),
    // Wave( 9, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),
    // Wave( 11, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),
    //   Enemy( 4, 3 )
    // } ),

    // Wave( 13, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 1, true ),
    //   Enemy( 2.5, 2 ),
    //   Enemy( 3, 3 ),
    // } ),
    // Wave( 15, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 1 ),
    //   Enemy( 2.5, 2 ),
    //   Enemy( 3, 3, true ),
    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 17, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 1, true ),
    //   Enemy( 2.5, 2 ),
    //   Enemy( 3, 3 ),
    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 19, array<Enemy@> = {
    //   Enemy( 1, 0, true ),
    //   Enemy( 1.75, 1 ),
    //   Enemy( 2.5, 2 ),
    //   Enemy( 3, 2, true ),
    //   Enemy( 3.75, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 23, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.25, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.25, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.25, 2 ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3 ),
    // } ),
    // Wave( 25, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.25, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.25, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.25, 2 ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3 ),
    // } ),
    // Wave( 27, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.25, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.25, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.25, 2 ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3 ),
    // } ),
    // Wave( 29, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.25, 0, true ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.25, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.25, 2, true ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3, true ),
    // } ),

    // Wave( 31, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 33, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1, true ),

    //   Enemy( 3, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 35, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 37, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4.5, 3, true ),
    // } ),

    // Wave( 41, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 43, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 45, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 47, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 49, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 0 ),

    //   Enemy( 2.75, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 51, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 0 ),

    //   Enemy( 2.75, 1 ),

    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 53, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 0 ),

    //   Enemy( 2.75, 1 ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),
    // Wave( 55, array<Enemy@> = {
    //   Enemy( 1.5, 0, true ),
    //   Enemy( 2, 0 ),

    //   Enemy( 2.75, 1, true ),

    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3, true ),
    //   Enemy( 4.75, 3 ),
    // } ),

    // Wave( 57, array<Enemy@> = {
    //   Enemy( 3.5, 0 ),
    //   Enemy( 4, 1 ),

    //   Enemy( 4.5, 2 ),
    // } ),

    // // MASTER Tabs
    // Wave( 5, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1, true ),
    //   Enemy( 2.5, 1, true ),
    //   Enemy( 3, 2, true ),
    //   Enemy( 3.5, 2, true ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 7, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0, true ),
    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 2, true ),
    //   Enemy( 3.5, 2, true ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 9, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),
    //   Enemy( 2, 1, true ),
    //   Enemy( 2.75, 1 ),
    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),
    //   Enemy( 4, 3, true ),
    //   Enemy( 4.5, 3, true ),
    // } ),

    // Wave( 11, array<Enemy@> = {
    //   Enemy( 1, 0, true ),
    //   Enemy( 1.75, 0 ),

    //   Enemy( 2.75, 1 ),
    //   Enemy( 3, 1, true ),

    //   Enemy( 3.25, 2 ),
    //   Enemy( 3.75, 2 ),
    //   Enemy( 4, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 13, array<Enemy@> = {
    //   Enemy( 1, 0 ),

    //   Enemy( 1.5, 1, true ),
    //   Enemy( 1.75, 1 ),

    //   Enemy( 2.5, 2 ),

    //   Enemy( 3, 3 ),
    // } ),

    // Wave( 15, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 0 ),

    //   Enemy( 2.5, 1 ),
    //   Enemy( 2.75, 1, true ),

    //   Enemy( 3, 2 ),

    //   Enemy( 4, 3, true ),
    // } ),

    // Wave( 17, array<Enemy@> = {
    //   Enemy( 1, 0 ),

    //   Enemy( 1.5, 1, true ),
    //   Enemy( 1.75, 1 ),

    //   Enemy( 2.5, 2 ),
    //   Enemy( 3, 3 ),
    // } ),

    // Wave( 19, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 0, true ),

    //   Enemy( 2.5, 1 ),
    //   Enemy( 3, 1 ),

    //   Enemy( 3.75, 2, true ),
    //   Enemy( 4.25, 2 ),

    //   Enemy( 4.5, 3 ),
    //   Enemy( 4.75, 3 ),
    // } ),

    // Wave( 23, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0, true ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3, true ),
    // } ),

    // Wave( 25, array<Enemy@> = {
    //   Enemy( 1, 0, true ),
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2, 1, true ),
    //   Enemy( 2.25, 1 ),

    //   Enemy( 3, 2, true ),
    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3, true ),
    //   Enemy( 4.25, 3 ),
    // } ),

    // Wave( 27, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0, true ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.5, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4, 3 ),
    //   Enemy( 4.25, 3, true ),
    // } ),

    // Wave( 29, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.75, 0, true ),

    //   Enemy( 2, 1 ),

    //   Enemy( 3, 2, true ),
    //   Enemy( 3.75, 2 ),

    //   Enemy( 4, 3, true ),
    // } ),

    // Wave( 31, array<Enemy@> = {
    //   Enemy( 1.5, 0, true ),
    //   Enemy( 1.75, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3, 2, true ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 33, array<Enemy@> = {
    //   Enemy( 1.5, 0 ),
    //   Enemy( 1.75, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 35, array<Enemy@> = {
    //   Enemy( 1.5, 0, true ),
    //   Enemy( 1.75, 0 ),

    //   Enemy( 2.5, 1 ),

    //   Enemy( 3, 2, true ),
    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 37, array<Enemy@> = {
    //   Enemy( 1.5, 1 ),

    //   Enemy( 2.5, 2, true ),

    //   Enemy( 3.5, 3, true ),

    //   Enemy( 4.5, 0 ),
    // } ),

    // Wave( 41, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.333333333333333, 0 ),

    //   Enemy( 1.666666666666667, 1 ),
    //   Enemy( 2, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.333333333333333, 2 ),

    //   Enemy( 3.666666666666667, 3 ),
    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 43, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.333333333333333, 0, true ),

    //   Enemy( 1.666666666666667, 1 ),
    //   Enemy( 2, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.333333333333333, 2, true ),

    //   Enemy( 3.666666666666667, 3 ),
    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 45, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.333333333333333, 0 ),

    //   Enemy( 1.666666666666667, 1 ),
    //   Enemy( 2, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.333333333333333, 2 ),

    //   Enemy( 3.666666666666667, 3 ),
    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 47, array<Enemy@> = {
    //   Enemy( 1, 0, true ),
    //   Enemy( 1.333333333333333, 0 ),

    //   Enemy( 1.666666666666667, 1 ),
    //   Enemy( 2.5, 1 ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.333333333333333, 2, true ),

    //   Enemy( 3.666666666666667, 3 ),
    //   Enemy( 4.5, 3 ),
    // } ),

    // Wave( 49, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.333333333333333, 1 ),
    //   Enemy( 2.666666666666667, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 51, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.333333333333333, 1 ),
    //   Enemy( 2.666666666666667, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.5, 2, true ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 53, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.5, 0 ),

    //   Enemy( 2, 1 ),
    //   Enemy( 2.333333333333333, 1, true ),
    //   Enemy( 2.666666666666667, 1 ),

    //   Enemy( 3, 2, true ),
    //   Enemy( 3.5, 2 ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 55, array<Enemy@> = {
    //   Enemy( 1, 0 ),
    //   Enemy( 1.333333333333333, 0, true ),
    //   Enemy( 1.666666666666667, 0 ),

    //   Enemy( 2, 1, true ),
    //   Enemy( 2.333333333333333, 1 ),
    //   Enemy( 2.666666666666667, 1, true ),

    //   Enemy( 3, 2 ),
    //   Enemy( 3.25, 2 ),

    //   Enemy( 4, 3 ),
    // } ),

    // Wave( 57, array<Enemy@> = {
    //   Enemy( 2.5, 0 ),
    //   Enemy( 2.75, 0 ),

    //   Enemy( 3.5, 1 ),

    //   Enemy( 4, 2 ),

    //   Enemy( 4.5, 3 ),
    // } ),
  };
}
