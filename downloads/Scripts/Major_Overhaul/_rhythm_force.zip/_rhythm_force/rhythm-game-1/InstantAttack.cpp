const int fall_max = 750;

class InstantAttack : callback_base {
  InstantAttack() {}

  void init( dustman@ dm ) {
    dm.on_subframe_end_callback(this, "on_subframe_end", 0);
  }

  void on_subframe_end(dustman@ dm, int) {
    if ( dm.dash_intent() == 1 ) {
      dm.state( 9 );
    }

    if ( dm.attack_state() != 0 && ( dm.heavy_intent() == 10 || dm.light_intent() == 10 ) ) {
      dm.attack_state(0);
    }

    // skip crouch_jump
    if (dm.state() == 10) dm.state(8);
    // skip wall dash
    if (dm.state() == 34)
    {
      dm.state(9);
      dm.face(-dm.face());
    }

    if (dm.attack_timer() > 0) {
      hitbox@ h = dm.hitbox();
      if (h !is null) {
        // light or heavy attacks
        h.state_timer(h.activate_time());
      } else {
        // super
      }

      dm.freeze_frame_timer(0);
    }

    if (dm.attack_timer() < 0 and dm.attack_timer() != -1) {
      dm.attack_timer(0);
    }
  }
}
