#include "../lib/std.cpp";

#include "../lib/drawing/common.cpp";
#include "../lib/emitters/common.cpp";
#include "../lib/enums/EmitterId.cpp";
#include "../lib/triggers/RemoveTimer.cpp";

#include "./InstantAttack.cpp";
#include "./sheetmusic.cpp";

const string EMBED_song = "./rhythm-game-2/rh-shootemup2.ogg";
const string EMBED_spawn = "./rhythm-game-2/spawn.ogg";
const string EMBED_spawnheavy = "./rhythm-game-2/spawn-heavy.ogg";
const string EMBED_shoot = "./rhythm-game-2/shoot.ogg";

const array<uint> ELEMENT_COLOURS = {
  0x11FFFFFF,
  0x33FFFFFF,
  0x55FFFFFF,
  0x77FFFFFF,
  0x99FFFFFF,
  0xAAFFFFFF,
  0xBBFFFFFF,
  0xDDFFFFFF,
  0xEEFFFFFF,
  0xFFFFFFFF,
};

const array<uint> THICKNESS = {
  15,
  12,
  8,
  4,
  3,
  1,
};

class script : callback_base {
  scene@ g;
  controllable@ player;
  dustman@ dm;
  camera@ cam;

  audio@ SONG;

  sprites@ arrow;
  bool draw_arrows = false;
  int draw_arrows_duration = 510;

  textfield@ text_field;
  uint text_frames = 0;
  uint colours_index = 0;

  int frames = 0;

  bool audio_played = false;

  InstantAttack@ instant_attack = InstantAttack();

  [persistent] int TEST_WAVE_OF_MEASURE = -1;

  [persistent] float bpm = 142;
  // all audio that's played will inevitably have some delay at the start; in
  // frames
  [persistent] int song_start_delay = 3;

  // leeway in frames
  [persistent] float hit_leeway_early = 3;
  // the late leeway cannot exceed 1/4th of the BPS, as using sixteenth notes
  // would then mean those notes take longer than they're supposed to (at least,
  // for this script's BPM)
  [persistent] float hit_leeway_late = 6;

  // determines how far from the player the enemy spawns
  float spawn_x_offset = 400;
  float spawn_y_offset = 300;
  // determines how much a second prism in the same spot will be offset from the
  // first
  float spawn_x_offset2 = 130;
  float spawn_y_offset2 = 100;

  // similar to above, but when enemies are "attacking" the player (on the part
  // of the beat where the player is supposed to hit them)
  float attack_x_offset = 70;
  float attack_y_offset = 200;

  // in frames
  int song_position = 1;

  // delay the spawn sound by a bit to line it up with the music
  [persistent] int spawn_sound_delay = 4;
  int spawn_sound_frames = 0;
  bool spawn_sound = false;
  bool spawn_sound_heavy = false;

  float bps;

  // frames per beat
  float fpb;
  // frames per measure
  float fpm;

  int beat = 0;
  int measure = 1;

  int conductor_time = 0;

  array<Wave@> waves = {};
  Wave@ current_wave;
  array<Enemy@> current_enemies = {};
  uint next_enemy_index = 0;
  int measure_to_hit;

  bool wave_complete = false;

  // attempt to determine if the player has paused by using this in
  // `step_fixed()`; if they did, kill them to restart the level, as the music
  // will be out of sync and we can't do anything about it
  int has_stepped = 2;
  bool paused = false;
  bool killed = false;
  bool level_ended = false;

  // drawing variables
  bool draw_spawn = false;
  bool draw_attack = false;
  bool draw_attack_hit = false;
  float enemy_pos_x = -1;
  float enemy_pos_y = -1;
  uint enemy_id = 0;
  int draw_position = 0;
  int draw_frames = 0;
  [color,alpha] uint trail_colour = 0xFFFFFFFF;

  // disallow turning around 1 frame after your attack, to make sure we don't
  // register a hit, and then the player turns around a frame later and doesn't
  // actually hit the prism; -1 is left, 1 is right
  int attacked = 0;

  bool callback_set = false;

  script() {
    @g = @get_scene();

    @arrow = create_sprites();
    arrow.add_sprite_set( "props5" );

    waves = get_waves();
  }

  void build_sounds( message @msg ) {
    msg.set_string( "rh_song", "song" );
    msg.set_string( "spawn", "spawn" );
    msg.set_string( "spawn_heavy", "spawnheavy" );
    msg.set_string( "shoot", "shoot" );
  }

  void on_level_end() {
    level_ended = true;
  }

  void on_level_start() {
    bps = bpm / 60;

    fpb = 60 / bps;
    fpm = fpb * 4;

    // register instant attacks
    @player = @controller_controllable(0);
    if (player is null) return;
    @dm = player.as_dustman();
    if (dm is null) return;
    instant_attack.init( dm );

    g.override_sound( "sfx_impact_light_1", "", false );
    g.override_sound( "sfx_impact_light_2", "", false );
    g.override_sound( "sfx_impact_light_3", "", false );
    g.override_sound( "sfx_impact_heavy_1", "", false );
    g.override_sound( "sfx_impact_heavy_2", "", false );
    g.override_sound( "sfx_impact_heavy_3", "", false );

    @cam = get_active_camera();
    cam.script_camera( true );

    if ( TEST_WAVE_OF_MEASURE > 0 ) {
      for ( uint i = 0; i < waves.length; i++ ) {
        if ( waves[ i ].measure == TEST_WAVE_OF_MEASURE ) {
          Wave@ wave = waves[ i ];
          wave.measure = 1;
          waves.insertAt( 0, wave );
          break;
        }
      }
    }

    uint colour = 0xDDFFFFFF;
    @text_field = create_textfield();

    text_field.set_font( "ProximaNovaReg", 58 );

    text_field.align_horizontal( 0 );
    text_field.align_vertical( 0 );
    text_field.text( "Put your music ON!" );
    text_field.colour( ELEMENT_COLOURS[ 0 ] );
  }

  void checkpoint_load() {
    // register instant attacks
    @player = @controller_controllable(0);
    if (player is null) return;
    @dm = player.as_dustman();
    if (dm is null) return;
    instant_attack.init( dm );
  }

  void step_fixed() {
    if ( frames <= 60 ) {
      // take into account level countdown
      return;
    }

    if ( level_ended ) {
      return;
    }

    has_stepped--;
    if ( has_stepped <= 0 ) {
      paused = true;
    }
  }

  void step( int entities ) {
    // attempt to determine whether the game is paused, by cross-checking this
    // in `step_fixed()`
    if ( has_stepped < 2 ) {
      has_stepped++;
    }

    if ( @SONG != null && SONG.is_playing() && paused && !killed && !level_ended ) {
      // kill the player if they paused, as that means the song will definitely
      // be out of sync
      dm.kill( true );
      killed = true;
    }

    if ( frames <= 100 ) {
      dm.set_speed_xy( 0, dm.y_speed() );

      // take into account level countdown
      frames++;
      return;
    }

    if ( player.y_intent() == 1 ) {
      // don't allow the player to hold down, as it is not necessary and
      // therefore we don't want them to think it might be
      player.y_intent( 0 );
    }

    if ( !callback_set ) {
      dm.on_subframe_end_callback(this, "on_subframe_end", 0);
      callback_set = true;
    }

    // keep the camera centered on the player
    cam.x( player.x() );
    cam.y( player.y() - 50 );

    if ( !audio_played ) {
      @SONG = g.play_script_stream( "rh_song", 1, 0, 0, false, 0.52 );
      audio_played = true;
    }

    frames++;

    if ( !audio_played ) {
      return;
    }

    if ( conductor_time <= song_start_delay ) {
      conductor_time++;
      return;
    }

    if ( frames < draw_arrows_duration ) {
      if ( !draw_arrows ) {
        draw_arrows = true;
      }

      text_frames++;
      if ( colours_index < ELEMENT_COLOURS.length-1 && text_frames % 3 == 0 ) {
        colours_index++;
        text_field.colour( ELEMENT_COLOURS[ colours_index ] );
      }
    }
    else if ( draw_arrows ) {
      draw_arrows = false;
    }

    conductor_time++;

    if ( player.x_intent() == -1 || player.x_intent() == 1 ) {
      // always allow the player to change their attack facing direction, even
      // while in the air
      player.attack_face( player.x_intent() );
    }

    if ( dm.combo_count() > 0 ) {
      // have the player retain combo indefinitely
      dm.combo_timer( 1 );
    }

    if ( attacked == -1 || attacked == 1 ) {
      player.attack_face( attacked );

      attacked = 0;
    }

    if ( dm.light_intent() == 10 || dm.heavy_intent() == 10 ) {
      attacked = player.x_intent();
    }

    // handle drawing variables
    if ( draw_spawn || draw_attack ) {
      draw_frames++;
      if ( draw_frames > 5 ) {
        draw_spawn = false;
        draw_attack = false;
        draw_attack_hit = false;
        draw_frames = 0;
      }
    }

    if ( song_position == 1 || floor( song_position % fpb ) == 0 ) {
      beat = int( ( floor( song_position / fpb ) % 4 ) + 1 );
      measure = int( floor( song_position / fpm ) + 1 );

      puts( "\nMeasure: " + measure );
      puts( "Beat: " + beat );
      puts( "Song_pos: " + song_position );
    }

    if ( waves.length > 0 ) {
      if ( @current_wave == null && ( measure == waves[ 0 ].measure ) ) {
        @current_wave = waves[ 0 ];
        // store the measure in which players need to hit enemies, which is
        // always 1 after the enemies are spawned
        measure_to_hit = current_wave.measure + 1;
      }
    }
    else if ( measure >= 59 ) {
      g.end_level( player.x(), player.y() );
    }

    if ( @current_wave == null ) {
      song_position++;
      return;
    }

    if ( spawn_sound ) {
      play_spawn_sound();
    }

    float current_beat = ( ( song_position / fpb ) % 4 ) + 1;

    // spawn in enemies
    if ( measure == current_wave.measure ) {
      if ( current_enemies.length < current_wave.enemies.length ) {
        Enemy next_enemy = current_wave.enemies[ next_enemy_index ];
        if ( current_beat >= next_enemy.beat ) {
          spawn_enemy( next_enemy );

          // calculate the song position of the hit timing
          next_enemy.song_position = ( ( fpm * measure_to_hit ) + ( fpb * next_enemy.beat ) ) - ( fpm + fpb );
          current_enemies.insertLast( next_enemy );
          next_enemy_index++;

          play_spawn_sound( next_enemy.heavy );
        }
      }
      else {
        next_enemy_index = 0;
      }
    }

    // handle the part of the beat where the player is supposed to hit the
    // enemies (which is always 1 measure after enemies were spawned in this
    // song)
    if ( @current_wave != null && current_enemies.length > 0 ) {
      move_enemies_with_player();

      // get the song position of the first enemy that needs to be hit
      Enemy@ next_enemy = current_enemies[ 0 ];
      Enemy@ previous_enemy;
      if ( next_enemy.hit && current_enemies.length > 1 ) {
        // start checking the enemy after already, since the other one was
        // already hit and we don't want to miss the early leeway frames
        @next_enemy = current_enemies[ 1 ];
        @previous_enemy = current_enemies[ 0 ];
      }
      float hit_timing_early = ( next_enemy.song_position - hit_leeway_early );
      float hit_timing_late = ( next_enemy.song_position + hit_leeway_late );

      if ( @previous_enemy != null ) {
        if ( song_position < ( hit_timing_early - 1 ) && ( player.light_intent() == 10 || player.heavy_intent() == 10 ) ) {
          // punish mashing, though we don't care all too much, we certainly
          // don't care to make it harder for people who want to play it
          // normally
          punish_player();
        }
      }

      // subtract 1 from `hit_timing_early` to account for attacks coming out 1
      // frame after pressing the button
      if ( !next_enemy.hit && song_position >= ( hit_timing_early - 1 ) && song_position <= hit_timing_late ) {
        // uncomment to automatically adjust the player's direction, so they
        // don't have to themselves; NOTE this has a bug where it does not work
        // if the player is already holding a direction
        // if ( player.light_intent() == 10 || player.heavy_intent() == 10 ) {
        //   if ( next_enemy.spawn_position == 0 || next_enemy.spawn_position == 2 ) {
        //     player.face( -1 );
        //     player.attack_face( -1 );
        //     if ( next_enemy.spawn_position == 2 ) {
        //       player.y_intent( -1 );
        //     }
        //   }
        //   else {
        //     player.face( 1 );
        //     player.attack_face( 1 );
        //     if ( next_enemy.spawn_position == 3 ) {
        //       player.y_intent( -1 );
        //     }
        //   }
        // }

        if ( player.light_intent() == 10 || player.heavy_intent() == 10 ) {
          if ( dm.stun_timer() > 0 ) {
            // make sure the player has a chance to attack even if they just
            // failed
            dm.stun_timer( 0 );
          }

          bool success = has_hit( next_enemy );
          if ( success ) {
            if ( !next_enemy.teleported ) {
              // teleport the enemy to the player
              teleport_enemy( next_enemy );
              next_enemy.teleported = true;
            }

            g.play_script_stream( "shoot", 3, 0, 0, false, 0.45 );
            next_enemy.hit = true;
          }
        }
      }
      else if ( song_position > ( hit_timing_late + 1 ) ) {
        // add 1 frame to song_pos_late as we're checking player attack intent
        // 10, which means the attack actually comes out a frame later and
        // therefore if a hit is done on the last frame, we don't want to remove
        // the entity if the attack would hit on the next frame

        entity@ e = entity_by_id( next_enemy.entity_id );
        if ( @e != null ) {
          g.remove_entity( e );
          float emitter_x;
          float emitter_y = player.y() - 50;
          switch ( next_enemy.spawn_position ) {
            case 0:
              emitter_x = player.x() - attack_x_offset;
              break;

            case 1:
              emitter_x = player.x() + attack_x_offset;
              break;

            case 2:
              emitter_x = player.x() - attack_x_offset;
              emitter_y = player.y() - attack_y_offset;
              break;

            case 3:
              emitter_x = player.x() + attack_x_offset;
              emitter_y = player.y() - attack_y_offset;
              break;
          }
          entity@ emitter = create_emitter(
            98,
            emitter_x, emitter_y,
            48, 48, 17, 12
          );
          g.add_entity(emitter);
          remove_timer(emitter, 10);

          // check if the enemy was hit, and if not that means the player did
          // not succeed
          if ( !next_enemy.hit ) {
            punish_player( true );
            draw_attack = true;
            draw_attack_hit = true;
            draw_position = next_enemy.spawn_position;
            enemy_pos_x = e.x();
            enemy_pos_y = e.y();
            enemy_id = e.id();
          }
        }

        current_enemies.removeAt( 0 );
        if ( current_enemies.length == 0 ) {
          wave_complete = true;
        }
      }
    }

    if ( @current_wave != null && wave_complete ) {
      waves.removeAt( 0 );
      @current_wave = null;
      wave_complete = false;
    }

    song_position++;
  }

  bool has_hit( Enemy@ enemy ) {
    if ( player.light_intent() != 10 && player.heavy_intent() != 10 ) {
      return false;
    }

    switch ( enemy.spawn_position ) {
      // enforce directionals
      case 0:
        if ( ( player.x_intent() != -1 || player.attack_face() != -1 ) || player.y_intent() != 0 ) {
          return false;
        }
        break;
      case 1:
        if ( ( player.x_intent() != 1 || player.attack_face() != 1 ) || player.y_intent() != 0 ) {
          return false;
        }
        break;
      case 2:
        if ( ( player.x_intent() != -1  || player.attack_face() != -1 ) || player.y_intent() != -1 ) {
          return false;
        }
        break;
      case 3:
        if ( ( player.x_intent() != 1 || player.attack_face() != 1 ) || player.y_intent() != -1 ) {
          return false;
        }
        break;
    }

    if ( player.heavy_intent() == 10 && enemy.heavy ) {
      return true;
    }
    else if ( player.light_intent() == 10 && !enemy.heavy ) {
      return true;
    }

    return false;
  }

  void spawn_enemy( Enemy@ enemy ) {
    entity@ e;
    if ( enemy.heavy ) {
      @e = create_entity( "enemy_tutorial_hexagon" );
    }
    else {
      @e = create_entity( "enemy_tutorial_square" );
    }

    float x;
    float y;
    switch ( enemy.spawn_position ) {
      case 0:
        x = player.x() - spawn_x_offset;
        y = player.y() + spawn_y_offset / 2;
        // y = player.y();
        for ( uint i = 0; i < current_enemies.length; i++ ) {
          if ( current_enemies[ i ].spawn_position == 0 ) {
            x -= spawn_x_offset2;
            y += spawn_y_offset2;
            enemy.second = true;
            break;
          }
        }
        break;

      case 1:
        x = player.x() + spawn_x_offset;
        y = player.y() + spawn_y_offset / 2;
        // y = player.y();
        for ( uint i = 0; i < current_enemies.length; i++ ) {
          if ( current_enemies[ i ].spawn_position == 1 ) {
            x += spawn_x_offset2;
            y += spawn_y_offset2;
            enemy.second = true;
            break;
          }
        }
        break;

      case 2:
        x = player.x() - spawn_x_offset;
        y = player.y() - spawn_y_offset;
        for ( uint i = 0; i < current_enemies.length; i++ ) {
          if ( current_enemies[ i ].spawn_position == 2 ) {
            x -= spawn_x_offset2;
            y -= spawn_y_offset2;
            enemy.second = true;
            break;
          }
        }
        break;

      case 3:
        x = player.x() + spawn_x_offset;
        y = player.y() - spawn_y_offset;
        for ( uint i = 0; i < current_enemies.length; i++ ) {
          if ( current_enemies[ i ].spawn_position == 3 ) {
            x += spawn_x_offset2;
            y -= spawn_y_offset2;
            enemy.second = true;
            break;
          }
        }
        break;
    }

    e.x( x );
    e.y( y );
    g.add_entity( e );
    enemy.entity_id = e.id();
    @enemy.entity = e;

    entity@ emitter = create_emitter(
      42,
      x, y,
      48, 48, 17, 12
    );
    g.add_entity(emitter);
    remove_timer(emitter, 10);

    entity@ emitter2 = create_emitter(
      98,
      x, y,
      48, 48, 17, 12
    );
    g.add_entity(emitter2);
    remove_timer(emitter2, 1);

    draw_spawn = true;
    draw_position = enemy.spawn_position;
    enemy_pos_x = e.x();
    enemy_pos_y = e.y();
    enemy_id = e.id();
  }

  void move_enemies_with_player() {
    array<int> seen_positions = {};
    for ( uint j = 0; j < current_enemies.length; j++ ) {
      Enemy@ enemy = current_enemies[ j ];
      if ( enemy.hit ) {
        continue;
      }

      entity@ _entity = enemy.entity;
      float x;
      float y;
      switch ( enemy.spawn_position ) {
        case 0:
          x = player.x() - spawn_x_offset;
          y = player.y() + spawn_y_offset / 2;
          // y = player.y();
          if ( enemy.second ) {
            x -= spawn_x_offset2;
            y += spawn_y_offset2;
          }
          else {
            seen_positions.insertLast( enemy.spawn_position );
          }
          break;

        case 1:
          x = player.x() + spawn_x_offset;
          y = player.y() + spawn_y_offset / 2;
          // y = player.y();
          if ( enemy.second ) {
            x += spawn_x_offset2;
            y += spawn_y_offset2;
          }
          else {
            seen_positions.insertLast( enemy.spawn_position );
          }
          break;

        case 2:
          x = player.x() - spawn_x_offset;
          y = player.y() - spawn_y_offset;
          if ( enemy.second ) {
            x -= spawn_x_offset2;
            y -= spawn_y_offset2;
          }
          else {
            seen_positions.insertLast( enemy.spawn_position );
          }
          break;

        case 3:
          x = player.x() + spawn_x_offset;
          y = player.y() - spawn_y_offset;
          if ( enemy.second ) {
            x += spawn_x_offset2;
            y -= spawn_y_offset2;
          }
          else {
            seen_positions.insertLast( enemy.spawn_position );
          }
          break;
      }

      _entity.x( x );
      _entity.y( y );

      if ( _entity.id() == enemy_id ) {
        enemy_pos_x = x;
        enemy_pos_y = y;
      }
    }
  }

  void teleport_enemy( Enemy@ enemy ) {
    entity@ e = entity_by_id( enemy.entity_id );

    float x;
    float y = player.y() - 50;
    switch ( enemy.spawn_position ) {
      case 0:
        x = player.x() - attack_x_offset;
        break;

      case 1:
        x = player.x() + attack_x_offset;
        break;

      case 2:
        x = player.x() - attack_x_offset;
        y = player.y() - attack_y_offset;
        break;

      case 3:
        x = player.x() + attack_x_offset;
        y = player.y() - attack_y_offset;
        break;
    }

    draw_attack = true;
    draw_position = enemy.spawn_position;
    enemy_pos_x = e.x();
    enemy_pos_y = e.y();
    enemy_id = e.id();

    e.x( x );
    e.y( y );
  }

  void play_spawn_sound( bool heavy_prism = false ) {
    if ( !spawn_sound ) {
      spawn_sound = true;
      if ( heavy_prism ) {
        spawn_sound_heavy = true;
      }
    }

    spawn_sound_frames++;

    if ( spawn_sound_frames >= spawn_sound_delay ) {
      if ( spawn_sound_heavy ) {
        g.play_script_stream( "spawn_heavy", 3, 0, 0, false, 0.9 );
      }
      else {
        g.play_script_stream( "spawn", 3, 0, 0, false, 0.775 );
      }
      spawn_sound_frames = 0;
      spawn_sound = false;
      spawn_sound_heavy = false;
    }
  }

  void punish_player( bool force_stun = false ) {
    // punish the player
    if ( player.stun_timer() <= 0 || force_stun ) {
      player.stun( 0, 0 );
      player.stun_timer( 15 );
    }
    dm.combo_count( 0 );

    // add a combo break
    g.combo_break_count( g.combo_break_count() + 1 );
  }

  void draw( float sub_frames ) {
    if ( draw_spawn ) {
      float x;
      float y;
      switch ( draw_position ) {
        case 0:
          x = enemy_pos_x - 1600;
          y = enemy_pos_y + 1050;
          draw_line( g, 15, 12, x, y, enemy_pos_x, enemy_pos_y, THICKNESS[ draw_frames ], trail_colour );
          break;

        case 2:
          x = enemy_pos_x - 1600;
          y = enemy_pos_y - 1050;
          draw_line( g, 15, 12, x, y, enemy_pos_x, enemy_pos_y, THICKNESS[ draw_frames ], trail_colour );
          break;

        case 1:
          x = enemy_pos_x + 1600;
          y = enemy_pos_y + 1050;
          draw_line( g, 15, 12, x, y, enemy_pos_x, enemy_pos_y, THICKNESS[ draw_frames ], trail_colour );
          break;

        case 3:
          x = enemy_pos_x + 1600;
          y = enemy_pos_y - 1050;
          draw_line( g, 15, 12, x, y, enemy_pos_x, enemy_pos_y, THICKNESS[ draw_frames ], trail_colour );
          break;
      }
    }

    if ( draw_attack ) {
      float x;
      float y = player.y() - 50;
      switch ( draw_position ) {
        case 0:
          x = player.x() - attack_x_offset;
          if ( draw_attack_hit ) {
            x += 50;
          }
          break;

        case 2:
          x = player.x() - attack_x_offset;
          y = player.y() - attack_y_offset;
          if ( draw_attack_hit ) {
            x += 50;
            y += 150;
          }
          break;

        case 1:
          x = player.x() + attack_x_offset;
          if ( draw_attack_hit ) {
            x -= 50;
          }
          break;

        case 3:
          x = player.x() + attack_x_offset;
          y = player.y() - attack_y_offset;
          if ( draw_attack_hit ) {
            x -= 50;
            y += 150;
          }
          break;
      }

      draw_line( g, 15, 12, x, y, enemy_pos_x, enemy_pos_y, THICKNESS[ draw_frames ] + 1, trail_colour );
    }

    if ( draw_arrows ) {
      // draw a arrow floating above the current unit's head
      arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() - 250, player.y() + 50, 180, 1, 1, 0xFFFFFFFF );
      if ( song_position > 51 ) {
        arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() + 250, player.y() + 240, 0, 1, 1, 0xFFFFFFFF );
      }
      if ( song_position > 203 ) {
        arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() - 350, player.y() - 210, 180, 1, 1, 0xFFFFFFFF );
        arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() - 100, player.y() - 260, -90, 1, 1, 0xFFFFFFFF );
      }
      if ( song_position > 254 ) {
        arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() + 350, player.y() - 22, 0, 1, 1, 0xFFFFFFFF );
        arrow.draw_world( 20, 2, "symbol_1", 1, 1, player.x() + 300, player.y() - 260, -90, 1, 1, 0xFFFFFFFF );
      }

      text_field.draw_hud( 20, 2, 0, 300, 1, 1, 0 );
    }
  }

  void on_subframe_end(dustman@ dm, int) {
    dm.set_speed_xy( 0, fall_max );
    dm.dash_intent( 0 );
    dm.jump_intent( 0 );
  }
}
