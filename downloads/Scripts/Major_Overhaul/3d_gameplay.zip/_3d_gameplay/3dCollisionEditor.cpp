#include "3dNodeCluster.cpp";
#include "3dFlats.cpp";
#include "3dTriggers.cpp";
//DustScripts/map/customCollision/3dCollisionEditor.cpp

class script : script_base
{
	d3::d3Manager@ manager;
	input_api@ input;
	editor_api@ editor;

	[label:"Aestethics"|option] int t1;
	[colour,alpha|label:"spikeColour2d"] uint spikeColour = 0xFFFF0000;
	[colour,alpha|label:"dustColour2d"] uint dustColour = 0xFF00FF00;
	[colour,alpha|label:"edgeColour2d"|tooltip:"colour of solid edges on 2d collision"] uint edgeColour = 0x11000000;
	[colour,alpha] uint spikeColour3d = 0xCCFF0000;
	[colour,alpha] uint dustColour3d = 0xCC00FF00;
	[colour,alpha|tooltip:"assigned to new node clusters by default"] uint default3dCol = 0xFFFFFFFF;
	[colour,alpha|tooltip:"assigned to new node clusters by default"] uint default2dCol = 0xBB888888;

	[colour,alpha|tooltip:"colour far away things converge to"] uint fogColour = 0x66000000;
	//more = fog is further
	[text|tooltip:"controlls the starting distance as well as strength gain of fog"] float fogDist = 500;

	[text] bool showCompass = true;
	[text] bool showCompassGame = true;
	[position,mode:world,layer:5,y:compassPosY|label:"compass pos"|tooltip:"I was lazy so this uses world coords, ctrl+x to 00 and set there"] float compassPosX = 750;
	[hidden] float compassPosY = -320;
	[slider,min:0,max:1000|label:"compass size"] float compassSize = 200;


	[label:"Map Settings"|option] int t2;
	Vector2 oldCamPos;
	[hidden] float rotation;
	[text|tooltip:"starting rotation in game and editor"] float startRot;
	float oldRotation;
	[text|tooltip:"enable a deathzone at a fixed height"] bool enableDeathzone = false;
	[text] float deathzoneHeight = 2000;

	//should I just have added a method list? yes.
	//am I too lazy to do that at this point? yes.
	array<d3NodeCluster@> nodeClusters;
	array<FakeTrigger@> fakeTriggers;
	array<d3FlatObjectBase@> flats;
	array<d3EndFlag@> flags;
	array<d3TextTrigger@> textTriggers;

	d3StartPos@ startPos;
	[hidden] Vector3 startCoords;

	Vector2 middleDragStart;
	float middleDragStartRot;
	[label:"middle mouse hotkeys"] bool middleDragEnable = true;

	bool wasRotating = false;
	//bools for up/down keys cause reasons
	bool right90 = false;
	bool left90 = false;
	[text|tooltip:"frames after pressing taunt where smooth turn is disabled"] int turnDelay = 6;
	int turnDelayCounter = -1;
	bool wasGrounded;

	bool firstFrame = true;

	//warning light system
	float yellowTreshold = 8000;
	//interestingly there seems to be more leniency to the right, 13k is fine for right but
	//this is about the limit for left
	float redTreshold = 11500;
	//0 = green, 1 = yellow, 2 = red
	int currentDistCol = 0;

	[text|label:"join distance"|tooltip:"distance that node clusters can join at with ctrl+j"] float joinDist = 40;

	[label:"Optimisation"|option] int t3;

	[text|tooltip:"only does layer sorting and node cluster side checks\nevery x frames, only applies to in game smooth turning"] uint layerFrames = 1;
	uint layerFrameCounter;

	//this was inherited from 2d editor so it's not a vector
	[hidden] int playAreaCornerX;
	[hidden] int playAreaCornerY;
	[text] int collisionOrder = 8;
	[text] int playAreaWidth = 10000;
	[text] int playAreaHeight = 10000;

	//added this cause I wanted to use it for horisontal
	//culling but then I realised I'd have to layer
	//when not turning so yeah idk not for now, maybe
	//some day I'll make a system where it re-layers per distance
	float screenHeight = 900;
	
	[label:"Debugging"|option] int t4;
	//debug
	[text|tooltip:"splits quads to easily see their shape\nhighly recommended when building collision"] bool quadDebug = false;
	[text|tooltip:"forces every quad face in a node cluster to be visible.\nIf you need to use this turn off isConvex\nfor the quad you're working with."] bool extraQuadDebug = false;
	array<d2Math::Rect> debugDraw;
	[position,mode:world,layer:19,y:debugPosY] int debugPosX;
	[hidden] int debugPosY;
	[text|tooltip:"visualises med(yellow)/short(blue)/line(white) checks"] bool layerDebug = false;
	[text|tooltip:"Visualises why med checks are happening\nby visualising maxDistHorisontal/up/down"] bool extraLayerDebug = false;

	[text|tooltip:"shows 2d play area"] bool showPlayArea = false;
	[text|tooltip:"shows occupied 2d grid squares"] bool showCacheDebug = false;

	script() 
	{
		puts("3dCollisionEditor working c:");
		if (@manager == null) 
		{
			@manager = @d3::d3Manager();
		}
		@input = @get_input_api();
		@editor = @get_editor_api();
		//makes enemies invisible so I can render them myself
		get_scene().sub_layer_visible(17, 8, false);
	}

	void on_editor_start() 
	{
		manager.manager.collisionOrder = collisionOrder;
		manager.manager.Init(d2Math::IntRect(Vector2(playAreaCornerX, playAreaCornerY), playAreaWidth, playAreaHeight));
		@manager.script = @this;
		rotation = startRot;
		oldRotation = 0;
		camera@ c = get_active_camera();
		manager.cam.igCoords = Vector2(c.x(), c.y());
		manager.cam.centre = Vector3(c.x(), c.y(), 0);
		manager.cam.centre = startCoords;
	}

	void PlayInit()
	{
		manager.manager.collisionOrder = collisionOrder;
		manager.manager.PlayInit(this, d2Math::IntRect(Vector2(playAreaCornerX, playAreaCornerY), playAreaWidth, playAreaHeight));	
		@manager.script = @this;
		rotation = startRot;
		oldRotation = 0;
		controllable@ c = controller_controllable(uint(get_active_player()));
		manager.cam.igCoords = Vector2(c.x(), c.y());
		manager.cam.centre = Vector3(c.x(), c.y(), 0);
		get_active_camera().controller_mode(4);
		oldCamPos = manager.cam.igCoords;
		manager.cam.centre = startCoords;
	}

	void on_level_start() { PlayInit(); }
	void checkpoint_load() { PlayInit(); }

	void editor_step()
	{
		if (firstFrame)
		{
			firstFrame = false;
			//I stopped asking questions long ago
			UpdateRotation(true);
			UpdateRotation(true);
			UpdateRotation(true);
		}
		for(uint i = 0; i < fakeTriggers.length(); i++)
		{
			fakeTriggers[i].EditorStep();
		}

		camera@ cam = get_active_camera();
		if (abs(cam.x()) > yellowTreshold || abs(cam.y()) > yellowTreshold)
		{
			if (abs(cam.x()) > redTreshold || abs(cam.y()) > redTreshold)
			{
				currentDistCol = 2;
			}
			else
			{
				currentDistCol = 1;
			}
		}
		else
		{
			currentDistCol = 0;
		}
		screenHeight = cam.screen_height();

		for(uint i = 0; i < fakeTriggers.length(); i++)
		{
			fakeTriggers[i].EditorStep();
		}

		//fuck this game I fucking hate this why are you this shit fuck you
		if (input.key_check_pressed_vk(0x58) && input.key_check_gvb(11) && currentDistCol != 2)
		{
			oldCamPos = Vector2(0,0);
			cam.x(0);
			cam.y(0);
			manager.cam.igCoords = Vector2(0,0);
			UpdateRotation(true);
		}

		HandleMiddleCommands();
		UpdateCamPos();
		UpdateRotation();
		CentraliseTriggers();
	}

	uint ApplyFog(uint col, float dist)
	{
		if (dist == 0)
		{
			return col;
		}
		float ed = fogDist/dist;
		if (ed > 1  || ed < 0) { return col; }
		uint a = uint(((col & 0xFF000000) >> 24) * ed + ((fogColour & 0xFF000000) >> 24) * (1-ed));
		uint r = uint(((col & 0xFF0000) >> 16) * ed + ((fogColour & 0xFF0000) >> 16) * (1-ed));
		uint g = uint(((col & 0xFF00) >> 8) * ed + ((fogColour & 0xFF00) >> 8) * (1-ed));
		uint b = uint((col & 0xFF) * ed + (fogColour & 0xFF) * (1-ed));
		// puts("cols " + a + ", " + r + ", " + g + ", " + b);
		return ((a & 0xFF) << 24) + ((r & 0xFF) << 16) + ((g & 0xFF) << 8) + (b & 0xFF);
	}

	//everything with middle mouse
	void HandleMiddleCommands()
	{
		if (!middleDragEnable) { return; }
		if (input.mouse_state() & 0x80 != 0)
		{
			middleDragStartRot = rotation;
			middleDragStart = Vector2(input.mouse_x_hud(true), input.mouse_y_hud(true));
		}
		if (input.mouse_state() & 0x10 != 0)
		{
			rotation = middleDragStartRot + (input.mouse_x_hud(true) - middleDragStart.x) / 200;
		}
		if (input.key_check_gvb(10))
		{
			if (input.mouse_state() & 0x1 != 0)
			{
				manager.cam.centre = manager.cam.CamToWorldPos(
					manager.cam.WorldToCamPos(manager.cam.centre) + Vector3(0,0,24));
				UpdateRotation(true);
				manager.UpdateCollision();
			}
			if (input.mouse_state() & 0x2 != 0)
			{
				manager.cam.centre = manager.cam.CamToWorldPos(
					manager.cam.WorldToCamPos(manager.cam.centre) - Vector3(0,0,24));
				UpdateRotation(true);
				manager.UpdateCollision();
			}
		}
	}

	void step(int idc) 
	{
		if (firstFrame)
		{
			firstFrame = false;
			//I stopped asking questions long ago
			UpdateRotation(true);
			UpdateRotation(true);
			UpdateRotation(true);

			manager.manager.SetCollisionHandlers();
			manager.UpdateCollision();
		}

		camera@ cam = get_active_camera();
		screenHeight = cam.screen_height();

		HandleGameplayRotation();
		manager.Step();
		UpdateCamPos();
		UpdateRotation();
		UpdatePlayArea();
		CentraliseTriggers();
		HandleDeathzone();
	}

	void CentraliseTriggers()
	{
		camera@ cam = get_active_camera();
		Vector2 camPos = Vector2(cam.x(), cam.y());
		for(uint i = 0; i < fakeTriggers.length(); i++)
		{
			entity@ t = fakeTriggers[i].trigger;
			if (@t != null && fakeTriggers[i].centralise)
			{
				t.x(camPos.x);
				t.y(camPos.y);
			}
		}
	}

	void UpdatePlayArea()
	{
		controllable@ p = controller_controllable(uint(get_active_player()));
		if (@p == null) { return; }
		bool update = false;
		if (p.x() - playAreaCornerX < playAreaWidth/6)
		{
			playAreaCornerX -= playAreaWidth/2;
			update = true;
		}
		if (playAreaCornerX + playAreaWidth - p.x() < playAreaWidth/6)
		{
			playAreaCornerX += playAreaWidth/2;
			update = true;
		}
		if (p.y() - playAreaCornerY < playAreaHeight/6)
		{
			playAreaCornerY -= playAreaHeight/2;
			update = true;
		}
		if (playAreaCornerY + playAreaHeight - p.y() < playAreaWidth/6)
		{
			playAreaCornerY += playAreaHeight/2;
			update = true;
		}
		if (update)
		{
			manager.manager.Init(d2Math::IntRect(Vector2(playAreaCornerX, playAreaCornerY), playAreaWidth, playAreaHeight));
			manager.UpdateCollision();
		}
	}
	
void HandleDeathzone()
{
	if (!enableDeathzone) { return; }
	controllable@ p = controller_controllable(uint(get_active_player()));
	if (@p == null) { return; }
	if (p.y() > deathzoneHeight) { p.as_dustman().kill(false); }
}

	void HandleGameplayRotation()
	{
		float rotPerSec = 3;
		camera@ ca = get_active_camera();
		controllable@ co = controller_controllable(uint(get_active_player()));
		if (ca.input_taunt() != 0)
		{
			co.as_entity().time_warp(0);
			for(uint i = 0; i < flats.length(); i++)
			{
				d3EnemyBase@ e = cast<d3EnemyBase>(flats[i]);
				if (@e == null || @e.entity == null) { continue; }
				e.entity.time_warp(0);
			}
			co.as_hittable().freeze_frame_timer(0.1);
			if (turnDelayCounter > 0) { turnDelayCounter--; }
			if (!wasRotating)
			{
				wasGrounded = co.ground();
				turnDelayCounter = turnDelay;
			}
			wasRotating = true;
			//right
			if (ca.input_x() & 0x2 != 0 && turnDelayCounter <= 0)
			{
				rotation += rotPerSec/60;
			}
			//left
			if (ca.input_x() & 0x1 != 0 && turnDelayCounter <= 0)
			{
				rotation -= rotPerSec/60;
			}
			//down = right 90
			float hpi = asin(1);
			if (ca.input_y() & 0x2 != 0)
			{
				if (!right90)
				{
					right90 = true;
					rotation += hpi;
					//doing an extra couple of updates because this really fucks it up for some reason...
					UpdateRotation(true);
					UpdateRotation(true);
				}
			}
			else { right90 = false; }
			//up = left 90
			if (ca.input_y() & 0x1 != 0)
			{
				if (!left90)
				{
					left90 = true;
					rotation -= hpi;
					UpdateRotation(true);
					UpdateRotation(true);
				}
			}
			else { left90 = false; }
		// manager.UpdateLooks(false);
		// manager.UpdateLooks(false);
		// manager.UpdateLooks(false);
		}
		else
		{
			if (wasRotating)
			{
				co.as_entity().time_warp(1);
				wasRotating = false;
				manager.UpdateCollision();
				co.ground(wasGrounded);
				turnDelayCounter = -1;
				for(uint i = 0; i < flats.length(); i++)
				{
					d3EnemyBase@ e = cast<d3EnemyBase>(flats[i]);
					if (@e == null || @e.entity == null) { continue; }
					e.entity.time_warp(1);
				}
			}
		}
	}

	//sorry it's also used for scroll up/down fuck you, whoever got confused by this later (probably me)
	void UpdateRotation(bool force = false)
	{
		if (oldRotation != rotation || force)
		{
			oldRotation = rotation;
			manager.cam.rotation = rotation;
			for (uint i = 0; i < nodeClusters.length(); i++)
			{
				nodeClusters[i].UpdateRotation(force);
			}
			for(uint i = 0; i < flats.length(); i++)
			{
				flats[i].UpdateRotation();
			}
			if (@startPos != null)
			{
				startPos.UpdateRotation();
			}
			for(uint i = 0; i < flags.length(); i++)
			{
				flags[i].UpdateRotation();
			}
			for(uint i = 0; i < textTriggers.length(); i++)
			{
				textTriggers[i].UpdateRotation();
			}
			manager.UpdateLooks(force);
		}
	}

	void UpdateCamPos()
	{
		if (!is_playing())
		{
			camera@ rcam = get_active_camera();
			auto rcamPos = Vector2(rcam.x(), rcam.y());
			if (oldCamPos == Vector2(0,0))
			{
				oldCamPos = rcamPos;
				return;
			}
			Vector2 dif = oldCamPos - rcamPos;
			if (dif.Magnitude() > 0.1)
			{
				Vector3 dif2 = manager.cam.CamToWorldDir(Vector3(dif.x, dif.y, 0));
				manager.cam.centre -= dif2;
				manager.cam.igCoords = rcamPos;
				oldCamPos = rcamPos;
				// puts("cam pos updated! " + manager.cam.centre.x + ", " + manager.cam.centre.y + ", " + manager.cam.centre.z);
			}
		}
		else
		{
			controllable@ player = controller_controllable(uint(get_active_player()));
			auto rcamPos = Vector2(player.x(), player.y());
			if (oldCamPos == Vector2(0,0))
			{
				oldCamPos = rcamPos;
				return;
			}
			Vector2 dif = oldCamPos - rcamPos;
			if (dif != Vector2())
			{
				Vector3 dif2 = manager.cam.CamToWorldDir(Vector3(dif.x, dif.y, 0));
				manager.cam.centre -= dif2;
				manager.cam.igCoords = rcamPos;
				oldCamPos = rcamPos;
			}
		}
	}

	void editor_draw(float lolxd) 
	{
		scene@ s = get_scene();
		if (showPlayArea) 
		{
			manager.manager.playArea.Draw(s, 22, 1);
		}
		manager.Draw();
		if (showCacheDebug) 
		{
			manager.manager.Draw(s, 22, 1);
		}
		// puts("debug len: " + debugDraw.length());
		for (uint i = 0; i < debugDraw.length(); i++) 
		{
			debugDraw[i].Draw(s, 22, 1);
		}
		debugDraw.resize(0);
		for(uint i = 0; i < fakeTriggers.length(); i++)
		{
			fakeTriggers[i].Draw(s);
		}
		if (showCompass)
		{
			DrawCompass();
		}
		
		float squareSize = 0;
		uint squareCol = 0;
		switch (currentDistCol)
		{
			case 0:
				squareSize = 20;
				squareCol = 0xFF00FF00;
			break;
			case 1:
				squareSize = 30;
				squareCol = 0xFFFFFF00;
			break;
			case 2:
				squareSize = 40;
				squareCol = 0xFFFF0000;
			break;
		}
		Vector2 pos = Vector2(750, 400);
		s.draw_rectangle_hud(21, 1, pos.x-squareSize, pos.y-squareSize, pos.x+squareSize, pos.y+squareSize, 0, squareCol);
	}

	void draw(float idkAnymore) 
	{
		scene@ sc = get_scene();
		if (showPlayArea) 
		{
			manager.manager.playArea.Draw(sc, 22, 1);
		}
		manager.Draw();
		if (showCacheDebug) 
		{
			manager.manager.Draw(sc, 22, 1);
		}
		for (uint i = 0; i < debugDraw.length(); i++) 
		{
			debugDraw[i].Draw(sc, 22, 1);
		}
		debugDraw.resize(0);
		if (showCompassGame)
		{
			DrawCompass();
		}
	}
	void DrawCompass()
	{
		scene@ s = get_scene();
		Vector3 dx = manager.cam.WorldToCamDir(Vector3(1,0,0)) * compassSize;
		Vector3 dz = manager.cam.WorldToCamDir(Vector3(0,0,1)) * compassSize;
		uint col1 = 0;
		uint col2 = 0;
		if (dx.z > 0)
		{
			col1 = 0xFF550000;
		}
		else
		{
			col1 = 0xFFFF0000;
		}
		if (dz.z > 0)
		{
			col2 = 0xFF000055;
		}
		else
		{
			col2 = 0xFF0000FF;
		}
		s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX,compassPosY-compassSize, 5, 0xFF00FF00);
		if (d2Math::sign(dx.x) != d2Math::sign(dz.x))
		{
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dx.x,compassPosY+dx.y, 5, col1);
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dz.x,compassPosY+dz.y, 5, col2);
		}
		else if (dx.z < dz.z)
		{
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dz.x,compassPosY+dz.y, 5, col2);
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dx.x,compassPosY+dx.y, 5, col1);
		}
		else
		{
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dx.x,compassPosY+dx.y, 5, col1);
			s.draw_line_hud(21,1,compassPosX,compassPosY, compassPosX+dz.x,compassPosY+dz.y, 5, col2);
		}
	}

	void on_level_end() 
	{
		uint count = 0;
		for (uint i = 0; i < manager.allQuads.length(); i++) 
		{
			count += manager.allQuads[i].GetDustCount();
		}
		MakeDust(count);
	}

	void MakeDust(int n) 
	{
		if (n == 0) { return; }
		Vector2 pos = manager.cam.igCoords + Vector2(5000, 5000);
		int width = int(sqrt(n));
		if (sqrt(n) - width > 0.01) { width += 1; } //round up while not fucking up square cases
		int height = n/width;
		int lastRow = n - width*height;
		// puts(width+ ", " + height + ", " + lastRow);

		tileinfo@ t = create_tileinfo();
		t.solid(true);
		t.sprite_set(2);
		t.sprite_tile(13);
		t.sprite_palette(1);
		t.set_dustblock(2);

		scene@ s = get_scene();

		for (int x = int(floor(-width/2.0)); x < width/2; x += 1)
		{
			for (int y = int(floor(-height/2.0)); y < height/2; y += 1) //stops 1 short 
			{
				s.set_tile(int(floor(pos.x/48+x)), int(floor(pos.y/48+y)), 19, t, false);
			}
		}
		for (int x = int(floor(-width/2.0)); x < int(floor(-width/2.0)) + lastRow; x += 1) 
		{
			s.set_tile(int(floor(pos.x/48))+x, int(floor(pos.y/48))+int(height/2), 19, t, false);
		}
	}
}
