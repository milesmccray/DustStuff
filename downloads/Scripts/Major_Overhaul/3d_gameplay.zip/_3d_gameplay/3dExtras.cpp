#include "mathHelper.cpp";
#include "3dCC.cpp";

//this file contains basic tools useful for any editor implementation of the 3d custom collision.

class nthggg{}

//usually I don't like inheritance but this seems like a good place to use it
//since all enemies need an unique implementation anyways, this will also work for props
class d3FlatObjectBase : d3::d3FlatDrawable
{
	//from interface:
	//d2Math::Rect drawRect;
	//float depth;

	d3::d3Manager@ manager;
	d3::Renderable@ renderable;
	script@ script;

	[hidden] d3FakeTrigger fakeTrigger;
	[hidden] bool hasInit = false;

	void init(script@ s, entity@ self) 
	{
		@this.manager = @s.manager;
		@script = @s;
		if (!hasInit)
		{
			fakeTrigger = d3FakeTrigger();
			hasInit = true;
		}
		fakeTrigger.Init(self, s, manager);
		UpdateRotation();
		@renderable = @d3::Renderable(1);
		@renderable.flat = @this;
		manager.renderables.insertLast(renderable);
		s.flats.insertLast(this);
	}

	void editor_step()
	{
		fakeTrigger.EditorStep();
	}

	void UpdateRotation()
	{
		fakeTrigger.UpdateRotation();
		depth = fakeTrigger.ssp.z;
	}

	void on_remove()
	{
		int i = manager.renderables.findByRef(renderable);
		if (i != -1)
		{
			manager.renderables.removeAt(i);
		}
		i = script.flats.findByRef(this);
		if (i != -1)
		{
			script.flats.removeAt(i);
		}
		fakeTrigger.DeleteSelf();
	}
}

class d3EnemyBase : d3FlatObjectBase
{
	[text|tooltip:"what layer is drawn on, don't change in normal circumstances."] int layer = 18;
	[text|tooltip:"what sub layer is drawn on, don't change in normal circumstances."] int sub_layer = 1;
	scripttrigger@ self;
	entity@ entity;
	[hidden] int entityId = -1;
	sprites@ sprites;
	string sprite;
	//have to just do create sprites in editor
	//cause fucking trigger radiai fuck triggers
	string spritesName;
	string entityName;
	uint palette = 1;
	float rotation = 0;
	Vector2 scale = Vector2(1,1);
	uint frame = 0;
	float thickness = 48;
	uint colour = 0xFFFFFFFF;

	void init(script@ s, scripttrigger@ self)
	{
		@this.self = self;
		self.editor_handle_size(0);

		if (is_playing())
		{
			if (entityId == -1) 
			{
				@entity = create_entity(entityName);
				get_scene().add_entity(entity);
				entityId = entity.id();
				// puts("new " + entityId);
			}
			else
			{
				// puts("id: " + entityId);
				@entity = @entity_by_id(uint(entityId));
				if (@entity == null)
				{
					// puts("couldn't find");
					@entity = create_entity(entityName);
					get_scene().add_entity(entity);
					entityId = entity.id();
					// puts("new " + entityId);
				}
			}
			puts("setting ent layer");
			entity.layer(17);
		}
		@sprites = @create_sprites();
		sprites.add_sprite_set(spritesName);
		d3FlatObjectBase::init(s, self.as_entity());
		fakeTrigger.colour = 0xFF0000FF;
	}

	void editor_step() override
	{
		d3FlatObjectBase::editor_step();
		frame = uint(get_scene().time_in_level()*12/1000) % sprites.get_animation_length(sprite);
	}
	void step()
	{
		frame = uint(get_scene().time_in_level()*12/1000) % sprites.get_animation_length(sprite);
		if (@entity != null && abs(fakeTrigger.ssp.z) > thickness)
		{
			Vector2 cp = manager.cam.igCoords;
			entity.x(cp.x+1000);
			entity.y(cp.y+1000);
		}
	}

	void UpdateRotation() override
	{
		d3FlatObjectBase::UpdateRotation();
		rectangle@ sr = sprites.get_sprite_rect(sprite, frame);
		Vector2 pos = Vector2(fakeTrigger.ssp.x, fakeTrigger.ssp.y);
		drawRect = d2Math::Rect(pos.x + sr.left()*scale.x, pos.y + sr.top()*scale.y, pos.x + sr.right()*scale.x, pos.y + sr.bottom()*scale.y);
		if (abs(fakeTrigger.ssp.z) > thickness)
		{
			Vector2 cp = manager.cam.igCoords;
			SetInactiveColour();
			if (@entity == null) { return; }
			entity.x(cp.x+200);
			entity.y(cp.y+200);
		}
		else
		{
			SetActiveColour();
			if (@entity == null) { return; }
			entity.x(fakeTrigger.ssp.x);
			entity.y(fakeTrigger.ssp.y);
		}
	}

	//I've seperated these to give overriding privelages c:
	void SetActiveColour()
	{
		colour = 0xFFFFFFFF;
	}
	void SetInactiveColour()
	{
		colour = script.ApplyFog(0x88888888, depth);
	}

	void Draw(scene@ s) override
	{
		if (depth < -thickness || (@entity != null && entity.destroyed())) { return; }
		// return;
		uint ncolour = script.ApplyFog(colour, depth);
		sprites.draw_world(layer, sub_layer, sprite, frame, palette, fakeTrigger.ssp.x, 
					 fakeTrigger.ssp.y, rotation, scale.x, scale.y, ncolour);
	}

	void on_remove() override
	{
		d3FlatObjectBase::on_remove();
		if (@entity == null) { return; }
		get_scene().remove_entity(entity);
	}
}

class d3MovingEnemyBase : d3EnemyBase
{
	Vector2 oldPos;
	//coords are weird so things look like they're inside the floor, use this to fix
	float verticalOffset;
	Vector3 deactivatedVelocity;
	void init(script@ s, scripttrigger@ self) override
	{
		d3EnemyBase::init(s, self);
		if (@entity == null) { return; }
		if (@entity.as_controllable() != null)
		{
			manager.manager.additionalControllables.insertLast(entity.as_controllable());
		}
		else
		{
			puts(entity.type_name() + " is not controllable!!!!!!!");
		}

	}
	void step() override
	{
		d3EnemyBase::step();
		if (@entity == null) { return; }
		if (abs(fakeTrigger.ssp.z) < thickness)
		{
			ActiveStep();
		}
		else
		{
			InactiveStep();
		}
	}

	void ActiveStep()
	{
		Vector2 curPos = Vector2(entity.x(), entity.y());
		if (oldPos == Vector2())
		{
			oldPos = curPos;
			return;
		}
		Vector2 dif = curPos - oldPos;
		if (dif != Vector2())
		{
			oldPos = curPos;
			fakeTrigger.pos += manager.cam.CamToWorldDir(Vector3(dif.x,dif.y,0));
			//sorry for this sin but also I don't care fuck you
			fakeTrigger.UpdateRotation();
		}
	}

	void InactiveStep() {}

	void UpdateRotation() override
	{
		d3EnemyBase::UpdateRotation();
		oldPos = Vector2();
		if (@entity == null) { return; }
		hittable@ hit = entity.as_hittable();
		if (entity.destroyed() || @hit == null) { return; }
		if (abs(depth) > thickness && deactivatedVelocity == Vector3())
		{
			deactivatedVelocity = manager.cam.CamToWorldDir(Vector3(hit.x_speed(), hit.y_speed(), 0));
		}
		else if (abs(depth) < thickness && deactivatedVelocity != Vector3())
		{
			Vector3 vel = manager.cam.WorldToCamDir(deactivatedVelocity);
			hit.set_speed_xy(vel.x, vel.y);
			deactivatedVelocity = Vector3();
		}
	}

	//idk why but I'm unable to hide apples but this should be better anyways c:
	void Draw(scene@ s)
	{
		if ((@entity != null && entity.destroyed()) || depth < -thickness) { return; }
		if (depth > thickness || !is_playing())
		{
			uint ncolour = script.ApplyFog(colour, depth);
			sprites.draw_world(layer, sub_layer, sprite, frame, palette, fakeTrigger.ssp.x, 
					  fakeTrigger.ssp.y+verticalOffset, rotation, scale.x, scale.y, ncolour);
		}
	}

}

class d3FakeTrigger
{
	[hidden] Vector3 pos;
	Vector3 ssp;
	[hidden] uint colour = 0xFF490f70;

	[hidden] Vector2 oldCentre;
	[hidden] bool hasInit = false;

	FakeTrigger@ fakeTrigger;
	d3::d3Manager@ manager;

	void Init(entity@ trigger, script@ s, d3::d3Manager@ manager)
	{
		@fakeTrigger = @FakeTrigger(s, trigger, Vector2(trigger.x(), trigger.y()));
		@this.manager = @manager;
		fakeTrigger.colour = colour;
		if (!hasInit)
		{
			Vector2 camCen = manager.cam.igCoords;
			Vector2 ipos = fakeTrigger.pos - camCen;
			pos = manager.cam.CamToWorldPos(Vector3(ipos.x, ipos.y, 0));
			hasInit = true;
		}
		UpdateRotation();
	}

	void EditorStep()
	{
		fakeTrigger.colour = colour;
		Vector2 curPos = fakeTrigger.pos;
		Vector2 dif = curPos - oldCentre;
		if (dif != Vector2())
		{
			pos += manager.cam.CamToWorldDir(Vector3(dif.x, dif.y,0));
			oldCentre = fakeTrigger.pos;
			Vector2 camCen = manager.cam.igCoords;
			Vector3 camPos = Vector3(camCen.x, camCen.y, 0);
			Vector3 newPos = manager.cam.WorldToCamPos(pos) + camPos;
			ssp = newPos;
		}
	}

	void UpdateRotation()
	{
		Vector2 camCen = manager.cam.igCoords;
		Vector3 camPos = Vector3(camCen.x, camCen.y, 0);
		Vector3 newPos = manager.cam.WorldToCamPos(pos) + camPos;
		fakeTrigger.pos = Vector2(newPos.x, newPos.y);
		oldCentre = Vector2(newPos.x, newPos.y);
		ssp = newPos;
		if (newPos.z < 0) { fakeTrigger.size = 0; }
		else { fakeTrigger.size = 10; }
	}

	void DeleteSelf()
	{
		fakeTrigger.DeleteSelf();
	}
}

//before I forger for the fifth time: trigger centralisation happens in script!!!
class FakeTrigger
{
	Vector2 pos;
	uint colour = 0xFF490f70;
	float size = 10;

	script@ script;
	input_api@ input;
	entity@ trigger;

	uint holdTime = 0;
	uint holdTimeR = 0;
	bool isHeld = false;
	bool isHeldR = false;

	Vector2 oldPos;

	bool centralise = true;

	FakeTrigger(){}
	FakeTrigger(script@ s, entity@ trigger, Vector2 pos)
	{
		@script = @s;
		@input = @get_input_api();
		this.pos = pos;
		s.fakeTriggers.insertLast(this);
		@this.trigger = @trigger;
	}

	FakeTrigger& opAssign(const FakeTrigger &inout o)
	{
		pos = o.pos;
		colour = o.colour;
		size = o.size;
		@script = @o.script;
		@input = @o.input;
		@trigger = @o.trigger;
		holdTime = o.holdTime;
		holdTimeR = o.holdTimeR;
		isHeld = o.isHeld;
		isHeldR = o.isHeldR;
		oldPos = o.oldPos;
		return this;
	}

	void DeleteSelf()
	{
		int i = script.fakeTriggers.findByRef(this);
		if (i != -1)
		{
			script.fakeTriggers.removeAt(i);
		}
	}

	void Draw(scene@ s)
	{
		s.draw_rectangle_world(21, 1, pos.x-size, pos.y-size, pos.x+size, pos.y+size, 0, colour);
	}

	void EditorStep()
	{
		if (script.editor.editor_tab() == "Select" 
	  && @script.editor.get_selected_trigger() == null)
		{
			if (!input.key_check_gvb(3) && isHeldR)
			{
				if (holdTime < 20)
				{
					if (@trigger != null)
					{
						get_scene().remove_entity(trigger.as_entity());
					}
				}
				holdTimeR = 0;
				isHeldR = false;
			}
			Vector2 mpos = Vector2(input.mouse_x_world(21), input.mouse_y_world(21));
			if (input.key_check_pressed_gvb(3)
				&& mpos.x > pos.x-size && mpos.x < pos.x+size
				&& mpos.y > pos.y-size && mpos.y < pos.y+size)
			{
				isHeldR = true;
			}
			if (input.key_check_gvb(3) && isHeldR)
			{
				holdTimeR++;
			}
			else
			{
				holdTimeR = 0;
			}
			if (!input.key_check_gvb(2) && isHeld)
			{
				if (holdTime < 20)
				{
					if (@trigger != null)
					{
						script.editor.editor_tab("Triggers");
						script.editor.set_selected_trigger(trigger.as_entity());
					}
				}
				holdTime = 0;
				isHeld = false;
				oldPos = Vector2();
			}
			if (input.key_check_pressed_gvb(2)
				&& mpos.x > pos.x-size && mpos.x < pos.x+size
				&& mpos.y > pos.y-size && mpos.y < pos.y+size)
			{
				isHeld = true;
			}
			if (input.key_check_gvb(2) && isHeld)
			{
				holdTime++;
				if (oldPos == Vector2())
				{
					oldPos = mpos;
					return;
				}
				Vector2 dif = mpos - oldPos;
				pos += dif;
				oldPos = mpos;
			}
			else
			{
				holdTime = 0;
				oldPos = Vector2();
			}
		}
		else
		{
			holdTime = 0;
			oldPos = Vector2();
		}
	}
}

