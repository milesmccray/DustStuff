#include "../lib/std.cpp";

const int MAX_PLAYERS = 4;

class script {
  scene@ scene;

  array<uint> player_indexes = {};

  dictionary players_by_index = {};

  float stun_x_max = 1200;

  bool callbacks_set = false;

  script() {
    @scene = get_scene();
  }

  void step( int entities ) {
    if ( player_indexes.length < MAX_PLAYERS ) {
      get_players();
      // return;
    }

    if ( !callbacks_set ) {
      set_callbacks();
    }

    dustman@ me = cast<dustman@>( players_by_index[ "0" ] );
    dustman@ opponent = cast<dustman@>( players_by_index[ "1" ] );

    if ( @opponent != null && opponent.state() == 20 ) {
      if ( opponent.ground() ) {
        // limit knockback on the ground
        if ( opponent.x_speed() < -stun_x_max ) {
          opponent.set_speed_xy( -stun_x_max, opponent.y_speed() );
        }
        else if ( opponent.x_speed() > stun_x_max ) {
          opponent.set_speed_xy( stun_x_max, opponent.y_speed() );
        }
      }
      opponent.x_intent( 1 );
    }
  }

  void set_callbacks() {}

  void get_players() {
    if ( player_indexes.length < MAX_PLAYERS ) {
      for ( uint i = 0; i < MAX_PLAYERS; i++ ) {
        // try to get a `dustman` object handle for each player.
        controllable@ c = controller_controllable( i );
        if ( @c == null ) {
          continue;
        }
        dustman@ dm = c.as_dustman();
        if ( @dm == null ) {
          continue;
        }

        bool broke = false;
        for ( uint j = 0; j < player_indexes.length; j++ ) {
          if ( i == player_indexes[ j ] ) {
            broke = true;
            break;
          }
        }
        if ( broke ) {
          continue;
        }

        player_indexes.insertLast( i );
        players_by_index.set( "" + i, @dm );
      }
    }
  }
}
