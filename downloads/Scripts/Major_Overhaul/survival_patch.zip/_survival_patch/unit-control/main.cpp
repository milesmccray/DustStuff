class script {
  scene @g;
  sprites@ arrow;

  // keep track of whether the level is played in multiplayer, as we want to
  // disable the entire script in that case
  bool multiplayer = false;
  bool ai_removed = false;

  // store the original starting controllable, since after switching to another
  // entity we cannot access the original via the global "get" methods anymore
  // (they return null)
  controllable@ original_player;
  dustman@ current_player;
  string character_type;

  array<uint> unit_ids;
  uint current_player_id = 0;
  uint cycle_index = 0;
  bool cycling = false;

  [persistent] bool team_attack = false;
  [text] uint arrow_sub_layer = 20;

  script() {
    @g = get_scene();
    @arrow = create_sprites();
    arrow.add_sprite_set( "props5" );
  }

  void on_level_start() {
    if ( num_cameras() > 1 ) {
      multiplayer = true;
    }
  }

  void step( int entities ) {
    if ( multiplayer ) {
      if ( !ai_removed ) {
        for ( int i = 1; i < entities; i++ ) {
          dustman@ dm = entity_by_index( i ).as_dustman();

          if ( @dm != null ) {
            if ( dm.is_same( controller_controllable( 0 ).as_dustman() ) ) {
              continue;
            }

            // remove entities that would normally be used as units, since in
            // multiplayer we want to disable all script functionality
            g.remove_entity( dm.as_entity() );
          }
        }

        ai_removed = true;
      }

      return;
    }

    if ( @current_player == null ) {
      controllable@ c = controller_controllable( 0 );
      if ( @c != null ) {
        @current_player = c.as_dustman();

        // see above about storing the original player entity
        @original_player = c;

        character_type = current_player.character();
      }
    }

    if ( current_player.destroyed() && !current_player.dead() ) {
      // kill non-player units
      current_player.kill( false );
    }

    if ( unit_ids.length == 0 ) {
      // we know that the original player entity will have an ID of 0, so just
      // put it first in the unit_ids list, which also makes unit cycling more
      // intuitive (you cycle to all other units and then finally get back to
      // the original player)
      unit_ids.insertAt( 0, 0 );
    }

    for ( int i = 0; i < entities; i++ ) {
      // entity IDs are naturally not going to be 0, 1, 2, etc. so get the
      // entities by index instead
      dustman@ dm = entity_by_index( i ).as_dustman();
      if ( @dm != null ) {
        if ( ( unit_ids.find( dm.id() ) >= 0 ) ) {
          // skip this ID which we've already mapped
          continue;
        }

        if ( i != 0 ) {
          // entity with index 0 is always the player themselves; disable the AI
          // and set the team to the player's team so the entities can't hit
          // each other
          dm.ai_disabled( true );

          if ( !team_attack ) {
            dm.team( 1 );
          }
        }

        // entity is a "dustman" object, so must be controllable by the player
        unit_ids.insertLast( dm.id() );
      }
    }

    if ( !cycling && ( current_player.taunt_intent() == 1 ) ) {
      // cycle through the available units; make sure not to try cycling while
      // already doing so on a previous frame (taunts can be held)
      cycling = true;
      cycle_unit();
    }
  }

  // cycle to the next controllable unit
  void cycle_unit() {
    if ( multiplayer ) {
      return;
    }

    if ( unit_ids.length <= 1 ) {
      return;
    }

    if ( cycle_index < unit_ids.length-1 ) {
      cycle_index += 1;
    }
    else {
      cycle_index = 0;
    }

    controllable@ c;
    if ( unit_ids[ cycle_index ] == 0 ) {
      // fetch the original player controllable, since we can't fetch it using
      // the API after cycling once (for whatever reason)
      @c = original_player;
    }
    else {
      @c = controllable_by_id( unit_ids[ cycle_index ] );
    }

    if ( ( @c == null ) || c.is_same( current_player ) ) {
      if ( @c == null ) {
        // remove the null controllable from the pool such that we avoid a
        // infinite loop
        unit_ids.removeAt( cycle_index );
      }

      cycle_unit();
      return;
    }

    // switch to the other unit
    current_player_id = c.id();
    @current_player = c.as_dustman();
    controller_entity( 0, c );

    cycling = false;

    // reset the camera and have it attempt to follow the new player
    reset_camera( 0 );
  }

  void draw( float sub_frames ) {
    if ( multiplayer ) {
      return;
    }

    if ( @current_player != null ) {
      // draw a arrow floating above the current unit's head
      arrow.draw_world(
        20, // layer
        arrow_sub_layer, // sublayer
        "symbol_1", // spriteName
        1, // frame
        1, // palette
        current_player.x() - 75, // x
        ( current_player.y() - 65 ), // y
        90, // rotation
        0.8, // scale_x
        0.8, // scale_y
        0xFFFFFFFF // colour
      );
    }
  }

  void reset() {
    if ( multiplayer ) {
      return;
    }

    current_player_id = 0;
    cycle_index = 0;
    @original_player = null;
    @current_player = null;
    unit_ids.removeRange( 0, unit_ids.length );
  }

  void checkpoint_load() {
    if ( multiplayer ) {
      return;
    }

    // (from the documentation:) controller_controllable() objects are no longer
    // valid and should be requeried when a checkpoint is loaded - therefore,
    // reset all params
    reset();

    // do hacky shit to make sure we don't load the player back in as the dead
    // unit
    controller_controllable( 0 ).as_dustman().character( character_type );
  }

  void entity_on_remove( entity@ e ) {
    if ( multiplayer ) {
      return;
    }

    if ( ( e.id() == 0 ) || e.is_same( current_player ) ) {
      return;
    }
    if ( unit_ids.find( e.id() ) >= 0 ) {
      current_player.kill( false );
    }
  }
}
