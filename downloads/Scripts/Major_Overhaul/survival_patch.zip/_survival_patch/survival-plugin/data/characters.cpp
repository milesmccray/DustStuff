const array<string> CHARACTERS = {
  "dustman",
  "dustgirl",
  "dustkid",
  "dustworth",
  "dustwraith",
  "leafsprite",
  "trashking",
  "slimeboss"
};
const array<string> JANITORS = {
  "dustman",
  "dustgirl",
  "dustkid",
  "dustworth"
};
const array<string> BOSSES = {
  "dustwraith",
  "leafsprite",
  "trashking",
  "slimeboss"
};

const array<string> V_CHARACTERS = {
  "vdustman",
  "vdustgirl",
  "vdustkid",
  "vdustworth",
  "vdustwraith",
  "vleafsprite",
  "vtrashking",
  "vslimeboss"
};
const array<string> V_JANITORS = {
  "vdustman",
  "vdustgirl",
  "vdustkid",
  "vdustworth"
};
const array<string> V_BOSSES = {
  "vdustwraith",
  "vleafsprite",
  "vtrashking",
  "vslimeboss"
};

const array<string> ALL_CHARACTERS = {
  "dustman",
  "dustgirl",
  "dustkid",
  "dustworth",
  "dustwraith",
  "leafsprite",
  "trashking",
  "slimeboss",
  "vdustman",
  "vdustgirl",
  "vdustkid",
  "vdustworth",
  "vdustwraith",
  "vleafsprite",
  "vtrashking",
  "vslimeboss"
};
const array<string> ALL_JANITORS = {
  "dustman",
  "dustgirl",
  "dustkid",
  "dustworth",
  "vdustman",
  "vdustgirl",
  "vdustkid",
  "vdustworth"
};
const array<string> ALL_BOSSES = {
  "dustwraith",
  "leafsprite",
  "trashking",
  "slimeboss",
  "vdustwraith",
  "vleafsprite",
  "vtrashking",
  "vslimeboss"
};

const dictionary CHARACTER_ACRONYMS = {
  { "dustman", "dm" },
  { "dustgirl", "dg" },
  { "dustkid", "dk" },
  { "dustworth", "do" },
  { "dustwraith", "dw" },
  { "leafsprite", "ls" },
  { "trashking", "tk" },
  { "slimeboss", "sb" },

  { "vdustman", "vdm" },
  { "vdustgirl", "vdg" },
  { "vdustkid", "vdk" },
  { "vdustworth", "vdo" },
  { "vdustwraith", "vdw" },
  { "vleafsprite", "vls" },
  { "vtrashking", "vtk" },
  { "vslimeboss", "vsb" }
};

const dictionary BASE_JANITOR_EQUIVALENTS = {
  { "vdustman", "dustman" },
  { "dustwraith", "dustman" },
  { "vdustwraith", "dustman" },

  { "vdustgirl", "dustgirl" },
  { "leafsprite", "dustgirl" },
  { "vleafsprite", "dustgirl" },

  { "vdustkid", "dustkid" },
  { "trashking", "dustkid" },
  { "vtrashking", "dustkid" },

  { "vdustworth", "dustworth" },
  { "slimeboss", "dustworth" },
  { "vslimeboss", "dustworth" }
};
