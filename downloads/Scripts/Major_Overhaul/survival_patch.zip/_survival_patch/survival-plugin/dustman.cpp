#include "./std.cpp";
#include "./enums/state_types.cpp";

class SpecialUpDustman {
  scene@ g;
  int player_index;
  dustman@ player;
  hittable@ hittable;

  hitbox@ hb;

  float SPEED_X = 1250;
  float SPEED_Y = 1250;

  int timer = -1;
  int interval = 12;
  int effect_interval = 3;
  int heavy_interval = 5;
  int end_interval = 10;

  int last_x_intent = -10;
  int last_y_intent = -10;

  bool hit_wall_or_ceiling = false;

  bool active = true;
  bool initialized = false;
  bool canceled = false;

  SpecialUpDustman(dustman@ player) {
    @this.player = player;
    @this.hittable = player.as_hittable();
    this.player_index = player.player_index();
    @g = get_scene();
  }

  void step() {
    if (!active) {
      return;
    }

    timer++;

    if (player.state() == state_types::spawn) {
      // player died and is respawning
      active = false;
      return;
    }

    if (!initialized) {
      if (player.attack_timer() > 0) {
        active = false;
        canceled = true;
        return;
      }

      if (player.x_intent() != 0) {
        // set the x-facing direction (zero does not exist for a facing
        // direction and would cause an invisible sprite bug)
        player.face(player.x_intent());
        last_x_intent = player.x_intent();
      }
      else {
        last_x_intent = player.face();
      }

      initialized = true;
    }

    if (timer == 0) {
      player.sprite_index("crouch");
    }

    if (timer < interval && timer % 3 == 0) {
      // gradually slow the player down until the first interval
      player.set_speed_xy(player.x_speed() / 1.5, player.y_speed() / 1.5);
    }

    if (timer == interval) {
      player.set_speed_xy(3000 * last_x_intent, -5000);

      player.state(state_types::hover);
      player.sprite_index("groundstrikeu1");
    }

    if (timer == (interval + effect_interval)) {
      // entity@ add_effect(string sprite_set, string sprite_name, float x, float y, float rotation, float scale_x, float scale_y, float frame_rate);
      g.add_effect("dustman", "dmheavyd", player.x() - 20, player.y() - 150, 180, -1.25, 1.25, 20);
    }

    if (timer == (interval + heavy_interval)) {
      player.set_speed_xy(0, 0);

      // hitbox@ create_hitbox(controllable@ owner, float activate_time, float x, float y, float top, float bottom, float left, float right);
      @hb = create_hitbox(player.as_controllable(), 0, player.x(), player.y(), -100, 100, 0, 200);
      // timer speed in frames per second
      hb.timer_speed(60);
      hb.attack_strength(1600);
      hb.can_parry(false);
      // have the direction of the attack be a radius outwards from the center
      // of the hitbox, rather than using a set direction
      hb.aoe(true);

      g.add_entity(hb.as_entity() );
    }

    // instant attack
    if (timer > (interval + heavy_interval) && player.attack_timer() > 0) {
      hitbox@ h = player.hitbox();
      if (h !is null) { // light or heavy attacks
        h.state_timer(h.activate_time());
      }
      player.freeze_frame_timer(0);
    }
    if (player.attack_timer() < 0 and player.attack_timer() != -1) {
      player.attack_timer(0);
    }

    if (timer < (interval + heavy_interval + end_interval)) {
      // disallow the player from dashing or jumping during the specialUp
      lock_player_intents(player);
    }
    else {
      active = false;
    }
  }

  void subframe_callback() {
    if (!active) {
      return;
    }
  }

  void set_dir_intents(dustman@ p, int &out x_int, int &out y_int) {
    x_int = p.x_intent();
    y_int = p.y_intent();
    if (x_int == 0 && y_int == 0) {
      x_int = p.face();
    }
  }

  void lock_player_intents(dustman@ p) {
    p.dash_intent(0);
    p.jump_intent(0);
    p.heavy_intent(0);
    p.light_intent(0);
  }

  void play_sfx(string sfx_name) {
    g.play_sound(sfx_name, 3, 0, 1, false, false);
  }
}

class DustmanSpecialManager : callback_base {
  scene@ g;

  bool initialized = false;

  int timer = 0;

  array<SpecialUpDustman@> active_specials = {};

  DustmanSpecialManager() {
    @g = get_scene();
  }

  void step(int entities, array<dustman@> players) {
    timer++;

    if (players.size() == 0 ) {
      return;
    }

    if (!initialized) {
      for (uint i = 0; i < players.length; i++) {
        players[i].on_subframe_end_callback(this, "on_subframe_end", 0);
      }

      initialized = true;
    }

    // remove any inactive specials and refresh the ability for the player to
    // activate a new one
    for (uint i = 0; i < active_specials.length; i++) {
      SpecialUpDustman@ special = active_specials[i];
      if ((!special.active && special.player.ground()) || (special.player.state() == state_types::spawn)) {
        // remove the active special only once the player touches the ground or
        // just died and is respawning
        active_specials.removeAt(i);
        i--;
      }
      else if (special.canceled) {
        active_specials.removeAt(i);
        i--;
      }
    }

    for (uint i = 0; i < players.length; i++) {
      dustman@ p = players[i];

      if (@p == null) {
        puts("ERROR: P == NULL");
        continue;
      }

      // player 1 during testing
      if (p.player_index() == 0) {
        puts(p.attack_timer());
      }

      if (p.state() == state_types::spawn) {
        // this player is currently respawning
        continue;
      }

      bool already_active = false;
      for (uint j = 0; j < active_specials.length; j++) {
        if (active_specials[j].player_index == p.player_index()) {
          already_active = true;
          break;
        }
      }
      if (already_active) {
        // this player is already in the middle of their special
        continue;
      }

      hittable@ ph = p.as_hittable();

      if (@ph == null) {
        puts("ERROR: PH == NULL");
        return;
      }

      if (p.taunt_intent() == 1 && p.y_intent() == -1) {
        p.taunt_intent(0);
        // create a new SpecialUpDustman instance for this player
        SpecialUpDustman@ special = SpecialUpDustman(p);
        active_specials.insertLast(special);
      }
    }

    for (uint i = 0; i < active_specials.length; i++) {
      active_specials[i].step();
    }
  }

  void on_subframe_end(dustman@ dm, int) {
    // run the subframe callback of a possibly existing special
    for (uint i = 0; i < active_specials.length; i++) {
      if (active_specials[i].player_index == dm.player_index()) {
        active_specials[i].subframe_callback();
        break;
      }
    }
  }
}
