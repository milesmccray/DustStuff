const int MAX_PLAYERS = 4;

class script {
  scene@ g;

  array<dustman@> players = {};

  int timer = -1;
  [persistent] int time_seconds = 5;
  int kill_timer = 0;

  uint num_players = 0;
  bool initialized = false;

  int wait_level_start = 0;

  script() {
    @g = get_scene();
  }

  void on_level_end() {
    puts("level ended");
  }

  void step( int entities ) {
    timer++;

    if (timer < wait_level_start) {
      return;
    }

    uint cams = num_cameras();
    uint players_found = 0;
    for ( uint i = 0; i < cams; i++ ) {
      controllable@ c = controller_controllable( i );
      if ( @c == null ) {
        continue;
      }

      dustman@ dm = c.as_dustman();
      if ( @dm == null ) {
        continue;
      }

      bool broke = false;
      for ( uint j = 0; j < players.length; j++ ) {
        if ( players[ j ].is_same( dm ) ) {
          broke = true;
          break;
        }
      }

      players_found++;

      if ( broke ) {
        continue;
      }

      players.insertLast( dm );
    }

    if (!initialized) {
      num_players = players_found;
      initialized = true;
    }

    if (timer >= (time_seconds * 60)) {
      // start killing players one at a time until a result happens
      kill_timer++;
      if (kill_timer % 60 == 0 && (players_found == num_players)) {
        for ( uint i = 0; i < players.length; i++) {
          players[ i ].kill(false);
        }
      }
    }
  }
}
