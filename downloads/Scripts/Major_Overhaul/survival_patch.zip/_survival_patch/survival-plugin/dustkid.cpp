#include "./std.cpp";
#include "./enums/state_types.cpp";

class SpecialUpDustkid {
  scene@ g;
  int player_index;
  dustman@ player;
  hittable@ hittable;

  float SPEED_X = 1250;
  float SPEED_Y = 1250;

  int timer = 0;
  int interval = 20;
  int interval2 = 40;
  int end_time = 41;

  int last_x_intent = -10;
  int last_y_intent = -10;

  bool hit_wall_or_ceiling = false;

  bool active = true;
  bool initialized = false;

  SpecialUpDustkid(dustman@ player) {
    @this.player = player;
    @this.hittable = player.as_hittable();
    this.player_index = player.player_index();
    @g = get_scene();
  }

  void step() {
    if (!active) {
      return;
    }

    timer++;

    if (player.state() == state_types::spawn) {
      // player died and is respawning
      active = false;
      return;
    }

    if (!initialized) {
      if (player.x_intent() != 0) {
        // set the x-facing direction (zero does not exist for a facing
        // direction and would cause an invisible sprite bug)
        player.face(player.x_intent());
      }

      play_sfx("sfx_stoneboss_jump");

      initialized = true;
    }

    if (timer <= interval2) {
      if (player.ground()) {
        // when in e.g. state "crouch_jump", the controllable::set_speed_xy method
        // does nothing, so just put the player in skid when grounded - if we put
        // them in idle, the player will be able to rapidly change their
        // direction, so we don't want that
        player.state(state_types::skid);
      }
      else {
        player.state(state_types::hover);
      }
    }

    if (timer < interval && timer % 3 == 0) {
      // gradually slow the player down until the first interval
      player.set_speed_xy(player.x_speed() / 2, player.y_speed() / 2);
    }

    if (timer == interval || timer == interval2) {
      float speed_x = 0;
      float speed_y = 0;
      int x_int = -10;
      int y_int = -10;
      set_dir_intents(player, x_int, y_int);
      bool can_spu = false;

      if (x_int != last_x_intent || y_int != last_y_intent) {
        can_spu = true;
        last_x_intent = x_int;
        last_y_intent = y_int;
      }

      // a player cannot continue specialUp here if they already used the same x
      // and y intent in a previous interval
      if (can_spu) {
        if (player.x_intent() != 0) {
          // set the x-facing direction (zero does not exist for a facing
          // direction and would cause an invisible sprite bug)
          player.face(player.x_intent());
        }

        set_spu_speed(player, speed_x, speed_y);
        player.set_speed_xy(speed_x, speed_y);

        if (player.ground()) {
          g.add_effect("particles", "foam2", player.x(), player.y() - 10, 0, 2, 2, 12);
        }
        else {
          g.add_effect("particles", "foam2", player.x(), player.y() - 10, 0, 1.75, 1.75, 12);
          g.add_effect("particles", "foam1", player.x(), player.y(), 0, 1.75, 1.75, 12);
        }

        play_sfx("sfx_bear_attack");
      }
      else {
        active = false;
        return;
      }
    }

    if (timer < end_time) {
      // disallow the player from dashing or jumping during the specialUp
      lock_player_intents(player);
    }
    else {
      active = false;
    }
  }

  void subframe_callback() {
    if (!active) {
      return;
    }

    if (player.state() == state_types::roof_run) {
      // allow the player to go into a roof run if that happens to work out, but
      // cancel the special if so
      active = false;
      return;
    }

    // do some visual work with the player sprite without messing up their state
    if (timer < interval) {
      player.sprite_index("crouch");
    }
    else if (timer > (interval2 - 10) && timer < interval2) {
      player.sprite_index("crouch");
    }
    else if (timer < interval2) {
      player.sprite_index("dash");
    }
  }

  void set_dir_intents(dustman@ p, int &out x_int, int &out y_int) {
    x_int = p.x_intent();
    y_int = p.y_intent();
    if (x_int == 0 && y_int == 0) {
      x_int = p.face();
    }
  }

  void set_spu_speed(dustman@ p, float &out x, float &out y) {
    int x_int;
    int y_int;
    set_dir_intents(p, x_int, y_int);

    float sx = SPEED_X;
    float sy = SPEED_Y;
    float x_modifier = 1.0;
    float y_modifier = 1.0;
    if (p.ground()) {
      // possibly reduce speed on the ground because it has much greater effect
      // versus air friction; NOTE: we currently use "skid" state, so that
      // already increases friction by quite a bit so comment this out for now
      // x_modifier = 0.75;
    }

    if (x_int != 0 && y_int != 0) {
      if (y_int == 1) {
        // make diagonal down more diagonal
        y_modifier = 0.75;
        x_modifier = 1.5;
      }
    }
    else if (x_int != 0) {
      x_modifier = 1.5;
    }
    else if (y_int != 0) {
      if (y_int == 1) {
        y_modifier = 0.75;
      }
    }

    if (x_int != 0) {
      x = (sx * x_modifier) * x_int;
    }
    if (y_int != 0) {
      y = (sy * y_modifier) * y_int;
    }
  }

  void lock_player_intents(dustman@ p) {
    p.dash_intent(0);
    p.jump_intent(0);
  }

  void play_sfx(string sfx_name) {
    g.play_sound(sfx_name, 3, 0, 1, false, false);
  }
}

class DustkidSpecialManager : callback_base {
  scene@ g;

  bool initialized = false;

  int timer = 0;

  array<SpecialUpDustkid@> active_specials = {};

  DustkidSpecialManager() {
    @g = get_scene();
  }

  void step(int entities, array<dustman@> dk_players) {
    timer++;

    if (dk_players.size() == 0 ) {
      return;
    }

    if (!initialized) {
      for (uint i = 0; i < dk_players.length; i++) {
        dk_players[i].on_subframe_end_callback(this, "on_subframe_end", 0);
      }

      initialized = true;
    }

    // remove any inactive specials and refresh the ability for the player to
    // activate a new one
    for (uint i = 0; i < active_specials.length; i++) {
      SpecialUpDustkid@ special = active_specials[i];
      if ((!special.active && special.player.ground()) || (special.player.state() == state_types::spawn)) {
        // remove the active special only once the player touches the ground or
        // just died and is respawning
        active_specials.removeAt(i);
        i--;
      }
    }

    for (uint i = 0; i < dk_players.length; i++) {
      dustman@ p = dk_players[i];

      if (@p == null) {
        puts("ERROR: p == NULL");
        continue;
      }

      // player 1 during testing
      if (p.player_index() == 0) {
      }

      if (p.state() == state_types::spawn) {
        // this player is currently respawning
        continue;
      }

      bool already_active = false;
      for (uint j = 0; j < active_specials.length; j++) {
        if (active_specials[j].player_index == p.player_index()) {
          already_active = true;
          break;
        }
      }
      if (already_active) {
        // this player is already in the middle of their special
        continue;
      }

      hittable@ ph = p.as_hittable();

      if (@ph == null) {
        puts("ERROR: p == NULL");
        return;
      }

      if (p.taunt_intent() == 1 && p.y_intent() == -1) {
        // create a new SpecialUpDustkid instance for this player
        SpecialUpDustkid@ special = SpecialUpDustkid(p);
        active_specials.insertLast(special);
      }
    }

    for (uint i = 0; i < active_specials.length; i++) {
      active_specials[i].step();
    }
  }

  void on_subframe_end(dustman@ dm, int) {
    // run the subframe callback of a possibly existing special
    for (uint i = 0; i < active_specials.length; i++) {
      if (active_specials[i].player_index == dm.player_index()) {
        active_specials[i].subframe_callback();
        break;
      }
    }
  }
}
