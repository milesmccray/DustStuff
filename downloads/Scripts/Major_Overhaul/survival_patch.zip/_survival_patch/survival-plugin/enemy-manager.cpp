class NewEntity {
  string type;
  // timer and respawn_after in frames
  int timer = 0;
  int respawn_after;
  float x;
  float y;
  // nodes that the entity moves to
  varstruct@ ai_vars;
  // facing direction
  int facing;

  NewEntity(int respawn_after, string type, float x, float y, varstruct@ ai_vars, int facing) {
    this.respawn_after = respawn_after;
    this.type = type;
    this.x = x;
    this.y = y;
    @this.ai_vars = ai_vars;
    this.facing = facing;
  }

  void step() {
    this.timer++;
  }
}

class LivingEntity {
  uint id;
  string type;
  float x;
  float y;
  // nodes that the entity moves to
  varstruct@ ai_vars;
  // facing direction
  int facing;

  LivingEntity(uint id, string type, float x, float y, varstruct@ vars, int facing) {
    this.id = id;
    this.type = type;
    this.x = x;
    this.y = y;
    @this.ai_vars = vars;
    this.facing = facing;
  }
}

/*
  IMPORTANT NOTE: the behaviour in multiplayer Survival is that if any player
  dies, the script resets specifically the annotation variables to their
  original state. E.g. an annotation variable `[entity] int entity_id` will
  reset to its original value, as set in the editor, when any player dies

  Therefore if annotation variables are desired to be used and modified during
  the script, assign their values to other non-annotation variables at level
  start
*/

class script {
  scene@ scene;
  [entity] array<int> enemy_ids = {};
  // if respawn_after is set to -1, don't respawn entities
  [persistent] int respawn_after = 180;
  array<LivingEntity@> living_entities = {};

  array<NewEntity@> entity_queue = {};

  bool initialized = false;

  script() {
    @scene = get_scene();
  }

  void entity_on_remove(entity@ e) {
    uint id = e.id();
    for (uint i = 0; i < living_entities.length; i++) {
      if (living_entities[i].id == id) {
        LivingEntity@ l_entity = living_entities[i];
        NewEntity@ new_entity = NewEntity(respawn_after, l_entity.type, l_entity.x, l_entity.y, l_entity.ai_vars, l_entity.facing);
        living_entities.removeAt(i);
        entity_queue.insertLast(new_entity);
        break;
      }
    }
  }

  void step(int entities) {
    if (!initialized) {
      // store more info of the entities like their positioning and movement
      // nodes so we can respawn them in the same spot always
      for (uint i = 0; i < enemy_ids.length; i++) {
        entity@ e = entity_by_id(enemy_ids[i]);

        if (@e == null) {
          puts("UserError: Annotated entity with ID: " + "'" + enemy_ids[i] + "'" + " does not exist.");
          continue;
        }

        // set the team from "0" to "2", as the boss characters are team "0"
        // already, which means they can't hit enemies by default
        e.as_hittable().team(2);

        varstruct@ entity_vars;
        // get the node(s) the entity moves to
        for (int j = 0; j < entities; j++) {
          entity@ ai_entity = entity_by_index(j);
          if (ai_entity.type_name() == "AI_controller") {
            varstruct@ vars = ai_entity.vars();

            if (vars.get_var("puppet_id").get_int32() == int(e.id()) ) {
              @entity_vars = vars;
            }
          }
        }

        LivingEntity@ l_entity = LivingEntity(e.id(), e.type_name(), e.x(), e.y(), entity_vars, e.face());
        living_entities.insertLast(l_entity);
      }

      initialized = true;
    }

    if (respawn_after >= 0) {
      for (uint i = 0; i < entity_queue.length; i++) {
        entity_queue[i].step();
        if (entity_queue[i].timer >= entity_queue[i].respawn_after) {
          puts( "RESPAWN NEW ENTITY " + entity_queue[i].x + " " + entity_queue[i].y);
          add_entity(entity_queue[i]);
          entity_queue.removeAt(i);
          i--;
        }
      }
    }
  }

  void add_entity(NewEntity@ new_entity) {
    entity@ spawnee = create_entity(new_entity.type);

    spawnee.x(new_entity.x);
    spawnee.y(new_entity.y);

    // set the team from "0" to "2", as the boss characters are team "0"
    // already, which means they can't hit enemies by default
    spawnee.as_hittable().team(2);

    spawnee.face(new_entity.facing);
    scene.add_entity(spawnee);

    entity@ ai = create_entity("AI_controller");
    ai.x(spawnee.x());
    ai.y(spawnee.y());

    varstruct@ ai_vars = ai.vars();
    ai_vars.get_var("puppet_id").set_int32(spawnee.id());
    vararray@ ai_nodes = ai_vars.get_var("nodes").get_array();
    vararray@ ai_nodes_wait_time = ai_vars.get_var("nodes_wait_time").get_array();

    varstruct@ vars = new_entity.ai_vars;
    vararray@ nodes = vars.get_var("nodes").get_array();
    vararray@ nodes_wait_time = vars.get_var("nodes_wait_time").get_array();

    ai_nodes.resize(nodes.size());
    ai_nodes_wait_time.resize(nodes_wait_time.size());
    for (uint i = 0; i < nodes.size(); i++) {
      float x = nodes.at(i).get_vec2_x();
      float y = nodes.at(i).get_vec2_y();
      ai_nodes.at(i).set_vec2(x, y);
    }
    for (uint i = 0; i < nodes_wait_time.size(); i++) {
      int32 wait_time = nodes_wait_time.at(i).get_int32();
      ai_nodes_wait_time.at(i).set_int32(wait_time);
    }

    scene.add_entity(ai);

    LivingEntity@ l_entity = LivingEntity(spawnee.id(), spawnee.type_name(), spawnee.x(), spawnee.y(), vars, spawnee.face());
    living_entities.insertLast(l_entity);
  }
}
