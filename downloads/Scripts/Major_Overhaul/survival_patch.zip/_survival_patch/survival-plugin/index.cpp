#include "./dustkid.cpp";
#include "./dustman.cpp";
#include "./data/characters.cpp";

class script {
  scene@ g;

  array<dustman@> players();

  dictionary players_dict = {
    {"dustman", array<dustman@>()},
    {"dustgirl", array<dustman@>()},
    {"dustkid", array<dustman@>()},
    {"dustworth", array<dustman@>()}
  };

  DustkidSpecialManager@ dustkid_special_manager;
  DustmanSpecialManager@ dustman_special_manager;

  script() {
    @g = get_scene();

    @dustkid_special_manager = DustkidSpecialManager();
    @dustman_special_manager = DustmanSpecialManager();
  }

  void step(int entities) {
    fetch_players();

    if (players.size() == 0) {
      puts("USERERROR: index.cpp - players.size() == 0");
      return;
    }

    // array<string> keys = players_dict.getKeys();
    // for (uint i = 0; i < keys.length; i++) {
    //   array<dustman@> p;
    //   players_dict.get(keys[i], p);
    // }

    dustkid_special_manager.step(entities, cast<array<dustman@>>(players_dict["dustkid"]));
    dustman_special_manager.step(entities, cast<array<dustman@>>(players_dict["dustman"]));

    /*
      uncomment to turn on for all characters
    */
    // dustkid_special_manager.step(entities, players);
    // dustman_special_manager.step(entities, players);
  }

  void fetch_players() {
    uint cams = num_cameras();
    for (uint i = 0; i < cams; i++) {
      controllable@ c = controller_controllable(i);
      if (@c == null) {
        continue;
      }

      dustman@ dm = c.as_dustman();
      if (@dm == null) {
        continue;
      }

      bool broke = false;
      for (uint j = 0; j < players.length; j++) {
        if (players[j].is_same(dm)) {
          broke = true;
          break;
        }
      }
      if (broke) {
        continue;
      }

      string character = dm.character();
      int index = JANITORS.find(character);
      if (index < 0) {
        // convert bosses and virtual janitors to their regular janitor
        // counterparts, e.g. "dustwraith" to "dustman", or "vdustgirl" to
        // "dustgirl", so we can aggregate them all in the same base character
        // arrays
        BASE_JANITOR_EQUIVALENTS.get(dm.character(), character);
      }

      array<dustman@> p;
      bool exists = players_dict.get(character, p);
      if (exists) {
        p.insertLast(dm);
        players_dict.set(character, p);
      }

      players.insertLast(dm);
    }
  }
}
