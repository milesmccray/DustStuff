#include 'debugging.cpp'
#include 'section_option.cpp'
#include 'intents.cpp'

const int L1_NUMBER_SECTION_OPTIONS = 17;
const int L1_NUMBER_MAP_SECTIONS = 3;

const int L2_NUMBER_SECTION_OPTIONS = 15;
const int L2_NUMBER_MAP_SECTIONS = 4;

const int L3_NUMBER_SECTION_OPTIONS = 12;
const int L3_NUMBER_MAP_SECTIONS = 5;


  class script {
    // Initializing player and scene
    scene@ g;
    dustman@ player;
    
    // making an intents object to track player intents
    intents intents;
    
    // Initializing rng seed
    int rng_seed = 0;

    // Adding an option to disable the boxes from showing
    [text] bool Show_Boxes = true;
    
    // Variables for index creation
    array<int> L1_Section_indicies(L1_NUMBER_MAP_SECTIONS);
    array<int> L1_candidates(L1_NUMBER_SECTION_OPTIONS);

    array<int> L2_Section_indicies(L2_NUMBER_MAP_SECTIONS);
    array<int> L2_candidates(L2_NUMBER_SECTION_OPTIONS);

    array<int> L3_Section_indicies(L3_NUMBER_MAP_SECTIONS);
    array<int> L3_candidates(L3_NUMBER_SECTION_OPTIONS);
    
    int rand;
    
    // 3 booleans for secret, determing if it is first time seeding rng, and determing if
    // map construction is done or not
    bool normal_everyday_things = false; // end flag is conssidered col_type_trigger_area
    bool first_time = true;
    bool map_construction_done = false;
    bool map_construction_done2 = false;
    bool map_construction_done3 = false;
    bool area_entered = false;
	
    // Creating  variables describing the limits of the starting area
    [text] area Starting_Area;
    
    // Creating  variables describing the limits of the construction area
    [text] array<area> Const_Area;

    // Creating a varible for loading areas
    [text] array<area> Loading_Section;
    
    // Defining an array of section options
    [text] array<section_option> L1_Sections;
    [text] section_option L1_Ending_Section;

    [text] array<section_option> L2_Sections;
    [text] section_option L2_Ending_Section;

    [text] array<section_option> L3_Sections;
    [text] section_option L3_Ending_Section;
    
    // RNG Seed Text position
    [position,mode:world,layer:19,y:Texty] int Textx;
	  [hidden] int Texty;
    
    // RMG Seed Textfield Object
    textfield@ Seed_Text;

    // Stuff Position
    [position,mode:world,layer:19,y:L1sy] int L1sx;
	  [hidden] int L1sy;

    [position,mode:world,layer:19,y:L2sy] int L2sx;
	  [hidden] int L2sy;

    [position,mode:world,layer:19,y:L3sy] int L3sx;
	  [hidden] int L3sy;

    // Stuff textfield
    textfield@ L1s;
    textfield@ L2s;
    textfield@ L3s;
    
    // Stuff String
    string temp_string = "";
    string temp_string2 = "";
    string temp_string3 = "";

    // Array of actual map sections ordered correctly
    array<section_option> L1_Section_Ordered(L1_NUMBER_MAP_SECTIONS);
    array<section_option> L2_Section_Ordered(L2_NUMBER_MAP_SECTIONS);
    array<section_option> L3_Section_Ordered(L3_NUMBER_MAP_SECTIONS);
    
    // Defining a current tile info for use when constructing map
    tileinfo@ CurrentTile;
    tilefilth@ CurrentTileFilth;
    
    // Defining current prop and entity info
    prop@ CurrentProp;
    entity@ CurrentEntity;
    
    // Defining offset variables for prop and entitiy construction
    int offset_x = 0;
    int offset_y = 0;
    int cumulative_width = 0;
    int cumulative_height = 0;
    int normal_section_height = 0;
    int normal_section_height2 = 0;

    array<int> L1_connection_offset(L1_NUMBER_MAP_SECTIONS+1);
    array<int> L2_connection_offset(L2_NUMBER_MAP_SECTIONS+1);
    array<int> L3_connection_offset(L3_NUMBER_MAP_SECTIONS+1);

    // Defining an int to serve as the current prop/entity collision
    int CurrentPropCollision = 0;
    int CurrentEntityCollision = 0;
    
    // Defining a var struct variables for fixing camera path
    varstruct@ varstruct;
    varvalue@ val;
    vararray@ valarray;
    varvalue@ tempvar;
    
    // Defining entities for camera construction
    entity@ Camera1;
    entity@ Camera2;
    
    // Defining a temp variable for various use
    int temp = 0;
    
    // Defining a frame count for each level
    // Thiss ensures that the camera has caught up to the loading area when map conssstruction begins
    int L1_Frame_Count = 0;
    int L2_Frame_Count = 0;
    int L3_Frame_Count = 0;

    // Secret stuff
    [text] area Secret_Area;
    [text] area Secret_Tiles;

    bool Secret_Tiles_Destroyed = false;

    array<int> Sequence_Layers(44);
    array<int> Sequence_Sublayers(44);

    string CurrentSequence = "";
    string CorrectSequence = "SXSSDZWAZXAADCXXWSDCXWSDASACXTWAWWWXDSDDSDWZ";

    int CurrentSequenceLength = 0;
    int CorrectSequenceLength = 45;

    int CurrentLayer = 13;
    int CurrentSubLayer = 0;

    bool failed = false;

    bool SequenceDone = false;

    camera@ CurrentCamera;

    fog_setting@ CurrentFog;

    [text] section_option L1_Apple_Area;
    [text] section_option L2_Apple_Area;
    [text] section_option L3_Apple_Area;
    [text] section_option L4_Apple_Area;

    int End_Flag_Id = 3276;

    bool L1_Apples_Destroyed = false;
    bool L2_Apples_Destroyed = false;
    bool L3_Apples_Destroyed = false;
    bool L4_Apples_Destroyed = false;



    bool TeleportDone = false;

    [position,mode:world,layer:19,y:L1Appley] int L1Applex;
	  [hidden] int L1Appley;

    [position,mode:world,layer:19,y:L2Appley] int L2Applex;
	  [hidden] int L2Appley;

    [position,mode:world,layer:19,y:L3Appley] int L3Applex;
	  [hidden] int L3Appley;

    [position,mode:world,layer:19,y:L4Appley] int L4Applex;
	  [hidden] int L4Appley;
    
    script() {
      // Getting scene
      @g = get_scene();
      @CurrentCamera = get_camera(0);

      @Seed_Text = @create_textfield();
      Seed_Text.set_font("Caracteres", 64);
      Seed_Text.align_horizontal(-1);
      Seed_Text.text(rng_seed+"");

      @L1s = @create_textfield();
      L1s.set_font("Caracteres", 64);
      L1s.align_horizontal(-1);

      @L2s = @create_textfield();
      L2s.set_font("Caracteres", 64);
      L2s.align_horizontal(-1);

      @L3s = @create_textfield();
      L3s.set_font("Caracteres", 64);
      L3s.align_horizontal(-1);
    }
    
    void on_level_start() {
		  puts("LEVEL START"); 
    
      // if no player is defined, get the player
      if(@player == null) {
        controllable@ c = controller_controllable(0);
        if(@c != null) {
          @player = c.as_dustman();
        }
      }
    
    }

    void checkpoint_load(){
      @player = null;
    }
    
    void step(int entities) {      
      //if no player is defined, get the player
      if(@player == null) {
        controllable@ c = controller_controllable(0);
        if(@c != null) {
          @player = c.as_dustman();
        }
        //if there's no player, we can't step this frame
        if(@player == null)
          return;
      }
      
      if(Starting_Area.player_in_area(player)) {
        area_entered = true;
        if(((player.character() != "vdustman") && (player.character() != "vdustgirl")) &&
          ((player.character() != "vdustkid") && (player.character() != "vdustworth"))){
          
          player.character("v"+player.character());

        }
      }
      
      if (area_entered) {
        // Assuming that it is not the first time
        if(first_time) {
          // If the player is within the starting area
          if(Starting_Area.player_in_area(player)) {

            // Record the current intents
            intents.setCurrentIntents(player);
            
            // If it has changed and the intent has not been used, increment the rng seed
            if(intents.checkHeavyIntent()) {
              rng_seed += 10 * 71;
            }
            
            if(intents.checkLightIntent()) {
              rng_seed += 10 * 518;
            } 
            
            if(intents.checkJumpIntent()) {
              rng_seed += 1 * 1843;
            } 
            
            if(intents.checkDashIntent()) {
              rng_seed += 1 * 19567;
            } 
            
            // If the player has supered note this for no particular reason
            if( player.attack_state() == 3) {
              normal_everyday_things = true;
            }
            
            // Record the current intents as previous intents to have a comparison point
            intents.setPreviousIntents(player);

            Seed_Text.text(rng_seed+"");
          } else { 
            // Seed the rng wwith the rng seed calculated above
            srand(rng_seed);
            
            // Defining the avalable L1_candidates
            for(int i = 0; i < L1_NUMBER_SECTION_OPTIONS; i++) {
              L1_candidates[i] = i;
            }
            
            for(int i = 0; i < L1_NUMBER_MAP_SECTIONS; i++) {
              // generating a random integer that is within the pool of L1_candidates
              rand = rand_int(0, L1_candidates.length());
              // setting the current section index to the position in the array index rand in the L1_candidates array
              L1_Section_indicies[i] = L1_candidates[rand];
              //removing that entry from the L1_candidates array such that it wont be repeated
              L1_candidates.removeAt(rand); 
            }

            for(int i = 0; i < L2_NUMBER_SECTION_OPTIONS; i++) {
              L2_candidates[i] = i;
            }
            
            for(int i = 0; i < L2_NUMBER_MAP_SECTIONS; i++) {
              // generating a random integer that is within the pool of L1_candidates
              rand = rand_int(0, L2_candidates.length());
              // setting the current section index to the position in the array index rand in the L1_candidates array
              L2_Section_indicies[i] = L2_candidates[rand];
              //removing that entry from the L1_candidates array such that it wont be repeated
              L2_candidates.removeAt(rand); 
            }

             for(int i = 0; i < L3_NUMBER_SECTION_OPTIONS; i++) {
              L3_candidates[i] = i;
            }
            
            for(int i = 0; i < L3_NUMBER_MAP_SECTIONS; i++) {
              // generating a random integer that is within the pool of L1_candidates
              rand = rand_int(0, L3_candidates.length());
              // setting the current section index to the position in the array index rand in the L1_candidates array
              L3_Section_indicies[i] = L3_candidates[rand];
              //removing that entry from the L1_candidates array such that it wont be repeated
              L3_candidates.removeAt(rand); 
            }
            
            // note that this is no longer the first time
            first_time = false;
          }
        }
      }
      
      if( !first_time && !map_construction_done){
        @L1s = @create_textfield();
        L1s.set_font("Caracteres", 64);
        L1s.align_horizontal(-1);

        @L2s = @create_textfield();
        L2s.set_font("Caracteres", 64);
        L2s.align_horizontal(-1);

        @L3s = @create_textfield();
        L3s.set_font("Caracteres", 64);
        L3s.align_horizontal(-1);

        for(int i = 0; i < L1_Section_indicies.length(); i++){
          if(L1_Section_indicies[i] == 0){
            temp_string += "0S";
          } else if (L1_Section_indicies[i] == 1) {
            temp_string += "1X";
          } else if (L1_Section_indicies[i] == 2) {
            temp_string += "2S";
          } else if (L1_Section_indicies[i] == 3) {
            temp_string += "3S";
          } else if (L1_Section_indicies[i] == 4) {
            temp_string += "4D";
          } else if (L1_Section_indicies[i] == 5) {
            temp_string += "5Z";
          } else if (L1_Section_indicies[i] == 6) {
            temp_string += "6W";
          } else if (L1_Section_indicies[i] == 7) {
            temp_string += "7A";
          } else if (L1_Section_indicies[i] == 8) {
            temp_string += "8Z";
          } else if (L1_Section_indicies[i] == 9) {
            temp_string += "9X";
          } else if (L1_Section_indicies[i] == 10) {
            temp_string += "10A";
          } else if (L1_Section_indicies[i] == 11) {
            temp_string += "11A";
          } else if (L1_Section_indicies[i] == 12) {
            temp_string += "12D";
          } else if (L1_Section_indicies[i] == 13) {
            temp_string += "13C";
          } else if (L1_Section_indicies[i] == 14) {
            temp_string += "14X";
          } else if (L1_Section_indicies[i] == 15) {
            temp_string += "15X";
          } else if (L1_Section_indicies[i] == 16) {
            temp_string += "16W";
          }
        }

        L1s.text(temp_string);

        temp_string = "";

        for(int i = 0; i < L2_Section_indicies.length(); i++){
          if(L2_Section_indicies[i] == 0){
            temp_string2 += "17S";
          } else if (L2_Section_indicies[i] == 1) {
            temp_string2+= "18D";
          } else if (L2_Section_indicies[i] == 2) {
            temp_string2 += "19C";
          } else if (L2_Section_indicies[i] == 3) {
            temp_string2 += "20X";
          } else if (L2_Section_indicies[i] == 4) {
            temp_string2 += "21W";
          } else if (L2_Section_indicies[i] == 5) {
            temp_string2 += "22S";
          } else if (L2_Section_indicies[i] == 6) {
            temp_string2 += "23D";
          } else if (L2_Section_indicies[i] == 7) {
            temp_string2 += "24A";
          } else if (L2_Section_indicies[i] == 8) {
            temp_string2 += "25S";
          } else if (L2_Section_indicies[i] == 9) {
            temp_string2 += "26A";
          } else if (L2_Section_indicies[i] == 10) {
            temp_string2 += "27C";
          } else if (L2_Section_indicies[i] == 11) {
            temp_string2 += "28X";
          } else if (L2_Section_indicies[i] == 12) {
            temp_string2 += "29T";
          } else if (L2_Section_indicies[i] == 13) {
            temp_string2 += "30W";
          } else if (L2_Section_indicies[i] == 14) {
            temp_string2 += "31A";
          }
        }

        L2s.text(temp_string2);

        temp_string2 = "";

        for(int i = 0; i < L3_Section_indicies.length(); i++){
          if(L3_Section_indicies[i] == 0){
            temp_string3 += "32W";
          } else if (L3_Section_indicies[i] == 1) {
            temp_string3+= "33W";
          } else if (L3_Section_indicies[i] == 2) {
            temp_string3 += "34W";
          } else if (L3_Section_indicies[i] == 3) {
            temp_string3 += "35X";
          } else if (L3_Section_indicies[i] == 4) {
            temp_string3 += "36D";
          } else if (L3_Section_indicies[i] == 5) {
            temp_string3 += "37S";
          } else if (L3_Section_indicies[i] == 6) {
            temp_string3 += "38D";
          } else if (L3_Section_indicies[i] == 7) {
            temp_string3 += "39D";
          } else if (L3_Section_indicies[i] == 8) {
            temp_string3 += "40S";
          } else if (L3_Section_indicies[i] == 9) {
            temp_string3 += "41D";
          } else if (L3_Section_indicies[i] == 10) {
            temp_string3 += "42W";
          } else if (L3_Section_indicies[i] == 11) {
            temp_string3 += "43Z";
          } 
        }

        L3s.text(temp_string3);

        temp_string3 = "";

      }



      // Level 1 --------------------------------------------------------------------


      if((!map_construction_done && !first_time) && (Loading_Section[0].player_in_area(player) && L1_Frame_Count < 60)) {
        L1_Frame_Count += 1;
        g.override_stream_sizes(64,8);
      }

      // Getting and setting tiles and tile filth, assuming that the rng has been seedded
      // and that the map construction is not done
      if((!map_construction_done && !first_time) && (Loading_Section[0].player_in_area(player) && L1_Frame_Count == 60)) {
        // Reorddering the sections to be in a linear order
        for(uint i=0; i < L1_NUMBER_MAP_SECTIONS; i++) {
          L1_Section_Ordered[i] = L1_Sections[L1_Section_indicies[i]];
        }
        
        L1_Section_Ordered.insertLast(L1_Ending_Section);
        L1_Sections.insertLast(L1_Ending_Section);
        
        // Determining the first and last camera ids for each section for later use
        for(uint i=0; i < L1_NUMBER_MAP_SECTIONS+1; i++) {
          temp = L1_Section_Ordered[i].first_node(g);
          temp = L1_Section_Ordered[i].last_node(g);

          L1_Section_Ordered[i].determine_height();
        }
        
        // Tiles for all sections
        for(uint k=0; k < L1_NUMBER_MAP_SECTIONS+1; k++){

          if(k == 0) {
            L1_connection_offset[k] = Const_Area[0].top_y() - (L1_Section_Ordered[k].get_height(1)/48);
          }

          for(uint i=0; i < L1_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L1_Section_Ordered[k].width(); j++) {
              @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,19);
              
              g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
              L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],19,@CurrentTile,true);

			  
			        @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,20);
              
              g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
              L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],20,@CurrentTile,true);
              
            }
          }
          cumulative_width += L1_Section_Ordered[k].width();

          L1_Section_Ordered[k].set_height((L1_Section_Ordered[k].get_height(1)/48) + L1_connection_offset[k],1);
          L1_Section_Ordered[k].set_height((L1_Section_Ordered[k].get_height(2)/48) + L1_connection_offset[k],2);

          if(k+1 != L1_NUMBER_MAP_SECTIONS+1) {
            L1_connection_offset[k+1] = (L1_Section_Ordered[k].get_height(2)/48) - (L1_Section_Ordered[k+1].get_height(1)/48);
          }

        }
        
        cumulative_width = 0;
        
        //Tile filth for all sections
        for(uint k = 0; k < L1_NUMBER_MAP_SECTIONS+1; k++) {
          for(uint i=0; i < L1_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L1_Section_Ordered[k].width(); j++) {
              @CurrentTileFilth = g.get_tile_filth(L1_Section_Ordered[k].left_x()+j,
              L1_Section_Ordered[k].top_y()+i);
              
              g.set_tile_filth(Const_Area[0].left_x()+j+cumulative_width,
              L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],@CurrentTileFilth);
            }
          }
          cumulative_width += L1_Section_Ordered[k].width();  
        }
        
        cumulative_width = 0;
        
        // Props for all sections
        for(uint j=0; j < L1_NUMBER_MAP_SECTIONS+1; j++) {
          CurrentPropCollision = L1_Section_Ordered[j].get_prop_collision(g);
          
          for(uint i=0; i < CurrentPropCollision; i++) {
            @CurrentProp = g.get_prop_collision_index(i);
            
            offset_x = CurrentProp.x() - L1_Section_Ordered[j].left_x()*48;
            offset_y = CurrentProp.y() - L1_Section_Ordered[j].top_y()*48;
            
            CurrentProp.x(Const_Area[0].left_x()*48 + offset_x + cumulative_width*48);
            CurrentProp.y(CurrentProp.y()+L1_connection_offset[j]*48);
          }

          cumulative_width += L1_Section_Ordered[j].width();

        }
        
        cumulative_width = 0;
        cumulative_height = 0;
        
        // Entity for all sections
        for(uint k = 0; k < L1_NUMBER_MAP_SECTIONS+1; k++) {

          for(uint i=0; i < 5; i++){
            // Depending on the loop iteration gets enemy, enemy ai, or camera node
            // Collision
            if(i == 0)
              CurrentEntityCollision = L1_Section_Ordered[k].get_enemy_collision(g);
            if(i == 1)
              CurrentEntityCollision = L1_Section_Ordered[k].get_enemy_ai_collision(g);
            if(i == 2)
              CurrentEntityCollision = L1_Section_Ordered[k].get_cnode_collision(g);
            if(i == 3)
              CurrentEntityCollision = L1_Section_Ordered[k].get_t_area_collision(g);
            if(i == 4)
              CurrentEntityCollision = L1_Section_Ordered[k].get_trigger_collision(g);

            
            for(uint j=0; j < CurrentEntityCollision; j++) {
              // Determines the current enemy
              @CurrentEntity = g.get_entity_collision_index(j);
              
              // Calculates the offset from the top left corner
              offset_x = CurrentEntity.x() - L1_Section_Ordered[k].left_x()*48;
              offset_y = CurrentEntity.y() - L1_Section_Ordered[k].top_y()*48;
              
              // Repositions the entities in the new area
              CurrentEntity.x(Const_Area[0].left_x()*48 + offset_x + cumulative_width*48);
              CurrentEntity.y(CurrentEntity.y()+L1_connection_offset[k]*48);
              
            }
          }
          cumulative_width += L1_Section_Ordered[k].width();
        }
        
        cumulative_width = 0;
        
        // Fixing camera path such that it is connected
        
        for(uint i=0; i < L1_NUMBER_MAP_SECTIONS; i++) {
          
          if(i == 0) {
            @Camera1 = entity_by_id(L1_Section_Ordered[i].first_node(g));

            @varstruct = Camera1.vars();

            @val = @varstruct.get_var("node_type");
            val.set_int32(3);
          }
          
          @Camera1 = entity_by_id(L1_Section_Ordered[i].last_node(g));
          @Camera2 = entity_by_id(L1_Section_Ordered[i+1].first_node(g));
          
          @varstruct = Camera1.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera2.id());
          
          @varstruct = Camera2.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera1.id());
          
        }

        
        
        // Removing all unused tile filth
        // NOTE MOVE THIS FOR SECRET OR DISABLE
        // Reminder to add checking for dustblocks
        for(uint k=0; k < L1_NUMBER_SECTION_OPTIONS+1; k++) {
          for(uint i=0; i < L1_Sections[k].height(); i++) {
            for(uint j=0; j < L1_Sections[k].width(); j++) {
              g.set_tile_filth(L1_Sections[k].left_x()+j, L1_Sections[k].top_y()+i,
              0,0,0,0,true,true);

               @CurrentTile = g.get_tile(L1_Sections[k].left_x()+j,L1_Sections[k].top_y()+i,19);

              if(CurrentTile.is_dustblock()){
                g.set_tile(L1_Sections[k].left_x()+j,L1_Sections[k].top_y()+i,19,true,0,5,1,6);
              }
            }
          } 
        }
        
        // Removing leftover entities
        
        for(uint k=0; k < L1_NUMBER_SECTION_OPTIONS+1; k++) {
          
          CurrentEntityCollision = L1_Sections[k].get_enemy_collision(g);
          
          array<entity@> EntityRemovalArray(CurrentEntityCollision);

          for(uint i=0; i < CurrentEntityCollision; i++) {
            @EntityRemovalArray[i] = g.get_entity_collision_index(i);
          }
          
          for(uint i=0; i < CurrentEntityCollision; i++) {
            g.remove_entity(@EntityRemovalArray[i]);
          }
        }

        // Noting that map consstruction has been complete to ensure this doesent run and
        // drop someones fps to 0, I mean really who would ever forget that
        map_construction_done = true;

        g.override_stream_sizes(32,8);
        
      }


      // Level 2 --------------------------------------------------------------------


      // puts((!map_construction_done2) + " " + (!first_time) + " " +  (Loading_Section[1].player_in_area(player)) + " " + (L2_Frame_Count < 90));

      if((!map_construction_done2 && !first_time) && (Loading_Section[1].player_in_area(player) && L2_Frame_Count < 60)) {
        L2_Frame_Count += 1;
        puts(L2_Frame_Count+"");

        g.override_stream_sizes(64,8);
      }


      // Getting and setting tiles and tile filth, assuming that the rng has been seedded
      // and that the map construction is not done
      if((!map_construction_done2 && !first_time) && (Loading_Section[1].player_in_area(player) && L2_Frame_Count >= 60)) {
        // Reorddering the sections to be in a linear order
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS; i++) {
          L2_Section_Ordered[i] = L2_Sections[L2_Section_indicies[i]];
        }
        
        L2_Section_Ordered.insertLast(L2_Ending_Section);
        L2_Sections.insertLast(L2_Ending_Section);
        
        // Determining the first and last camera ids for each section for later use
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS+1; i++) {
          temp = L2_Section_Ordered[i].first_node(g);
          temp = L2_Section_Ordered[i].last_node(g);

          L2_Section_Ordered[i].determine_height();
        }
        
        // Tiles for all sections
        for(uint k=0; k < L2_NUMBER_MAP_SECTIONS+1; k++){

          if(k == 0) {
            L2_connection_offset[k] = Const_Area[1].top_y() - (L2_Section_Ordered[k].get_height(1)/48);
          }

          for(uint i=0; i < L2_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L2_Section_Ordered[k].width(); j++) {
              @CurrentTile = g.get_tile(L2_Section_Ordered[k].left_x()+j,L2_Section_Ordered[k].top_y()+i,19);
              
              g.set_tile(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],19,@CurrentTile,true);
			  
			        @CurrentTile = g.get_tile(L2_Section_Ordered[k].left_x()+j,L2_Section_Ordered[k].top_y()+i,20);
              
              g.set_tile(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],20,@CurrentTile,true);
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();

          L2_Section_Ordered[k].set_height(((L2_Section_Ordered[k].get_height(1)/48) + L2_connection_offset[k])*48,1);
          L2_Section_Ordered[k].set_height(((L2_Section_Ordered[k].get_height(2)/48) + L2_connection_offset[k])*48,2);

          if(k+1 != L2_NUMBER_MAP_SECTIONS+1) {
            L2_connection_offset[k+1] = (L2_Section_Ordered[k].get_height(2)/48) - (L2_Section_Ordered[k+1].get_height(1)/48);
          }
        }
        
        cumulative_width = 0;
        
        //Tile filth for all sections
        for(uint k = 0; k < L2_NUMBER_MAP_SECTIONS+1; k++) {
          for(uint i=0; i < L2_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L2_Section_Ordered[k].width(); j++) {
              @CurrentTileFilth = g.get_tile_filth(L2_Section_Ordered[k].left_x()+j,
              L2_Section_Ordered[k].top_y()+i);
              
              g.set_tile_filth(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],@CurrentTileFilth);
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();  
        }
        
        cumulative_width = 0;
        
        // Props for all sections
        for(uint j=0; j < L2_NUMBER_MAP_SECTIONS+1; j++) {
          CurrentPropCollision = L2_Section_Ordered[j].get_prop_collision(g);

          for(uint i=0; i < CurrentPropCollision; i++) {
            @CurrentProp = g.get_prop_collision_index(i);
            
            offset_x = CurrentProp.x() - L2_Section_Ordered[j].left_x()*48;
            offset_y = CurrentProp.y() - L2_Section_Ordered[j].top_y()*48;
            
            CurrentProp.x(Const_Area[1].left_x()*48 + offset_x + cumulative_width*48);
            CurrentProp.y(CurrentProp.y()+L2_connection_offset[j]*48);
          }
          cumulative_width += L2_Section_Ordered[j].width();
        }
        
        cumulative_width = 0;
        
        // Entity for all sections
        for(uint k = 0; k < L2_NUMBER_MAP_SECTIONS+1; k++) {
          
          if(L2_Section_Ordered[k].is_up()){
              cumulative_height -= (L2_Section_Ordered[k].height()-normal_section_height2);
            }

          for(uint i=0; i < 5; i++){
            // Depending on the loop iteration gets enemy, enemy ai, or camera node
            // Collision
            if(i == 0)
              CurrentEntityCollision = L2_Section_Ordered[k].get_enemy_collision(g);
            if(i == 1)
              CurrentEntityCollision = L2_Section_Ordered[k].get_enemy_ai_collision(g);
            if(i == 2)
              CurrentEntityCollision = L2_Section_Ordered[k].get_cnode_collision(g);
            if(i == 3)
              CurrentEntityCollision = L2_Section_Ordered[k].get_t_area_collision(g);
            if(i == 4)
              CurrentEntityCollision = L2_Section_Ordered[k].get_trigger_collision(g);

            
            
            for(uint j=0; j < CurrentEntityCollision; j++) {
              // Determines the current enemy
              @CurrentEntity = g.get_entity_collision_index(j);
              
              // Calculates the offset from the top left corner
              offset_x = CurrentEntity.x() - L2_Section_Ordered[k].left_x()*48;
              offset_y = CurrentEntity.y() - L2_Section_Ordered[k].top_y()*48;
              
              // Repositions the entities in the new area
              CurrentEntity.x(Const_Area[1].left_x()*48 + offset_x + cumulative_width*48);
              CurrentEntity.y(CurrentEntity.y()+L2_connection_offset[k]*48);
              
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();
        }
        
        cumulative_width = 0;
        cumulative_height = 0;
        
        // Fixing camera path such that it is connected
        
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS; i++) {
          
          if(i == 0) {
            @Camera1 = entity_by_id(L2_Section_Ordered[i].first_node(g));
            
            @varstruct = Camera1.vars();
            @val = @varstruct.get_var("node_type");
            val.set_int32(3);
          }
          
          @Camera1 = entity_by_id(L2_Section_Ordered[i].last_node(g));
          @Camera2 = entity_by_id(L2_Section_Ordered[i+1].first_node(g));
          
          @varstruct = Camera1.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera2.id());
          
          @varstruct = Camera2.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera1.id());
          
        }
        
        // Removing all unused tile filth
        // NOTE MOVE THIS FOR SECRET OR DISABLE
        // Reminder to add checking for dustblocks
        for(uint k=0; k < L2_NUMBER_SECTION_OPTIONS+1; k++) {
          for(uint i=0; i < L2_Sections[k].height(); i++) {
            for(uint j=0; j < L2_Sections[k].width(); j++) {
              g.set_tile_filth(L2_Sections[k].left_x()+j, L2_Sections[k].top_y()+i,
              0,0,0,0,true,true);

              @CurrentTile = g.get_tile(L2_Sections[k].left_x()+j,L2_Sections[k].top_y()+i,19);

              if(CurrentTile.is_dustblock()){
                g.set_tile(L2_Sections[k].left_x()+j,L2_Sections[k].top_y()+i,19,true,0,5,1,6);
              }
            }
          } 
        }
        
        // Removing leftover entities
        
        for(uint k=0; k < L2_NUMBER_SECTION_OPTIONS+1; k++) {
          
          CurrentEntityCollision = L2_Sections[k].get_enemy_collision(g);
          
          array<entity@> EntityRemovalArray(CurrentEntityCollision);

          for(uint i=0; i < CurrentEntityCollision; i++) {
            @EntityRemovalArray[i] = g.get_entity_collision_index(i);
          }
          
          for(uint i=0; i < CurrentEntityCollision; i++) {
            g.remove_entity(@EntityRemovalArray[i]);
          }
        }

        // Noting that map consstruction has been complete to ensure this doesent run and
        // drop someones fps to 0, I mean really who would ever forget that
        map_construction_done2 = true;

        

        

        puts("L2 built");
        
      }



      // Level 3 --------------------------------------------------------------------


      if((!map_construction_done3 && !first_time) && (Loading_Section[2].player_in_area(player) && L3_Frame_Count < 60)) {
        L3_Frame_Count += 1;
        puts(L3_Frame_Count+"");

        g.override_stream_sizes(64,8);
      }


      // Getting and setting tiles and tile filth, assuming that the rng has been seedded
      // and that the map construction is not done
      if((!map_construction_done3 && !first_time) && (Loading_Section[2].player_in_area(player) && L3_Frame_Count >= 60)) {
        // Reorddering the sections to be in a linear order
        for(uint i=0; i < L3_NUMBER_MAP_SECTIONS; i++) {
          L3_Section_Ordered[i] = L3_Sections[L3_Section_indicies[i]];
        }
        
        L3_Section_Ordered.insertLast(L3_Ending_Section);
        L3_Sections.insertLast(L3_Ending_Section);
        
        // Determining the first and last camera ids for each section for later use
        for(uint i=0; i < L3_NUMBER_MAP_SECTIONS+1; i++) {
          temp = L3_Section_Ordered[i].first_node(g);
          temp = L3_Section_Ordered[i].last_node(g);

          L3_Section_Ordered[i].determine_height();
        }
        
        // Tiles for all sections
        for(uint k=0; k < L3_NUMBER_MAP_SECTIONS+1; k++){

          if(k == 0) {
            L3_connection_offset[k] = Const_Area[2].top_y() - (L3_Section_Ordered[k].get_height(1)/48);
          }

          for(uint i=0; i < L3_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L3_Section_Ordered[k].width(); j++) {
              @CurrentTile = g.get_tile(L3_Section_Ordered[k].left_x()+j,L3_Section_Ordered[k].top_y()+i,19);
              
              g.set_tile(Const_Area[2].left_x()+j+cumulative_width,
              L3_Section_Ordered[k].top_y()+i+L3_connection_offset[k],19,@CurrentTile,true);
			  
			        @CurrentTile = g.get_tile(L3_Section_Ordered[k].left_x()+j,L3_Section_Ordered[k].top_y()+i,20);
              
              g.set_tile(Const_Area[2].left_x()+j+cumulative_width,
              L3_Section_Ordered[k].top_y()+i+L3_connection_offset[k],20,@CurrentTile,true);
            }
          }
          cumulative_width += L3_Section_Ordered[k].width();

          L3_Section_Ordered[k].set_height(((L3_Section_Ordered[k].get_height(1)/48) + L3_connection_offset[k])*48,1);
          L3_Section_Ordered[k].set_height(((L3_Section_Ordered[k].get_height(2)/48) + L3_connection_offset[k])*48,2);

          if(k+1 != L3_NUMBER_MAP_SECTIONS+1) {
            L3_connection_offset[k+1] = (L3_Section_Ordered[k].get_height(2)/48) - (L3_Section_Ordered[k+1].get_height(1)/48);
          }
        }
        
        cumulative_width = 0;
        
        //Tile filth for all sections
        for(uint k = 0; k < L3_NUMBER_MAP_SECTIONS+1; k++) {
          for(uint i=0; i < L3_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L3_Section_Ordered[k].width(); j++) {
              @CurrentTileFilth = g.get_tile_filth(L3_Section_Ordered[k].left_x()+j,
              L3_Section_Ordered[k].top_y()+i);
              
              g.set_tile_filth(Const_Area[2].left_x()+j+cumulative_width,
              L3_Section_Ordered[k].top_y()+i+L3_connection_offset[k],@CurrentTileFilth);
            }
          }
          cumulative_width += L3_Section_Ordered[k].width();  
        }
        
        cumulative_width = 0;
        
        // Props for all sections
        for(uint j=0; j < L3_NUMBER_MAP_SECTIONS+1; j++) {
          CurrentPropCollision = L3_Section_Ordered[j].get_prop_collision(g);

          for(uint i=0; i < CurrentPropCollision; i++) {
            @CurrentProp = g.get_prop_collision_index(i);
            
            offset_x = CurrentProp.x() - L3_Section_Ordered[j].left_x()*48;
            offset_y = CurrentProp.y() - L3_Section_Ordered[j].top_y()*48;
            
            CurrentProp.x(Const_Area[2].left_x()*48 + offset_x + cumulative_width*48);
            CurrentProp.y(CurrentProp.y()+L3_connection_offset[j]*48);
          }
          cumulative_width += L3_Section_Ordered[j].width();
        }
        
        cumulative_width = 0;
        
        // Entity for all sections
        for(uint k = 0; k < L3_NUMBER_MAP_SECTIONS+1; k++) {
          
          if(L3_Section_Ordered[k].is_up()){
              cumulative_height -= (L3_Section_Ordered[k].height()-normal_section_height2);
            }

          for(uint i=0; i < 5; i++){
            // Depending on the loop iteration gets enemy, enemy ai, or camera node
            // Collision
            if(i == 0)
              CurrentEntityCollision = L3_Section_Ordered[k].get_enemy_collision(g);
            if(i == 1)
              CurrentEntityCollision = L3_Section_Ordered[k].get_enemy_ai_collision(g);
            if(i == 2)
              CurrentEntityCollision = L3_Section_Ordered[k].get_cnode_collision(g);
            if(i == 3)
              CurrentEntityCollision = L3_Section_Ordered[k].get_t_area_collision(g);
            if(i == 4)
              CurrentEntityCollision = L3_Section_Ordered[k].get_trigger_collision(g);

            
            
            for(uint j=0; j < CurrentEntityCollision; j++) {
              // Determines the current enemy
              @CurrentEntity = g.get_entity_collision_index(j);
              
              // Calculates the offset from the top left corner
              offset_x = CurrentEntity.x() - L3_Section_Ordered[k].left_x()*48;
              offset_y = CurrentEntity.y() - L3_Section_Ordered[k].top_y()*48;
              
              // Repositions the entities in the new area
              CurrentEntity.x(Const_Area[2].left_x()*48 + offset_x + cumulative_width*48);
              CurrentEntity.y(CurrentEntity.y()+L3_connection_offset[k]*48);
              
            }
          }
          cumulative_width += L3_Section_Ordered[k].width();
        }
        
        cumulative_width = 0;
        cumulative_height = 0;
        
        // Fixing camera path such that it is connected
        
        for(uint i=0; i < L3_NUMBER_MAP_SECTIONS; i++) {
          
          if(i == 0) {
            @Camera1 = entity_by_id(L3_Section_Ordered[i].first_node(g));
            
            @varstruct = Camera1.vars();
            @val = @varstruct.get_var("node_type");
            val.set_int32(3);
          }
          
          @Camera1 = entity_by_id(L3_Section_Ordered[i].last_node(g));
          @Camera2 = entity_by_id(L3_Section_Ordered[i+1].first_node(g));
          
          @varstruct = Camera1.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera2.id());
          
          @varstruct = Camera2.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera1.id());
          
        }
        
        // Removing all unused tile filth
        // NOTE MOVE THIS FOR SECRET OR DISABLE
        // Reminder to add checking for dustblocks
        for(uint k=0; k < L3_NUMBER_SECTION_OPTIONS+1; k++) {
          for(uint i=0; i < L3_Sections[k].height(); i++) {
            for(uint j=0; j < L3_Sections[k].width(); j++) {
              g.set_tile_filth(L3_Sections[k].left_x()+j, L3_Sections[k].top_y()+i,
              0,0,0,0,true,true);

              @CurrentTile = g.get_tile(L3_Sections[k].left_x()+j,L3_Sections[k].top_y()+i,19);

              if(CurrentTile.is_dustblock()){
                g.set_tile(L3_Sections[k].left_x()+j,L3_Sections[k].top_y()+i,19,true,0,5,1,6);
              }
            }
          } 
        }
        
        // Removing leftover entities
        
        for(uint k=0; k < L3_NUMBER_SECTION_OPTIONS+1; k++) {
          
          CurrentEntityCollision = L3_Sections[k].get_enemy_collision(g);
          
          array<entity@> EntityRemovalArray(CurrentEntityCollision);

          for(uint i=0; i < CurrentEntityCollision; i++) {
            @EntityRemovalArray[i] = g.get_entity_collision_index(i);
          }
          
          for(uint i=0; i < CurrentEntityCollision; i++) {
            g.remove_entity(@EntityRemovalArray[i]);
          }
        }

        // Noting that map consstruction has been complete to ensure this doesent run and
        // drop someones fps to 0, I mean really who would ever forget that
        map_construction_done3 = true;

        g.override_stream_sizes(32,8);

        puts("L3 built");
        
      }


      // Other Stuff ---------------------------------------

      if((Loading_Section[0].player_in_area(player) || Loading_Section[1].player_in_area(player)) || (Loading_Section[2].player_in_area(player) || Starting_Area.player_in_area(player))
          || Secret_Area.player_in_area(player)){
        player.combo_timer(1.0);
      }

      if(normal_everyday_things && !Secret_Tiles_Destroyed) {
        for(uint i=0; i < Secret_Tiles.height(); i++) {
            for(uint j=0; j < Secret_Tiles.width(); j++) {
              g.set_tile(Secret_Tiles.left_x()+j,Secret_Tiles.top_y()+i,19,false,0,5,1,6);
            }
        }
        for(uint i=0; i < 44; i++){
          if(i<25){
            Sequence_Layers[i] = 13;
            Sequence_Sublayers[i] = i;
          } else {
            Sequence_Layers[i] = 14;
            Sequence_Sublayers[i] = i-25;
          }
        }
        Secret_Tiles_Destroyed = true;
      }

      if(Secret_Area.player_in_area(player) && !SequenceDone){
        CurrentSequence = SequenceCheck(player, intents, CurrentSequence);
        CurrentSequenceLength = CurrentSequence.length();
        CorrectSequenceLength = CorrectSequence.length();

        @CurrentFog = CurrentCamera.get_fog();

        if(!(CurrentSequenceLength == 0)){
          if(CurrentSequenceLength == CorrectSequenceLength){
            failed = !(CurrentSequence == CorrectSequence);

            if(!failed){
              SequenceDone = true;
              puts("done");

              for(uint i=0; i < CorrectSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x7038A6E0);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            } else { 
              CurrentSequence = "";

              for(uint i=0; i < CorrectSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x70000000);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            }

          } else if(CurrentSequenceLength < CorrectSequenceLength) {
            failed = !(CurrentSequence == CorrectSequence.substr(0,CurrentSequenceLength));

            if(!failed){
              for(uint i=0; i < CurrentSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x7038A6E0);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            } else { 
              CurrentSequence = "";

              for(uint i=0; i < CurrentSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x70000000);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            }

          } else {
            failed = !(CurrentSequence.substr(0,CorrectSequenceLength) == CorrectSequence);

            if(!failed){
              SequenceDone = true;
              puts("done");

              for(uint i=0; i < CorrectSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x7038A6E0);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            } else { 
              CurrentSequence = "";

              for(uint i=0; i < CorrectSequenceLength; i++){
                CurrentFog.colour(Sequence_Layers[i], Sequence_Sublayers[i], 0x70000000);
                CurrentCamera.change_fog(CurrentFog, 0.0);
              }
            }

          }
        }
      }


      if(!L1_Apples_Destroyed){

        CurrentEntityCollision = L1_Apple_Area.get_enemy_collision(g);

        if(CurrentEntityCollision == 5){
          L1_Apples_Destroyed = true;
        }
        
        
        if(L1_Apples_Destroyed){
          player.set_xy(L1Applex, L1Appley);
        }
      }

      if(!L2_Apples_Destroyed){

        CurrentEntityCollision = L2_Apple_Area.get_enemy_collision(g);

        if(CurrentEntityCollision == 3){
          L2_Apples_Destroyed = true;
        }

       
        if(L2_Apples_Destroyed){
          player.set_xy(L2Applex, L2Appley);
        }
      }

      if(!L3_Apples_Destroyed){

        CurrentEntityCollision = L3_Apple_Area.get_enemy_collision(g);

        if(CurrentEntityCollision == 1){
          L3_Apples_Destroyed = true;
        }
        
      }

      if(!L4_Apples_Destroyed){

        CurrentEntityCollision = L4_Apple_Area.get_enemy_collision(g);

        if(CurrentEntityCollision == 1){
          L4_Apples_Destroyed = true;
        }

       
        if(L4_Apples_Destroyed){
          player.set_xy(L4Applex, L4Appley);
        }
      }

      if(((SequenceDone && L1_Apples_Destroyed) && (L2_Apples_Destroyed))){
        g.remove_entity(entity_by_id(3276));
      }

      if(((SequenceDone && L1_Apples_Destroyed) && (L2_Apples_Destroyed && L3_Apples_Destroyed)) && !TeleportDone){
        player.set_xy(L3Applex, L3Appley);

        TeleportDone = true;
      }



      
    }
    
    void draw(float sub_frame){
      Seed_Text.draw_world(17,12,Textx,Texty,1,1,0);
      L1s.draw_world(17,12,L1sx,L1sy,1,1,0);
      L2s.draw_world(17,12,L2sx,L2sy,1,1,0);
      L3s.draw_world(17,12,L3sx,L3sy,1,1,0);
    }


    void editor_draw(float sub_frame) {
      if(Show_Boxes){
        // Drawing the startinng area
        g.draw_rectangle_world(20,20,Starting_Area.left_x()*48,Starting_Area.top_y()*48,
        Starting_Area.right_x()*48+48,Starting_Area.bottom_y()*48+48,0,0x70F7747B);
        
        // Drawing the construction area
        for(uint i=0; i < Const_Area.length(); i++){
          g.draw_rectangle_world(20,20,Const_Area[i].left_x()*48,Const_Area[i].top_y()*48,
          Const_Area[i].right_x()*48+48,Const_Area[i].bottom_y()*48+48,0,0x70F0A754);
        }

        // Drawwing the ending section
        g.draw_rectangle_world(20,20,L1_Ending_Section.left_x()*48,L1_Ending_Section.top_y()*48,
        L1_Ending_Section.right_x()*48+48,L1_Ending_Section.bottom_y()*48+48,0,0x70BB66E3);

        g.draw_rectangle_world(20,20,L2_Ending_Section.left_x()*48,L2_Ending_Section.top_y()*48,
        L2_Ending_Section.right_x()*48+48,L2_Ending_Section.bottom_y()*48+48,0,0x70BB66E3);

        g.draw_rectangle_world(20,20,L3_Ending_Section.left_x()*48,L3_Ending_Section.top_y()*48,
        L3_Ending_Section.right_x()*48+48,L3_Ending_Section.bottom_y()*48+48,0,0x70BB66E3);
        
        for(uint i=0; i < L1_Sections.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,L1_Sections[i].left_x()*48,L1_Sections[i].top_y()*48,
          L1_Sections[i].right_x()*48+48, L1_Sections[i].bottom_y()*48+48,0,0x7068f7EE);

          L1_Sections[i].draw_connections(g);
        }

        for(uint i=0; i < L2_Sections.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,L2_Sections[i].left_x()*48,L2_Sections[i].top_y()*48,
          L2_Sections[i].right_x()*48+48, L2_Sections[i].bottom_y()*48+48,0,0x7068f7EE);

          L2_Sections[i].draw_connections(g);
        }

        for(uint i=0; i < L3_Sections.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,L3_Sections[i].left_x()*48,L3_Sections[i].top_y()*48,
          L3_Sections[i].right_x()*48+48, L3_Sections[i].bottom_y()*48+48,0,0x7068f7EE);

          L3_Sections[i].draw_connections(g);
        }

        for(uint i=0; i < Loading_Section.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,Loading_Section[i].left_x()*48,Loading_Section[i].top_y()*48,
          Loading_Section[i].right_x()*48+48, Loading_Section[i].bottom_y()*48+48,0,0x7003FC45);
        }
      }

      Seed_Text.draw_world(17,12,Textx,Texty,1,1,0);
    }
   
    
  }

  // Consider trying rand() % L1_NUMBER_SECTION_OPTIONS
  // rand() % (max-min) + min
  // Credit to skyhawk for this function
  int rand_int(int min, int max) {
		//get a random number between 0 and 1 (0 inclusive)
		double frac = rand() / 1073741824.0;
		
    //puts(""+frac);
    
		//fit the number into the range
		int random = int((frac * (max - min)) + min);
		
		return random;
	}
  
  void print_array(array<int> array){
    puts("");

    for(int i = 0; i < array.length(); i++){
      puts(""+array[i]);
    }

    puts("");
  }

  string SequenceCheck(dustman@ player, intents@ intents, string Sequence){
        // Record the current intents
        intents.setCurrentIntents(player);
                
        if(intents.checkHeavyIntent()) {
            Sequence += "C";
        }
                
        if(intents.checkLightIntent()) {
            Sequence += "X";
        } 
                
        if(intents.checkJumpIntent()) {
            Sequence += "Z";
        } 
                
        if(intents.checkDashIntent()) {
            Sequence += "T";
        }

        if(intents.checkXIntent()){

            if( player.x_intent() == 1 ){
                Sequence += "D";
            } else {
                Sequence += "A";
            }

        }

        if(intents.checkYIntent()){

            if( player.y_intent() == 1 ){
                Sequence += "S";
            } else {
                Sequence += "W";
            }

        }

        // Record the current intents as previous intents to have a comparison point
        intents.setPreviousIntents(player);

        return Sequence;
    }
