#include 'debugging.cpp'
#include 'section_option.cpp'
#include 'intents.cpp'

const int L1_NUMBER_SECTION_OPTIONS = 10;
const int L1_NUMBER_MAP_SECTIONS = 4;

const int L2_NUMBER_SECTION_OPTIONS = 1;
const int L2_NUMBER_MAP_SECTIONS = 1;


  class script {
    // Initializing player and scene
    scene@ g;
    dustman@ player;
    
    // making an intents object to track player intents
    intents intents;
    
    // Initializing rng seed
    int rng_seed = 0;

    // Adding an option to disable the boxes from showing
    [text] bool Show_Boxes = true;
    
    // Variables for index creation
    array<int> L1_Section_indicies(L1_NUMBER_MAP_SECTIONS);
    array<int> L1_candidates(L1_NUMBER_SECTION_OPTIONS);

    array<int> L2_Section_indicies(L2_NUMBER_MAP_SECTIONS);
    array<int> L2_candidates(L2_NUMBER_SECTION_OPTIONS);
    
    int rand;
    
    // 3 booleans for secret, determing if it is first time seeding rng, and determing if
    // map construction is done or not
    bool normal_everyday_things = false; // end flag is conssidered col_type_trigger_area
    bool first_time = true;
    bool map_construction_done = false;
    bool map_construction_done2 = false;
    bool area_entered = false;
	
    // Creating  variables describing the limits of the starting area
    [text] area Starting_Area;
    
    // Creating  variables describing the limits of the construction area
    [text] array<area> Const_Area;

    // Creating a varible for loading areas
    [text] array<area> Loading_Section;
    
    // Defining an array of section options
    [text] array<section_option> L1_Sections;
    [text] section_option L1_Ending_Section;

    [text] array<section_option> L2_Sections;
    [text] section_option L2_Ending_Section;
    
    // RNG Seed Text position
    [position,mode:world,layer:19,y:Texty] int Textx;
	  [hidden] int Texty;
    
    // RMG Seed Textfield Object
    textfield@ Seed_Text;

    // Stuff Position
    [position,mode:world,layer:19,y:L1sy] int L1sx;
	  [hidden] int L1sy;

    [position,mode:world,layer:19,y:L2sy] int L2sx;
	  [hidden] int L2sy;

    // Stuff textfield
    textfield@ L1s;
    textfield@ L2s;
    
    // Stuff String
    string temp_string = "";
    string temp_string2 = "";

    // Array of actual map sections ordered correctly
    array<section_option> L1_Section_Ordered(L1_NUMBER_MAP_SECTIONS);
    array<section_option> L2_Section_Ordered(L2_NUMBER_MAP_SECTIONS);
    
    // Defining a current tile info for use when constructing map
    tileinfo@ CurrentTile;
    tilefilth@ CurrentTileFilth;
    
    // Defining current prop and entity info
    prop@ CurrentProp;
    entity@ CurrentEntity;
    
    // Defining offset variables for prop and entitiy construction
    int offset_x = 0;
    int offset_y = 0;
    int cumulative_width = 0;
    int cumulative_height = 0;
    int normal_section_height = 0;
    int normal_section_height2 = 0;

    array<int> L1_connection_offset(L1_NUMBER_MAP_SECTIONS+1);
    array<int> L2_connection_offset(L2_NUMBER_MAP_SECTIONS+1);

    // Defining an int to serve as the current prop/entity collision
    int CurrentPropCollision = 0;
    int CurrentEntityCollision = 0;
    
    // Defining a var struct variables for fixing camera path
    varstruct@ varstruct;
    varvalue@ val;
    vararray@ valarray;
    varvalue@ tempvar;
    
    // Defining entities for camera construction
    entity@ Camera1;
    entity@ Camera2;
    
    // Defining a temp variable for various use
    int temp = 0;
    
    // Defining a frame count for each level
    // Thiss ensures that the camera has caught up to the loading area when map conssstruction begins
    int L1_Frame_Count = 0;
    int L2_Frame_Count = 0;

    int loading_frame_count = 0;

    // Area to know where to destroy tiles
    [text] area tile_destroy;

    int tile_destroy_frame = 0;

    bool tiles_destroyed = false;
    
    script() {
      // Getting scene
      @g = get_scene();

      @Seed_Text = @create_textfield();
      Seed_Text.set_font("Caracteres", 64);
      Seed_Text.align_horizontal(-1);
      Seed_Text.text(rng_seed+"");

      @L1s = @create_textfield();
      L1s.set_font("Caracteres", 64);
      L1s.align_horizontal(-1);

      @L2s = @create_textfield();
      L2s.set_font("Caracteres", 64);
      L2s.align_horizontal(-1);
    }
    
    void on_level_start() {
		  puts("LEVEL START"); 
    
      // if no player is defined, get the player
      if(@player == null) {
        controllable@ c = controller_controllable(0);
        if(@c != null) {
          @player = c.as_dustman();
        }
      }
    
    }

    void checkpoint_load(){
      @player = null;
    }
    
    void step(int entities) {      
      //if no player is defined, get the player
      if(@player == null) {
        controllable@ c = controller_controllable(0);
        if(@c != null) {
          @player = c.as_dustman();
        }
        //if there's no player, we can't step this frame
        if(@player == null)
          return;
      }

      if(Starting_Area.player_in_area(player)) {
        area_entered = true;
      }
      
      if (area_entered) {
        // Assuming that it is not the first time
        if(first_time) {
          // If the player is within the starting area
          if(Starting_Area.player_in_area(player)) {

            // Record the current intents
            intents.setCurrentIntents(player);
            
            // If it has changed and the intent has not been used, increment the rng seed
            if(intents.checkHeavyIntent()) {
              rng_seed += 10 * 71;
            }
            
            if(intents.checkLightIntent()) {
              rng_seed += 10 * 518;
            } 
            
            if(intents.checkJumpIntent()) {
              rng_seed += 1 * 1843;
            } 
            
            if(intents.checkDashIntent()) {
              rng_seed += 1 * 19567;
            } 
            
            // If the player has supered note this for no particular reason
            if( player.attack_state() == 3) {
              normal_everyday_things = true;
            }
            
            // Record the current intents as previous intents to have a comparison point
            intents.setPreviousIntents(player);

            Seed_Text.text(rng_seed+"");
          } else { 
            // Seed the rng wwith the rng seed calculated above
            srand(rng_seed);
            
            // Defining the avalable L1_candidates
            for(int i = 0; i < L1_NUMBER_SECTION_OPTIONS; i++) {
              L1_candidates[i] = i;
            }
            
            for(int i = 0; i < L1_NUMBER_MAP_SECTIONS; i++) {
              // generating a random integer that is within the pool of L1_candidates
              rand = rand_int(0, L1_candidates.length());
              // setting the current section index to the position in the array index rand in the L1_candidates array
              L1_Section_indicies[i] = L1_candidates[rand];
              //removing that entry from the L1_candidates array such that it wont be repeated
              L1_candidates.removeAt(rand); 
            }

            for(int i = 0; i < L2_NUMBER_SECTION_OPTIONS; i++) {
              L2_candidates[i] = i;
            }
            
            for(int i = 0; i < L2_NUMBER_MAP_SECTIONS; i++) {
              // generating a random integer that is within the pool of L1_candidates
              rand = rand_int(0, L2_candidates.length());
              // setting the current section index to the position in the array index rand in the L1_candidates array
              L2_Section_indicies[i] = L2_candidates[rand];
              //removing that entry from the L1_candidates array such that it wont be repeated
              L2_candidates.removeAt(rand); 
            }
            
            // note that this is no longer the first time
            first_time = false;
          }
        }
      }
      
      
        

      

      if(!map_construction_done && !first_time) {
  

        // Increasing load range before constructing the map
        g.override_stream_sizes(64,8);


      }

      // Getting and setting tiles and tile filth, assuming that the rng has been seedded
      // and that the map construction is not done
      if((!map_construction_done && !first_time) && (Loading_Section[0].player_in_area(player))) {

        if(loading_frame_count == 0) {
          // Reorddering the sections to be in a linear order
          for(uint i=0; i < L1_NUMBER_MAP_SECTIONS; i++) {
            L1_Section_Ordered[i] = L1_Sections[L1_Section_indicies[i]];
          }
          
          L1_Section_Ordered.insertLast(L1_Ending_Section);
          L1_Sections.insertLast(L1_Ending_Section);
          
          // Determining the first and last camera ids for each section for later use
          for(uint i=0; i < L1_NUMBER_MAP_SECTIONS+1; i++) {
            temp = L1_Section_Ordered[i].first_node(g);
            temp = L1_Section_Ordered[i].last_node(g);

            L1_Section_Ordered[i].determine_height();
          }

          
          
          // Tiles for all sections
          for(uint k=0; k < L1_NUMBER_MAP_SECTIONS+1; k++){

            if(k == 0) {
              L1_connection_offset[k] = Const_Area[0].top_y() - (L1_Section_Ordered[k].get_height(1)/48);
            }

            for(uint i=0; i < L1_Section_Ordered[k].height(); i++) {
              for(uint j=0; j < L1_Section_Ordered[k].width(); j++) {
                @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,19);
                
                g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
                L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],19,@CurrentTile,true);

          
                @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,20);
                
                g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
                L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],20,@CurrentTile,true);

                @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,15);
                
                g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
                L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],15,@CurrentTile,true);

                @CurrentTile = g.get_tile(L1_Section_Ordered[k].left_x()+j,L1_Section_Ordered[k].top_y()+i,16);
                
                g.set_tile(Const_Area[0].left_x()+j+cumulative_width,
                L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],16,@CurrentTile,true);
                
              }
            }
            cumulative_width += L1_Section_Ordered[k].width();

            L1_Section_Ordered[k].set_height(((L1_Section_Ordered[k].get_height(1)/48) + L1_connection_offset[k])*48,1);
            L1_Section_Ordered[k].set_height(((L1_Section_Ordered[k].get_height(2)/48) + L1_connection_offset[k])*48,2);

            if(k+1 != L1_NUMBER_MAP_SECTIONS+1) {
              L1_connection_offset[k+1] = (L1_Section_Ordered[k].get_height(2)/48) - (L1_Section_Ordered[k+1].get_height(1)/48);
            }

          }
          
          cumulative_width = 0;

        }

        if(loading_frame_count == 1) {
          
          //Tile filth for all sections
          for(uint k = 0; k < L1_NUMBER_MAP_SECTIONS+1; k++) {
            for(uint i=0; i < L1_Section_Ordered[k].height(); i++) {
              for(uint j=0; j < L1_Section_Ordered[k].width(); j++) {
                @CurrentTileFilth = g.get_tile_filth(L1_Section_Ordered[k].left_x()+j,
                L1_Section_Ordered[k].top_y()+i);
                
                g.set_tile_filth(Const_Area[0].left_x()+j+cumulative_width,
                L1_Section_Ordered[k].top_y()+i+L1_connection_offset[k],@CurrentTileFilth);
              }
            }
            cumulative_width += L1_Section_Ordered[k].width();  
          }
          
          cumulative_width = 0;
        }

        if(loading_frame_count == 2) {
          
          // Props for all sections
          for(uint j=0; j < L1_NUMBER_MAP_SECTIONS+1; j++) {
            CurrentPropCollision = L1_Section_Ordered[j].get_prop_collision(g);
            
            for(uint i=0; i < CurrentPropCollision; i++) {
              @CurrentProp = g.get_prop_collision_index(i);
              
              offset_x = CurrentProp.x() - L1_Section_Ordered[j].left_x()*48;
              offset_y = CurrentProp.y() - L1_Section_Ordered[j].top_y()*48;
              
              CurrentProp.x(Const_Area[0].left_x()*48 + offset_x + cumulative_width*48);
              CurrentProp.y(CurrentProp.y()+L1_connection_offset[j]*48);
            }

            cumulative_width += L1_Section_Ordered[j].width();

          }
          
          cumulative_width = 0;
          cumulative_height = 0;

        }

        if(loading_frame_count == 3){
          
          // Entity for all sections
          for(uint k = 0; k < L1_NUMBER_MAP_SECTIONS+1; k++) {

            for(uint i=0; i < 6; i++){
              // Depending on the loop iteration gets enemy, enemy ai, or camera node
              // Collision
              if(i == 0)
                CurrentEntityCollision = L1_Section_Ordered[k].get_enemy_collision(g);
              if(i == 1)
                CurrentEntityCollision = L1_Section_Ordered[k].get_enemy_ai_collision(g);
              if(i == 2)
                CurrentEntityCollision = L1_Section_Ordered[k].get_cnode_collision(g);
              if(i == 3)
                CurrentEntityCollision = L1_Section_Ordered[k].get_t_area_collision(g);
              if(i == 4)
                CurrentEntityCollision = L1_Section_Ordered[k].get_trigger_collision(g);
              if(i == 5)
                CurrentEntityCollision = L1_Section_Ordered[k].get_death_collision(g);

              
              for(uint j=0; j < CurrentEntityCollision; j++) {
                // Determines the current enemy
                @CurrentEntity = g.get_entity_collision_index(j);
                
                // Calculates the offset from the top left corner
                offset_x = CurrentEntity.x() - L1_Section_Ordered[k].left_x()*48;
                offset_y = CurrentEntity.y() - L1_Section_Ordered[k].top_y()*48;
                
                // Repositions the entities in the new area
                CurrentEntity.x(Const_Area[0].left_x()*48 + offset_x + cumulative_width*48);
                CurrentEntity.y(CurrentEntity.y()+L1_connection_offset[k]*48);
                
              }
            }
            cumulative_width += L1_Section_Ordered[k].width();
          }
          
          cumulative_width = 0;

        }

        if(loading_frame_count == 4) {
          
          // Fixing camera path such that it is connected
          
          for(uint i=0; i < L1_NUMBER_MAP_SECTIONS; i++) {
            
            if(i == 0) {
              @Camera1 = entity_by_id(L1_Section_Ordered[i].first_node(g));

              @varstruct = Camera1.vars();

              @val = @varstruct.get_var("node_type");
              val.set_int32(3);
            }
            
            @Camera1 = entity_by_id(L1_Section_Ordered[i].last_node(g));
            @Camera2 = entity_by_id(L1_Section_Ordered[i+1].first_node(g));
            
            @varstruct = Camera1.vars();
            @val = @varstruct.get_var("c_node_ids");
            @valarray = @val.get_array();
            valarray.resize(2);
            @tempvar = @valarray.at(1);
            tempvar.set_int32(Camera2.id());
            
            @varstruct = Camera2.vars();
            @val = @varstruct.get_var("c_node_ids");
            @valarray = @val.get_array();
            valarray.resize(2);
            @tempvar = @valarray.at(1);
            tempvar.set_int32(Camera1.id());
            
          }

        }

        if(loading_frame_count == 5) {
          
          // Removing all unused tile filth
          // NOTE MOVE THIS FOR SECRET OR DISABLE
          // Reminder to add checking for dustblocks
          for(uint k=0; k < L1_NUMBER_SECTION_OPTIONS+1; k++) {
            for(uint i=0; i < L1_Sections[k].height(); i++) {
              for(uint j=0; j < L1_Sections[k].width(); j++) {
                g.set_tile_filth(L1_Sections[k].left_x()+j, L1_Sections[k].top_y()+i,
                0,0,0,0,true,true);
              }
            } 
          }
          
          // Removing leftover entities
          
          for(uint k=0; k < L1_NUMBER_SECTION_OPTIONS+1; k++) {
            
            CurrentEntityCollision = L1_Sections[k].get_enemy_collision(g);
            
            array<entity@> EntityRemovalArray(CurrentEntityCollision);

            for(uint i=0; i < CurrentEntityCollision; i++) {
              @EntityRemovalArray[i] = g.get_entity_collision_index(i);
            }
            
            for(uint i=0; i < CurrentEntityCollision; i++) {
              g.remove_entity(@EntityRemovalArray[i]);
            }
          }

        }

        if(loading_frame_count == 6) {

          // Noting that map consstruction has been complete to ensure this doesent run and
          // drop someones fps to 0, I mean really who would ever forget that
          map_construction_done = true;

        }

        loading_frame_count += 1;
          
      }

      if(map_construction_done && (L1_Frame_Count < 2)){
        L1_Frame_Count += 1;

        // Returning load range to normal since map construction is done
        g.override_stream_sizes(32,8);
      }

      // puts((!map_construction_done2) + " " + (!first_time) + " " +  (Loading_Section[1].player_in_area(player)) + " " + (L2_Frame_Count < 90));

      if((!map_construction_done2 && !first_time) && (Loading_Section[1].player_in_area(player) && L2_Frame_Count < 90)) {
        L2_Frame_Count += 1;
        puts(L2_Frame_Count+"");
      }


      // Getting and setting tiles and tile filth, assuming that the rng has been seedded
      // and that the map construction is not done
      if((!map_construction_done2 && !first_time) && (Loading_Section[1].player_in_area(player) && L2_Frame_Count >= 90)) {
        // Reorddering the sections to be in a linear order
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS; i++) {
          L2_Section_Ordered[i] = L2_Sections[L2_Section_indicies[i]];
        }
        
        L2_Section_Ordered.insertLast(L2_Ending_Section);
        L2_Sections.insertLast(L2_Ending_Section);
        
        // Determining the first and last camera ids for each section for later use
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS+1; i++) {
          temp = L2_Section_Ordered[i].first_node(g);
          temp = L2_Section_Ordered[i].last_node(g);

          L2_Section_Ordered[i].determine_height();
        }
        
        // Tiles for all sections
        for(uint k=0; k < L2_NUMBER_MAP_SECTIONS+1; k++){

          if(k == 0) {
            L2_connection_offset[k] = Const_Area[1].top_y() - (L2_Section_Ordered[k].get_height(1)/48);
          }

          for(uint i=0; i < L2_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L2_Section_Ordered[k].width(); j++) {
              @CurrentTile = g.get_tile(L2_Section_Ordered[k].left_x()+j,L2_Section_Ordered[k].top_y()+i,19);
              
              g.set_tile(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],19,@CurrentTile,true);
			  
			        @CurrentTile = g.get_tile(L2_Section_Ordered[k].left_x()+j,L2_Section_Ordered[k].top_y()+i,20);
              
              g.set_tile(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],20,@CurrentTile,true);
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();

          L2_Section_Ordered[k].set_height(((L2_Section_Ordered[k].get_height(1)/48) + L2_connection_offset[k])*48,1);
          L2_Section_Ordered[k].set_height(((L2_Section_Ordered[k].get_height(2)/48) + L2_connection_offset[k])*48,2);

          if(k+1 != L2_NUMBER_MAP_SECTIONS+1) {
            L2_connection_offset[k+1] = (L2_Section_Ordered[k].get_height(2)/48) - (L2_Section_Ordered[k+1].get_height(1)/48);
          }
        }
        
        cumulative_width = 0;
        
        //Tile filth for all sections
        for(uint k = 0; k < L2_NUMBER_MAP_SECTIONS+1; k++) {
          for(uint i=0; i < L2_Section_Ordered[k].height(); i++) {
            for(uint j=0; j < L2_Section_Ordered[k].width(); j++) {
              @CurrentTileFilth = g.get_tile_filth(L2_Section_Ordered[k].left_x()+j,
              L2_Section_Ordered[k].top_y()+i);
              
              g.set_tile_filth(Const_Area[1].left_x()+j+cumulative_width,
              L2_Section_Ordered[k].top_y()+i+L2_connection_offset[k],@CurrentTileFilth);
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();  
        }
        
        cumulative_width = 0;
        
        // Props for all sections
        for(uint j=0; j < L2_NUMBER_MAP_SECTIONS+1; j++) {
          CurrentPropCollision = L2_Section_Ordered[j].get_prop_collision(g);

          for(uint i=0; i < CurrentPropCollision; i++) {
            @CurrentProp = g.get_prop_collision_index(i);
            
            offset_x = CurrentProp.x() - L2_Section_Ordered[j].left_x()*48;
            offset_y = CurrentProp.y() - L2_Section_Ordered[j].top_y()*48;
            
            CurrentProp.x(Const_Area[1].left_x()*48 + offset_x + cumulative_width*48);
            CurrentProp.y(CurrentProp.y()+L2_connection_offset[j]*48);
          }
          cumulative_width += L2_Section_Ordered[j].width();
        }
        
        cumulative_width = 0;
        
        // Entity for all sections
        for(uint k = 0; k < L2_NUMBER_MAP_SECTIONS+1; k++) {
          
          if(L2_Section_Ordered[k].is_up()){
              cumulative_height -= (L2_Section_Ordered[k].height()-normal_section_height2);
            }

          for(uint i=0; i < 5; i++){
            // Depending on the loop iteration gets enemy, enemy ai, or camera node
            // Collision
            if(i == 0)
              CurrentEntityCollision = L2_Section_Ordered[k].get_enemy_collision(g);
            if(i == 1)
              CurrentEntityCollision = L2_Section_Ordered[k].get_enemy_ai_collision(g);
            if(i == 2)
              CurrentEntityCollision = L2_Section_Ordered[k].get_cnode_collision(g);
            if(i == 3)
              CurrentEntityCollision = L2_Section_Ordered[k].get_t_area_collision(g);
            if(i == 4)
              CurrentEntityCollision = L2_Section_Ordered[k].get_trigger_collision(g);

            
            
            for(uint j=0; j < CurrentEntityCollision; j++) {
              // Determines the current enemy
              @CurrentEntity = g.get_entity_collision_index(j);
              
              // Calculates the offset from the top left corner
              offset_x = CurrentEntity.x() - L2_Section_Ordered[k].left_x()*48;
              offset_y = CurrentEntity.y() - L2_Section_Ordered[k].top_y()*48;
              
              // Repositions the entities in the new area
              CurrentEntity.x(Const_Area[1].left_x()*48 + offset_x + cumulative_width*48);
              CurrentEntity.y(CurrentEntity.y()+L2_connection_offset[k]*48);
              
            }
          }
          cumulative_width += L2_Section_Ordered[k].width();
        }
        
        cumulative_width = 0;
        cumulative_height = 0;
        
        // Fixing camera path such that it is connected
        
        for(uint i=0; i < L2_NUMBER_MAP_SECTIONS; i++) {
          
          if(i == 0) {
            @Camera1 = entity_by_id(L2_Section_Ordered[i].first_node(g));
            
            @varstruct = Camera1.vars();
            @val = @varstruct.get_var("node_type");
            val.set_int32(3);
          }
          
          @Camera1 = entity_by_id(L2_Section_Ordered[i].last_node(g));
          @Camera2 = entity_by_id(L2_Section_Ordered[i+1].first_node(g));
          
          @varstruct = Camera1.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera2.id());
          
          @varstruct = Camera2.vars();
          @val = @varstruct.get_var("c_node_ids");
          @valarray = @val.get_array();
          valarray.resize(2);
          @tempvar = @valarray.at(1);
          tempvar.set_int32(Camera1.id());
          
        }
        
        // Removing all unused tile filth
        // NOTE MOVE THIS FOR SECRET OR DISABLE
        // Reminder to add checking for dustblocks
        for(uint k=0; k < L2_NUMBER_SECTION_OPTIONS+1; k++) {
          for(uint i=0; i < L2_Sections[k].height(); i++) {
            for(uint j=0; j < L2_Sections[k].width(); j++) {
              g.set_tile_filth(L2_Sections[k].left_x()+j, L2_Sections[k].top_y()+i,
              0,0,0,0,true,true);
            }
          } 
        }
        
        // Removing leftover entities
        
        for(uint k=0; k < L2_NUMBER_SECTION_OPTIONS+1; k++) {
          
          CurrentEntityCollision = L2_Sections[k].get_enemy_collision(g);
          
          array<entity@> EntityRemovalArray(CurrentEntityCollision);

          for(uint i=0; i < CurrentEntityCollision; i++) {
            @EntityRemovalArray[i] = g.get_entity_collision_index(i);
          }
          
          for(uint i=0; i < CurrentEntityCollision; i++) {
            g.remove_entity(@EntityRemovalArray[i]);
          }
        }

        // Noting that map consstruction has been complete to ensure this doesent run and
        // drop someones fps to 0, I mean really who would ever forget that
        map_construction_done2 = true;

        puts("L2 built");
        
      }


      if(Starting_Area.player_in_area(player) && !tiles_destroyed){
        tile_destroy_frame +=1;

        if(tile_destroy_frame >= 180) {
          for(uint i=0; i < tile_destroy.height(); i++) {
            for(uint j=0; j < tile_destroy.width(); j++) {
              g.set_tile(tile_destroy.left_x()+j,tile_destroy.top_y()+i,19,false,0,5,1,6);
            }
          }
          tiles_destroyed = true;
        }
      }
      
    }
    
    void draw(float sub_frame){
      Seed_Text.draw_world(17,12,Textx,Texty,1,1,0);
      L1s.draw_world(17,12,L1sx,L1sy,1,1,0);
      L2s.draw_world(17,12,L2sx,L2sy,1,1,0);
    }


    void editor_draw(float sub_frame) {
      if(Show_Boxes){
        // Drawing the startinng area
        g.draw_rectangle_world(20,20,Starting_Area.left_x()*48,Starting_Area.top_y()*48,
        Starting_Area.right_x()*48+48,Starting_Area.bottom_y()*48+48,0,0x70F7747B);
        
        // Drawing the construction area
        for(uint i=0; i < Const_Area.length(); i++){
          g.draw_rectangle_world(20,20,Const_Area[i].left_x()*48,Const_Area[i].top_y()*48,
          Const_Area[i].right_x()*48+48,Const_Area[i].bottom_y()*48+48,0,0x70F0A754);
        }

        // Drawwing the ending section
        g.draw_rectangle_world(20,20,L1_Ending_Section.left_x()*48,L1_Ending_Section.top_y()*48,
        L1_Ending_Section.right_x()*48+48,L1_Ending_Section.bottom_y()*48+48,0,0x70BB66E3);

        g.draw_rectangle_world(20,20,L2_Ending_Section.left_x()*48,L2_Ending_Section.top_y()*48,
        L2_Ending_Section.right_x()*48+48,L2_Ending_Section.bottom_y()*48+48,0,0x70BB66E3);
        
        for(uint i=0; i < L1_Sections.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,L1_Sections[i].left_x()*48,L1_Sections[i].top_y()*48,
          L1_Sections[i].right_x()*48+48, L1_Sections[i].bottom_y()*48+48,0,0x7068f7EE);

          L1_Sections[i].draw_connections(g);
        }

        for(uint i=0; i < L2_Sections.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,L2_Sections[i].left_x()*48,L2_Sections[i].top_y()*48,
          L2_Sections[i].right_x()*48+48, L2_Sections[i].bottom_y()*48+48,0,0x7068f7EE);

          L2_Sections[i].draw_connections(g);
        }

        for(uint i=0; i < Loading_Section.length(); i++) { 
          // Drawing the rectangle for the current level 1 section
          g.draw_rectangle_world(20,20,Loading_Section[i].left_x()*48,Loading_Section[i].top_y()*48,
          Loading_Section[i].right_x()*48+48, Loading_Section[i].bottom_y()*48+48,0,0x7003FC45);
        }
      }

      Seed_Text.draw_world(17,12,Textx,Texty,1,1,0);
    }
   
    
  }

  // Consider trying rand() % L1_NUMBER_SECTION_OPTIONS
  // rand() % (max-min) + min
  // Credit to skyhawk for this function
  int rand_int(int min, int max) {
		//get a random number between 0 and 1 (0 inclusive)
		double frac = rand() / 1073741824.0;
		
    //puts(""+frac);
    
		//fit the number into the range
		int random = int((frac * (max - min)) + min);
		
		return random;
	}
  
  void print_array(array<int> array){
    puts("");

    for(int i = 0; i < array.length(); i++){
      puts(""+array[i]);
    }

    puts("");
  }