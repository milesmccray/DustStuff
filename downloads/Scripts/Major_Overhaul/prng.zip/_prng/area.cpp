class area{
    [position,mode:world,layer:19,y:y1] int x1 = 0;
	[hidden] int y1 = 0;
	[position,mode:world,layer:19,y:y2] int x2 = 0;
	[hidden] int y2 = 0;
    
    // Defining functions to get important values for the section
	// Credit to skyhawk for this segment of code
	int left_x(){
		int left_x;
		int dx1, dx2;

		//I have to do some dumb math to get everything to round
		//to the top left of the tile, because default behaviour
		//causes things to round toward (0, 0)
		dx1 = (x1%48+48)%48;
		dx2 = (x2%48+48)%48;

		if(x1 < x2) {
		  left_x = (x1-dx1)/48;
		} else {
		  left_x = (x2-dx2)/48;
		}

		return left_x;
	}

	int right_x(){
		int right_x;
		int dx1, dx2;

		dx1 = (x1%48+48)%48;
		dx2 = (x2%48+48)%48;

		if(x1 < x2) {
		  right_x = (x2-dx2)/48;
		} else {
		  right_x = (x1-dx1)/48;
		}

		return right_x;
	}

	int top_y(){
		int top_y;
		int dy1, dy2;

		dy1 = (y1%48+48)%48;
		dy2 = (y2%48+48)%48;

		if(y1 < y2) {
		  top_y = (y1-dy1)/48;
		} else {
		  top_y = (y2-dy2)/48;
		}

		return top_y;
	}

	int bottom_y(){
		int bottom_y;
		int dy1, dy2;

		dy1 = (y1%48+48)%48;
		dy2 = (y2%48+48)%48;

		if(y1 < y2) {
		  bottom_y = (y2-dy2)/48;
		} else {
		  bottom_y = (y1-dy1)/48;
		}

		return bottom_y;
	}

    uint width(){
        return right_x() - left_x() + 1;
    }
      
    uint height(){
        return bottom_y() - top_y() +1;
    }

    bool player_in_area(dustman@ player){
		// puts((left_x()*48 <= player.x())+ " " + (player.x() <= right_x()*48) + " " + (bottom_y()*48 >= player.y()) + " " + (player.y() >= top_y()*48) + "L");
		// puts(player.x() + " " + player.y());
		// puts((left_x()*48) + " " + (right_x()*48) + " " + (bottom_y()*48) + " " + (top_y()*48));

        if(( (left_x()*48 <= player.x()) && (player.x() <= right_x()*48) ) 
          && ((bottom_y()*48 >= player.y()) && (player.y() >= top_y()*48))) {
              return true;
		} else {
            return false;
        }
    }

}