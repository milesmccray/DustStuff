class intents{
    // Initializing intents to be used later
    int previous_heavy_intent = 0;
    int previous_light_intent = 0;
    int previous_jump_intent = 0;
    int previous_dash_intent = 0;
    int previous_x_intent = 0;
    int previous_y_intent = 0;
     
    int current_heavy_intent = 0;
    int current_light_intent = 0;
    int current_jump_intent = 0;
    int current_dash_intent = 0;
    int current_x_intent = 0;
    int current_y_intent = 0;

    void setCurrentIntents(dustman@ player){
        // Record the current intents
        current_heavy_intent = player.heavy_intent();
        current_light_intent = player.light_intent();
        current_jump_intent = player.jump_intent();
        current_dash_intent = player.dash_intent();
        current_x_intent = player.x_intent();
        current_y_intent = player.y_intent();
    }

    void setPreviousIntents(dustman@ player){
        // Record the current intents as previous intents to have a comparison point
        previous_heavy_intent = player.heavy_intent();
        previous_light_intent = player.light_intent();
        previous_jump_intent = player.jump_intent();
        previous_dash_intent = player.dash_intent();
        previous_x_intent = player.x_intent();
        previous_y_intent = player.y_intent();
    }

    bool checkHeavyIntent(){
        if((current_heavy_intent > previous_heavy_intent) && (current_heavy_intent!= 11)) {
            return true;
        }else{
            return false;
        }
    }

    bool checkLightIntent(){
        if((current_light_intent > previous_light_intent) && (current_light_intent!= 11)) {
            return true;
        }else{
            return false;
        }  
    }

    bool checkJumpIntent(){
        if( (current_jump_intent > previous_jump_intent) && (current_jump_intent != 2) ) {
            return true;
        }else{
            return false;
        }
    }

    bool checkDashIntent(){
        if( (current_dash_intent > previous_dash_intent) && (current_dash_intent != 2) ) {
            return true;
        }else{
            return false;
        }
    }

    bool checkXIntent(){
        if((current_x_intent != previous_x_intent) && (current_x_intent != 0)) {
            return true;
        }else{
            return false;
        }
    }

    bool checkYIntent(){
        if((current_y_intent != previous_y_intent) && (current_y_intent != 0)) {
            return true;
        }else{
            return false;
        }
    }

}