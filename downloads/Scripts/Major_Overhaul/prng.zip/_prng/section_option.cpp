#include 'area.cpp'

class section_option: area {

    [option, 0:horizontal, 1:up, 2:down] int direction;
    
    [position,mode:world,layer:19,y:C1y] int C1x = 0;
	[hidden] int C1y = 0;
	[position,mode:world,layer:19,y:C2y] int C2x = 0;
	[hidden] int C2y = 0;

    int first_node_id = -1;
    int last_node_id = -1;

    int connection1_height = 0;
    int connection2_height = 0;

    // function to get enemy collision
    int get_enemy_collision(scene@ g) {
        int EntityCollision = 0;
        
        EntityCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,1);
        
        return EntityCollision;
    }
    
    // function to get enemy ai collision
    int get_enemy_ai_collision(scene@ g) {
        int EntityAiCollision = 0;
        
        EntityAiCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,15);
        
        return EntityAiCollision;
    
    }
    
    // function to get camera node collision
    int get_cnode_collision(scene@ g) {
        int CNodeCollision = 0;
        
        CNodeCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,12);
        
        return CNodeCollision;
    
    }
    
    // function to checkpoint collision
    int get_checkpoint_collision(scene@ g) {
        int CheckpointCollision = 0;
        
        CheckpointCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,17);
        
        return CheckpointCollision;
    
    }
    
    // function to get enemy ai collision
    int get_t_area_collision(scene@ g) {
        int TAreaCollision = 0;
        
        TAreaCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,20);
        
        return TAreaCollision;
    
    }

    // function to get trigger collision
    int get_trigger_collision(scene@ g) {
        int TriggerCollision = 0;
        
        TriggerCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,16);
        
        return TriggerCollision;
    
    }
    
    // function to get prop collision
    int get_prop_collision(scene@ g) {
        int PropCollision = 0;
        
        PropCollision = g.get_prop_collision(top_y()*48, bottom_y()*48, left_x()*48 ,right_x()*48);
        
        return PropCollision;
    }

    // function to get trigger collision
    int get_death_collision(scene@ g) {
        int DeathCollision = 0;
        
        DeathCollision = g.get_entity_collision(top_y()*48, bottom_y()*48, left_x()*48, right_x()*48,21);
        
        return DeathCollision;
    }      
    
    // function to get the first camera node
    int first_node(scene@ g) {
    
        if(first_node_id > 0)
            return first_node_id;
        
        int lowest_x = 999999;
        
        int CNodeCollision = 0;
        
        entity@ CurrentEntity;
        
        CNodeCollision = get_cnode_collision(g);
        
        for(int i = 0; i < CNodeCollision; i++) {
            @CurrentEntity = g.get_entity_collision_index(i);
            
            if(CurrentEntity.x() < lowest_x) {
            lowest_x = CurrentEntity.x();
            first_node_id = CurrentEntity.id();
            }
        }
        
        return first_node_id;
    }
    
    // function to get the last camera node
    int last_node(scene@ g) {
    
        if(last_node_id > 0)
            return last_node_id;
        
        int highest_x = -999999;
        
        int CNodeCollision = 0;
        
        entity@ CurrentEntity;
        
        CNodeCollision = get_cnode_collision(g);
        
        for(int i = 0; i < CNodeCollision; i++) {
            @CurrentEntity = g.get_entity_collision_index(i);
            
            if(CurrentEntity.x() > highest_x) {
            highest_x = CurrentEntity.x();
            last_node_id = CurrentEntity.id();
            }
        }
        
        return last_node_id;
    }

    bool is_up(){
        if(direction == 1){
            return true;
        } else{
            return false;
        }
    }

    bool is_down(){
       if(direction == 2){
            return true;
        } else{
            return false;
        } 
    }

    // drawing the connection points
    void draw_connections(scene@ g){
        float temp1 = 0;
        float temp2 = 0;

        int top1 = 0;
        int bottom1 = 0;
        int left1 = 0;
        int right1 = 0;

        int top2 = 0;
        int bottom2 = 0;
        int left2 = 0;
        int right2 = 0;

        temp1 = C1y / 48.0;
        temp2 = floor(temp1);

        top1 = temp2*48;

        temp1 = C1y / 48.0;
        temp2 = ceil(temp1);

        bottom1 = temp2*48;

        temp1 = C1x / 48.0;
        temp2 = floor(temp1);

        left1 = temp2*48;

        temp1 = C1x / 48.0;
        temp2 = ceil(temp1);

        right1 = temp2*48;


        temp1 = C2y / 48.0;
        temp2 = floor(temp1);

        top2 = temp2*48;

        temp1 = C2y / 48.0;
        temp2 = ceil(temp1);

        bottom2 = temp2*48;

        temp1 = C2x / 48.0;
        temp2 = floor(temp1);

        left2 = temp2*48;

        temp1 = C2x / 48.0;
        temp2 = ceil(temp1);

        right2 = temp2*48;

        g.draw_rectangle_world(20,20,left1,top1,right1,bottom1,0,0x70F0A754);

        g.draw_rectangle_world(20,20,left2,top2,right2,bottom2,0,0x70F0A754);


    }

    // initializing the connection height variables
    void determine_height(){
        float temp1 = 0;
        float temp2 = 0;

        temp1 = C1y / 48.0;
        temp2 = floor(temp1);

        connection1_height = temp2*48;

        temp1 = C2y / 48.0;
        temp2 = floor(temp1);

        connection2_height = temp2*48;
    }

    // Setting the height to a value h for connection point c
    void set_height(int h, int c){
        if(c == 1){
            connection1_height = h;
        } else {
            connection2_height = h;
        }
    }

    int get_height(int c){
        if(c == 1){
            return connection1_height;
        } else {
            return connection2_height;
        }
    }

}