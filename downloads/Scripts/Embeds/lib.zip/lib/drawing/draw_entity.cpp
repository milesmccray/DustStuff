void draw_entity()
{
	
}