const int STEP_SAMPLES = 300;
const int DRAW_SAMPLES = 600;

const float TARGET_HEIGHT = 0.4;
const float STEP_SIZE = 1.4;

// const float SCREEN_HEIGHT = 1080;

class FPS
{
    canvas@ c;
    textfield@ t;

    int step_start_time;
    array<int> step_samples = array(STEP_SAMPLES);
    int step_samples_count = 0;
    int step_i;
    float step_scale = 1;

    int draw_start_time;
    array<int> draw_samples = array(DRAW_SAMPLES);
    int draw_samples_count = 0;
    int draw_i;
    float draw_scale = 1;

    FPS()
    {
        @c = create_canvas(true, 20, 0);
        @t = create_textfield();
        t.set_font("envy_bold", 20);
        t.align_horizontal(-1);
        t.align_vertical(-1);
    }

    void step_start()
    {
        step_start_time = get_time_us();
    }

    void step_end()
    {
        step_samples[step_i] = get_time_us() - step_start_time;
        step_i = (step_i + 1) % STEP_SAMPLES;
        if (step_samples_count < STEP_SAMPLES)
            ++step_samples_count;
    }

    void draw_start()
    {
        draw_start_time = get_time_us();
    }

    void draw_end()
    {
        draw_samples[draw_i] = get_time_us() - draw_start_time;
        draw_i = (draw_i + 1) % DRAW_SAMPLES;
        if (draw_samples_count < DRAW_SAMPLES)
            ++draw_samples_count;

        // Compute avg and max
        int draw_samples_sum = 0;
        int draw_samples_max = 0;
        for (int i=0; i<DRAW_SAMPLES; ++i)
        {
            const int sample = draw_samples[(draw_i + i) % DRAW_SAMPLES];
            draw_samples_sum += sample;
            if (sample > draw_samples_max) draw_samples_max = sample;
        }
        float draw_samples_avg = float(draw_samples_sum) / draw_samples_count;

        int step_samples_sum = 0;
        int step_samples_max = 0;
        for (int i=0; i<STEP_SAMPLES; ++i)
        {
            const int sample = step_samples[(step_i + i) % STEP_SAMPLES];
            step_samples_sum += sample;
            if (sample > step_samples_max) step_samples_max = sample;
        }
        float step_samples_avg = float(step_samples_sum) / step_samples_count;

        // Update graph scale
        const float draw_height = draw_scale * draw_samples_avg / SCREEN_HEIGHT;
        if (draw_height > TARGET_HEIGHT * STEP_SIZE) draw_scale /= STEP_SIZE;
        if (draw_height < TARGET_HEIGHT / STEP_SIZE) draw_scale *= STEP_SIZE;

        const float step_height = step_scale * step_samples_avg / SCREEN_HEIGHT;
        if (step_height > TARGET_HEIGHT * STEP_SIZE) step_scale /= STEP_SIZE;
        if (step_height < TARGET_HEIGHT / STEP_SIZE) step_scale *= STEP_SIZE;

        // Draw graph
        const float scale = min(step_scale, draw_scale);
        for (int i=0; i<DRAW_SAMPLES; ++i)
        {
            const float sample = scale * draw_samples[(draw_i + i) % DRAW_SAMPLES];
            c.draw_line(0.5 * i - 801, -450, 0.5 * i - 801, sample - 450, 1, 0x66008800);
        }

        for (int i=0; i<STEP_SAMPLES; ++i)
        {
            const float sample = scale * step_samples[(step_i + i) % STEP_SAMPLES];
            c.draw_line(i - 800, -450, i - 800, sample - 450, 1, 0x88880000);
        }

        // Draw text
        t.text(
            "Step:" + formatFloat(step_samples_avg, " ", 8, 2) + "us, max: " + step_samples_max + "us\n"
            "Draw:" + formatFloat(draw_samples_avg, " ", 8, 2) + "us, max: " + draw_samples_max + "us\n"
        );
        c.draw_text(t, -800, -450, 0.7, 0.7, 0);
    }
}
