#include "math/math.cpp"

const array<string> STATES = {"idle", "victory", "run", "skid", "superskid", "fall", "land", "hover", "jump", "dash", "crouch_jump", "wall_run", "wall_grab", "wall_grab_idle", "wall_grab_release", "roof_grab", "roof_grab_idle", "roof_run", "slope_slide", "raise", "stun", "stun_wall", "stun_ground", "slope_run", "hop", "spawn", "fly", "thanks_cleansed", "idle_cleansed", "idle_cleansed_thanks", "fall_cleansed", "land_cleansed", "cleansed", "block", "wall_dash"};

const dictionary CHARACTER = {
    {"dustman", "dm"},
    {"vdustman", "vdm"},
    {"dustgirl", "dg"},
    {"vdustgirl", "vdg"},
    {"dustkid", "dk"},
    {"vdustkid", "vdk"},
    {"dustworth", "do"},
    {"vdustworth", "vdo"}
};
const array<string> EFFECTS = {
    "dmairdash",
    "dmbjump",
    "dmdash",
    "dmdbljump",
    "dmfastfall",
    "dmfjump",
    "dmheavyland",
    "dmjump",
    "dmland",
    "dmwalljump",

    "dmairheavyd",
    "dmairstriked1",
    "dmgroundstrike1",
    "dmgroundstriked",
    "dmgroundstrikeu1",
    "dmheavyd",
    "dmheavyf",
    "dmheavyu",

    "dgairdash",
    "dgbjump",
    "dgdash",
    "dgdbljump",
    "dgfastfall",
    "dgfjump",
    "dgheavyland",
    "dgjump",
    "dgland",
    "dgwalljump",

    "dgairheavyd",
    "dgairstriked1",
    "dggroundstrike1",
    "dggroundstriked",
    "dggroundstrikeu1",
    "dgheavyd",
    "dgheavyf",
    "dgheavyu",

    "dkairdash",
    "dkbjump",
    "dkdash",
    "dkdbljump",
    "dkfastfall",
    "dkfjump",
    "dkheavyland",
    "dkjump",
    "dkland",
    "dkwalljump",

    "dkairheavyd",
    "dkairstriked1",
    "dkgroundstrike1",
    "dkgroundstriked",
    "dkgroundstrikeu1",
    "dkheavyd",
    "dkheavyf",
    "dkheavyu",

    "doairdash",
    "dobjump",
    "dodash",
    "dodbljump",
    "dofastfall",
    "dofjump",
    "doheavyland",
    "dojump",
    "doland",
    "dowalljump",

    "doairheavyd",
    "doairstriked1",
    "dogroundstrike1",
    "dogroundstriked",
    "dogroundstrikeu1",
    "doheavyd",
    "doheavyf",
    "doheavyu",

    "vdmairdash",
    "vdmbjump",
    "vdmdash",
    "vdmdbljump",
    "vdmfastfall",
    "vdmfjump",
    "vdmheavyland",
    "vdmjump",
    "vdmland",
    "vdmwalljump",

    "vdmairheavyd",
    "vdmairstriked1",
    "vdmgroundstrike1",
    "vdmgroundstriked",
    "vdmgroundstrikeu1",
    "vdmheavyd",
    "vdmheavyf",
    "vdmheavyu",

    "vdgairdash",
    "vdgbjump",
    "vdgdash",
    "vdgdbljump",
    "vdgfastfall",
    "vdgfjump",
    "vdgheavyland",
    "vdgjump",
    "vdgland",
    "vdgwalljump",

    "vdgairheavyd",
    "vdgairstriked1",
    "vdggroundstrike1",
    "vdggroundstriked",
    "vdggroundstrikeu1",
    "vdgheavyd",
    "vdgheavyf",
    "vdgheavyu",

    "vdkairdash",
    "vdkbjump",
    "vdkdash",
    "vdkdbljump",
    "vdkfastfall",
    "vdkfjump",
    "vdkheavyland",
    "vdkjump",
    "vdkland",
    "vdkwalljump",

    "vdkairheavyd",
    "vdkairstriked1",
    "vdkgroundstrike1",
    "vdkgroundstriked",
    "vdkgroundstrikeu1",
    "vdkheavyd",
    "vdkheavyf",
    "vdkheavyu",

    "vdoairdash",
    "vdobjump",
    "vdodash",
    "vdodbljump",
    "vdofastfall",
    "vdofjump",
    "vdoheavyland",
    "vdojump",
    "vdoland",
    "vdowalljump",

    "vdoairheavyd",
    "vdoairstriked1",
    "vdogroundstrike1",
    "vdogroundstriked",
    "vdogroundstrikeu1",
    "vdoheavyd",
    "vdoheavyf",
    "vdoheavyu",
};

const array<array<int>> FRAMES = {
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 2, 3, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},

    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},

    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 2, 3, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},

    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},

    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3, 2, 3, 2},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},

    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},

    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3, 2, 3, 2},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},

    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},

    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 2, 3, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},

    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},

    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 2, 3, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},
    {3, 3, 4, 3, 3},

    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},
    {4, 3, 4, 3, 2, 3},

    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3, 2, 3, 2},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},

    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},

    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3, 2, 3, 2},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},
    {3, 2, 3, 2, 3},

    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
    {4, 2, 3, 2, 3, 2},
};

class clone {
    int layer;
    int player_sublayer;
    int effect_sublayer;

    float offset_x = 0;
    float offset_y = 0;

    float scale_x = 1;
    float scale_y = 1;

    bool visible = true;

    scene@ g;
    controllable@ p;
    sprites@ spr;

    player_state new_state;
    player_state last_state;
    array<effect@> effects;
    array<hitbox@> attacks;

    clone(scene@ g, controllable@ p, int layer=18, int player_sublayer=10, int effect_sublayer=14) {
        @this.g = g;
        @this.p = p;
        @spr = p.get_sprites();

        this.layer = layer;
        this.player_sublayer = player_sublayer;
        this.effect_sublayer = effect_sublayer;
    }

    void set_controllable(controllable@ p) {
        @this.p = p;
    }

    void step_post() { 
        for (int i=effects.length()-1; i>=0; --i) {
            effects[i].step();
            if (effects[i].finished) {
                effects.removeAt(i);
            }
        }

        new_state = player_state(p);

        compute_fx();

        compute_attacks();

        last_state = new_state;
    }

    void compute_fx() {
        int effect_num = effects.size();

        dustman@ d = p.as_dustman();

        string c = string(CHARACTER[d.character()]);
        float x = scale_x * new_state.x + offset_x;
        float y = scale_y * new_state.y + offset_y;
        int face = new_state.face;

        if (
            (new_state.state == "jump" && last_state.state != "jump") ||
            (new_state.jump_intent == 2 && last_state.jump_intent != 2)
        ) {
            if (last_state.air_charges == new_state.air_charges) {
                if (last_state.ground) {
                    float direction = sign(new_state.x_speed);
                    if (direction == 0) {
                        effects.insertLast(@effect(c+"jump", layer, x, y, face, scale_y));
                    } else if (direction == new_state.face) {
                        effects.insertLast(@effect(c+"fjump", layer, x, y, face, scale_y));
                    } else {
                        effects.insertLast(@effect(c+"bjump", layer, x, y, face, scale_y));
                    }
                } else if (last_state.wall_left) {
                    effects.insertLast(@effect(c+"walljump", layer, x, y+scale_y*8, -1, scale_y));
                } else if (last_state.wall_right) {
                    effects.insertLast(@effect(c+"walljump", layer, x, y+scale_y*8, 1, scale_y));
                }
            } else {
                effects.insertLast(@effect(c+"dbljump", layer, x, y, 1, scale_y));
            }
        }

        if (new_state.dash_intent == 2) {
            if (last_state.air_charges <= new_state.air_charges && (last_state.ground || (!last_state.ground && new_state.ground))) {
                effects.insertLast(@effect(c+"dash", layer, x, y, face, scale_y));
            } else {
                if (last_state.state == "wall_dash" || last_state.state == "wall_run" || last_state.state == "wall_grab" || last_state.state == "wall_grab_idle") {
                    effects.insertLast(@effect(c+"airdash", layer, x + scale_x*24*last_state.face, y, last_state.face, scale_y));
                } else {
                    effects.insertLast(@effect(c+"airdash", layer, x, y, face, scale_y));
                }
            }
        }

        if (new_state.fall_intent == 2) {
            effects.insertLast(@effect(c+"fastfall", layer, x, y, 1, scale_y));
        }

        if (new_state.ground && !last_state.ground) {
            if (last_state.y_speed >= 1500.0) {
                effects.insertLast(@effect(c+"heavyland", layer, x, y, 1, scale_y));
            } else if (new_state.state != "dash") {
                effects.insertLast(@effect(c+"land", layer, x, y, 1, scale_y));
            }
        }

        if (new_state.state == "roof_run" && last_state.state != "roof_run") {
            effects.insertLast(@effect(c+"dash", layer, x, y-scale_y*96, -face, scale_y, 180));
        }

        if (new_state.state == "wall_run" && last_state.state != "wall_run") {
            effects.insertLast(@effect(c+"dash", layer, x+scale_x*20*face, y-scale_y*32, face, scale_y, -90*face));
        }

        if (not visible) effects.resize(effect_num);

    }

    void compute_attacks() {
        for (int i=attacks.length()-1; i>=0; --i) {
            if (@attacks[i] is null) {
                attacks.removeAt(i);
                continue;
            }

            if (attacks[i].hit_outcome() == 1 || attacks[i].hit_outcome() == 2 || attacks[i].hit_outcome() == 3 || attacks[i].hit_outcome() == 4) {
                effect@ e;
                dustman@ d = p.as_dustman();
                string c = string(CHARACTER[d.character()]);
                int damage = attacks[i].damage();
                int direction = abs(attacks[i].attack_dir());
                float x = scale_x * p.x() + offset_x;
                float y = scale_y * p.y() + offset_y;
                int face = last_state.attack_face;
                int freeze = (attacks[i].hit_outcome() == 2 or attacks[i].hit_outcome() == 4) ? 0 : (damage == 1 ? 2 : 7);
                if (damage == 1) {
                    if (direction == 30) {
                        @e = @effect(c+"groundstrikeu1", layer, x, y, face, scale_y, 0, freeze);
                    } else if (direction == 85) {
                        @e = @effect(c+"groundstrike1", layer, x, y, face, scale_y, 0, freeze);
                    } else if (direction == 150 and not p.ground()) {
                        @e = @effect(c+"airstriked1", layer, x, y, face, scale_y, 0, freeze);
                    } else if (direction == 151) {
                        @e = @effect(c+"groundstriked", layer, x, y, face, scale_y, 0, freeze);
                    }
                } else if (damage == 3) {
                    if (direction == 30) {
                        @e = @effect(c+"heavyu", layer, x, y, face, scale_y, 0, freeze);
                    } else if (direction == 85) {
                        @e = @effect(c+"heavyf", layer, x, y, face, scale_y, 0, freeze);
                    } else if (direction == 150) {
                        if (p.ground()) {
                            @e = @effect(c+"heavyd", layer, x, y, face, scale_y, 0, freeze);
                        } else {
                            @e = @effect(c+"airheavyd", layer, x, y, face, scale_y, 0, freeze);
                        }
                    }
                }

                if (@e !is null) effects.insertLast(@e);
                attacks.removeAt(i);
            }
        }
    }

    void entity_on_add(entity@ e) {
        if (not visible) return;

        hitbox@ h = e.as_hitbox();
        if (h !is null && h.owner().is_same(p)) {
            attacks.insertLast(@h);
        }
    }

    void draw(float subframe) {
        dustman@ d = p.as_dustman();

        float px = subframe * p.x() + (1 - subframe) * p.prev_x();
        float py = subframe * p.y() + (1 - subframe) * p.prev_y();

        if (visible) {
            // Draw the player
            if (p.attack_state() == 0) {
                // State timer doesn't loop in fall
                int state_timer = p.state_timer();
                if (p.state() == 5) state_timer %= 4;

                spr.draw_world(layer, player_sublayer, p.sprite_index(), state_timer, 1, scale_x*px+offset_x, scale_y*py+offset_y, 0, p.face() * scale_x, scale_y, 0xFFFFFFFF);
            } else {
                spr.draw_world(layer, player_sublayer, p.attack_sprite_index(), p.attack_timer(), 1, scale_x*px+offset_x, scale_y*py+offset_y, 0, p.attack_face() * scale_x, scale_y, 0xFFFFFFFF);
            }
        }
        // Draw the effects
        for (int i=0; i<effects.length(); ++i) {
            effects[i].draw(spr, effect_sublayer);
        }
    }
}

class player_state {
    bool ground = true;
    bool wall_left = false;
    bool wall_right = false;
    int air_charges = 0;
    string state = "idle";
    float x_speed = 0.0;
    float y_speed = 0.0;
    float x = 0.0;
    float y = 0.0;
    int jump_intent = 0;
    int dash_intent = 0;
    int fall_intent = 0;
    int face = 1;
    int attack_face = 1;

    player_state() {}
    player_state(controllable@ p) {
        dustman@ d = p.as_dustman();

        ground = p.ground();
        wall_left = p.wall_left();
        wall_right = p.wall_right();
        air_charges = d.dash();
        state = STATES[p.state()];
        x_speed = p.x_speed();
        y_speed = p.y_speed();
        x = p.x();
        y = p.y();
        jump_intent = p.jump_intent();
        dash_intent = p.dash_intent();
        fall_intent = p.fall_intent();
        face = p.face();
        attack_face = p.attack_face();
    }
}

class effect {
    string sprite_name;
    int effect_index;
    int face;
    float x;
    float y;
    float rotation;
    int freeze;
    float scale_y;
    int layer;

    int frame = 0;
    int sprite_index = 0;

    bool finished = false;

    effect(string sprite_name, int layer, float x, float y, int face, float scale_y, float rotation=0, int freeze=0) {
        this.sprite_name = sprite_name;
        this.effect_index = EFFECTS.find(sprite_name);
        this.x = x;
        this.y = y;
        this.face = face;
        this.rotation = rotation;
        this.freeze = freeze;
        this.scale_y = scale_y;
        this.layer = layer;
    }

    void step() {
        if (++frame >= FRAMES[effect_index][sprite_index] + (sprite_index == 0 ? freeze : 0)) {
            frame = 0;
            if (++sprite_index >= FRAMES[effect_index].length()) {
                finished = true;
            }
        }
    }

    void draw(sprites@ spr, int sub_layer) {
        if (!finished) {
            spr.draw_world(layer, sub_layer, sprite_name, sprite_index, 1, x, y, sign(scale_y) * rotation, face, scale_y, 0xFFFFFFFF);
        }
    }
}
