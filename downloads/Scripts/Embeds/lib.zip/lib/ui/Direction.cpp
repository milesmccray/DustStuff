enum Direction
{
	
	Horizontal,
	Vertical,
	
}