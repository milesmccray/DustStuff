#include "math3d.as"

class Drawable {}

class Sprite : Drawable
{
    Vec3 target;
    string sprite_set;
    string sprite_name;
    int sprite_frame;

    Vec3 pos;
    int state_timer = 0;

    Sprite() {}

    Sprite(Vec3 pos, string sprite_set, string sprite_name)
    {
        this.pos = pos;
        this.target = pos;
        this.sprite_set = sprite_set;
        this.sprite_name = sprite_name;
    }

    void step()
    {
        if (++state_timer > 10)
        {
            state_timer = 0;
            if (++sprite_frame > 7)
                sprite_frame = 0;
        }
    }
}

class Triangle : Drawable
{
    int v1, v2, v3;
    uint colour;

    Triangle() {}

    Triangle(int v1, int v2, int v3)
    {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.colour = (0xFF << 24) + rand() % 0xFFFFFF;
    }

    Triangle(int v1, int v2, int v3, uint colour)
    {
        this.v1 = v1;
        this.v2 = v2;
        this.v3 = v3;
        this.colour = colour;
    }

    Triangle offset(int v)
    {
        return Triangle(v + v1, v + v2, v + v3, colour);
    }
}

interface Mesh
{
    array<Vec3> vertices();
    array<Triangle@> triangles();
    bool intersects_box(Box other);
    bool intersects_ray(Vec3 start, Vec3 dir, float &out dist, Vec3 &out normal);
}

class Box : Mesh
{
    float x1, y1, z1, x2, y2, z2;

    Box(Vec3 p1, Vec3 p2)
    {
        this.x1 = p1.x;
        this.y1 = p1.y;
        this.z1 = p1.z;
        this.x2 = p2.x;
        this.y2 = p2.y;
        this.z2 = p2.z;
    }

    Box(Vec3 centre, float radius)
    {
        this.x1 = centre.x - radius;
        this.y1 = centre.y - radius;
        this.z1 = centre.z - radius;
        this.x2 = centre.x + radius;
        this.y2 = centre.y + radius;
        this.z2 = centre.z + radius;
    }

    Box expand(float dx1, float dx2, float dy1, float dy2, float dz1, float dz2)
    {
        return Box(
            Vec3(x1 - dx1, y1 - dy1, z1 - dz1),
            Vec3(x2 + dx2, y2 + dy2, z2 + dz2)
        );
    }

    array<Vec3> vertices() override
    {
        array<Vec3> vs = {
            Vec3(x1, y1, z1),
            Vec3(x2, y1, z1),
            Vec3(x2, y2, z1),
            Vec3(x1, y2, z1),
            Vec3(x1, y1, z2),
            Vec3(x2, y1, z2),
            Vec3(x2, y2, z2),
            Vec3(x1, y2, z2)
        };
        return vs;
    }

    array<Triangle@> triangles() override
    {
        array<Triangle@> ts = {
            Triangle(0, 2, 1),
            Triangle(3, 2, 0),
            Triangle(5, 6, 7),
            Triangle(7, 4, 5),
            Triangle(5, 0, 1),
            Triangle(0, 5, 4),
            Triangle(2, 3, 7),
            Triangle(7, 6, 2),
            Triangle(0, 7, 3),
            Triangle(7, 0, 4),
            Triangle(6, 1, 2),
            Triangle(1, 6, 5)
        };
        return ts;
    }

    bool intersects_box(Box other)
    {
        return (
            x1 <= other.x2 and
            x2 >= other.x1 and
            y1 <= other.y2 and
            y2 >= other.y1 and
            z1 <= other.z2 and
            z2 >= other.z1
        );
    }

    bool intersects_ray(Vec3 start, Vec3 dir, float &out dist, Vec3 &out normal)
    {
        float inv_x = dir.x == 0 ? INFINITY : 1.0 / dir.x;
        float inv_y = dir.y == 0 ? INFINITY : 1.0 / dir.y;
        float inv_z = dir.z == 0 ? INFINITY : 1.0 / dir.z;

        float tx1 = (x1 - start.x) * inv_x;
        float tx2 = (x2 - start.x) * inv_x;
        float ty1 = (y1 - start.y) * inv_y;
        float ty2 = (y2 - start.y) * inv_y;
        float tz1 = (z1 - start.z) * inv_z;
        float tz2 = (z2 - start.z) * inv_z;

        float t_min = max(max(min(tx1, tx2), min(ty1, ty2)), min(tz1, tz2));
        float t_max = min(min(max(tx1, tx2), max(ty1, ty2)), max(tz1, tz2));

        if (t_min > t_max) return false;
        if (t_min < 0) return false;

        if (t_min == tx1) normal = Vec3(-1, 0, 0);
        if (t_min == tx2) normal = Vec3( 1, 0, 0);
        if (t_min == ty1) normal = Vec3(0, -1, 0);
        if (t_min == ty2) normal = Vec3(0,  1, 0);
        if (t_min == tz1) normal = Vec3(0, 0, -1);
        if (t_min == tz2) normal = Vec3(0, 0,  1);

        dist = t_min;
        return true;
    }
}

const array<array<int>> cube_edges = {
    {0, 1}, // Normal
    {1, 2},
    {2, 3},
    {3, 0},
    {4, 5},
    {5, 6},
    {6, 7},
    {7, 4},
    {0, 4},
    {1, 5},
    {2, 6},
    {3, 7},
    {0, 2}, // Crosses
    {1, 3},
    {4, 6},
    {5, 7},
    {0, 5},
    {1, 4},
    {1, 6},
    {2, 5},
    {2, 7},
    {3, 6},
    {3, 4},
    {0, 7}
};

array<Vec3> plane_vertices(float size, int subdivisions)
{
    array<Vec3> vertices;
    for (int i=0; i<=subdivisions; ++i)
    {
        float z = size * i / subdivisions;
        for (int j=0; j<=subdivisions; ++j)
        {
            float x = size * j / subdivisions;
            vertices.insertLast(Vec3(x, 0, z));
        }
    }
    return vertices;
}

array<Triangle> plane_triangles(int subdivisions)
{
    array<Triangle> triangles;
    for (int i=0; i<subdivisions; ++i)
    {
        for (int j=0; j<subdivisions; ++j)
        {
            triangles.insertLast(Triangle(
                (subdivisions + 1) * i + j,
                (subdivisions + 1) * (i + 1) + j,
                (subdivisions + 1) * i + j + 1
            ));
            triangles.insertLast(Triangle(
                (subdivisions + 1) * (i + 1) + j,
                (subdivisions + 1) * (i + 1) + j + 1,
                (subdivisions + 1) * i + j + 1
            ));
        }
    }
    return triangles;
}
