#include "../std.cpp"
#include "bsp.as"

class Scene
{
    array<Mesh@> meshes;
    array<Vec3> vertices;
    array<Triangle@> triangles;
    BSP@ bsp;

    void add(Box cube)
    {

        @bsp = null;
        meshes.insertLast(cube.expand(3, 3, 3, 8, 3, 3));

        int vertex_count = vertices.size();

        array<Vec3> vs = cube.vertices();
        for (uint i=0; i<vs.size(); ++i)
            vertices.insertLast(vs[i]);

        array<Triangle@> ts = cube.triangles();
        for (uint i=0; i<ts.size(); ++i)
            triangles.insertLast(ts[i].offset(vertex_count));
    }

    void floor(float size, int divisions)
    {
        vertices = plane_vertices(size, divisions);
        array<Triangle> pt = plane_triangles(divisions);
        for (uint i = 0; i < pt.size(); ++i)
            triangles.insertLast(pt[i]);
        add(Box(Vec3(0, -1, 0), Vec3(1000, -0.001, 1000)));
    }

    array<Drawable@>@ draw_order(Vec3 pos, array<Sprite@> sprites = array<Sprite@>())
    {
        if (bsp is null)
        {
            array<uint> indices = {0,78,48,3,22,20,2,2,2,0,0,0,0,0,8,0,0,8,6,0,0,9,0,0,0,0,11,0,0,2,2,0,5,0,0,0,15,0,0,0,11,0,0,0,0,27,9,9,0,0,0,0,0,0,12,0,0,0,0,0,0,6,19,6,0,2,2,0,3,3,0,0,3,0,0,0,0,20,3,0,0,3,0,0,0,0,0,0,7,0,0,0,0,106,31,36,17,0,0,0,0,0,0,0,16,0,0,0,0,6,0,0,3,0,0,3,0,0,0,0,2,2,0,5,0,0,0,0,0,0,5,3,0,0,0,0,3,0,37,3,0,0,3,0,3,3,0,0,8,0,0,15,10,0,0,0,8,0,0,0,0,6,6,3,0,0,0,0,0,42,0,0,2,0,0,0,0,0,0,0,0,0,0,90,26,33,31,0,7,0,3,0,15,3,0,6,0,0,0,0,0,9,4,0,0,0,14,0,9,9,0,0,0,0,11,33,7,12,0,0,0,3,0,0,0,0,0,7,0,0,0,0,0,0,17,0,3,3,0,0,5,0,3,0,0,0,4,0,3,0,10,0,0,6,7,0,0,0,0,0,0,0,16,14,0,8,0,0,6,0,0,0,0,0,0,0,4,0,0,13,18,0,0,0,0,4,0,0,0,0,0,0,0,0,0,0,0,0,80,23,11,0,0,3,0,9,0,0,0,0,0,3,3,0,6,0,0,0,0,19,0,9,4,0,11,4,0,0,0,0,0,6,0,0,7,0,0,0,11,0,0,0,7,0,0,61,15,0,0,3,3,0,10,0,3,0,0,0,0,5,0,3,0,12,5,0,0,0,0,0,8,22,21,6,0,0,7,0,0,6,0,5,0,0,23,0,7,3,0,5,0,0,0,0,0,0,0,3,0,0,0,4,0,0,0,0,56,68,39,28,6,0,0,0,7,0,0,8,0,0,0,0,28,0,7,0,0,7,0,0,0,0,0,0,0,0,11,0,5,0,0,23,0,26,0,0,0,0,0,0,2,0,5,0,6,0,0,0,0,0,6,3,0,5,0,0,26,0,0,0,10,0,3,0,0,0,7,0,0,3,0,0,4,0,3,0,3,0,4,0,0,11,0,0,4,0,0,0,0,3,0,0,91,22,9,0,0,4,0,4,0,4,0,0,23,0,3,0,3,0,0,0,0,3,0,4,0,0,0,0,26,0,7,0,0,9,12,0,0,0,0,33,7,0,0,0,4,0,0,0,3,0,3,0,0,53,35,10,5,0,24,5,0,0,14,0,0,0,0,36,5,5,0,0,15,0,0,0,0,3,0,0,0,3,3,0,0,4,0,0,0,0,20,17,8,0,0,0,3,0,0,0,0,35,0,0,4,0,4,0,5,0,0,0,0,0,0,3,0,3,3,0,0,4,0,0,};
            if (indices.size() > 0)
            {
                @bsp = build_bsp(vertices, triangles, indices);
            }
            else
            {
                @bsp = optimise_bsp(vertices, triangles, indices);
                string output = "{";
                for (uint i=0; i<indices.size(); ++i)
                    output += indices[i] + ",";
                output += "}";
                puts(output);
            }
            puts("BSP Nodes: " + bsp.size());
            puts("Vertices: " + vertices.size());
            puts("Triangles: " + triangles.size());
        }

        return bsp.draw_order(pos, sprites);
    }

    bool intersects_ray(Vec3 pos, Vec3 dir, float &out closest_dist, Vec3 &out closest_normal)
    {
        closest_dist = INFINITY;
        closest_normal = Vec3();
        bool intersection = false;
        for (uint i=0; i<meshes.size(); ++i)
        {
            float dist;
            Vec3 normal;
            if (meshes[i].intersects_ray(pos, dir, dist, normal) and dist < closest_dist)
            {
                closest_dist = dist;
                closest_normal = normal;
                intersection = true;
            }
        }
        return intersection;
    }
}
