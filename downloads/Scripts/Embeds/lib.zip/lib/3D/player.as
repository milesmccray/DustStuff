#include "../input/Mouse.cpp"

#include "math3d.as"

class Player
{
    controllable@ p;

    Mouse m(true);

    float accel = 0.1;
    float air_accel = 0.05;
    float friction = 0.05;
    float max_speed = 2;
    float gravity = 0.05;
    float jump_vel = 1.5;

    Vec3 pos(1, 10, 1);
    Vec3 vel(0, 0, 0);
    float yaw = -3 * PI / 4;
    float pitch;
    bool grounded = true;

    Player(controllable@ p)
    {
        @this.p = p;
        m.step(true);
    }

    void step(Scene@ s)
    {
        m.step();
        if (m.left_down)
        {
            yaw -= 0.005 * m.delta_x;
            pitch -= 0.005 * m.delta_y;
            pitch = min(1.55, max(-1.55, pitch));
        }

        const int dx = p.x_intent();
        const int dy = p.y_intent();
        const bool jump = p.jump_intent() > 0;
        const bool dash = p.dash_intent() > 0;
        p.x_intent(0);
        p.y_intent(0);
        p.jump_intent(0);
        p.dash_intent(0);

        // grounded = pos.y <= 0;
        // if (grounded)
        // {
        //     pos.y = 0;
        //     vel.y = 0;
        // }

        if (dx != 0)
        {
            vel.x += (grounded ? accel : air_accel) * dx * cos(yaw);
            vel.z -= (grounded ? accel : air_accel) * dx * sin(yaw);
        }
        if (dy != 0)
        {
            vel.x += (grounded ? accel : air_accel) * dy * sin(yaw);
            vel.z += (grounded ? accel : air_accel) * dy * cos(yaw);
        }

        if (dash)
        {
            vel = vel + 5 * look_dir();
        }

        float speed = sqrt(vel.x * vel.x + vel.z * vel.z);
        if (speed != 0)
        {
            float new_speed = min(max_speed, speed);
            if (grounded)
                new_speed = max(0.f, new_speed - friction);
            vel.x *= new_speed / speed;
            vel.z *= new_speed / speed;
        }

        if (grounded)
        {
            if (jump) vel.y += jump_vel;
        }
        else
        {
            vel.y -= gravity;
        }

        int max_collisions = 10;
        float remaining = 1.0;
        do
        {
            float speed = vel.magnitude();
            if (speed == 0)
                break;

            float dist;
            Vec3 normal;
            if (!s.intersects_ray(pos, vel.normalised(), dist, normal))
                break;

            if (dist > speed * remaining)
                break;

            remaining -= dist / speed;
            pos = pos + vel.normalised() * (dist - EPSILON);
            vel = vel - normal * normal.dot(vel);

            if (normal.y > 0) grounded = true;
        }
        while (--max_collisions > 0);
        pos = pos + vel * remaining;

        float dist;
        Vec3 normal;
        grounded = s.intersects_ray(pos, Vec3(0, -1, 0), dist, normal) && dist < 1;
        // puts(dist);
        // puts(grounded);
    }

    Vec3 camera_pos()
    {
        return pos;
    }

    Vec3 look_dir()
    {
        return Vec3(0, 0, -1).rotate_x(pitch).rotate_y(yaw);
    }

    Box collision_box()
    {
        return Box(pos - Vec3(0.2, 0, 0.2), pos + Vec3(0.2, 0.7, 0.2));
    }

    Mat4 view_matrix()
    {
        return look_at_matrix(camera_pos(), yaw, pitch);
    }
}
