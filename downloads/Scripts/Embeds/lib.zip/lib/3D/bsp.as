#include "math3d.as"

class BSP
{
    Vec3 origin;
    Vec3 normal;

    array<Triangle@> up;
    array<Triangle@> down;

    BSP@ front_child;
    BSP@ back_child;

    BSP() {}

    BSP(Vec3 origin, Vec3 normal, array<Triangle@> up, array<Triangle@> down, BSP@ front_child, BSP@ back_child)
    {
        this.origin = origin;
        this.normal = normal;

        this.up = up;
        this.down = down;

        @this.front_child = front_child;
        @this.back_child = back_child;
    }

    array<Drawable@>@ draw_order(Vec3@ pos, array<Sprite@> sprites, array<Drawable@>& order = array<Drawable@>())
    {
        array<Sprite@> front_sprites, back_sprites;
        for (uint i = 0; i < sprites.size(); ++i)
            if ((sprites[i].pos - origin).dot(normal) > 0)
                front_sprites.insertLast(sprites[i]);
            else
                back_sprites.insertLast(sprites[i]);

        // TODO: Reduce the duplication here, either with variables for front/back,
        //       or by sorting all sprites in scene, so they don't need to be sorted here.
        if ((pos - origin).dot(normal) > 0)
        {
            if (back_child !is null) back_child.draw_order(pos, back_sprites, order);
            else
            {
                // sort by distance, furthest to closest
                uint n = back_sprites.size();
                while (n > 1)
                {
                    uint new_n = 0;
                    for (uint i = 0; i + 1 < n; ++i)
                        if ((back_sprites[i].pos - pos).magnitude_sqr() < (back_sprites[i + 1].pos - pos).magnitude_sqr())
                        {
                            Sprite@ t = back_sprites[i];
                            @back_sprites[i] = back_sprites[i + 1];
                            @back_sprites[i + 1] = t;
                            new_n = i;
                        }
                    n = new_n;
                }

                for (uint i = 0; i < back_sprites.size(); ++i)
                    order.insertLast(back_sprites[i]);
            }

            for (uint i = 0; i < up.size(); ++i)
                order.insertLast(up[i]);

            if (front_child !is null) front_child.draw_order(pos, front_sprites, order);
            else
            {
                // sort by distance, furthest to closest
                uint n = front_sprites.size();
                while (n > 1)
                {
                    uint new_n = 0;
                    for (uint i = 0; i + 1 < n; ++i)
                        if ((front_sprites[i].pos - pos).magnitude_sqr() < (front_sprites[i + 1].pos - pos).magnitude_sqr())
                        {
                            Sprite@ t = front_sprites[i];
                            @front_sprites[i] = front_sprites[i + 1];
                            @front_sprites[i + 1] = t;
                            new_n = i;
                        }
                    n = new_n;
                }

                for (uint i = 0; i < front_sprites.size(); ++i)
                    order.insertLast(front_sprites[i]);
            }
        }
        else
        {
            if (front_child !is null) front_child.draw_order(pos, front_sprites, order);
            else
            {
                // sort by distance, furthest to closest
                uint n = front_sprites.size();
                while (n > 1)
                {
                    uint new_n = 0;
                    for (uint i = 0; i + 1 < n; ++i)
                        if ((front_sprites[i].pos - pos).magnitude_sqr() < (front_sprites[i + 1].pos - pos).magnitude_sqr())
                        {
                            Sprite@ t = front_sprites[i];
                            @front_sprites[i] = front_sprites[i + 1];
                            @front_sprites[i + 1] = t;
                            new_n = i;
                        }
                    n = new_n;
                }

                for (uint i = 0; i < front_sprites.size(); ++i)
                    order.insertLast(front_sprites[i]);
            }

            for (uint i = 0; i < down.size(); ++i)
                order.insertLast(down[i]);

            if (back_child !is null) back_child.draw_order(pos, back_sprites, order);
            else
            {
                // sort by distance, furthest to closest
                uint n = back_sprites.size();
                while (n > 1)
                {
                    uint new_n = 0;
                    for (uint i = 0; i + 1 < n; ++i)
                        if ((back_sprites[i].pos - pos).magnitude_sqr() < (back_sprites[i + 1].pos - pos).magnitude_sqr())
                        {
                            Sprite@ t = back_sprites[i];
                            @back_sprites[i] = back_sprites[i + 1];
                            @back_sprites[i + 1] = t;
                            new_n = i;
                        }
                    n = new_n;
                }

                for (uint i = 0; i < back_sprites.size(); ++i)
                    order.insertLast(back_sprites[i]);
            }
        }
        return order;
    }

    int size() const
    {
        int total = 1;
        if (front_child !is null)
            total += front_child.size();
        if (back_child !is null)
            total += back_child.size();
        return total;
    }
}

/* Greedily create a BSP that has the fewest number of triangles remaining
 * after each split. Stores the indices of the triangles that are chosen as
 * pivots in `indices` and returns the resultant BSP.
 */
BSP@ optimise_bsp(array<Vec3>& vertices, array<Triangle@> triangles, array<uint>& indices = array<uint>())
{
    if (triangles.size() == 0)
        return null;

    uint best_count = 1e8;
    uint best_split;
    Vec3 best_origin, best_normal;
    for (uint split = 0; split < triangles.size(); ++split)
    {
        Triangle@ triangle = triangles[split];
        Vec3 origin = vertices[triangle.v1];
        Vec3 normal = (vertices[triangle.v2] - origin).cross(vertices[triangle.v3] - origin).normalised();

        uint front_count = 0;
        uint back_count = 0;

        for (uint i=0; i<triangles.size(); ++i)
        {
            if (i == split) continue;

            Vec3@ o1, o2, o3, o4, o5;
            switch (split_triangle(origin, normal, vertices[triangles[i].v1], vertices[triangles[i].v2], vertices[triangles[i].v3], o1, o2, o3, o4, o5))
            {
                case SplitResult::Inside:
                    break;
                case SplitResult::InFront:
                    front_count += 1;
                    break;
                case SplitResult::Behind:
                    back_count += 1;
                    break;
                case SplitResult::PointInFront:
                {
                    front_count += 1;
                    back_count += 2;
                    break;
                }
                case SplitResult::PointBehind:
                    front_count += 2;
                    back_count += 1;
                    break;
            }
        }

        uint count = max(front_count, back_count);
        if (count < best_count)
        {
            best_count = count;
            best_split = split;
            best_origin = origin;
            best_normal = normal;
        }
    }

    indices.insertLast(best_split);

    array<Triangle@> front, back, up, down;
    split_triangles(vertices, triangles, best_origin, best_normal, front, back, up, down);

    BSP@ front_child, back_child;
    if (front.size() > 0) @front_child = optimise_bsp(vertices, front, indices);
    if (back.size() > 0) @back_child = optimise_bsp(vertices, back, indices);

    return BSP(best_origin, best_normal, up, down, front_child, back_child);
}

/* Build a BSP with an optional list of indices of pivot triangles.
 * If no indices are provided then random pivots will be chosen.
 */
BSP@ build_bsp(array<Vec3>& vertices, array<Triangle@> triangles, array<uint>@ indices = null)
{
    uint split;
    if (indices !is null)
    {
        if (indices.size() > 0)
        {
            split = indices[0];
            indices.removeAt(0);
        }
        else
        {
            puts("WARNING: Missing indices when building BSP");
        }
    }
    else
    {
        split = rand() % triangles.size();
    }

    Triangle@ pivot = triangles[split];
    Vec3 origin = vertices[pivot.v1];
    Vec3 normal = (vertices[pivot.v2] - origin).cross(vertices[pivot.v3] - origin).normalised();

    array<Triangle@> front, back, up, down;
    split_triangles(vertices, triangles, origin, normal, front, back, up, down);

    BSP@ front_child, back_child;
    if (front.size() > 0) @front_child = build_bsp(vertices, front, indices);
    if (back.size() > 0) @back_child = build_bsp(vertices, back, indices);

    return BSP(origin, normal, up, down, front_child, back_child);
}

/* Split the given triangles along the plane passing through the triangle
 * triangles[split], creating new vertices if required. Partition the resultant
 * triangles into those that are in-front of and behind the pivot triangle.
 */
void split_triangles(array<Vec3>& vertices, array<Triangle@> triangles, Vec3 origin, Vec3 normal, array<Triangle@>& front, array<Triangle@>& back, array<Triangle@>& up, array<Triangle@>& down)
{
    for (uint i=0; i<triangles.size(); ++i)
    {
        Vec3@ o1, o2, o3, o4, o5;
        switch (split_triangle(origin, normal, vertices[triangles[i].v1], vertices[triangles[i].v2], vertices[triangles[i].v3], o1, o2, o3, o4, o5))
        {
            case SplitResult::Inside:
            {
                Vec3 new_origin = vertices[triangles[i].v1];
                Vec3 new_normal = (vertices[triangles[i].v2] - new_origin).cross(vertices[triangles[i].v3] - new_origin);
                if (new_normal.dot(normal) > 0)
                    up.insertLast(triangles[i]);
                else
                    down.insertLast(triangles[i]);
                break;
            }
            case SplitResult::InFront:
                front.insertLast(triangles[i]);
                break;
            case SplitResult::Behind:
                back.insertLast(triangles[i]);
                break;
            case SplitResult::PointInFront:
            {
                uint t = vertices.size();
                uint colour = triangles[i].colour;
                vertices.insertLast(o1);
                vertices.insertLast(o2);
                vertices.insertLast(o3);
                vertices.insertLast(o4);
                vertices.insertLast(o5);
                front.insertLast(Triangle(t, t + 1, t + 2, colour));
                back.insertLast(Triangle(t + 2, t + 1, t + 3, colour));
                back.insertLast(Triangle(t + 3, t + 4, t + 2, colour));
                break;
            }
            case SplitResult::PointBehind:
            {
                uint t = vertices.size();
                uint colour = triangles[i].colour;
                vertices.insertLast(o1);
                vertices.insertLast(o2);
                vertices.insertLast(o3);
                vertices.insertLast(o4);
                vertices.insertLast(o5);
                back.insertLast(Triangle(t, t + 1, t + 2, colour));
                front.insertLast(Triangle(t + 2, t + 1, t + 3, colour));
                front.insertLast(Triangle(t + 3, t + 4, t + 2, colour));
                break;
            }
        }
    }
}
